import Vue from 'vue';
import VueI18n from 'vue-i18n';
import { locale as Locale } from 'view-design';
import customZhCn from './lang/zh-CN';
// import customZhTw from './lang/zh-TW';
// import customEnUs from './lang/en-US';
import zhCN from 'view-design/src/locale/lang/zh-CN';
// import enUS from 'view-design/src/locale/lang/en-US';
// import zhTwLocale from 'iview/src/locale/lang/zh-TW';
import { getLocalStorageWithPrefix, setLocalStorageWithPrefix } from '@/utils/util';
import { getQueryFromURL } from '@/utils/tools';
Vue.use(VueI18n);

// 自动根据浏览器系统语言设置语言
const query = getQueryFromURL(window.location.href); // 在sso登录成功后带过来的语言代码lang
const ssoLang = query.lang ? query.lang : null;
const navLang = navigator.language;
const lang = ssoLang || getLocalStorageWithPrefix('lang') || navLang || 'zh-CN'; // 默认中文

// vue-i18n 6.x+写法
const messages = {
  'zh-CN': Object.assign(zhCN, customZhCn)
  // 'en-US': Object.assign(enUS, customEnUs)
};

// 生成一个新的i18n对象，locale 默认为 en-US
const i18n = new VueI18n({
  messages
});

// 为 i18n 的绑定切换语言的方法
i18n.setLocale = locale => {
  locale = 'zh-CN';
  Vue.config.lang = locale;
  i18n.locale = locale;
  setLocalStorageWithPrefix('lang', locale); // 保存到本地存储localStorage

  // 往 vant-ui 组件的 $vantMessages 中注入语言对象，通过改变 $vantLang 来改变切换组件多语言
  Locale(messages[locale]); // 切换组件的语言

  window.document.title = i18n.t('APP_TITLE'); // 设置网页Title
};

// 将语言代码转化为标准的语言代码，目前只支持中英文
const formatLangCode = lang => {
  return /^en/.test(lang) ? 'en-US' : 'zh-CN';
};

// 初始化语言配置
i18n.setLocale(formatLangCode(lang));

export default i18n;

// vue-i18n 5.x写法
// Vue.locale('zh-CN', Object.assign(zhCnLocale, customZhCn))
// Vue.locale('en-US', Object.assign(zhTwLocale, customZhTw))
// Vue.locale('zh-TW', Object.assign(enUsLocale, customEnUs))
