export default {
  APP_TITLE: 'Royole Vue Admin Template',

  'route.user_authority': 'User Authority',
  'route.user_authority.user': 'User',
  'route.user_authority.authority': 'Authority'
};
