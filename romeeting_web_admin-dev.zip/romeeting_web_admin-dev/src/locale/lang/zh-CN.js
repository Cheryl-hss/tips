export default {
  APP_TITLE: 'RoMeeting后台管理系统',
  // home: '首页',
  // 顶部导航栏
  ro_meeting: 'RoMeeting',
  meeting: '会议',
  call: '呼叫服务',
  me: '个人中心',

  // 登录页面
  ro_meeting_title: '柔宇智能铭牌会议系统',
  ro_meeting_login: '登录',
  auto_login: '自动登录',
  help: '帮助',
  privacy: '隐私',
  provision: '条款',
  copyright: 'copyright © 2020 深圳市柔宇科技股份有限公司出品',
  meeting_domain_setting: '域名配置',
  meeting_domain_input: '请输入本单位正确域名完成配置',

  // 会议列表item的状态
  status_info_waiting: '待开始',
  status_info_completed: '已结束',
  status_info_expired: '未开始就过期',
  status_info_doing: '进行中',

  meeting_list: '',
  meeting_end_list: '历史会议',
  meeting_add: '创建会议',
  meeting_edit: '编辑会议',
  meeting_detail: '会议详情',

  // 会议互动
  meeting_sign_in: '会议签到：',
  meeting_a_sign_in: '发起签到',
  meeting_status: '铭牌状态',
  meeting_conference: '会议资料',
  meeting_sign: '签到',

  // 会议列表item信息
  meeting_card_info_item_time: '时间：',
  meeting_card_info_item_connect: '连接：',
  meeting_card_info_item_status: '状态：',

  // 会议查询按钮
  title_bar_all: '全部',
  title_bar_waiting: '待开始',
  title_bar_doing: '进行中',
  title_bar_completed: '已结束',

  // 新增会议表单
  meeting_name: '会议名称：',
  meeting_date: '日期：',
  meeting_start_date: '会议日期',
  meeting_time: '时间：',
  meeting_start_time: '开始时间',
  meeting_end_time: '结束时间',
  meeting_name_setting: '名字设置',
  meeting_default_device_name: '显示铭牌默认名',
  meeting_host: '主持人：',
  meeting_bulk_import: '批量导入',
  meeting_bulk_import_devices: '批量导入铭牌',
  meeting_bulk_import_persons: '批量导入联系人',
  meeting_appointed_presenter: '指定主持人',
  meeting_select_logo: '选择logo',
  meeting_table_name: '姓名',
  meeting_table_company: '公司',
  meeting_table_logo: 'Logo',
  meeting_table_position: '职位',
  meeting_table_device: '使用铭牌',
  meeting_table_status: '状态/电量',
  meeting_table_status_tips: '预估电量，仅供参考',
  meeting_table_remark: '备注',
  meeitng_table_action: '操作',
  meeting_table_add: '添加参会人',
  meeting_table_save: '保存',
  meeting_table_cancel: '取消',
  meeting_table_submit: '添加',
  meeting_device_style_setting: '铭牌样式',
  meeting_device_wallpaper: '壁纸：',
  meeting_device_wallpaper_change: '更换壁纸',
  meeting_device_logo_position: 'Logo位置：',
  meeting_device_logo_size: 'Logo尺寸：',
  meeting_device_font: '字体：',
  meeting_device_font_color: '字色：',
  meeting_device_font_action: '动效：',
  meeting_content: '会议内容',
  meeting_agenda: '会议议程：',
  meeting_documents: '会议资料：',
  meeting_keywords: '提词：',
  meeting_vote: '会议投票：',
  meeting_content_upload_pdf: '上传PDF',
  meeting_content_upload_file: '上传文件',
  meeting_content_upload_mp4: '上传视频',
  meeting_agenda_tips: '支持扩展名：pdf、jpg、png',
  meeting_documents_tips: '支持扩展名：pdf、jpg、png、mp4',
  meeting_keywords_add: '新增提词',
  meeting_vote_add: '新建投票',
  meeting_add_meeting: '立即推送',
  meeting_edit_meeting: '保存并推送',
  meeting_add_save: '保存',
  meeting_add_cancle: '取消',
  meeting_add_delete: '删除',
  no_history_meeting: '暂无历史会议',
  meeting_same_screen: '同屏',
  meeting_delete: '删除',
  // 已结束会议
  metting_finished: '已结束会议',
  metting_end_to_home: '返回首页',
  metting_end_shutdown: '批量关机',

  // 个人中心
  me_title: '个人中心',
  me_device_binding: '终端维护',
  me_attendee: '常用参会人',
  me_account_security: '账号与安全',

  // 个人中心-帮助

  me_help: '帮助',
  me_help_about_us: '关于我们',
  me_help_about_us_desc:
    'RoMeeting是基于私有云建设的智能会议系统。可稳定支持多台智能会议终端同时使用，支持名字设置，会议议程、会议资料一键推送，多议题投票，呼叫服务等功能，既满足客户基础功能使用，又保证使用过程中数据安全。',
  me_help_about_us_version: '版本：V1.0.0',
  me_help_about_us_update: '为了数据安全，智能会议系统（私有云）提供以下两种方式进行升级',
  // me_help_about_us_update_by_self:
  //   '1、自主升级。访问{link}检查是否有新的软件版本，下载新的软件压缩包后，点击此处{upload}进行升级。',
  me_help_about_us_update_by_self_left: '1、自主升级。连接外部网络，点击',
  me_help_about_us_update_by_self_link: '版本升级',
  me_help_about_us_update_by_self_center: '检查是否有新的软件版本，下载新的软件压缩包后，点击此处',
  me_help_about_us_update_by_self_upload: '上传升级包',
  me_help_about_us_update_by_self_right: '进行升级。（适用于可连接外部网络用户）',
  // me_help_about_us_update_by_hand:
  //   '2、售后升级。联系我司售后，获取最新版本软件压缩包，点击此处{upload}进行升级。',
  me_help_about_us_update_by_hand_left:
    '2、售后升级。联系我司售后，获取最新版本软件压缩包，点击此处',
  me_help_about_us_update_by_hand_right: '进行升级。（适用于所有用户）',
  me_help_document: '帮助文档',
  me_help_issues: '报告问题',
  me_help_issues_p1: '使用过程中，如遇到问题或者更好的建议，请通过售后人员与我们沟通。',
  me_help_issues_p2:
    '为了更快速解决问题，请点击此处{log}，辅助售后解决问题。错误日志只包含软件自身运行数据，不包含会议内容，可放心使用。',
  me_help_issues_p2_log: '获取错误日志',

  // 个人中心-设备绑定
  device_table_index: '序号',
  device_table_mac: 'mac地址',
  device_table_default_name: '默认名',
  device_table_name: '备注名',
  device_table_software_version: '软件版本',
  device_table_system_version: '系统版本',
  device_table_action: '操作',
  device_table_log: '设备日志',

  // 个人中心-常用参会人
  attendee_table_index: '序号',
  attendee_table_name: '姓名',
  attendee_table_company: '公司',
  attendee_table_logo: 'Logo',
  attendee_table_position: '职位',
  attendee_table_action: '操作',

  // 个人中心-账户与安全
  account_setting_host: '配置域名',
  account_table_index: '序号',
  account_table_account: '账号',
  account_table_password: '密码',
  account_table_role: '角色',
  account_table_action: '操作',
  account_table_binding: '第三方通知',
  account_table_cell_phone_number: '手机号',

  // 呼叫服务-设置
  call_setting_web: 'Web端',
  call_setting_device: '铭牌端',
  call_fast_reply: '快捷回复',
  call_fast_directive: '快捷指令',
  call_add: '新增',
  call_fast_reply_web_clear: '会议结束后，清空呼叫服务内容',
  call_fast_reply_devive: '铭牌端呼叫服务消息弹窗',
  call_fast_reply_devive_close: '关闭'
};
