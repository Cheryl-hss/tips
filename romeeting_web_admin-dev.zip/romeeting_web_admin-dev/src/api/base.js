import axios from '@/utils/api.request';
import qs from 'qs'; // post接口的 'Content-Type'为'application/x-www-form-urlencoded' 使用 qs 格式化 data

export default class API {
  constructor(api) {
    this.api = api;
  }

  /**
   * @description 获取列表（分页）
   * @param {{pageNum:Number, pageSize:Number, keyword:String, [propName: string]: any}} params { pageNum 页码, pageSize 页大小, keyword 搜索关键字 }
   * @returns {{ url:String, method:String, fetch:Function }} { url, method, fetch }
   */
  getList(params = {}) {
    const query = qs.stringify(params); // 查询字符串
    const url = this.api + (query ? `?${query}` : '');
    const method = 'get';
    const fetch = () => axios.request({ url, method });

    return { url, method, fetch };
  }

  /**
   * @description 获取详情
   * @param {String|Number} id ID
   * @returns {{ url:String, method:String, fetch:Function }} { url, method, fetch }
   */
  getDetail(id) {
    const url = `${this.api}/${id}`;
    const method = 'get';
    const fetch = () => axios.request({ url, method });

    return { url, method, fetch };
  }

  /**
   * @description 新增
   * @param {Object} data
   * @returns {{ url:String, method:String, fetch:Function }} { url, method, fetch }
   */
  add(data) {
    const url = this.api;
    const method = 'post';
    const fetch = () => axios.request({ url, method, data });

    return { url, method, fetch };
  }

  /**
   * @description 删除
   * @param {String|Number} id ID
   * @returns {{ url:String, method:String, fetch:Function }} { url, method, fetch }
   */
  delete(id) {
    const url = `${this.api}/${id}`;
    const method = 'delete';
    const fetch = () => axios.request({ url, method });

    return { url, method, fetch };
  }

  /**
   * @description 编辑
   * @param {Object} data
   * @returns {{ url:String, method:String, fetch:Function }} { url, method, fetch }
   */
  modify(id, data) {
    const url = `${this.api}/${id}`;
    const method = 'put';
    const fetch = () => axios.request({ url, method, data });

    return { url, method, fetch };
  }

  /**
   * @description 排序
   * @param {Array<{id:Number, order:Number}>} data
   * @returns {{ url:String, method:String, fetch:Function }} { url, method, fetch }
   */
  sort(data) {
    const url = `${this.api}/order`;
    const method = 'put';
    const fetch = () => axios.request({ url, method, data });

    return { url, method, fetch };
  }

  /**
   * @description 导出excel
   * @param {{pageNum:Number, pageSize:Number, keyword:String, [propName: string]: any}} params { pageNum 页码, pageSize 页大小, keyword 搜索关键字 }
   * @returns {{ url:String, method:String, fetch:Function }} { url, method, fetch }
   */
  getExcel(params = {}) {
    const query = qs.stringify(params); // 查询字符串
    const url = `${this.api}/excel` + (query ? `?${query}` : '');
    const method = 'get';
    const fetch = () => axios.request({ url, method });

    return { url, method, fetch };
  }
}
