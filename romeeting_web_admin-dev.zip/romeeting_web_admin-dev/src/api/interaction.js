import axios from '@/utils/api.request';

const syncShow = data => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/sync`;
  const method = `post`;
  const headers = {
    appId: 'zwz3vdA7IJ',
    token: JSON.parse(localStorage.getItem('userInfo')).token
  };
  const fetch = () => axios.request({ url, method, headers, data });

  return { url, method, fetch };
};
/**
 * @description 查看签到结果
 * @param {String} meetingId
 */
const meetingSign = meetingId => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}/checkin`;
  const method = `get`;
  const fetch = () => axios.request({ url, method });
  return { url, method, fetch };
};
/**
 * @description 发起签到
 * @param {Object} data {meetingId,deadline}
 */
const initiateSignin = (meetingId, deadline) => {
  const url = `/iot/meeting/${
    process.env.VUE_APP_VERSION
  }/meetings/${meetingId}/checkin/${deadline}`;
  const method = `post`;
  const fetch = () => axios.request({ url, method });
  return { url, method, fetch };
};
/**
 * @description 结束签到
 * @param {String} meetingId
 */
const endSignIn = meetingId => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}/checkin/end`;
  const method = `post`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 新建投票
 * @param {String} meetingId
 * @param {Object} data {title,anonymous}
 */
// const meetingVotes = (meetingId, data) => {
//   const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}/votes`;
//   const method = `post`;
//   const fetch = () => axios.request({ url, method, data });
//   return { url, method, fetch };
// };
/**
 * @description 发布投票
 * @param {String} voteId
 */
const releaseVote = (meetingId, voteId) => {
  const url = `/iot/meeting/${
    process.env.VUE_APP_VERSION
  }/meetings/${meetingId}/votes/${voteId}/publish`;
  const method = `post`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description
 * @param {String, Boolean} vote
 */
const newVote = (meetingId, data) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}/votes`;
  const method = `post`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

/**
 * @description 结束投票
 * @param {Long} voteId
 */
const endVote = (meetingId, voteId) => {
  const url = `/iot/meeting/${
    process.env.VUE_APP_VERSION
  }/meetings/${meetingId}/votes/${voteId}/end`;
  const method = `post`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 集中控制(显示主页，关机，锁屏)
 * @param {String} meetingId
 * @param {Object} params
 */
const onCenterControl = (meetingId, data) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}/control`;
  const method = `post`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

const getPDFUrl = resourceId => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/pdf/resources/${resourceId}`;
  const method = `get`;
  const user = JSON.parse(localStorage.getItem('userInfo'));
  const headers = {
    userId: user.userId,
    appId: 'zwz3vdA7IJ',
    token: user.token
  };
  const fetch = () => axios.request({ url, method, headers });

  return { url, method, fetch };
};
/**
 * @description 删除投票
 * @param {String} command
 * @param {String} voteId
 */
const deleteVote = (meetingId, voteId) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}/votes/${voteId}`;
  const method = `delete`;
  const fetch = () => axios.request({ url, method });
  return { url, method, fetch };
};
/**
 * @description 修改投票
 * @param {String}meetingId
 * @param {String} voteId
 * @param {Object} data {title,anonymous}
 */
const modifyVote = (meetingId, voteId, data) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}/votes/${voteId}`;
  const method = `put`;
  const fetch = () => axios.request({ url, method, data });
  return { url, method, fetch };
};
export default {
  getPDFUrl,
  endVote,
  newVote,
  initiateSignin,
  endSignIn,
  releaseVote,
  // meetingVotes,
  meetingSign,
  syncShow,
  onCenterControl,
  deleteVote,
  modifyVote
};
