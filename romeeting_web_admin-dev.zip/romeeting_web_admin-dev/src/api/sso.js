import axios from '@/utils/api.request';

/**
 * @description 获取登录用户权限列表
 * @returns {{ url:String, method:String, fetch:Function }} { url, method, fetch }
 */
const getUserPermission = () => {
  const url = '/ssoSystem/getUserPermission';
  const method = 'get';
  const mockURL = new RegExp('/ssoSystem/getUserPermission');
  const fetch = () => axios.request({ url, method });

  return { url, method, mockURL, fetch };
};

/**
 * @description 注销当前用户
 * @returns {{ url:String, method:String, fetch:Function }} { url, method, fetch }
 */
const logout = () => {
  const url = '/ssoSystem/logout';
  const method = 'post';
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

export default {
  getUserPermission,
  logout
};
