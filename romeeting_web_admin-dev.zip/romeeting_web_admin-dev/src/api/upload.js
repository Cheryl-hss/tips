import axios from '@/utils/api.request';

import Buffer from 'buffer';
// import SHAjs from 'sha.js';
import MD5js from 'md5.js';

/**
 * @description 获取md5值和资源key
 * @param {String} objectName
 * @param {String} contentMD5
 * @param {String} contentSHA256
 * @returns { url, method, fetch }
 */
const authPut = (objectName, contentMD5) => {
  const url = `/iot/auth/${process.env.VUE_APP_VERSION}/oss/auth-put`;
  const method = `post`;
  const data = {
    objectName,
    contentMD5
  };
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

/**
 * @description 向 OSS 上传文件
 * @param {File} file 上传的文件
 * @param {Function} onProgress 上传进度回调
 * @returns { key, md5 }
 */
const uploadToOSS = (file, onProgress) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsArrayBuffer(file);
    // const sha256 = SHAjs('sha256');
    const md5 = new MD5js();
    reader.onload = e => {
      const data = e.target.result;

      const contentMD5 = md5.update(Buffer.Buffer.from(data)).digest('base64');
      // const contentSHA256 = sha256.update(Buffer.Buffer.from(data)).digest('hex');

      authPut(contentMD5, contentMD5)
        .fetch()
        .then(response => {
          const headers = response.data;
          if (response.data.exist) {
            resolve({
              key: response.data.objectKey,
              md5: headers['Content-MD5'],
              exist: response.data.exist
            });
            return;
          }
          // 上传资源
          axios
            .request({
              baseURL: headers.baseUrl, // oss server 的 base_url
              url: headers.url,
              method: headers.method,
              headers: {
                Authorization: headers['Authorization'],
                'x-amz-date': headers['x-amz-date'],
                'x-amz-content-sha256': headers['x-amz-content-sha256'],
                'Content-MD5': headers['Content-MD5'],
                // Host: headers['Host'],
                'Content-Type': file.type
              },
              data: file,
              onUploadProgress: onProgress
            })
            .then(() => resolve({ key: headers.objectKey, md5: headers['Content-MD5'] }))
            .catch(err => reject(err));
        });
    };
  });
};

/**
 * @description 创建单个OSS资源记录
 * @param {*} userId
 * @param {Object} data { fileKey, name, size, desc, md5, fileType }
 * @returns
 */
const addOssResourse = (userId, data) => {
  const url = `/iot/resource/${process.env.VUE_APP_VERSION}/oss/solo`;
  const method = `post`;
  const headers = {
    userId,
    appId: 'zwz3vdA7IJ',
    token: JSON.parse(localStorage.getItem('userInfo')).token
  };
  const fetch = () => axios.request({ url, method, headers, data });

  return { url, method, fetch };
};

// 获取OSS临时下载资源
const getOssResourse = (userId, params) => {
  const url = `/iot/resource/oss/url`;
  const method = `get`;
  const headers = {
    userId,
    appId: 'zwz3vdA7IJ',
    token: JSON.parse(localStorage.getItem('userInfo')).token
  };
  const fetch = () => axios.request({ url, method, headers, params });

  return { url, method, fetch };
};

// 获取默认壁纸
const getDefaultResourses = (type, params) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/default/resources/${type}`;
  const method = `get`;
  const fetch = () => axios.request({ url, method, params });

  return { url, method, fetch };
};

// 保存我的壁纸为默认资源
const saveCustomResourses = data => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/default/resources`;
  const method = `post`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

// 删除我的壁纸
const deleteCustomResourses = resourceId => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/default/resources/${resourceId}`;
  const method = `delete`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 获取视频资源快照下载地址
 * @param {Number} resourceId
 * @returns {Object} { url, method, fetch }
 */
const getScreenshot = resourceId => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/screenshot/resources/${resourceId}`;
  const method = `get`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 获取系统版本信息
 * @returns { url, method, fetch }
 */
const getUpgradeVersion = () => {
  const url = `/iot/upgrade/${process.env.VUE_APP_VERSION}/version`;
  const method = `get`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 发布升级包
 * @param {Object} data
 * @returns { url, method, fetch }
 */
const upgrade = data => {
  const url = `/iot/upgrade/${process.env.VUE_APP_VERSION}/upgrades`;
  const method = `post`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

/**
 * @description 获取日志下载Key
 * @returns  { url, method, fetch }
 */
const getLogsKey = identifier => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/logs/${identifier}`;
  const method = `get`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 检查设备是否有升级包
 * @param {*} params {region} 传参
 * @returns { url, method, fetch }
 */
const checkUpgradeInfo = params => {
  const url = `/iot/ota/${process.env.VUE_APP_VERSION}/upgrade/check`;
  const method = `get`;
  const fetch = () => axios.request({ url, method, params });
  return { url, method, fetch };
};

/**
 * @description 设备升级
 * @param {Object} data
 * @returns { url, method, fetch }
 */
const upgradeAll = data => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/devices/upgrade`;
  const method = `post`;
  const fetch = () => axios.request({ url, method, data });
  return { url, method, fetch };
};

/**
 * @description
 * @returns { url, method, fetch }
 */
const getExcelPerson = resourceId => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/excelperson/${resourceId}`;
  const method = `get`;
  const fetch = () => axios.request({ url, method });
  return { url, method, fetch };
};

export {
  authPut,
  uploadToOSS,
  addOssResourse,
  getOssResourse,
  getDefaultResourses,
  saveCustomResourses,
  deleteCustomResourses,
  getScreenshot,
  getUpgradeVersion,
  upgrade,
  getLogsKey,
  checkUpgradeInfo,
  upgradeAll,
  getExcelPerson
};
