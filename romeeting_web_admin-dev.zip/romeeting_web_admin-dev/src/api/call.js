import axios from '@/utils/api.request';

/**
 * @description 获取呼叫信息列表
 * @param {Long} meetingId
 */
const getChats = meetingId => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/chats/meetings/${meetingId}`;
  const method = `get`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 获取呼叫会议列表
 */
const getMeetings = () => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/chats/meetings`;
  const method = `get`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 获取未读消息列表
 */
const getUnreadChats = () => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/chats/unread`;
  const method = `get`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 获取呼叫常用语列表
 * @param {Object} params { wordFlag } 常用语的标志（web:web端快捷回复常用语，device:铭牌端回复常用语）
 * @returns { url, method, fecth }
 */
const getFastReplyList = params => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/chat/commonwords`;
  const method = `get`;
  const fetch = () => axios.request({ url, method, params });

  return { url, method, fetch };
};

/**
 * @description 提交呼叫常用语数据
 * @param {Object} data {controlFlag, wordFlag, webCommonWords}
 * @param {String} controlFlag 控制呼叫消息显示标识（CLEAR-WEB端会议结束后清空消息内容，CLOSE-铭牌端手动关闭消息，COUNTDOWN+N-铭牌端根据时间进行自动关闭消息）
 * @param {String} wordFlag 常用语的标志（web:web端快捷回复常用语，device:铭牌端回复常用语）
 * @param {Array} webCommonWords {iconId(图标id),commonWord(常用语)}
 * @returns { url, method, fecth }
 */
const submitFastReply = data => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/chat/commonwords`;
  const method = `post`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

export default { getChats, getMeetings, getUnreadChats, getFastReplyList, submitFastReply };
