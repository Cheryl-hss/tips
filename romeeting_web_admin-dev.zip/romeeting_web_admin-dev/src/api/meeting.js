import axios from '@/utils/api.request';

/**
 * @description 获取会议列表
 */
const getMeetingList = params => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings`;
  const method = `get`;
  const fetch = () => axios.request({ url, method, params });
  return { url, method, fetch };
};

/**
 * @description 查看会议详情
 * @param {String} meetingId
 */
const getMeetingDetail = meetingId => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}`;
  const method = `get`;
  const fetch = () => axios.request({ url, method });
  return { url, method, fetch };
};

/**
 * @description 预约会议
 * @param {Object} data { name, startTime, endTime, password, devices, votings, resources, style  }
 */
const addMeeting = data => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings`;
  const method = `post`;
  const userInfo = JSON.parse(localStorage.getItem('userInfo'));
  const headers = {
    appId: 'zwz3vdA7IJ',
    token: userInfo && userInfo.token,
    requestId: (data && data.requestId) || ''
  };
  const fetch = () => axios.request({ url, method, headers, data });

  return { url, method, fetch };
};

/**
 * @description 修改会议设备配置(包括修改主持会议的设备)
 * @param {String} meetingId
 * @param {String} id
 * @param {Object} data
 */
const alterDeviceToMeeting = (meetingId, id, data) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/${meetingId}/mdevice/${id}`;
  const method = `post`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

/**
 * @description 开始会议
 * @param {String} meetingId
 */
const startMeeting = meetingId => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}/start`;
  const method = `post`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 结束会议
 * @param {String} meetingId
 */
const stopMeeting = meetingId => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}/end`;
  const method = `post`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 设置会议编辑状态
 * @param {String} meetingId
 * @param {Boolean} editing  编辑时要设置状态为true， 取消时设置状态为false
 */
const alterMeetingEditType = (meetingId, editing) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}/${editing}`;
  const method = `put`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 修改会议信息
 * @param {String} meetingId
 * @param {Object} data {comment: String} 备注
 */
const alterMeeting = (meetingId, data) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meeting/${meetingId}`;
  const method = `put`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

/**
 * @description 集中控制(显示主页，关机，锁屏)
 * @param {String} meetingId
 * @param {Object} params
 */
const onCenterControl = (meetingId, data) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}/control`;
  const method = `post`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

/**
 * @description 设备控制(设备端显示设备默认名)
 * @param {String} command
 * @param {Object} params
 */
const onDeviceControl = (command, data) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/control/${command}`;
  const method = `post`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

/**
 * @description 删除会议记录
 * @param {String} meetingId
 */
const deleteMeeting = meetingId => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}`;
  const method = `delete`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 保存会议资源记录
 * @param {Object} data { fileKey, name, size, desc, md5, fileType }
 * @returns
 */
const saveResourse = (userId, data) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/resources`;
  const method = `post`;
  const headers = {
    userId,
    appId: 'zwz3vdA7IJ',
    token: JSON.parse(localStorage.getItem('userInfo')).token
  };
  const fetch = () => axios.request({ url, method, headers, data });

  return { url, method, fetch };
};
/**
 * @description 设置会议主持人
 * @param {Object} meetingIdnpm -g install npm
 * @param {Object} personId
 * @returns
 */
const changeHost = (meetingId, personId) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/meetings/${meetingId}/host/${personId}`;
  const method = `put`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

export default {
  getMeetingList,
  getMeetingDetail,
  addMeeting,
  alterDeviceToMeeting,
  startMeeting,
  stopMeeting,
  alterMeetingEditType,
  alterMeeting,
  onCenterControl,
  onDeviceControl,
  deleteMeeting,
  saveResourse,
  changeHost
};
