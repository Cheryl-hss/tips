import axios from '@/utils/api.request';
/**
 * @description 新增手机号
 * @param {Object} data { phone uid }
 */
const newMobilePhoneNumber = data => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/modification`;
  const method = `put`;

  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};
/**
 * @description 绑定钉钉/微信
 * @param {String} mobile
 * @param {String} thirdpartflag
 */
const binDing = params => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/bind`;
  const method = `post`;
  const fetch = () => axios.request({ url, method, params });
  return { url, method, fetch };
};
/**
 * @description 查询钉钉/微信/飞书信息
 */
const getQuerydata = () => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/configs/thirdpart`;
  const method = `get`;
  const fetch = () => axios.request({ url, method });
  return { url, method, fetch };
};
/**
 * @description 新增或者修改钉钉/微信/飞书信息
 * @param {Object} data
 */
const addAndmodify = data => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/configs/thirdpart`;
  const method = `post`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

export default {
  newMobilePhoneNumber,
  binDing,
  getQuerydata,
  addAndmodify
};
