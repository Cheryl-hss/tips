import axios from '@/utils/api.request';

/**
 * @description 查询设备列表
 * @param {Object} params {usable} 设备是否可用
 */
const getAttendeeList = params => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/persons`;
  const method = `get`;
  const fetch = () => axios.request({ url, method, params });
  return { url, method, fetch };
};

/**
 * @description 查询设备列表
 * @param {Object} params {usable} 设备是否可用
 */
const getDeviceList = params => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/devices`;
  const method = `get`;
  const fetch = () => axios.request({ url, method, params });
  return { url, method, fetch };
};

/**
 * @description 新建参会人
 * @param {Object} data { name, company, position, logo }
 */
const addAttendee = data => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/persons`;
  const method = `post`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

/**
 * @description 修改参会人
 * @param {Object} data { id, name, company, position, logo }
 */
const alterAttendee = data => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/persons`;
  const method = `put`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

/**
 * @description 删除参会人
 * @param {Object} id 参会人id
 */
const deleteAttendee = id => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/persons/${id}`;
  const method = `delete`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 新增会议设备
 * @param {String} meetingId
 * @param {Object} data
 */
const addDevice = (meetingId, data) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/${meetingId}/mdevice`;
  const method = `post`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

/**
 * @description 修改设备名称
 * @param {Object} data {devId: string, devName: string}
 */
const alterDeviceName = data => {
  const url = `/iot/device/${process.env.VUE_APP_VERSION}/devices`;
  const method = `put`;
  const fetch = () => axios.request({ url, method, data });

  return { url, method, fetch };
};

/**
 * @description 删除设备
 * @param {String} id
 */
const deleteDevice = id => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/mdevice/${id}`;
  const method = `delete`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

/**
 * @description 获取某台设备的在线状态
 * @param {String} devId
 * @returns { url, method, fetch } 0-离线，1-在线，2-未知
 */
const getDeviceStatus = devId => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/onlineinfo/${devId}`;
  const method = `get`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

export default {
  getAttendeeList,
  getDeviceList,
  addAttendee,
  alterAttendee,
  deleteAttendee,
  addDevice,
  alterDeviceName,
  deleteDevice,
  getDeviceStatus
};
