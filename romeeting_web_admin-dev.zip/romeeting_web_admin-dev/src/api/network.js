const INTERVAL = 300; // ms
/**
 * @description 请求下载网络速度 get http://10.0.100.84:8296/iot/meeting/v1/bps/download
 */
const networkTest = (dSpeeds, uSpeed, COUNT) => {
  var count = COUNT || 15;
  var lastTime, startTime, endTime;
  var xhr = new XMLHttpRequest();
  // download test
  xhr.open('get', `/iot/meeting/${process.env.VUE_APP_VERSION}/bps/download`);
  xhr.onprogress = progress => {
    endTime = Date.now();
    if (!lastTime) {
      startTime = endTime;
      lastTime = startTime;
    }
    const iv = endTime - lastTime;
    if (iv >= INTERVAL && count > 0) {
      const bps = Math.floor((progress.loaded / (endTime - startTime)) * 1000);
      dSpeeds.push(bps);
      lastTime = endTime;
      count--;
    }
    if (count === 0) {
      xhr.abort();
      // upload test
      uSpeed && uploadTest(xhr, uSpeed, COUNT);
    }
  };
  xhr.send();
  return xhr;
};
/**
 * @description 请求上传网络速度 get http://10.0.100.84:8296/iot/meeting/v1/bps/upload
 */
const uploadTest = (xhr, speeds, COUNT) => {
  var count = COUNT || 15;
  const chunkSize = 16 * 1024 * 1024; // 16MB
  const chunk = new ArrayBuffer(chunkSize);
  var uploadTotal = 0;
  sendTest(xhr, speeds, count, chunk, Date.now(), Date.now(), uploadTotal);
  return xhr;
};

function sendTest(xhr, speeds, count, chunk, startTime, lastTime, uploadTotal) {
  // var lastTime = startTime;
  xhr.onload = () => {
    if (count === 0) {
      return;
    }
    sendTest(xhr, speeds, count, chunk, startTime, lastTime, uploadTotal);
  };
  xhr.upload.onprogress = progress => {
    var endTime = Date.now();
    if (endTime - lastTime >= INTERVAL) {
      const bps = Math.floor(((uploadTotal + progress.loaded) / (endTime - startTime)) * 1000);
      speeds.push(bps);
      count--;
      lastTime = endTime;
    }
    if (count === 0) {
      xhr.abort();
      return;
    }
    if (progress.loaded === progress.total) {
      uploadTotal += progress.total;
    }
  };
  sendTestData(xhr, chunk);
}

function sendTestData(xhr, chunk) {
  xhr.open('post', `/iot/meeting/${process.env.VUE_APP_VERSION}/bps/upload`, true);
  // 发送数据
  xhr.send(new Blob([chunk]));
}

export default {
  networkTest
};
