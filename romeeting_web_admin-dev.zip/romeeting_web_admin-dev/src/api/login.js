import axios from '@/utils/api.request';
import qs from 'qs';

/**
 * @description 登录
 * @param {Object} { username, password }
 * @returns {{ url:String, method:String, fetch:Function }} { url, method, fetch }
 */
const login = (appId, { username, password } = {}) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/login`;
  const method = `post`;
  const headers = { appId, 'Content-Type': 'application/x-www-form-urlencoded' };
  const data = qs.stringify({ username, password });

  const fetch = () => axios.request({ url, method, headers, data });

  return { url, method, fetch };
};

/**
 * @description 退出登录
 * @param {Object} { username, password }
 * @returns {{ url:String, method:String, fetch:Function }} { url, method, fetch }
 */
const logout = (appId, token) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/logout`;
  const method = `post`;
  const headers = { appId, token, 'Content-Type': 'application/x-www-form-urlencoded' };

  const fetch = () => axios.request({ url, method, headers });

  return { url, method, fetch };
};

/**
 * @description 获取用户信息
 * @param {String} appId
 */
const getUserInfo = (appId, token) => {
  // user
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/info`;
  const method = `get`;
  const headers = { appId, token, 'Content-Type': 'application/x-www-form-urlencoded' };

  const fetch = () => axios.request({ url, method, headers });

  return { url, method, fetch };
};

const getAccountList = () => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/users`;
  const method = `get`;

  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};
const createAccount = params => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/register`;
  const method = `post`;
  const headers = {
    'Content-Type': 'application/x-www-form-urlencoded',
    userId: JSON.parse(localStorage.getItem('userInfo')).userId,
    appId: 'zwz3vdA7IJ',
    token: JSON.parse(localStorage.getItem('userInfo')).token
  };
  const data = qs.stringify(params);
  const fetch = () => axios.request({ url, method, headers, data });
  return { url, method, fetch };
};
// 修改密码
const modifyPwd = (params, modifyUserId) => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/modifypwd/${modifyUserId}`;
  const method = `post`;
  const headers = {
    'Content-Type': 'application/x-www-form-urlencoded',
    userId: JSON.parse(localStorage.getItem('userInfo')).userId,
    appId: 'zwz3vdA7IJ',
    token: JSON.parse(localStorage.getItem('userInfo')).token
  };
  const data = qs.stringify(params);
  const fetch = () => axios.request({ url, method, headers, data });
  return { url, method, fetch };
};

// 删除子用户
const deleteAccount = userId => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/deleteuser/${userId}`;
  const method = `delete`;
  const fetch = () => axios.request({ url, method });
  return { url, method, fetch };
};

// // 获取账号权限
// const meetingAccountLogin = (appId, { username, password } = {}) => {
//   const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/login`;
//   const method = `post`;
//   const headers = { appId, 'Content-Type': 'application/x-www-form-urlencoded' };
//   const data = qs.stringify({ username, password });
//   const fetch = () => axios.request({ url, method, headers, data });
//   return { url, method, fetch };
// };

export default {
  login,
  logout,
  getUserInfo,
  getAccountList,
  createAccount,
  modifyPwd,
  deleteAccount
};
