import axios from '@/utils/api.request';

/**
 * @description 配置主机地址
 * @param {Number} userId
 * @param {Object} params
 * @returns { url, method, fetch }
 */
const setConfigHost = params => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/config/host`;
  const method = `post`;
  const headers = {
    userId: JSON.parse(localStorage.getItem('userInfo')).userId,
    appId: 'zwz3vdA7IJ',
    token: JSON.parse(localStorage.getItem('userInfo')).token
  };
  const fetch = () => axios.request({ url, method, headers, params });

  return { url, method, fetch };
};

/**
 * @description 获取mqtt链接信息
 */
const getMQTTConfig = () => {
  const url = `/iot/meeting/${process.env.VUE_APP_VERSION}/mqtt/websocket`;
  const method = `get`;
  const fetch = () => axios.request({ url, method });

  return { url, method, fetch };
};

export default { setConfigHost, getMQTTConfig };
