const MainContainer = () => import('@/views/main');
/**
 * iview-admin中meta除了原生参数外可配置的参数:
 * title
 * meta: {
 *  title: 在左侧导航栏中显示的名字，不为空的话则显示其多语言版本，否则显示 name 的对应多语言版本
 *  hideInMenu: (false) 设为true后在左侧菜单不会显示该页面选项
 *  showAlways: (false) 设为true后如果该路由只有一个子路由，在菜单中也会显示该父级菜单
 *  notCache: (false) 设为true后页面不会缓存
 *  access: (null) 可访问该页面的权限数组，当前路由设置的权限会影响子路由
 *  icon: (-) 该页面在左侧菜单、面包屑和标签导航处显示的图标，如果是自定义图标，需要在图标名称前加下划线'_'
 *  hide: (false), //设为true后在 header 的面包屑 Breadcrumb 不显示
 *  hideSelfInMenu: (false), // （自定义，iview-admin 中没有这个参数）在menu中隐藏自己，但是不隐藏子目录，相当于将子目录提升了一级
 * }
 */

// 路由path尽量简洁，name 是唯一的，推荐使用格式：父路由名 + '.' + 子路由名，例如 user.security.psdchange
// meta中title的格式，route + '.' + 路由name，例如 route.user.security.psdchange

const constantRouterMap = [
  // {
  //   path: '/login',
  //   name: 'login',
  //   meta: {
  //     title: 'Login - 登录',
  //     hideInMenu: true
  //   },
  //   component: () => import('@/views/login/login.vue')
  // },
  // {
  //   path: '/',
  //   name: '_home',
  //   redirect: '/redirect',
  //   meta: {
  //     hideInMenu: true // 在菜单中隐藏，包括所有子目录
  //   }
  // },
  {
    path: '/login',
    name: 'login',
    meta: {
      title: 'Login - 登录',
    },
    component: () => import('@/views/login/login.vue')
  },
  {
    path: '/',
    name: 'home',
    redirect: '/meeting',
    component: MainContainer,
    meta: {
      notCache: true
    },
    children: [
      {
        path: '/meeting',
        name: 'meeting',
        meta: {
          title: '会议',
          notCache: true
        },
        component: () => import('@/views/pages/meeting')
      },
      {
        path: '/call',
        name: 'call',
        meta: {
          title: '呼叫服务',
          notCache: true
        },
        component: () => import('@/views/pages/call')
      },
      {
        path: '/me',
        name: 'me',
        meta: {
          title: '个人中心',
          notCache: true
        },
        component: () => import('@/views/pages/me')
      }
    ]
  },
  {
    path: '/401',
    name: 'error_401',
    meta: {
      hideInMenu: true
    },
    component: () => import('@/views/error-page/401.vue')
  },
  {
    path: '/500',
    name: 'error_500',
    meta: {
      hideInMenu: true
    },
    component: () => import('@/views/error-page/500.vue')
  },
  {
    path: '*',
    name: 'error_404',
    meta: {
      hideInMenu: true
    },
    component: () => import('@/views/error-page/404.vue')
  }
];

/**
 * 动态路由
 */
const asyncRouterMap = [
  // {
  //   path: '/redirect',
  //   name: 'redirect',
  //   meta: {
  //     hide: true,
  //     hideInMenu: true
  //   },
  //   redirect: { name: 'user_authority' } // 默认打开第一个
  // },
  // // 下面是各个功能模块的路由
  // {
  //   path: '/user_authority',
  //   name: 'user_authority',
  //   redirect: { name: 'user_authority.user' },
  //   meta: {
  //     title: 'route.user_authority', // 用于i18n
  //     icon: 'ios-cloud-upload'
  //   },
  //   // eslint-disable-next-line
  //   component: MainContainer,
  //   children: [
  //     {
  //       path: 'authority',
  //       name: 'user_authority.authority',
  //       meta: {
  //         title: 'route.user_authority.authority'
  //         // icon: 'md-albums'
  //       },
  //       component: () => import('@/views/pages/user-authority/authority')
  //     },
  //     {
  //       path: 'user',
  //       name: 'user_authority.user',
  //       meta: {
  //         title: 'route.user_authority.user'
  //         // icon: 'md-albums'
  //       },
  //       component: () => import('@/views/pages/user-authority/user')
  //     }
  //   ]
  // }
];

export { constantRouterMap, asyncRouterMap };
