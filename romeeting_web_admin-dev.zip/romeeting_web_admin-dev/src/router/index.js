import Vue from 'vue';
import Router from 'vue-router';
import { constantRouterMap } from './routers';
import store from '@/store';
import { LoadingBar } from 'view-design';
import config from '@/config';

Vue.use(Router);
const router = new Router({
  mode: 'history',
  base: process.env.VUE_APP_BASE_URL,
  routes: constantRouterMap
});

const { homeName } = config;
const LOGIN_PAGE_NAME = 'login';

router.beforeEach((to, from, next) => {
  LoadingBar.start();
  LoadingBar.start();
  // const token = store.state.user.autoLogin ? getToken() : store.state.user.token;
  var user = JSON.parse(localStorage.getItem('userInfo'));
  var token = '';
  if (user) {
    token = user.token;
  }
  if (!token && to.name !== LOGIN_PAGE_NAME) {
    // 未登录且要跳转的页面不是登录页
    next({
      name: LOGIN_PAGE_NAME // 跳转到登录页
    });
  } else if (!token && to.name === LOGIN_PAGE_NAME) {
    // 未登陆且要跳转的页面是登录页
    next(); // 跳转
  } else if (token && to.name === LOGIN_PAGE_NAME) {
    // 已登录且要跳转的页面是登录页
    next({
      name: homeName // 跳转到homeName页
    });
  } else {
    if (token) {
      store
        .dispatch('getUserInfo', user)
        .then(({ success, msg, code, data }) => {
          if (code === 280010002 || code === 280010003) {
            localStorage.removeItem('userInfo');
            next({
              name: 'login'
            });
            return;
          }
          if (success && data.token) {
            next();
          } else {
            if (user.autoLogin) {
              const loginAcount = JSON.parse(localStorage.getItem('userAcount'));
              store
                .dispatch('handleLogin', loginAcount)
                .then(({ success, msg, data }) => {
                  if (success) {
                    next();
                  } else {
                    localStorage.removeItem('userInfo');
                    next({
                      name: 'login'
                    });
                  }
                })
                .catch(() => {
                  next({
                    name: 'login'
                  });
                });
            }
          }
        })
        .catch(() => {
          // 判断用户是否勾选自动登录
          if (user.autoLogin) {
            const loginAcount = JSON.parse(localStorage.getItem('userAcount'));
            if (!loginAcount.username || !loginAcount.password) {
              next({ name: 'login' });
              return;
            }
            store
              .dispatch('handleLogin', loginAcount)
              .then(({ success, msg, data }) => {
                if (success) {
                  next();
                } else {
                  localStorage.removeItem('userInfo');
                  localStorage.removeItem('userAcount');
                  next({
                    name: 'login'
                  });
                }
              })
              .catch(() => {
                localStorage.removeItem('userInfo');
                localStorage.removeItem('userAcount');
                next({
                  name: 'login'
                });
              });
          } else {
            // localStorage.removeItem('userInfo');
            // window.console.log('清除userInfo');
            // next({
            //   name: 'login'
            // });
          }
        });
    } else {
      next({ name: 'login' });
    }
  }
});

router.afterEach(to => {
  LoadingBar.finish();
  window.scrollTo(0, 0);
});

router.onError(error => {
  window.console.log('routerError: ' + error);
  const pattern = /Loading chunk (\d)+ failed/g;
  const isChunkLoadFailed = error.message.match(pattern);
  const targetPath = router.history.pending.fullPath;
  if (isChunkLoadFailed) {
    router.replace(targetPath);
  }

  // try {
  //   if (isChunkLoadFailed) {
  //     let LoadingChunk = window.sessionStorage.getItem('LoadingChunk');
  //     if (LoadingChunk) {
  //       window.sessionStorage.setItem('LoadingChunk', LoadingChunk - 0 + 1);
  //     } else {
  //       window.sessionStorage.setItem('LoadingChunk', 1);
  //     }
  //     if (LoadingChunk - 0 > 1) {
  //       // 防止 死循环
  //       return false;
  //     }
  //     router.replace(targetPath);
  //     window.sessionStorage.setItem('LoadingChunkPath', targetPath);
  //     const sa = window.sa;
  //     if (sa && sa.track) {
  //       sa.track('element_click', {
  //         page_title: 'LoadingChunk',
  //         element_type: 'view',
  //         page_source: targetPath, // 当前路由
  //         element_name: `刷新页面${LoadingChunk - 0}次` // 尝试 打开次数
  //       });
  //     }
  //   }
  // } catch (e) {
  //   window.console.log(e);
  // }
});

// router.onReady(vm => {
//   try {
//     let LoadingChunkPath = window.sessionStorage.getItem('LoadingChunkPath');

//     const path = vm.path;
//     if (LoadingChunkPath) {
//       if (path !== LoadingChunkPath && path !== '/') {
//         window.sessionStorage.setItem('LoadingChunkPath', vm.path);
//         router.replace(vm.path);
//       } else {
//         router.replace(LoadingChunkPath);
//       }
//     }
//   } catch (e) {
//     window.console.log(e);
//   }
// });

export default router;
