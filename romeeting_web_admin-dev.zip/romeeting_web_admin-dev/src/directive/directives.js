import { on } from '@/utils/tools';
import { Spin } from 'view-design';
import Vue from 'vue';

const directives = {
  draggable: {
    inserted: (el, binding, vnode) => {
      let triggerDom = document.querySelector(binding.value.trigger);
      triggerDom.style.cursor = 'move';
      let bodyDom = document.querySelector(binding.value.body);
      let pageX = 0;
      let pageY = 0;
      let transformX = 0;
      let transformY = 0;
      let canMove = false;
      const handleMousedown = e => {
        let transform = /\(.*\)/.exec(bodyDom.style.transform);
        if (transform) {
          transform = transform[0].slice(1, transform[0].length - 1);
          let splitxy = transform.split('px, ');
          transformX = parseFloat(splitxy[0]);
          transformY = parseFloat(splitxy[1].split('px')[0]);
        }
        pageX = e.pageX;
        pageY = e.pageY;
        canMove = true;
      };
      const handleMousemove = e => {
        let xOffset = e.pageX - pageX + transformX;
        let yOffset = e.pageY - pageY + transformY;
        if (canMove) {
          bodyDom.style.transform = `translate(${xOffset}px, ${yOffset}px)`;
        }
      };
      const handleMouseup = e => {
        canMove = false;
      };
      on(triggerDom, 'mousedown', handleMousedown);
      on(document, 'mousemove', handleMousemove);
      on(document, 'mouseup', handleMouseup);
    },
    update: (el, binding, vnode) => {
      if (!binding.value.recover) {
        return;
      }
      let bodyDom = document.querySelector(binding.value.body);
      bodyDom.style.transform = '';
    }
  },
  access: {
    // 控制 dom 的访问权限
    bind: function(el, binding, vnode) {
      // el是对应的dom,binding中包含你传过来的参数
      if (binding.value && binding.value.key && typeof binding.value.key === 'string') {
        (!Array.isArray(binding.value.access) ||
          !binding.value.access.includes(binding.value.key)) &&
          el &&
          el.parentNode &&
          el.parentNode.removeChild(el);
      }
    }
  },
  resize: {
    // 监测dom的尺寸变化
    bind(el, binding) {
      let height = el.clientHeight;
      let width = el.clientWidth;
      function get() {
        const style = document.defaultView.getComputedStyle(el);
        if (width !== style.width || height !== style.height) {
          binding.value({ width, height });
        }
        width = style.width;
        height = style.height;
      }

      el.__vueReize__ = window.setInterval(get, 150);
    },
    unbind(el) {
      clearInterval(el.__vueReize__);
    }
  },
  loading: {
    bind(el, binding) {
      const Spinner = Vue.extend(Spin);
      let show = false;
      let propsData = { fix: true };
      if (typeof binding.value === 'object' && binding.value) {
        show = binding.value.show;
        Object.assign(propsData, binding.value);
      } else {
        show = binding.value;
      }

      el.__vueSpinner = new Spinner({
        el: document.createElement('div'),
        propsData
      });

      el.__vueSpinner.$el.style.backgroundColor = 'rgba(255,255,255,0.5)';

      if (!['fixed', 'absolute', 'relative'].includes(el.style.position)) {
        el.__oldStylePosition = el.style.position;
        el.style.position = 'relative';
      }

      if (show) {
        el.appendChild(el.__vueSpinner.$el);
      }
    },
    inserted(el, binding, vnode) {
      // const show = binding.value;
      // let height = el.clientHeight;
      // let width = el.clientWidth;
    },
    update(el, binding, vnode) {
      let show = false;
      if (typeof binding.value === 'object' && binding.value) {
        show = binding.value.show;
      } else {
        show = binding.value;
      }
      const has = [...el.childNodes].find(item => item === el.__vueSpinner.$el);
      if (show) {
        !has && el.appendChild(el.__vueSpinner.$el);
      } else {
        has && el.removeChild(el.__vueSpinner.$el);
      }
    },
    unbind(el, binding, vnode) {
      const has = [...el.childNodes].find(item => item === el.__vueSpinner.$el);
      has && el.removeChild(el.__vueSpinner.$el);
      el.style.position = el.__oldStylePosition;
      delete el.__vueSpinner;
      delete el.__oldStylePosition;
    }
  }
};

export default directives;
