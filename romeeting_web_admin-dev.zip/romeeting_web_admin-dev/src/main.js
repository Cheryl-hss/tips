// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import 'babel-plugin-promise';
import Promise from 'es6-promise';
import './ie.compatible';

import Vue from 'vue';
import App from './App';
import router from './router';
import 'view-design/dist/styles/iview.css';

import './index.less';
import '@/assets/icons/iconfont.css';

import store from './store';
import { Message, Modal, Notice } from 'view-design';
import i18n from '@/locale';
import config from '@/config';
import importDirective from '@/directive';
import importComponents from '@/components';
import Videojs from 'video.js';
import 'video.js/dist/video-js.css';
import * as echarts from 'echarts';
Vue.config.productionTip = false;
Vue.prototype.$echarts = echarts;

Vue.prototype.$vuescrollConfig = {
  bar: {
    background: '#000'
  }
};
Promise.polyfill();
// 实际打包时应该不引入mock
if (process.env.NODE_ENV !== 'production') {
  require('@/mock');
}
// require('es6-promise').polyfill();
// require('es6-promise/auto');
// Vue.use(iView, {
//   i18n: (key, value) => i18n.t(key, value),
//   transfer: true // 所有带浮层的组件，是否将浮层放置在 body 内，默认为不设置，详见各组件默认的 transfer 值。可选值为 true 或 false。
// });

// 全局配置 Message
Message.config({
  duration: 5
});

Notice.config({
  top: 66, // 导航栏高度 + 2
  duration: 8
});

Vue.config.productionTip = false;
Vue.config.errorHandler = (err, vm, info) => {
  // handle error
  // `info` 是 Vue 特定的错误信息，比如错误所在的生命周期钩子
  // 只在 2.2.0+ 可用
  window.console.log('errorHandler: ' + err);
};

Vue.prototype.$mqtt = null;

/**
 * @description 全局注册应用配置
 */

Vue.prototype.$config = config;
Vue.prototype.$Message = Message;
Vue.prototype.$Modal = Modal;
Vue.prototype.$Notice = Notice;
Vue.prototype.$video = Videojs;
/**
 * 注册指令
 */
importDirective(Vue);

/**
 * 注册组件
 */
importComponents(Vue);

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  i18n,
  store,
  render: h => h(App),
  data: {
    eventHub: new Vue()
  }
});
