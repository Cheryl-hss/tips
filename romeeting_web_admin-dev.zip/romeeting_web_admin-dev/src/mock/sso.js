import basicData from './basic-data';
import SSOApi from '@/api/sso';

// const USER_MAP = {
//   super_admin: {
//     name: 'super_admin',
//     user_id: '1',
//     access: ['super_admin', 'admin'],
//     token: 'super_admin',
//     avator: 'https://file.iviewui.com/dist/a0e88e83800f138b94d2414621bd9704.png'
//   },
//   admin: {
//     name: 'admin',
//     user_id: '2',
//     access: ['admin'],
//     token: 'admin',
//     avator: 'https://avatars0.githubusercontent.com/u/20942571?s=460&v=4'
//   }
// };

// const login = req => {
//   req = JSON.parse(req.body);
//   return { ...basicData, ...{ data: { token: USER_MAP[req.userName].token } } };
// };

const getUserPermission = req => {
  return {
    ...basicData,
    data: {
      username: 'Jack',
      realname: '小笨',
      avatar: 'https://file.iviewui.com/dist/a0e88e83800f138b94d2414621bd9704.png',
      menuList: [
        {
          name: '用户权限管理/用户管理',
          uri: 'user_authority/user_authority.user',
          buttonList: [
            'user:list', // 轮播图列表
            'user:view', // 查看轮播图详情
            'user:add', // 新增轮播图
            'user:modify', // 编辑轮播图
            'user:delete', // 删除轮播图
            'user:sort', // 轮播图排序
            'user:publish', // 上架轮播图
            'user:remove', // 下架轮播图
            'user:push' // 消息推送
          ]
        },
        {
          name: '用户权限管理/权限管理',
          uri: 'user_authority/user_authority.authority',
          buttonList: [
            'authority:list', // 列表
            'authority:view', // 查看详情
            'authority:add', // 新增
            'authority:modify', // 编辑
            'authority:delete', // 删除
            'authority:sort', // 排序
            'authority:publish', // 上架
            'authority:remove' // 下架
          ]
        }
      ],
      roles: [
        { name: 'super', title: '超级管理员', decription: '拥有所有权限' },
        { name: 'admin', title: '管理员', decription: '拥有除权限管理系统外的所有权限' }
      ]
    }
  };
};

const logout = req => {
  return { ...basicData, errorCode: -1, errorMessage: 'mock模式下无法注销' };
};

// MOCK 配置
export default [
  {
    on: false,
    rurl: new RegExp(SSOApi.getUserPermission().url),
    rtype: SSOApi.getUserPermission().method,
    template: getUserPermission
  },
  {
    on: true,
    rurl: new RegExp(SSOApi.logout().url),
    rtype: SSOApi.logout().method,
    template: logout
  }
];
