import Mock from 'mockjs';
// mockjs 文档：https://github.com/nuysoft/Mock/wiki

const mockIsOn = false; // MOCK: MOCK的全局开关

/**
 * The file enables `@/mock/index.js` to import all mocks automatically
 * in a one-shot manner. There should not be any reason to edit this file.
 *
 * There's one thing to remember is that the exports.default of mock file must be an array like:
 * [{
 *    on: true,
 *    rurl: new RegExp(Api.getWholeTrend().url),
 *    rtype: Api.getWholeTrend().method,
 *    template: getWholeTrend
 *  },
 *  {
 *    on: true,
 *    rurl: new RegExp(Api.getDuration().url),
 *    rtype: Api.getDuration().method,
 *    template: getDuration
 * }]
 *
 */

let mockArrays = [];

const files = require.context('.', true, /\.js$/);
mockIsOn &&
  files.keys().forEach(key => {
    if (key === './index.js') {
      return;
    }
    mockArrays = mockArrays.concat(files(key).default);
  });

// 插入mock，插入前做一个排序，将路径较长的正则排在前面，FIXED: 较长的路径匹配到较短路径正则的问题，如：/app 和 /app/name，后者会匹配前者的正则
mockArrays.sort((a, b) => {
  const aString = (a.rurl && a.rurl.source) || a.rurl || '';
  const bString = (b.rurl && b.rurl.source) || b.rurl || '';
  const aLen = aString.split(/\\\/|\/|\?|&/).length;
  const bLen = bString.split(/\\\/|\/|\?|&/).length;
  return bLen - aLen;
});
mockIsOn &&
  mockArrays.forEach(item => {
    item.on && Mock.mock(item.rurl, item.rtype ? item.rtype : '', item.template);
  });

export default Mock;
