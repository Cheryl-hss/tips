/**
 * 接口数据返回时候的最外层格式
 */
export default {
  status: 0, // int 状态值，目前没有使用
  errorCode: 0, // int 错误码，0表示没有错误
  errorMessage: '', // string 错误码对应的消息
  timestamp: new Date().getTime(), // number 返回的时间戳
  data: {
    // errorList: [], // 批量操作失败的项
    // successList: [] // 批量操作成功的项
  } // object 实际消息体对象
};
