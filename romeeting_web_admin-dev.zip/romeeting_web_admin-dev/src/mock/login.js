import Mock from 'mockjs';
import BasicData from './basic-data';
import { doCustomTimes } from '@/utils/util';

import LoginApi from '@/api/login';

// 登录
const login = req => {
  const data = Mock.mock({
    token: '@guid(30)',
    userId: '@guid(11)',
    username: '@name(2,10)',
    iconUrl: '@image()'
  });
  return { ...BasicData, ...{ data } };
};

// 获取用户信息
const getUserInfo = req => {
  const data = Mock.mock({
    token: '@guid(30)',
    userId: '@guid(11)',
    username: '@name(2,10)',
    iconUrl: '@image()'
  });
  return { ...BasicData, ...{ data } };
};

const getAccountList = req => {
  const data = [];

  doCustomTimes(3, () => {
    data.push(
      Mock.mock({
        account: '账号@increment()',
        password: '密码@increment()',
        role: '角色@increment()',
        id: '@guid()'
      })
    );
  });

  return { ...BasicData, data };
};

const mocks = [
  {
    on: true,
    rurl: new RegExp(LoginApi.login('v1').url),
    rtype: LoginApi.login().method,
    template: login
  },
  {
    on: true,
    rurl: new RegExp(LoginApi.getUserInfo('v1').url),
    rtype: LoginApi.getUserInfo().method,
    template: getUserInfo
  },
  {
    on: true,
    rurl: new RegExp(LoginApi.getAccountList('v1').url),
    rtype: LoginApi.getAccountList().method,
    template: getAccountList
  }
];

export default mocks;
