import Mock from 'mockjs';
import BasicData from './basic-data';
import { doCustomTimes } from '@/utils/util';
import PersonApi from '@/api/person';

// 查询参会人列表
const getAttendeeList = req => {
  const data = [];
  doCustomTimes(10, () => {
    data.push(
      Mock.mock({
        id: '@increment(1,10)',
        name: '参会人@increment(1,10)',
        company: '深圳市柔宇科技有限公司@increment(1,10)',
        logo: 'https://shared-https.ydstatic.com/dict/v2016/logo.png',
        position: '高级经理'
      })
    );
  });
  return { ...BasicData, ...{ data } };
};

// 查询设备列表
const getDeviceList = req => {
  const data = [];
  doCustomTimes(10, index => {
    data.push(
      Mock.mock({
        devId: '@increment(1, 10)',
        devName: '铭牌@increment(1, 10)',
        devType:
          index === (0 || 1 || 2 || 3) ? '100%' : index === (4 || 5 || 6 || 7) ? '90%' : '20%',
        devMac: 'mac @increment()',
        shadow: {
          state: {
            reported: {
              common: {
                battery: index === (0 || 1 || 2 || 3) ? 100 : index === (4 || 5 || 6 || 7) ? 90 : 20
              }
            }
          }
        }
      })
    );
  });
  return { ...BasicData, ...{ data } };
};

// 新建参会人
const addAttendee = req => {
  const data = [];
  doCustomTimes(10, index => {
    data.push(
      Mock.mock({
        id: '@increment(1,10)',
        name: '参会人@increment(1,10)',
        company: '深圳市柔宇科技有限公司@increment(1,10)',
        logo: 'https://shared-https.ydstatic.com/dict/v2016/logo.png',
        position: '高级经理'
      })
    );
  });
  return { ...BasicData, data };
};

// 修改会议设备
const alterAttendee = req => {
  return { ...BasicData };
};

// 删除会议设备
const deleteAttendee = req => {
  return { ...BasicData };
};

// 新增会议设备
const addDevice = req => {
  return { ...BasicData };
};

// 修改会议设备名称
const alterDeviceName = req => {
  return { ...BasicData };
};

// 删除会议设备
const deleteDevice = req => {
  return { ...BasicData };
};

const mocks = [
  {
    on: true,
    rurl: new RegExp(PersonApi.getAttendeeList().url),
    rtype: PersonApi.getAttendeeList().method,
    template: getAttendeeList
  },
  {
    on: true,
    rurl: new RegExp(PersonApi.getDeviceList().url),
    rtype: PersonApi.getDeviceList().method,
    template: getDeviceList
  },
  {
    on: true,
    rurl: new RegExp(PersonApi.addAttendee().url),
    rtype: PersonApi.addAttendee().method,
    template: addAttendee
  },
  {
    on: true,
    rurl: new RegExp(PersonApi.alterAttendee().url),
    rtype: PersonApi.alterAttendee().method,
    template: alterAttendee
  },
  {
    on: true,
    rurl: new RegExp(PersonApi.deleteAttendee('[0-9a-zA-Z-^/]+').url),
    rtype: PersonApi.deleteAttendee().method,
    template: deleteAttendee
  },
  {
    on: true,
    rurl: new RegExp(PersonApi.addDevice('[0-9a-zA-Z-^/]+').url),
    rtype: PersonApi.addDevice().method,
    template: addDevice
  },
  {
    on: true,
    rurl: new RegExp(PersonApi.addDevice('[0-9a-zA-Z-^/]+').url),
    rtype: PersonApi.addDevice().method,
    template: addDevice
  },
  {
    on: true,
    rurl: new RegExp(PersonApi.alterDeviceName().url),
    rtype: PersonApi.alterDeviceName().method,
    template: alterDeviceName
  },
  {
    on: true,
    rurl: new RegExp(PersonApi.deleteDevice('[0-9a-zA-Z-^/]+').url),
    rtype: PersonApi.deleteDevice().method,
    template: deleteDevice
  }
];

export default mocks;
