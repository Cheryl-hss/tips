import Mock from 'mockjs';
import BasicData from './basic-data';
import { doCustomTimes } from '@/utils/util';
import { getQueryFromURL } from '@/utils/tools';

import Api from '@/api/call';

// 获取快捷回复列表
const getFastReplyList = req => {
  const query = getQueryFromURL(req.url); // 获取请求参数

  const web = {
    controlFlag: 0,
    list: []
  };

  doCustomTimes(7, () => {
    web.list.push(
      Mock.mock({
        commonWord: '@csentence()'
      })
    );
  });

  const device = {
    controlFlag: 0,
    list: []
  };

  doCustomTimes(5, index => {
    device.list.push(
      Mock.mock({
        iconId: index + 1,
        commonWord: '@csentence()'
      })
    );
  });
  var data = {};
  if (query.wordFlag === 'web') {
    data = web;
  } else {
    data = device;
  }
  return { ...BasicData, ...{ data } };
};
const submitFastReply = req => {
  return { ...BasicData };
};

const mocks = [
  {
    on: true,
    rurl: new RegExp(Api.getFastReplyList('v1').url),
    rtype: Api.getFastReplyList().method,
    template: getFastReplyList
  },
  {
    on: true,
    rurl: new RegExp(Api.submitFastReply('v1').url),
    rtype: Api.submitFastReply().method,
    template: submitFastReply
  }
];

export default mocks;
