import Mock from 'mockjs';
import BasicData from './basic-data';
import { checkUpgradeInfo } from '@/api/upload';

const testCheckUpgradeInfo = req => {
  const data = [];
  data.push(
    Mock.mock({
      versionCode: 10020,
      apkUrl: 'https://www.baidu.com',
      devType: '111',
      devices: [],
      packageName: 'hello world',
      type: 'App',
      versionName: '10020',
      md5: '1111111111',
      updateInfo: '有新版本啦'
    })
  );
  return { ...BasicData, data };
};

const mocks = [
  {
    on: true,
    rurl: new RegExp(checkUpgradeInfo('v1').url),
    rtype: checkUpgradeInfo().method,
    template: testCheckUpgradeInfo
  }
];

export default mocks;
