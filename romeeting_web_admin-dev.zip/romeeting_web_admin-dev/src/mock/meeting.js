import Mock from 'mockjs';
import BasicData from './basic-data';
import { doCustomTimes } from '@/utils/util';
import { getQueryFromURL } from '@/utils/tools';

import MeetingApi from '@/api/meeting';

// 获取会议列表
const getMeetingList = req => {
  const data = [];
  const query = getQueryFromURL(req.url);
  // window.console.log(query);
  doCustomTimes(10, index => {
    data.push(
      Mock.mock({
        name: '智能会议系统媒体见面会',
        status:
          query.status === 'Completed'
            ? 'Completed'
            : index === 3 || index === 4 || index === 5
              ? 'Waiting'
              : 'Doing',
        startTime: 1608533940660,
        endTime: 1608533940660,
        stat: {
          devSize: 30,
          eolSize: 3,
          unlinkSize: 6
        },
        meetingId: '@id()'
      })
    );
  });
  return { ...BasicData, data };
};

// 查看会议详情
const getMeetingDetail = req => {
  const devices = [];
  const normalResources = [];
  const agendaResources = [];
  const keywords = [];
  const votes = [];

  doCustomTimes(20, index => {
    devices.push(
      Mock.mock({
        devId: '@id()',
        devName: '铭牌@increment(1,2)',
        devType: '铭牌@increment()',
        number: '@increment()',
        meetingStatus: index % 5 !== 0 ? 1 : 0,
        online: index % 5 !== 0 ? 1 : 0,
        shadow: {
          state: {
            reported: {
              common: {
                battery:
                  index === 0 || index === 1 || index === 2 || index === 3
                    ? 20
                    : index === 4 || index === 5 || index === 6 || index === 7
                      ? 90
                      : 100
              }
            }
          }
        },
        person: Mock.mock({
          name: '参会人' + (index + 1),
          company: '公司@increment()',
          position: '高级经理',
          logo: 'https://shared-https.ydstatic.com/dict/v2016/logo.png',
          id: index === 0 ? 1 : '@integer(0, 100)'
        })
      })
    );
  });
  doCustomTimes(4, index => {
    normalResources.push(
      Mock.mock({
        resources: ['@id()', '@id()'],
        type: index % 5 !== 0 ? 'jpg' : 'pdf',
        name: '铭牌@increment()',
        size: '@increment()',
        personIds: index % 5 !== 0 ? 1 : '@integer(0, 100)',
        fileType: index % 5 !== 0 ? 'Image' : 'PDF'
      })
    );

    agendaResources.push(
      Mock.mock({
        id: ['@id()'],
        type: index % 5 !== 0 ? 'jpg' : 'pdf',
        name: '铭牌@increment()',
        size: '@increment()',
        personIds: index % 5 !== 0 ? 1 : '@integer(0, 100)',
        fileType: index % 5 !== 0 ? 'Image' : 'PDF'
      })
    );

    keywords.push(
      Mock.mock({
        id: '@id()',
        title: `提词器${index + 1}`,
        keyword: '@cword(100)',
        personId: devices[index].person.id,
        meetingId: '@id()'
      })
    );

    votes.push(
      Mock.mock({
        id: '@id()',
        title: '是否赞同这个议题？',
        optionA: {
          value: index === 0 ? 60 : index === 1 ? 70 : 30,
          persons: [
            { personId: '@integer(0,100)', personName: '参会A' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' }
          ]
        },
        optionB: {
          value: index === 0 ? 10 : index === 1 ? 20 : 40,
          persons: [
            { personId: '@integer(0,100)', personName: 'B' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' }
          ]
        },
        optionC: {
          value: index === 0 ? 20 : index === 1 ? 10 : 25,
          persons: [
            { personId: '@integer(0,100)', personName: 'C' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' }
          ]
        },
        unknown: {
          value: index === 0 ? 10 : index === 1 ? 0 : 5,
          persons: [
            { personId: '@integer(0,100)', personName: 'C' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' },
            { personId: '@integer(0,100)', personName: '参会@increment(1)' }
          ]
        },
        anonymous: index % 5 !== 0 ? 1 : 0
      })
    );
  });
  const data = Mock.mock({
    id: '@id()',
    name: '会议@integer()',
    status:
      `@integer(0,3)` === 0
        ? 'Completed'
        : `@integer(0,3)` === 1
          ? 'Expired'
          : `@integer(0,3)` === 2
            ? 'Doing'
            : 'Waiting',
    startTime: 1608533940660,
    endTime: 1608533940660,
    host: devices[4].person.id,
    style: {
      background: 'https://pp.myapp.com/ma_pic2/0/shot_12127266_1_1555381022/550',
      size: 'Normal',
      position: 'Center',
      font: 'Default'
      // 铭牌样式
    },
    stat: {
      devSize: 30, // 设备数量
      unlinkSize: 6, // 未连接设备数
      eolSize: 3 // 低电量设备数
    },
    devices,
    normalResources,
    agendaResources,
    keywords,
    votes
  });

  return { ...BasicData, ...{ data } };
};

// 预约会议
const addMeeting = req => {
  const data = {
    meetingId: 1
  };
  return { ...BasicData, ...{ data } };
};

// 投票
const alterDeviceToMeeting = req => {
  return { ...BasicData };
};

// 开始会议
const startMeeting = req => {
  return { ...BasicData };
};

// 结束会议
const stopMeeting = req => {
  return { ...BasicData };
};

// 修改会议信息
const alterMeeting = req => {
  return { ...BasicData };
};

// 集中控制
const onCenterControl = req => {
  return { ...BasicData };
};

// 删除会议
const deleteMeeting = req => {
  return { ...BasicData };
};

const mocks = [
  {
    on: true,
    rurl: new RegExp(MeetingApi.getMeetingList().url),
    rtype: MeetingApi.getMeetingList().method,
    template: getMeetingList
  },
  {
    on: true,
    rurl: new RegExp(MeetingApi.getMeetingDetail('[0-9a-zA-Z-^/]+').url),
    rtype: MeetingApi.getMeetingDetail().method,
    template: getMeetingDetail
  },
  {
    on: true,
    rurl: new RegExp(MeetingApi.onCenterControl('[0-9a-zA-Z-^/]+').url),
    rtype: MeetingApi.onCenterControl().method,
    template: onCenterControl
  },
  {
    on: true,
    rurl: new RegExp(MeetingApi.addMeeting().url),
    rtype: MeetingApi.addMeeting().method,
    template: addMeeting
  },
  {
    on: true,
    rurl: new RegExp(MeetingApi.alterDeviceToMeeting('[0-9a-zA-Z-^/]+').url),
    rtype: MeetingApi.alterDeviceToMeeting().method,
    template: alterDeviceToMeeting
  },
  {
    on: true,
    rurl: new RegExp(MeetingApi.startMeeting('[0-9a-zA-Z-^/]+').url),
    rtype: MeetingApi.startMeeting().method,
    template: startMeeting
  },
  {
    on: true,
    rurl: new RegExp(MeetingApi.stopMeeting('[0-9a-zA-Z-^/]+').url),
    rtype: MeetingApi.stopMeeting().method,
    template: stopMeeting
  },
  {
    on: true,
    rurl: new RegExp(MeetingApi.alterMeetingEditType('[0-9a-zA-Z-^/]+', '[0-9a-zA-Z-^/]+').url),
    rtype: MeetingApi.alterMeetingEditType().method,
    template: getMeetingDetail
  },
  {
    on: true,
    rurl: new RegExp(MeetingApi.alterMeeting('[0-9a-zA-Z-^/]+').url),
    rtype: MeetingApi.alterMeeting().method,
    template: alterMeeting
  },
  {
    on: true,
    rurl: new RegExp(MeetingApi.deleteMeeting('[0-9a-zA-Z-^/]+').url),
    rtype: MeetingApi.deleteMeeting().method,
    template: deleteMeeting
  }
];

export default mocks;
