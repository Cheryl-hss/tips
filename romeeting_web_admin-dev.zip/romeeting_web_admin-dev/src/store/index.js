import Vue from 'vue';
import Vuex from 'vuex';
import modules from './module';

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    unreadMeetingChats: null, // 未读消息列表
    newStatus: false,
    mqtt: null,
    meetingList: null, // 拉取的会议列表
    meetingDatail: null, // 当前会议
    nowDialogue: null, // 当前会话者
    quickReplyList: null // 快捷用语列表
    //
  },
  getters: {
    getData: state => options => state[options.key]
  },
  mutations: {
    setValue(state, options) {
      state[options.key] = options.value;
    }
    //
  },
  actions: {
    //
  },
  modules
});
