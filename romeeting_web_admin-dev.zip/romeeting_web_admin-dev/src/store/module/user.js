import LoginApi from '@/api/login';
const appId = 'zwz3vdA7IJ';

export default {
  state: {
    username: '',
    userId: '',
    iconUrl: '',
    token: '',
    role: '',
    auth: [],
    autoLogin: false.valueOf
  },
  mutations: {
    setAvatar(state, avatarPath) {
      state.iconUrl = avatarPath;
    },
    setUserId(state, id) {
      state.userId = id;
    },
    setUserName(state, name) {
      state.username = name;
    },
    setToken(state, token) {
      state.token = token;
    }
  },
  getters: {},
  actions: {
    // 登录
    handleLogin({ commit }, { username, password, autoLogin }) {
      username = username.trim();
      return new Promise((resolve, reject) => {
        LoginApi.login(appId, { username, password })
          .fetch()
          .then(res => {
            const data = res.data;
            data.autoLogin = autoLogin;
            commit('setToken', data.token);
            commit('setAvatar', data.iconUrl);
            commit('setUserName', data.username);
            commit('setUserId', data.userId);
            localStorage.setItem('userInfo', JSON.stringify(data));
            if (autoLogin) {
              localStorage.setItem('userAcount', JSON.stringify({ username, password, autoLogin }));
            } else {
              localStorage.removeItem('userAcount');
            }
            resolve(res);
          })
          .catch(err => {
            reject(err);
          });
      });
    },

    // 获取用户信息
    getUserInfo({ commit }, { token }) {
      return new Promise((resolve, reject) => {
        LoginApi.getUserInfo(appId, token)
          .fetch()
          .then(res => {
            if (res.success) {
              const data = res.data;
              commit('setToken', data.token);
              commit('setAvatar', data.iconUrl);
              commit('setUserName', data.username);
              commit('setUserId', data.userId);
            }
            resolve(res);
          })
          .catch(err => {
            reject(err);
          });
      });
    },

    // 退出登录
    handleLogOut({ commit }, { token }) {
      return new Promise((resolve, reject) => {
        LoginApi.logout(appId, token)
          .fetch()
          .then(() => {
            commit('setToken', '');
            localStorage.removeItem('userInfo');
            resolve();
          })
          .catch(err => {
            reject(err);
          });
        // 如果你的退出登录无需请求接口，则可以直接使用下面三行代码而无需使用logout调用接口
        // commit('setToken', '')
        // commit('setAccess', [])
        // resolve()
      });
    }
  }
};
