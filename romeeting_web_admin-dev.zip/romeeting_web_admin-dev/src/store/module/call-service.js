/**
 * 呼叫服务状态管理
 */

export default {
  namespaced: true,
  state: {},
  mutations: {},
  getters: {},
  actions: {}
};
