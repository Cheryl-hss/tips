<template>
  <draggable :value="value"
             :animation="200"
             :element="element"
             :tag="tag"
             :disabled="disabled"
             filter='.filtered'
             draggable=".drag-list-item"
             :handle='handle'
             @start="onStart"
             @end="onEnd"
             @input="onInput">
    <div class="drag-list-item"
         v-for="(item,index) in value"
         :key="'drag-list-item-'+index"
         :class="!!item.filtered&&'filtered'">
      <slot name="drag-item"
            :value="{item, index}"
            :filtered="!!item.filtered"></slot>
    </div>
  </draggable>
</template>
<script>
import draggable from 'vuedraggable';

/**
 * 可拖拽的列表
 * @vuedoc
 * @exports DragList
 */
export default {
  name: 'DragList',
  components: {
    draggable
  },
  props: {
    value: {
      type: Array,
      default: () => {
        return [];
      }
    },
    disabled: {
      type: Boolean,
      default: false
    },
    handle: {
      type: String,
      default: ''
    },
    element: {
      type: String,
      default: 'div'
    },
    tag: {
      type: String,
      default: null
    }
  },
  data() {
    return {};
  },
  methods: {
    onStart(evt) {
      this.$emit('start', evt);
    },
    onEnd(evt) {
      this.$emit('end', evt);
    },
    onInput(value) {
      this.$emit('input', value);
    }
  }
};
</script>
<style lang="less">
.drag-list-item {
  border-radius: 4px;
  margin-bottom: 10px;
  transition: all 0.2s ease-in-out;
  &.sortable-chosen,
  &.sortable-ghost {
    background: fade(#57a3f3, 70%);
  }
  &.filtered {
    background: #efefef;
    .handle {
      &:hover {
        cursor: not-allowed;
      }
    }
  }
  .handle {
    &:hover {
      cursor: move;
    }
  }
}
</style>
