<template>
  <Spin ref="c-loading"
        fix
        :hidden="!isShow"
        style="background-color:rgba(0, 0, 0, 0.2);">
    <Icon :type="type"
          :color="color"
          :size="size"
          :custom="custom"
          class="demo-spin-icon-load"></Icon>
    <div>{{message || $t('loading')}}</div>
  </Spin>
</template>

<style lang="less" scoped>
.demo-spin-icon-load {
  animation: ani-demo-spin 1s linear infinite;
}
@keyframes ani-demo-spin {
  from {
    transform: rotate(0deg);
  }
  25% {
    transform: rotate(90deg);
  }
  50% {
    transform: rotate(180deg);
  }
  75% {
    transform: rotate(270deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>

<script>
import { Spin, Icon } from 'view-design';

export default {
  name: 'Loading',
  components: { Spin, Icon },
  props: {
    isShow: {
      type: Boolean,
      default: true
    },
    message: {
      type: String,
      default: ''
    },
    type: {
      type: String,
      default: 'ios-loading'
    },
    color: {
      type: String,
      default: ''
    },
    size: {
      type: Number | String,
      default: 20
    },
    custom: {
      type: String,
      default: ''
    }
  },
  methods: {
    show() {
      this.$refs['c-loading'].$el.hidden = false;
    },
    hide() {
      this.$refs['c-loading'].$el.hidden = true;
    }
  }
};
</script>
