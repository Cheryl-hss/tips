import Loading from './loading.vue';
export default Loading;
