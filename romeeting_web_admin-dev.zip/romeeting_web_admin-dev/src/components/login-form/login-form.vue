<template>
  <Form class="login-form"
        ref="loginForm"
        :model="form"
        :rules="rules"
        @keydown.enter.native="handleSubmit">
    <FormItem prop="username">
      <Input v-model="form.username"
             placeholder="请输入账号"
             size="large" />
      </Input>
    </FormItem>
    <FormItem prop="password">
      <Input type="password"
             password
             v-model="form.password"
             placeholder="请输入密码"
             size="large" />
      </Input>
    </FormItem>
    <Checkbox v-model="autoLogin"><span class="margin-left-4">{{$t('auto_login')}}</span></Checkbox>
    <div class="login-form-alert">
      <Alert v-if="0"
             type="error"
             show-icon>账号或密码有误</Alert>
    </div>

    <Button class="login-form-btn"
            type="primary"
            size="large"
            long
            @click="handleSubmit">登&nbsp; 录</Button>
  </Form>
</template>
<script>
import { Form, FormItem, Input, Alert, Button, Checkbox, Icon } from 'view-design';

export default {
  name: 'LoginForm',
  components: { Form, FormItem, Input, Alert, Button, Checkbox, Icon },
  props: {
    usernameRules: {
      type: Array,
      default: () => {
        return [{ required: true, message: '账号不能为空', trigger: 'change' }];
      }
    },
    passwordRules: {
      type: Array,
      default: () => {
        return [{ required: true, message: '密码不能为空', trigger: 'change' }];
      }
    }
  },
  data() {
    return {
      form: {
        username: '',
        password: ''
      },
      autoLogin: false,
      open: true
    };
  },
  computed: {
    rules() {
      return {
        username: this.usernameRules,
        password: this.passwordRules
      };
    }
  },
  methods: {
    handleSubmit() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.$emit('on-success-valid', {
            username: this.form.username,
            password: this.form.password,
            autoLogin: this.autoLogin
          });
        }
      });
    }
  }
};
</script>

<style lang="less">
.login-form {
  .ivu-checkbox-checked .ivu-checkbox-inner {
    border-color: #0050ff;
    background-color: #0050ff;
  }

  .ivu-form-item {
    margin-bottom: 26px;
  }

  &-alert {
    height: 32px;
  }

  &-btn {
    font-family: PingFangSC-Regular;
    font-size: 14px;
    color: #ffffff;
    line-height: 14px;
    &:hover {
      font-family: PingFangSC-Regular;
      font-size: 14px;
      color: #ffffff;
      line-height: 14px;
    }
  }
}
</style>
