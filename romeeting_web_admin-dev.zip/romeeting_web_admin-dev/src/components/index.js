/**
 *  在这里注册全局组件
 */

// import {
//   Button,
//   Spin,
//   Radio,
//   RadioGroup,
//   Card,
//   Row,
//   Col,
//   Modal,
//   Form,
//   FormItem,
//   Input,
//   Select,
//   Option,
//   OptionGroup,
//   Poptip,
//   Icon,
//   Drawer,
//   Upload
// } from 'view-design';

const importComponents = Vue => {
  // Vue.component('Button', Button);
  // Vue.component('IButton', Button);
  // Vue.component('Spin', Spin);
  // Vue.component('Radio', Radio);
  // Vue.component('IRadio', Radio);
  // Vue.component('RadioGroup', RadioGroup);
  // Vue.component('Card', Card);
  // Vue.component('Row', Row);
  // Vue.component('Col', Col);
  // Vue.component('ICol', Col);
  // Vue.component('Modal', Modal);
  // Vue.component('Form', Form);
  // Vue.component('IForm', Form);
  // Vue.component('FormItem', FormItem);
  // Vue.component('Input', Input);
  // Vue.component('IInput', Input);
  // Vue.component('Select', Select);
  // Vue.component('ISelect', Select);
  // Vue.component('Option', Option);
  // Vue.component('IOption', Option);
  // Vue.component('OptionGroup', OptionGroup);
  // Vue.component('Poptip', Poptip);
  // Vue.component('Icon', Icon);
  // Vue.component('Drawer', Drawer);
  // Vue.component('Upload', Upload);
};

export default importComponents;
