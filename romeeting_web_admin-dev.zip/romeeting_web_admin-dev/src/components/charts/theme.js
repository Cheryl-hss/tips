export default {
  colors: [
    '#00A2FF',
    '#00CFCD',
    '#9EB0C3',
    '#fd8e50',
    '#2d8cf0',
    '#19be6b',
    '#ff9900',
    '#E46CBB',
    '#9A66E4',
    '#ed3f14',
    '#60b9ff',
    '#cddc39',
    '#ffc107',
    '#00BCD4',
    '#009688',
    '#ff7f76'
  ], // 颜色数组，默认从数组第一个元素取色

  chart: {
    spacing: [20, 10, 0, 10],
    backgroundColor: 'rgba(0,0,0,0)' // 背景透明
  },

  // title白色字
  title: {
    align: 'center',
    style: { color: '#516b91', fontSize: '18px' }
  },

  credits: {
    enabled: false // 是否显示右下角的 Highcharts 图标
  },

  exporting: {
    enabled: false // 隐藏导出按钮
  },

  plotOptions: {
    // 这个属性常用于饼图的时候对每个区域的说明
    pie: {
      innerSize: 100,
      depth: 45,
      dataLabels: {
        distance: 7,
        enabled: true,
        color: '#333',
        connectorColor: '#333',
        // 默认是 format: '<b>{point.name}</b>: {point.percentage:.1f} %'显示百分比
        formatter: function() {
          // 自定义显示
          return '<b>' + this.point.name + ':（' + this.y + '）</b>';
        }
      }
    },
    map: { showInLegend: true },
    funnel: {
      showInLegend: true,
      width: '70%'
    },
    pyramid: {
      showInLegend: true,
      width: '70%'
    },
    series: {
      dataLabels: {
        // 影响条形图上数字的字体颜色
        color: '#000'
      },
      marker: {
        radius: 3,
        fillColor: '#fff',
        lineWidth: 2,
        lineColor: null // inherit from series
      }
    }
  },

  // x,y轴上的字白色
  xAxis: {
    labels: {
      style: {
        color: '#606060'
      }
    }
  },

  yAxis: {
    title: {
      enabled: false,
      style: { color: '#606060' }
    },
    markable: { enabled: false }, // 不显示每一个点的实心
    labels: {
      style: {
        color: '#606060'
      }
    }
  },

  // 图例上的字白色
  legend: {
    itemStyle: {
      fontSize: '12px',
      color: '#333'
    }
  }
};
