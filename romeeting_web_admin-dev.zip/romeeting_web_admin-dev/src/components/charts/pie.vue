<template>
  <div ref="dom"
       :style="{height:domHeight}"
       class="charts chart-pie"
       v-resize="reflow"></div>
</template>

<script>
import { deepCopy } from '@/utils/tools';
import Highcharts from 'highcharts';
import Theme from './theme';
export default {
  name: 'ChartPie',
  props: {
    title: {
      // 图表标题
      type: String,
      default: ''
    },
    subtitle: {
      // 图表副标题
      type: String,
      default: ''
    },
    height: {
      // 图表高度
      type: Number | String,
      default: 300
    },
    innerSize: {
      type: String,
      default: '0'
    },
    value: {
      type: Array,
      default: () => {
        return [
          // {
          //   name: 'xxx', // 列名
          //   y: 23 // 值
          // }
        ];
      }
    }
  },
  computed: {
    domHeight() {
      return +this.height > 0 ? this.height + 'px' : this.height;
    }
  },
  watch: {
    title(value) {
      this.chart &&
        this.chart.title &&
        this.chart.title.update({
          text: value
        });
    },
    subtitle(value) {
      this.chart &&
        this.chart.subtitle &&
        this.chart.subtitle.update({
          text: value
        });
    },
    innerSize(newVal, oldVal) {
      // const legend = value.map(_ => _.name);
      this.chart && this.chart.redraw();
    },
    height() {
      this.$nextTick(() => {
        this.chart && this.chart.reflow();
      });
    },
    value(newVal, oldVal) {
      if (this.chart && JSON.stringify(newVal) !== JSON.stringify(oldVal)) {
        // const legend = value.map(_ => _.name);
        this.chart.series[0].setData(deepCopy(newVal));
      }
    }
  },
  methods: {
    getOptions() {
      return {
        title: {
          text: this.title
        },
        subtitle: {
          text: this.subtitle
        },
        tooltip: {
          headerFormat: `<span style="color:{point.color}"> ● </span>`,
          pointFormat: '{point.name}: <b>{point.percentage:.2f}%</b>'
        },
        legend: {
          layout: 'horizontal',
          align: 'center',
          verticalAlign: 'bottom',
          padding: 16
        },
        plotOptions: {
          pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
              enabled: false,
              format: '<b>{point.name}</b>: {point.percentage:.2f} %'
            },
            showInLegend: true
          }
        },
        series: [
          {
            type: 'pie',
            name: '占比',
            innerSize: this.innerSize,
            data: this.value,
            itemStyle: {
              emphasis: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      };
    },
    init() {
      Highcharts.setOptions(Theme);
      this.chart = Highcharts.chart(this.$refs.dom, this.getOptions());
    },
    // 更新图表
    update(redraw = true) {
      this.chart && this.chart.update(this.getOptions(), redraw);
    },
    // 重绘
    redraw() {
      this.chart && this.chart.redraw();
    },
    // 重新适应
    reflow() {
      this.chart && this.chart.reflow();
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.init();
    });
  }
};
</script>

<style lang="less">
</style>
