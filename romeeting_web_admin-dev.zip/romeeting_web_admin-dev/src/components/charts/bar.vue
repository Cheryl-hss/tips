<template>
  <div ref="dom"
       :style="{height:domHeight}"
       class="charts chart-bar"
       v-resize="reflow"></div>
</template>

<script>
/**
 * 折线图
 */
import Highcharts from 'highcharts';
import Theme from './theme';
export default {
  name: 'ChartBar',
  props: {
    title: {
      // 图表标题
      type: String,
      default: ''
    },
    subtitle: {
      // 图表副标题
      type: String,
      default: ''
    },
    xTitle: {
      // x坐标轴标题
      type: String,
      default: ''
    },
    yTitle: {
      // y坐标轴标题
      type: String,
      default: ''
    },
    height: {
      // 图表高度
      type: Number | String,
      default: 300
    },
    value: {
      // 数据
      type: Object,
      default: () => {
        return {
          // x: [
          //   '2019-10-08',
          //   '2019-10-08',
          //   '2019-10-08',
          //   '2019-10-08',
          //   '2019-10-08',
          //   '2019-10-08',
          //   '2019-10-08'
          // ], //
          // y: [
          //   {
          //     name: '线一',
          //     data: [12, 12, 3, 45, 6, 7, 7]
          //   },
          //   {
          //     name: '线二',
          //     data: [1, 12, 33, 45, 6, 44, 7]
          //   }
          // ]
        };
      }
    },
    type: {
      type: String,
      default: 'bar'
    }
  },
  computed: {
    domHeight() {
      return +this.height > 0 ? this.height + 'px' : this.height;
    }
  },
  watch: {
    title(value) {
      this.chart &&
        this.chart.title &&
        this.chart.title.update({
          text: value
        });
    },
    subtitle(value) {
      this.chart &&
        this.chart.subtitle &&
        this.chart.subtitle.update({
          text: value
        });
    },
    xTitle(value) {
      this.chart &&
        this.chart.update({
          xAxis: {
            title: {
              enabled: !!value,
              text: value
            }
          }
        });
    },
    yTitle(value) {
      this.chart &&
        this.chart.update({
          yAxis: {
            title: {
              enabled: !!value,
              text: value
            }
          }
        });
    },
    height() {
      this.$nextTick(() => {
        this.chart && this.chart.reflow();
      });
    },
    type(newVal, oldVal) {
      if (this.chart && JSON.stringify(newVal) !== JSON.stringify(oldVal)) {
        this.chart.update({
          chart: {
            type: ['bar', 'column'].includes(newVal) ? newVal : 'bar'
          }
        });
      }
    },
    value(newVal, oldVal) {
      if (this.chart && JSON.stringify(newVal) !== JSON.stringify(oldVal)) {
        const { x: categories, y: series } = newVal;
        // 更新x轴label
        this.chart.xAxis[0].setCategories(categories, false);
        // 更新数据
        [...this.chart.series].forEach((item, index) => {
          item.remove(false);
        });
        series.forEach((item, index) => {
          this.chart.addSeries(item, false);
        });
        this.redraw();
      }
    }
  },
  methods: {
    getOptions() {
      const { x: categories = [], y: series = [] } = this.value;
      return {
        chart: {
          type: ['bar', 'column'].includes(this.type) ? this.type : 'bar'
        },
        title: {
          text: this.title
        },
        subtitle: {
          text: this.subtitle
        },
        tooltip: {
          pointFormat:
            '<span style="color:{point.color}"> ● </span>{series.name}:<b>{point.y}</b><br/><br/>',
          shared: false
        },
        legend: {
          bottom: 12
        },
        xAxis: {
          categories,
          title: {
            enabled: !!this.xTitle,
            text: this.xTitle
          }
        },
        yAxis: {
          title: {
            enabled: !!this.yTitle,
            text: this.yTitle
          }
        },
        series
      };
    },
    init() {
      Highcharts.setOptions(Theme);
      this.chart = Highcharts.chart(this.$refs.dom, this.getOptions());
    },
    // 更新图表
    update(redraw = true) {
      this.chart && this.chart.update(this.getOptions(), redraw);
    },
    // 重绘
    redraw() {
      this.chart && this.chart.redraw();
    },
    // 重新适应
    reflow() {
      this.chart && this.chart.reflow();
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.init();
    });
  }
};
</script>

<style lang="less">
</style>
