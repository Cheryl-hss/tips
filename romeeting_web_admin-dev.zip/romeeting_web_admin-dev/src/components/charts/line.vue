<template>
  <div ref="dom"
       :style="{height:domHeight}"
       class="charts chart-line"
       v-resize="reflow"></div>
</template>

<script>
/**
 * 折线图
 */
import Highcharts from 'highcharts';
import Theme from './theme';
export default {
  name: 'ChartLine',
  props: {
    title: {
      // 图表标题
      type: String,
      default: ''
    },
    subtitle: {
      // 图表副标题
      type: String,
      default: ''
    },
    xTitle: {
      // x坐标轴标题
      type: String,
      default: ''
    },
    yTitle: {
      // y坐标轴标题
      type: String,
      default: ''
    },
    height: {
      // 图表高度
      type: Number | String,
      default: 300
    },
    value: {
      // 数据
      type: Object,
      default: () => {
        return {
          // x: [
          //   '2019-10-08',
          //   '2019-10-08',
          //   '2019-10-08',
          //   '2019-10-08',
          //   '2019-10-08',
          //   '2019-10-08',
          //   '2019-10-08'
          // ], //
          // y: [
          //   {
          //     name: '线一',
          //     data: [12, 12, 3, 45, 6, 7, 7]
          //   },
          //   {
          //     name: '线二',
          //     data: [1, 12, 33, 45, 6, 44, 7]
          //   }
          // ]
        };
      }
    },
    type: {
      // 线类型 1-折线 2-曲线
      type: String,
      default: 'line'
    }
  },
  computed: {
    domHeight() {
      return +this.height > 0 ? this.height + 'px' : this.height;
    }
  },
  watch: {
    title(value) {
      this.chart &&
        this.chart.title &&
        this.chart.title.update({
          text: value
        });
    },
    subtitle(value) {
      this.chart &&
        this.chart.subtitle &&
        this.chart.subtitle.update({
          text: value
        });
    },
    xTitle(value) {
      this.chart &&
        this.chart.update({
          xAxis: {
            title: {
              enabled: !!value,
              text: value
            }
          }
        });
    },
    yTitle(value) {
      this.chart &&
        this.chart.update({
          yAxis: {
            title: {
              enabled: !!value,
              text: value
            }
          }
        });
    },
    height() {
      this.$nextTick(() => {
        this.chart && this.chart.reflow();
      });
    },
    type(newVal, oldVal) {
      if (this.chart && JSON.stringify(newVal) !== JSON.stringify(oldVal)) {
        this.chart.update({
          chart: {
            type: ['line', 'spline'].includes(newVal) ? newVal : 'line'
          }
        });
      }
    },
    value(newVal, oldVal) {
      if (this.chart && JSON.stringify(newVal) !== JSON.stringify(oldVal)) {
        const { x: categories, y: series } = newVal;
        // 更新x轴label
        this.chart.xAxis[0].setCategories(categories, false);
        // 更新数据
        [...this.chart.series].forEach((item, index) => {
          item.remove(false);
        });
        series.forEach((item, index) => {
          this.chart.addSeries(item, false);
        });
        this.redraw();
      }
    }
  },
  methods: {
    getOptions() {
      const { x: categories = [], y: series = [] } = this.value;
      return {
        chart: {
          type: ['line', 'spline'].includes(this.type) ? this.type : 'line'
        },
        title: {
          text: this.title
        },
        subtitle: {
          text: this.subtitle
        },
        tooltip: {
          pointFormat:
            '<span style="color:{point.color}"> ● </span>{series.name}:<b>{point.y}</b><br/>',
          shared: true
        },
        legend: {
          bottom: 12
        },
        xAxis: {
          categories,
          title: {
            enabled: !!this.xTitle,
            text: this.xTitle
          }
        },
        yAxis: {
          title: {
            enabled: !!this.yTitle,
            text: this.yTitle
          }
        },
        series
      };
    },
    init() {
      Highcharts.setOptions(Theme);
      this.chart = Highcharts.chart(this.$refs.dom, this.getOptions());
    },
    // 更新图表
    update(redraw = true) {
      this.chart && this.chart.update(this.getOptions(), redraw);
    },
    // 重绘
    redraw() {
      this.chart && this.chart.redraw();
    },
    // 重新适应
    reflow() {
      this.chart && this.chart.reflow();
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.init();
    });
  }
};
</script>

<style lang="less">
</style>
