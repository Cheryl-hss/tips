<template>
  <div v-if="src"
       class="cropper-wrapper">
    <div class="img-box">
      <img class="cropper-image"
           :id="imgId"
           alt="">
    </div>
  </div>
  </div>
</template>

<script>
import Cropper from 'cropperjs';
import './index.less';
import 'cropperjs/dist/cropper.min.css';

export default {
  name: 'Cropper',
  props: {
    src: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      cropper: null
    };
  },
  computed: {
    imgId() {
      return `cropper${this._uid}`;
    }
  },
  watch: {
    src(src) {
      this.replace(src);
    }
  },
  methods: {
    replace(src) {
      this.cropper.replace(src);
    }
  },
  mounted() {
    this.$nextTick(() => {
      let dom = document.getElementById(this.imgId);
      this.cropper = new Cropper(dom, {
        checkCrossOrigin: true,
        // aspectRatio: 3 / 1, // 固定长宽比例
        autoCropArea: 1,
        dragMode: 'move'
      });
      this.replace(this.src);
    });
  }
};
</script>
