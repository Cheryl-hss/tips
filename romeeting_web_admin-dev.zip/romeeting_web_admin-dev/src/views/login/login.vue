<template>
  <div class="login">
    <div class="login-con">
      <div class="login-con-left">
        <div class="login-con-left-logo"></div>
        <div class="login-con-left-title">{{ $t('ro_meeting_title') }}</div>
        <div class="login-con-left-img"></div>
      </div>
      <div class="login-con-right">
        <div class="login-con-right-content">
          <div class="login-con-right-content-body">
            <div class="login-con-right-content-body-title">{{ $t('ro_meeting_login')}}</div>
            <login-form @on-success-valid="handleSubmit"></login-form>
          </div>
          <Loading :isShow="false"
                   ref="loading"
                   message="正在登录..."></Loading>
        </div>
      </div>
    </div>
    <Row class="login-help"
         type="flex"
         justify="center">
      <Col span="1">{{$t('help')}}</Col>
      <Col span="1">{{$t('privacy')}}</Col>
      <Col span="1">{{$t('provision')}}</Col>
    </Row>
    <Row class="login-copyright"
         type="flex"
         justify="center">{{$t('copyright')}}</Row>
  </div>
</template>

<script>
import { Row, Col } from 'view-design';
import LoginForm from '_c/login-form';
import Loading from '_c/loading';
import config from '@/config';
import { mapActions } from 'vuex';

export default {
  components: {
    Row,
    Col,
    LoginForm,
    Loading
  },
  data() {
    return {};
  },
  methods: {
    ...mapActions(['handleLogin']),
    handleSubmit({ username, password, autoLogin }) {
      this.$refs.loading.show();
      this.handleLogin({ username, password, autoLogin })
        .then(res => {
          this.$router.push({
            name: config.homeName
          });
          this.$refs.loading.hide();
        })
        .catch(() => {
          this.$refs.loading.hide();
          this.$Message.destroy();
          this.$Message.error({
            content: '账号或密码错误',
            duration: 10,
            closable: true
          });
        });
    }
  }
};
</script>

<style lang="less">
@import './login.less';
</style>
