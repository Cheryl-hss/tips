<style src="./annotationLayer.css">
</style>
<script>
import componentFactory from './componentFactory.js';

if (process.env.VUE_ENV !== 'server') {
  var pdfjsWrapper = require('./pdfjsWrapper.js').default;
  var PDFJS = require('pdfjs-dist/es5/build/pdf.js');
  var component = componentFactory(pdfjsWrapper(PDFJS));
} else {
  component = componentFactory({});
}

export default component;
</script>
