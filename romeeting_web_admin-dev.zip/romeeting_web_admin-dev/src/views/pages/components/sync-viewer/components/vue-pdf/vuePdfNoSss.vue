<template>
  <span ref="container"
        style='position: relative; display: block; width:100%; height:100%; text-align: center;'>
    <!-- <sapn style='position: relative; display: block;'> -->
    <canvas ref="canvas"
            style='display: inline-block; vertical-align: top;' />
    <span ref="annotationLayer"
          class="annotationLayer"
          style='display: inline-block;' />
    <!-- <ResizeSensor @resize="resize" /> -->
  </span>
</template>
<style src="./annotationLayer.css">
</style>
<script>
// import ResizeSensor from 'vue-resize-sensor';
var pdfjsWrapper = require('./pdfjsWrapper.js').default;
var PDFJS = require('pdfjs-dist/es5/build/pdf.js');

if (
  typeof window !== 'undefined' &&
  'Worker' in window &&
  navigator.appVersion.indexOf('MSIE 10') === -1
) {
  // eslint-disable-next-line import/no-webpack-loader-syntax
  var PdfjsWorker = require('worker-loader!pdfjs-dist/es5/build/pdf.worker.js');
  PDFJS.GlobalWorkerOptions.workerPort = new PdfjsWorker();
}

var pdfViewer = pdfjsWrapper(PDFJS);
export default {
  createLoadingTask: pdfViewer.createLoadingTask,
  // components: {
  //   ResizeSensor
  // },
  data() {
    return {
      initScale: null,
      pdf: null
    };
  },
  // render: h => {
  //   return h(
  //     'span',
  //     {
  //       attrs: {
  //         style: 'position: relative; display: block;'
  //       }
  //     },
  //     [
  //       h('canvas', {
  //         attrs: {
  //           style: 'display: inline-block; width: 100%; height: 100%; vertical-align: top'
  //         },
  //         ref: 'canvas'
  //       }),
  //       h('span', {
  //         style: 'display: inline-block; width: 100%; height: 100%',
  //         class: 'annotationLayer',
  //         ref: 'annotationLayer'
  //       }),
  //       h(ResizeSensor, {
  //         props: {
  //           initial: true
  //         },
  //         on: {
  //           resize() {
  //             return this.resize();
  //           }
  //         }
  //       })
  //     ]
  //   );
  // },
  props: {
    src: {
      type: [String, Object, Uint8Array],
      default: ''
    },
    page: {
      type: Number,
      default: 1
    },
    scale: {
      type: Number,
      default: 0 // 0 表示自动适应容器宽高
    },
    maxScale: {
      type: Number,
      default: 10
    },
    minScale: {
      type: Number,
      default: 0.1
    },
    rotate: {
      type: Number
    },
    mode: {
      type: String,
      default: 'Fullscreen'
    }
  },
  watch: {
    src() {
      this.pdf.loadDocument(this.src);
    },
    page() {
      this.pdf.loadPage(this.page, this.scale, this.rotate);
    },
    rotate() {
      this.pdf.renderPage(this.scale, this.rotate);
    },
    mode() {
      this.initScale = null;
      this.pdf.renderPage(this.scale, this.rotate);
      this.$emit('page-loaded', this.page);
    },
    scale(val) {
      const scale = this.initScale + val;
      if (scale >= this.minScale && scale <= this.maxScale) {
        this.pdf.renderPage(scale, this.rotate);
      }
    }
  },
  methods: {
    resize(size) {
      // check if the element is attached to the dom tree || resizeSensor being destroyed
      // if (this.$el.parentNode === null || (size.width === 0 && size.height === 0)) {
      //   return;
      // }
      // on IE10- canvas height must be set
      // this.$refs.canvas.style.height =
      //   this.$refs.canvas.offsetWidth * (this.$refs.canvas.height / this.$refs.canvas.width) + 'px';
      // update the page when the resolution is too poor
      // var resolutionScale = this.pdf.getResolutionScale();
      // if (resolutionScale < 0.85 || resolutionScale > 1.15) {
      //   this.pdf.renderPage(this.rotate);
      // }
      // this.$refs.annotationLayer.style.transform = 'scale('+resolutionScale+')';
    },
    print(dpi, pageList) {
      this.pdf.printPage(dpi, pageList);
    }
  },

  // doc: mounted hook is not called during server-side rendering.
  mounted() {
    //
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
    this.$nextTick(() => {
      this.pdf = new pdfViewer.PDFJSWrapper(
        this.$refs.container,
        this.$refs.canvas,
        this.$refs.annotationLayer,
        this.$emit.bind(this)
      );

      this.$on('loaded', () => {
        this.pdf.loadPage(this.page, this.scale, this.rotate);
      });

      this.$on('page-size', (width, height, scale) => {
        if (!this.initScale) {
          this.initScale = scale;
        }
        // 是canvas垂直居中
        this.$refs.canvas.style.marginTop = '0px';
        const offset = this.$refs.container.clientHeight - height;
        if (offset > 0) {
          this.$refs.canvas.style.marginTop = offset / 2 + 'px';
        }
      });

      this.pdf.loadDocument(this.src);
    });
  },
  // doc: destroyed hook is not called during server-side rendering.
  beforeDestroy() {
    this.pdf.destroy();
  }
};
// export default component;
</script>
