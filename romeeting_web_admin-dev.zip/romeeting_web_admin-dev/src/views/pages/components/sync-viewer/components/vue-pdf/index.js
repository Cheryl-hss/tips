import PDF from './vuePdfNoSss.vue';

export default PDF;
