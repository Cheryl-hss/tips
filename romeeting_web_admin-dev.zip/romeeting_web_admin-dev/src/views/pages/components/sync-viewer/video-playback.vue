<template>
  <div v-if="isShow">
    <!-- <div> -->
    <div class="page-container"
         @mousemove="mousemove">
      <div class="page-container-background">
      </div>
      <video class="video-js vjs-default-skin vjs-big-play-centered"
             autoplay="autoplay"
             ref="videoPlayer"
             :key="showMode"
             controls>
        <source :src="data.url"
                type="video/mp4" />
      </video>
    </div>
    <div v-if="isSync && bindShow"
         class="cancel-button">
      <div @click="isSync = false">取消同屏</div>
    </div>
    <div class="viewer-title-bar">
      <span>{{this.data.filename}}</span>
      <!-- 右上角退出按钮开始 -->
      <span class="viewer-title-bar-close-btn"
            @click="onClose">
        <Tooltip content="关闭"
                 placement="bottom"
                 class="tooltipStyle">
          <p>
            <Icon type="md-close"
                  class="icon" />
          </p>
        </Tooltip>
      </span>
      <!-- 右上角退出按钮退出 -->
      <Button v-if="showSyncButton"
              type="primary"
              class="viewer-title-bar-samescreennow"
              @click="samesCreennow">立即同屏</Button>
    </div>
  </div>
</template>
<script>
import { Icon, Tooltip, Button } from 'view-design';
import screenfull from 'screenfull';

export default {
  name: 'VideoPlayback',
  data() {
    return {
      showMode: 'Fullscreen',
      isShow: false,
      isSync: false,
      bindShow: true,
      player: null
    };
  },
  props: {
    data: {
      // 文件类型（jpg，pdf）
      type: Object,
      default() {
        return {
          meetingId: 0,
          filename: '',
          groupId: 0,
          sync: true,
          url: ''
        };
      }
    }
  },
  watch: {
    isShow(newVal) {
      if (newVal) {
        window.addEventListener('resize', this.resize);
      } else {
        window.removeEventListener('resize', this.resize);
      }
    },
    isSync(value) {
      if (!value) {
        this.onCancel();
      }
    }
  },
  components: { Icon, Tooltip, screenfull, Button },
  computed: {
    showSyncButton() {
      if (this.showMode === 'Normal') {
        return this.data.sync === true;
      } else if (this.showMode === 'Fullscreen') {
        return this.data.sync === false;
      }
    }
  },
  methods: {
    mousemove() {
      // 鼠标移动
      if (!this.syncShow) {
        return;
      }
      this.bindShow = true;
      this.timer && window.clearTimeout(this.timer);
      this.timer = window.setTimeout(() => {
        // 鼠标没有操作超过5秒，执行隐藏
        this.bindShow = false;
      }, 5000);
    },
    // 立即同屏
    samesCreennow() {
      this.syncShow();
    },
    resize() {
      this.$nextTick(() => {
        if (!screenfull.isFullscreen) {
          this.showMode = 'Normal';

          this.isSync = false;
        } else {
          this.showMode = 'Fullscreen';
          this.isSync = true;
          this.onSync();
        }
      });
    },

    // 全屏操作
    clickFullscreen() {
      if (!screenfull.isEnabled) {
        this.$message({
          message: '',
          type: 'warning'
        });
        return false;
      }
      screenfull.request();
    },
    show() {
      this.isShow = true;
      this.showMode = 'Normal';
    },
    syncShow() {
      this.isShow = true;
      this.$nextTick(() => {
        this.clickFullscreen();
      });
    },
    // 右上角关闭按钮----整页退出全屏
    onClose() {
      if (screenfull.isEnabled) {
        screenfull.exit();
      }
      this.isShow = false;
      this.isSync = false;
      this.$emit('on-close', {});
    },
    onSync() {
      if (!this.isSync) {
        return;
      }
      const controlData = {
        pushId: this.data.groupId,
        value: 0,
        control_type: 0
      };
      const params = {
        type: 'Resource',
        meetingId: this.data.meetingId,
        data: JSON.stringify(controlData)
      };
      this.$emit('on-sync', params);
    },
    onCancel() {
      if (screenfull.isEnabled) {
        screenfull.exit();
      }
      const controlData = {
        pushId: this.data.groupId,
        value: 0,
        control_type: 2
      };
      const params = {
        type: 'Resource',
        meetingId: this.data.meetingId,
        data: JSON.stringify(controlData)
      };
      this.$emit('on-cancel', params);
    }
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
    if (this.player) {
      this.player.dispose();
    }
  }
};
</script>
<style lang="less" scoped>
.video-js {
  width: 100%;
  height: 100%;
  z-index: 1190;
}
// 头部样式
.viewer-title-bar {
  height: 70px;
  width: 100%;
  position: absolute;
  top: 0;
  left: 0;
  background: black;
  font-size: 20px;
  color: #fff;
  display: flex;
  // justify-content: center;
  align-items: center;
  z-index: 1190;
  &-close-btn {
    width: 70px;
    height: 70px;
    background: black;
    position: fixed;
    top: 0;
    right: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1190;
    color: white;
    &:hover {
      transition: 0.3s;
      cursor: pointer;
      background: rgb(46, 45, 45);
    }
  }
  &-samescreennow {
    position: absolute;
    right: 80px;
  }
}

// 页面样式
.page-container {
  position: fixed;
  top: 70px;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1190;
  &-background {
    opacity: 0.8;
    background: black;
    position: fixed;
    top: 64px;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 1190;
  }
}

.cancel-button {
  right: 0;
  display: flex;
  align-items: center;
  justify-content: space-around;
  position: absolute;
  bottom: 1%;
  left: 44%;
  width: 204px;
  height: 32px;
  background: #202020;
  z-index: 1190;
  color: white;
  opacity: 0.8;
  border-radius: 15px;
}
</style>
