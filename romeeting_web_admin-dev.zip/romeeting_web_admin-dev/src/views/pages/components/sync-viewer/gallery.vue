<template>
  <div v-if="isShow">
    <div class="gallery-container">
    </div>
    <div class="gallery-rotationChart">
      <div :key="showMode"
           @mousemove="mouseout"
           class="gallery-rotationChart-div"
           :style="{transform:'scale('+scale+')'}"
           @mousedown="move"
           ref="callCenter">
        <transition-group name="list">
          <div class="gallery-rotationChart-div-image"
               v-for="(item,index) in data.items"
               :key="item.id"
               v-show="value == index"
               id="items">
            <img :src="'/iot/resource/302/oss?id=' + item.resourceId"
                 style="object-fit: contain;height:calc(100vh - 200px)" />
          </div>
        </transition-group>
      </div>
    </div>
    <div v-if="showMode === 'Normal'"
         class="gallery-container-pageTotalNum"> {{value + 1  }} / {{this.data.items.length}}</div>
    <div v-else-if="showMode === 'Fullscreen'"
         class="gallery-container-samescreenbutton"
         v-show="bindShow">
      <div class="gallery-container-samescreenbutton-leftimg">
        <Tooltip content="上一页"
                 placement="top"
                 style="width: 32px;height: 32px"
                 :disabled="isFirstPage">
          <Button class="gallery-container-samescreenbutton-leftimg"
                  :disabled="isFirstPage"
                  :ghost="isFirstPage"
                  @click="onChangePage('-')">
            <img src="~@/assets/images/leftarrow@2x.png"
                 style="width: 32px;height: 32px;margin-left: -23px;" />
          </Button>
        </Tooltip>
      </div>
      <div class="gallery-container-samescreenbutton-leftimg">
        <Tooltip content="下一页"
                 placement="top"
                 style="width: 32px;height: 32px"
                 :disabled="isLastPage">
          <Button class="gallery-container-samescreenbutton-leftimg"
                  :disabled="isLastPage"
                  :ghost="isLastPage"
                  @click="onChangePage('+')">
            <img src="~@/assets/images/rightarrow@2x.png"
                 style="width: 32px;height: 32px;margin-left: -15px;" />
          </Button>
        </Tooltip>
      </div>
      <div>|</div>
      <div @click="isSync = false">取消同屏</div>
    </div>
    <div class="viewer-title-bar">
      <span style="margin-left:48px">{{this.data.items[this.value].name}}</span>
      <span class="viewer-title-bar-close-btn"
            @click="onClose">
        <Tooltip content="关闭"
                 placement="bottom"
                 class="tooltipStyle">
          <p>
            <Icon type="md-close"
                  class="icon" />
          </p>
        </Tooltip>
      </span>
      <Button v-show="showSyncButton"
              type="primary"
              class="viewer-title-bar-samescreennow"
              @click="samesCreennow">立即同屏</Button>
    </div>
    <Button v-show="bindShow"
            :class="{select:idx==0}"
            @touchstart="idx=0"
            @touchend="idx=-1"
            @click="magnify"
            class="enlarge">
      <Icon type="ios-add-circle-outline" />
    </Button>
    <Button v-show="bindShow"
            :disabled="narrowDisabled"
            :class="{select:idx==1}"
            @touchstart="idx=1"
            @touchend="idx=-1"
            @click="shrink"
            class="enlarge narrow">
      <Icon type="ios-remove-circle-outline" />
    </Button>
    <div class="control-layer"
         v-if="showMode === 'Normal'">
      <div class="control-layer-left"
           v-show="!isFirstPage"
           @click="onChangePage('-')">
        <Tooltip content="上一页"
                 placement="top">
          <span>
            <Icon type="ios-arrow-back" />
          </span>
        </Tooltip>
      </div>
      <div class="control-layer-right"
           v-show="!isLastPage"
           @click="onChangePage('+')">
        <Tooltip content="下一页"
                 placement="top">
          <span>
            <Icon type="ios-arrow-forward" />
          </span>
        </Tooltip>
      </div>
    </div>
  </div>
</template>

<script>
import { Icon, Tooltip, Button } from 'view-design';
import screenfull from 'screenfull';
export default {
  // 不要忘记了 name 属性
  name: 'Gallery',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    data: {
      type: Object,
      default() {
        return {
          meetingId: 0,
          items: [
            {
              id: 0,
              groupId: 0,
              resourceId: 0,
              name: '',
              sync: true
            }
          ]
        };
      }
    }
  },
  // 变量
  data() {
    return {
      showMode: 'Fullscreen',
      Creennow: true,
      isShow: false,
      isSync: false,
      value: 0,
      bindShow: true,
      scale: 1,
      idx: -1,
      initLeft: null,
      initTop: null,
      // 按下时的坐标
      startX: '',
      startY: '',
      // 抬起时的坐标
      endX: '',
      endY: ''
    };
  },

  // 使用其它组件
  components: { Icon, Tooltip, screenfull, Button },
  // 计算属性
  computed: {
    isFirstPage() {
      return this.value === 0;
    },
    isLastPage() {
      return this.value === this.data.items.length - 1;
    },
    narrowDisabled() {
      return this.scale < 1.0001;
    },
    showSyncButton() {
      if (this.showMode === 'Normal') {
        return this.data.items[0].sync === true;
      } else if (this.showMode === 'Fullscreen') {
        return this.data.items[0].sync === false;
      }
    }
  },
  // 监听
  watch: {
    isShow(newVal) {
      if (newVal) {
        window.addEventListener('resize', this.resize);
        document.addEventListener('keydown', this.keyDown);
      } else {
        window.removeEventListener('resize', this.resize);
        document.removeEventListener('keydown', this.keyDown);
      }
    },
    isSync(value) {
      if (!value) {
        this.onCancel();
      }
    }
  },
  // 方法
  methods: {
    // 刷新页面
    reset() {
      this.$nextTick(() => {
        this.$refs.callCenter.style.left = this.initLeft;
        this.$refs.callCenter.style.top = this.initTop;
        this.scale = 1;
      });
    },
    move(event) {
      event.preventDefault();
      if (this.narrowDisabled) {
        return false;
      }
      // 给对应div添加拖拽属性
      let callCenter = this.$refs.callCenter;
      callCenter.style.cursor = 'move';
      var distanceX = event.clientX - callCenter.offsetLeft;
      var distanceY = event.clientY - callCenter.offsetTop;
      // 获取按下时对应的坐标
      this.startX = event.pageX;
      this.startY = event.pageY;
      document.onmousemove = ev => {
        var oevent = ev || event;
        callCenter.style.left = oevent.clientX - distanceX + 'px';
        callCenter.style.top = oevent.clientY - distanceY + 'px';
      };
      document.onmouseup = () => {
        document.onmousemove = null;
        document.onmouseup = null;
        callCenter.style.cursor = 'default';
      };
    },

    // 放大
    magnify() {
      if (!this.initLeft || !this.initTop) {
        this.initLeft = this.$refs.callCenter.style.left;
        this.initTop = this.$refs.callCenter.style.top;
      }
      this.scale += 0.1;
      this.mouseout();
    },
    // 缩小
    shrink() {
      if (this.narrowDisabled) {
        return;
      }
      this.scale -= 0.1;
      this.narrowDisabled && this.reset();
      this.mouseout();
    },
    mouseout() {
      // 鼠标移动
      this.bindShow = true;
      this.timer && window.clearTimeout(this.timer);
      this.timer = window.setTimeout(() => {
        // 鼠标没有操作超过5秒，执行隐藏
        this.bindShow = false;
      }, 5000);
    },
    // 立即同屏
    samesCreennow() {
      this.syncShow();
    },
    keyDown(e) {
      e = e || window.event;
      switch (e.keyCode) {
        case 37: // 左键
          this.changePage('-');
          break;
        case 38: // 向上键
          this.changePage('-');
          break;
        case 39: // 右键
          this.changePage('+');
          break;
        case 40: // 向下键
          this.changePage('+');
          break;
        default:
          break;
      }
    },
    resize() {
      this.$nextTick(() => {
        if (!screenfull.isFullscreen) {
          this.showMode = 'Normal';
          this.isSync = false;
        } else {
          this.showMode = 'Fullscreen';
          this.isSync = true;
          this.onSync();
        }
      });
    },
    // 全屏操作
    clickFullscreen() {
      if (!screenfull.isEnabled) {
        this.$message({
          message: '',
          type: 'warning'
        });
        return false;
      }
      screenfull.request();
    },
    show() {
      this.value = this.value || 0;
      this.isShow = true;
      this.showMode = 'Normal';
    },
    syncShow() {
      this.scale = 1;
      this.value = this.value || 0;
      this.isShow = true;
      this.$nextTick(() => {
        this.clickFullscreen();
      });
    },
    // 右上角关闭按钮------退出全屏
    onClose() {
      if (screenfull.isEnabled) {
        screenfull.exit();
      }
      this.value = 0;
      this.isShow = false;
      this.isSync = false;
      this.scale = 1;
      this.$emit('on-close', {});
    },
    onChangePage(direction) {
      this.changePage(direction);
      this.mouseout();
    },
    // 键盘切换页面
    changePage(direction) {
      this.reset();
      this.scale = 1;
      let value = this.value;
      if (
        (value === 0 && direction === '-') ||
        (value === this.data.items.length - 1 && direction === '+')
      ) {
        return;
      }
      direction === '-' ? value-- : value++;
      value =
        value === -1 ? 0 : value === this.data.items.length ? this.data.items.length - 1 : value;
      this.$nextTick(() => {
        this.value = value;
        this.onSync();
      });
    },
    onSync() {
      if (!this.isSync) {
        return;
      }
      const controlData = {
        pushId: this.data.items[this.value].groupId,
        value: this.value,
        control_type: 0
      };
      const params = {
        type: 'Resource',
        meetingId: this.data.meetingId,
        data: JSON.stringify(controlData)
      };
      this.$emit('on-sync', params);
    },
    onCancel() {
      this.scale = 1;
      if (screenfull.isEnabled) {
        screenfull.exit();
      }
      const controlData = {
        pushId: this.data.items[this.value].groupId,
        value: this.value,
        control_type: 2
      };
      const params = {
        type: 'Resource',
        meetingId: this.data.meetingId,
        data: JSON.stringify(controlData)
      };
      this.$emit('on-cancel', params);
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
    this.onSync();
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
// 轮播图样式
.list-enter-active,
.list-leave-active {
  transition: all 0.9s ease;
}
.list-enter-active,
.list-leave {
  opacity: 1;
}
.list-enter,
.list-leave-active {
  opacity: 0;
}
.gallery-rotationChart {
  position: absolute;
  top: 70px;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1190;
  overflow: auto;
  &-div {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    z-index: 1190;
    width: 100%;
    height: 100%;
    overflow: hidden;
    &-image {
      z-index: 1190;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 80px;
    }
  }
}
.vdr.active:before {
  outline: none;
}
.enlarge {
  z-index: 1190;
  position: absolute;
  top: 160px;
  right: 100px;
  height: 32px;
  width: 32px;
  background: white;
  opacity: 0.8;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: none;
  border: none;
  &:hover {
    background: darkgrey;
    opacity: 0.8;
  }
}
// 缩小
.narrow {
  top: 210px;
}
.buttonStyle {
  z-index: 1190;
  position: absolute;
  top: 300px;
  right: 100px;
  height: 32px;
  width: 32px;
  background: white;
  opacity: 0.8;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: none;
  border: none;
}
.galleryStyle {
  position: fixed;
  text-align: center;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1190;
  overflow-y: auto;
  height: 100%;
  &-center {
    top: 50%;
    transform: translateY(-50%);
    opacity: 1;
    z-index: 11909;
  }
}
// 页面样式
.gallery-container {
  opacity: 0.8;
  background: darkgrey;
  position: fixed;
  text-align: center;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1190;
  &-center {
    top: 50%;
    transform: translateY(-50%);
    > img {
      width: 100%;
      height: 100%;
    }
  }
  &-pageTotalNum {
    width: 76px;
    height: 32px;
    position: absolute;
    /* top: 50%; */
    bottom: 1%;
    left: 46%;
    background: #202020;
    z-index: 1190;
    color: white;
    opacity: 0.8;
    border-radius: 15px;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
  }
  &-samescreenbutton {
    display: flex;
    align-items: center;
    justify-content: space-around;
    position: absolute;
    bottom: 1%;
    left: 44%;
    width: 204px;
    height: 32px;
    background: #202020;
    z-index: 1190;
    color: white;
    opacity: 0.8;
    border-radius: 15px;
    &-leftimg {
      width: 32px;
      height: 32px;
      background: #202020;
      opacity: 0.8;
      color: white;
      border-radius: 10px;
      border: none;
      box-shadow: none;

      > img {
        width: 100%;
        height: 100%;
      }
    }
  }
}

.viewer-title-bar {
  height: 70px;
  width: 100%;
  position: absolute;
  top: 0;
  left: 0;
  background: black;
  font-size: 20px;
  color: #fff;
  display: flex;
  align-items: center;
  z-index: 1190;
  opacity: 1;
  &-close-btn {
    width: 70px;
    height: 70px;
    background: black;
    position: fixed;
    top: 0;
    right: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    &:hover {
      transition: 0.3s;
      cursor: pointer;
      background: rgb(46, 45, 45);
    }
  }
  &-samescreennow {
    z-index: 1190;
    position: absolute;
    right: 80px;
  }
}
.control-layer {
  z-index: 1190;
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  width: 100%;
  height: 70px;
  text-align: center;
  &-left {
    opacity: 0.6;
    background-color: black;
    height: 70px;
    width: 70px;
    margin: 5px 0;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 50px;
    position: fixed;
    top: 50%;
    left: 10px;
    color: white;
    &:hover {
      transition: 0.3s;
      cursor: pointer;
      background: darkgray;
    }
  }
  &-right {
    opacity: 0.6;
    background-color: black;
    height: 70px;
    width: 70px;
    margin: 5px 0;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 50px;
    position: fixed;
    top: 50%;
    right: 10px;
    color: white;
    &:hover {
      transition: 0.3s;
      cursor: pointer;
      background: darkgray;
    }
  }
}
</style>
