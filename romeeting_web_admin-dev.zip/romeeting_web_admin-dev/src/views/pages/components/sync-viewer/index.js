import PdfPlug from './pdf-plug.vue';
import Gallery from './gallery.vue';
import VideoPlayback from './video-playback.vue';
export { PdfPlug, Gallery, VideoPlayback };
