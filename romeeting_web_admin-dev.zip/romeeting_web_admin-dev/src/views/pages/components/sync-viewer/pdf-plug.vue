<template>
  <div v-if="isShow"
       ref="PDFViewer">
    <div class="page-container-background"></div>
    <div class="page-container">
      <div class="page-container-div"
           @mousemove="mouseout"
           id="container"
           @mousedown="move"
           ref="callCenter">
        <pdf :src="data.url"
             :page="currentPage"
             :scale="scale"
             :mode="showMode"
             @progress="loadedRatio = $event"
             @loaded="loadPdfHandler"
             @num-pages="pageCount = $event"
             @page-loaded="onPageLoaded($event)"
             ref="wrapper"
             class="page-container-pdf">
        </pdf>
      </div>
    </div>
    <Button v-show="bindShow"
            :class="{ select: idx == 0 }"
            @touchstart="idx = 0"
            @touchend="idx = -1"
            @click.prevent="enlarge"
            class="enlarge">
      <Icon type="ios-add-circle-outline" />
    </Button>
    <Button :disabled="narrowDisabled"
            v-show="bindShow"
            :class="{ select: idx == 1 }"
            @touchstart="idx = 1"
            @touchend="idx = -1"
            @click.prevent="narrow"
            class="enlarge narrow">
      <Icon type="ios-remove-circle-outline" />
    </Button>
    <div v-if="showMode === 'Normal'"
         class="page-container-pageTotalNum">
      {{ currentPage }} / {{ pageCount }}
    </div>
    <div v-else-if="showMode === 'Fullscreen'"
         class="page-container-samescreenbutton"
         v-show="bindShow">
      <div class="page-container-samescreenbutton-leftimg">
        <Tooltip :disabled="isFirstPage"
                 content="上一页"
                 placement="top"
                 style="width: 32px; height: 32px">
          <Button class="page-container-samescreenbutton-leftimg"
                  :disabled="isFirstPage"
                  :ghost="isFirstPage"
                  @click="onChangePage(0)">
            <img src="~@/assets/images/leftarrow@2x.png"
                 style="width: 32px; height: 32px; margin-left: -15px" />
          </Button>
        </Tooltip>
      </div>
      <div class="page-container-samescreenbutton-leftimg">
        <Tooltip :disabled="isLastPage"
                 content="下一页"
                 placement="top"
                 style="width: 32px; height: 32px">
          <Button class="page-container-samescreenbutton-leftimg"
                  :disabled="isLastPage"
                  :ghost="isLastPage"
                  @click="onChangePage(1)">
            <img src="~@/assets/images/rightarrow@2x.png"
                 style="width: 32px; height: 32px; margin-left: -15px" />
          </Button>
        </Tooltip>
      </div>
      <div>|</div>
      <div style="height: 32px; line-height: 32px; font-size: 14px; margin-right: 8px; cursor: pointer"
           @click="
          isSync = false;
          scale = 0;
        ">
        取消同屏
      </div>
    </div>
    <!-- 左右翻页开始 -->
    <div class="control-layer"
         v-if="showMode === 'Normal'">
      <div class="control-layer-left"
           v-show="!isFirstPage"
           @click="onChangePage(0)">
        <Tooltip content="上一页"
                 placement="top">
          <span>
            <Icon type="ios-arrow-back" />
          </span>
        </Tooltip>
      </div>
      <div class="control-layer-right"
           v-show="!isLastPage"
           @click="onChangePage(1)">
        <Tooltip content="下一页"
                 placement="top">
          <span>
            <Icon type="ios-arrow-forward" />
          </span>
        </Tooltip>
      </div>
    </div>
    <!-- 左右翻页结束 -->
    <div class="viewer-title-bar">
      <span style="margin-left: 10px">{{ this.data.filename }}</span>
      <!-- 右上角退出按钮开始 -->
      <span class="viewer-title-bar-close-btn"
            @click="onClose">
        <Tooltip content="关闭"
                 placement="bottom"
                 class="tooltipStyle">
          <p>
            <Icon type="md-close"
                  class="icon" />
          </p>
        </Tooltip>
      </span>
      <Button v-if="showSyncButton"
              type="primary"
              class="viewer-title-bar-samescreennow"
              @click.native="samesCreennow">立即同屏</Button>
      <!-- 右上角退出按钮退出 -->
    </div>
  </div>
</template>
<script>
import pdf from './components/vue-pdf';
import { Icon, Tooltip, Button } from 'view-design';
import screenfull from 'screenfull';
export default {
  data() {
    return {
      showMode: 'Fullscreen',
      isShow: false,
      isSync: false,
      isFullscreen: false, // 默认不全屏,
      currentPage: 1, // 当前页码
      pageCount: null, // pdf总页码
      loadedRatio: 0,
      bindShow: true,
      timer: null,
      idx: -1,
      scale: 0,
      // 按下时的坐标
      startX: '',
      startY: '',
      // 抬起时的坐标
      endX: '',
      endY: '',
      initLeft: null,
      initTop: null
    };
  },
  props: {
    data: {
      // 文件类型（jpg，pdf）
      type: Object,
      default() {
        return {
          meetingId: 0,
          filename: '',
          groupId: 0,
          url: '',
          sync: true
        };
      }
    }
  },
  computed: {
    isFirstPage() {
      return this.currentPage === 1;
    },
    isLastPage() {
      return this.currentPage === this.pageCount;
    },
    narrowDisabled() {
      return this.scale < 0.0001;
    },
    showSyncButton() {
      if (this.showMode === 'Normal') {
        return this.data.sync === true;
      } else if (this.showMode === 'Fullscreen') {
        return this.data.sync === false;
      }
    }
  },
  watch: {
    isShow(newVal) {
      if (newVal) {
        window.addEventListener('resize', this.resize);
        document.addEventListener('keydown', this.keyDown);
      } else {
        window.removeEventListener('resize', this.resize);
        document.removeEventListener('keydown', this.keyDown);
      }
    },
    isSync(value) {
      if (!value) {
        this.onCancel();
      }
    }
  },
  components: {
    pdf,
    Icon,
    Tooltip,
    screenfull,
    Button
  },
  methods: {
    // 刷新页面
    reset() {
      this.$nextTick(() => {
        this.$refs.callCenter.style.left = this.initLeft;
        this.$refs.callCenter.style.top = this.initTop;
        this.scale = 0;
      });
    },
    // 拖动窗口,鼠标按下
    move(event) {
      if (this.narrowDisabled) {
        return false;
      }
      // 给对应div添加拖拽属性
      let callCenter = this.$refs.callCenter;
      callCenter.style.cursor = 'move';
      var distanceX = event.clientX - callCenter.offsetLeft;
      var distanceY = event.clientY - callCenter.offsetTop;
      // 获取按下时对应的坐标
      this.startX = event.pageX;
      this.startY = event.pageY;

      document.onmousemove = ev => {
        var oevent = ev || event;
        callCenter.style.left = oevent.clientX - distanceX + 'px';
        callCenter.style.top = oevent.clientY - distanceY + 'px';
      };
      document.onmouseup = () => {
        document.onmousemove = null;
        document.onmouseup = null;
        callCenter.style.cursor = 'default';
      };
    },
    // 放大
    enlarge() {
      this.scale += 0.1;
      this.mouseout();
    },
    // 缩小
    narrow() {
      if (this.narrowDisabled) {
        return;
      }
      this.scale += -0.1;
      this.narrowDisabled && this.reset();
      this.mouseout();
    },
    // 鼠标移动
    mouseout() {
      this.bindShow = true;
      this.timer && window.clearTimeout(this.timer);
      this.timer = window.setTimeout(() => {
        // 鼠标没有操作超过5秒，执行隐藏
        this.bindShow = false;
      }, 5000);
    },
    // 立即同屏
    samesCreennow() {
      this.reset();
      this.syncShow();
    },
    keyDown(e) {
      e = e || window.event;
      switch (e.keyCode) {
        case 37: // 左键
          this.changePage(0);
          break;
        case 38: // 向上键
          this.changePage(0);
          break;
        case 39: // 右键
          this.changePage(1);
          break;
        case 40: // 向下键
          this.changePage(1);
          break;
        default:
          break;
      }
    },
    resize() {
      this.$nextTick(() => {
        if (!screenfull.isFullscreen) {
          this.showMode = 'Normal';
          this.isSync = false;
          this.reset();
        } else {
          this.showMode = 'Fullscreen';
          this.isSync = true;
        }
      });
    },
    // 全屏操作
    clickFullscreen() {
      if (!screenfull.isEnabled) {
        this.$message({
          message: '',
          type: 'warning'
        });
        return false;
      }
      screenfull.request();
    },
    show() {
      this.currentPage = this.currentPage || 1;
      this.isShow = true;
      this.showMode = 'Normal';
    },
    syncShow() {
      this.currentPage = this.currentPage || 1;
      this.isShow = true;
      this.$nextTick(() => {
        this.clickFullscreen();
      });
    },
    // 右上角关闭按钮----整页退出全屏
    onClose() {
      if (screenfull.isEnabled) {
        screenfull.exit();
      }
      this.currentPage = 1;
      this.isShow = false;
      this.isSync = false;
      this.scale = 0; // 点击关闭按钮,倍数初始化
      this.$emit('on-close', {});
    },
    pageSize(event) {
      window.console.log('page size ===>', event);
    },
    // PDF文件page-loaded的事件
    onPageLoaded(currentPage) {
      this.onSync(currentPage);
    },
    onSync(currentPage) {
      if (!this.isSync) {
        return;
      }
      const controlData = {
        pushId: this.data.groupId,
        value: currentPage - 1,
        control_type: 0
      };
      const params = {
        type: 'Resource',
        meetingId: this.data.meetingId,
        data: JSON.stringify(controlData)
      };
      this.$emit('on-sync', params);
    },
    onCancel() {
      if (screenfull.isEnabled) {
        screenfull.exit();
      }
      this.scale = 0;
      const controlData = {
        pushId: this.data.groupId,
        value: this.currentPage - 1,
        control_type: 2
      };
      const params = {
        type: 'Resource',
        meetingId: this.data.meetingId,
        data: JSON.stringify(controlData)
      };
      this.$emit('on-cancel', params);
    },
    // 改变PDF页码,val传过来区分上一页下一页的值,0上一页,1下一页
    onChangePage(val) {
      this.changePage(val);
      this.mouseout();
    },
    // 键盘切换翻页
    changePage(val) {
      this.reset();
      this.scale = 0; // 倍数初始化
      if (
        (this.currentPage === 1 && val === 0) ||
        (this.currentPage === this.pageCount && val === 1)
      ) {
        return;
      }
      if (val === 0 && this.currentPage > 1) {
        this.currentPage--;
      }

      if (val === 1 && this.currentPage < this.pageCount) {
        this.currentPage++;
      }
    },
    // pdf加载时
    loadPdfHandler(e) {
      this.currentPage = this.currentPage || 1; // 加载的时候先加载第一页
    }
  },
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
    clearInterval(this.timer);
    this.timer = null;
  }
};
</script>
<style lang="less" scoped>
// 头部样式
.viewer-title-bar {
  height: 70px;
  width: 100%;
  position: absolute;
  top: 0;
  left: 0;
  background: black;
  font-size: 20px;
  color: #fff;
  display: flex;
  // justify-content: center;
  align-items: center;
  z-index: 1190;
  &-close-btn {
    width: 70px;
    height: 70px;
    background: black;
    position: fixed;
    top: 0;
    right: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1190;
    color: white;
    &:hover {
      transition: 0.3s;
      cursor: pointer;
      background: rgb(46, 45, 45);
    }
  }
  &-samescreennow {
    position: absolute;
    right: 80px;
  }
}

// 页面样式
.page-container {
  position: absolute;
  top: 70px;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1190;
  overflow: auto;
  &-div {
    position: absolute;
    left: 0;
    z-index: 1190;
    width: 100%;
    height: 100%;
  }
  &-background {
    opacity: 0.8;
    background: darkgrey;
    position: fixed;
    top: 64px;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 1190;
  }
  &-pdf {
    z-index: 1190;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  &-pageTotalNum {
    width: 76px;
    height: 32px;
    position: absolute;
    /* top: 50%; */
    bottom: 1%;
    left: 46%;
    background: #202020;
    z-index: 1190;
    color: white;
    opacity: 0.8;
    border-radius: 15px;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
  }
  &-samescreenbutton {
    display: flex;
    align-items: center;
    justify-content: space-around;
    position: absolute;
    /* top: 50%; */
    bottom: 1%;
    left: 44%;
    width: 204px;
    height: 32px;
    background: #202020;
    z-index: 1190;
    color: white;
    opacity: 0.8;
    border-radius: 15px;
    &-leftimg {
      width: 32px;
      height: 32px;
      background: #202020;
      opacity: 0.8;
      color: white;
      // outline: none;
      border-radius: 10px;
      border: none;
      box-shadow: none;
      > img {
        width: 100%;
        height: 100%;
      }
    }
  }
}
// 放大按钮
.enlarge {
  z-index: 1190;
  position: absolute;
  top: 160px;
  right: 100px;
  height: 32px;
  width: 32px;
  background: white;
  opacity: 0.8;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: none;
  border: none;
  &:hover {
    background: darkgrey;
    opacity: 0.8;
  }
}
// 缩小
.narrow {
  top: 210px;
}
// 左右翻页箭头样式
.control-layer {
  position: absolute;
  text-align: center;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1190;
  &-left {
    opacity: 0.6;
    background-color: black;
    height: 70px;
    width: 70px;
    margin: 5px 0;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 50px;
    position: fixed;
    top: 50%;
    left: 10px;
    color: white;

    &:hover {
      transition: 0.3s;
      cursor: pointer;
      background: darkgray;
    }
  }
  &-right {
    opacity: 0.6;
    background-color: black;
    height: 70px;
    width: 70px;
    margin: 5px 0;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 50px;
    position: fixed;
    top: 50%;
    right: 10px;
    color: white;
    &:hover {
      transition: 0.3s;
      cursor: pointer;
      background: darkgray;
    }
  }
}
</style>
