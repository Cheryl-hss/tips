import TitleBar from './title-bar.vue';

export default TitleBar;
