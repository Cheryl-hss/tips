<template>
  <div>
    <div class="title-bar">
      <div class="title-bar-content">
        <div v-if="showToBack"
             class="title-bar-content-icon"
             @click="toBack"></div>
        <div class="title-bar-content-thumb">{{ name }}</div>
        <slot name="content"
              class="title-bar-content-center"></slot>
        <div class="title-bar-content-button">
          <slot name="button"></slot>
        </div>
        <div v-if="showSetting"
             class="title-bar-content-tail"
             float-right
             @click="onClickSetting">
          <img src="@/assets/images/icon-setting@2x.png" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  // 不要忘记了 name 属性
  name: 'TitleBar',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    name: {
      // titlebar 名称
      type: String,
      default: ''
    },

    showSetting: {
      // 是否显示设置
      type: Boolean,
      default() {
        return false;
      }
    },

    showToBack: {
      // 是否显示返回按钮
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {};
  },

  // 使用其它组件
  components: {},
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    // 返回主页
    toBack() {
      this.$emit('to-back');
    },

    // 点击设置
    onClickSetting() {
      this.$emit('on-click-setting');
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
.title-bar {
  position: relative;
  width: 100%;
  height: 64px;
  background: #ffffff;
  border-bottom: 1px solid #dcdee2;
  padding: 16px 50px;
  z-index: 1000;

  &-content {
    display: flex;
    height: 32px;
    line-height: 32px;

    &-icon {
      float: left;
      width: 32px;
      height: 32px;
      background: url('~@/assets/images/icon-back@2x.png');
      background-repeat: no-repeat;
      background-position: center;
      background-size: 32px 32px;
      cursor: pointer;
      margin-right: 16px;
    }

    &-thumb {
      font-family: PingFangSC-Medium;
      font-size: 20px;
      color: #333333;
      font-weight: 550;
      margin-right: 24px;
    }

    &-center {
      display: inline-block;
    }

    &-button {
      position: absolute;
      top: 50%;
      right: 50px;
      margin-top: -16px;
    }

    &-tail {
      position: absolute;
      top: 50%;
      right: 50px;
      width: 18px;
      height: 18px;
      cursor: pointer;
      margin-top: -9px;

      > img {
        width: 100%;
        height: 100%;
      }
    }
  }
}
</style>
