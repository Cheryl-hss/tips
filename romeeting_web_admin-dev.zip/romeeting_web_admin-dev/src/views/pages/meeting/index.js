import Meeting from './meeting';

export default Meeting;
