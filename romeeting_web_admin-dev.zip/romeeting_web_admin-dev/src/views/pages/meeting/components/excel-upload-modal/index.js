import ExcelUplodModal from './excel-upload-modal.vue';

export default ExcelUplodModal;
