<template>
  <div v-if="value">
    <Modal :value="value"
           :mask-closable="false"
           :width="550"
           @on-visible-change="onChange">
      <p slot="header"
         class="header">
        <span>通过Excel导入参会人</span>
      </p>
      <div slot="close"
           @click="onClose"
           class="margin-right">
        <Icon type="ios-close"
              :size="35"
              color="#999999" />
      </div>

      <div class="excel-body">
        <div v-if="status === 'upload'">
          <div class="excel-body-content">
            <Upload ref="uploader"
                    :action="uploadURL"
                    accept=".xls, .xlsx"
                    :format="['.xls', '.xlsx']"
                    :before-upload="beforeUpload">
              <Button>
                <div class="upload-entrance-btn">
                  <div class="upload-entrance-btn-icon margin-right-4">
                    <img src="~@/assets/images/icon-upload@2x.png" />
                  </div>
                  {{$t('meeting_content_upload_file')}}
                </div>
              </Button>
            </Upload>

            <div class="excel-body-content-text">仅支持xls、xlsx格式文件</div>
            <div>
              <span class="excel-body-content-download"
                    @click="downloadTemplate"> 下载模板 </span>
            </div>
          </div>
          <div class="excel-body-footer">请使用模板样式导入参会人，不要随意修模板改文件列</div>
        </div>

        <div v-if="status === 'reupload'"
             class="excel-file">
          <Row class="excel-file-item">
            <Col span="24">
            <div class="excel-file-item-left">
              <img src="~@/assets/images/file-zip@2x.png" />
            </div>
            <div class="excel-file-item-center margin-left">
              <div class="excel-file-item-center-title"
                   :title="fileData.name ">{{ fileData.name }}</div>
              <div class="excel-file-item-center-body">
                <span> {{ fileData.size && changeSize(fileData.size) }}</span>
              </div>
            </div>
            </Col>
            <div class="excel-file-item-right">
              <Upload ref="uploader"
                      :action="uploadURL"
                      accept=".xls, .xlsx"
                      :format="['.xls', '.xlsx']"
                      :before-upload="beforeUpload">
                <div class="excel-body-content-download">
                  更换文件
                </div>
              </Upload>
            </div>
          </Row>
          <div class="excel-body-footer">新导入的参会人不会覆盖已添加的数据</div>
        </div>

        <div v-if="status === 'result'"
             class="result">
          <div class="result-top">
            <div class="result-top-icon">
              <img v-if="success"
                   src="@/assets/images/icon-success@2x.png" />
              <img v-else
                   src="@/assets/images/icon-error@2x.png" />
            </div>
            <div v-if="success"
                 class="result-top-text">导入成功</div>
            <div v-else
                 class="result-top-text">无法导入</div>
          </div>
          <div v-if="success">已成功导入 {{ list.length }} 个参会人，请在名字设置列表中确认</div>
          <div v-else>文件损坏或内容有误，请重新上传新的文件</div>
        </div>
      </div>

      <div slot="footer">
        <Button v-if="status !== 'result'"
                class="button-width"
                @click="onClose">取消</Button>
        <Button v-if="status === 'result'"
                class="button-width"
                type="primary"
                @click="onOk">完成</Button>
        <Button v-else
                class="button-width"
                type="primary"
                :disabled="fileData.resourceId === null"
                @click="getExcelPerson">导入</Button>
      </div>
    </Modal>
  </div>
</template>

<script>
import { Modal, Icon, Upload, Button, Row, Col } from 'view-design';

import { deepCopy } from '@/utils/tools';

import MeetingApi from '@/api/meeting';
import { uploadToOSS, getOssResourse, getExcelPerson } from '@/api/upload';

export default {
  // 不要忘记了 name 属性
  name: 'ExcelUplodModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序

    value: {
      // 是否显示模态框
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      status: 'upload', // 页面显示状态（上传界面、替换界面、已上传页面）
      success: true,
      list: [], // 上传excel文件后获取的参会人列表
      uploadURL: '', // 上传Excel路径
      fileData: {
        resourceId: null,
        name: '',
        size: null
      } // 文件数据
    };
  },

  // 使用其它组件
  components: { Modal, Icon, Upload, Button, Row, Col },
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    // 关闭对话框
    onClose() {
      this.$emit('on-close');
    },

    // 确定选项并关闭对话框
    onOk() {
      this.$emit('on-ok', this.list);
    },

    // 显示状态发生变化时触发
    onChange(value) {
      if (!value) {
        this.onClose();
      }
    },

    // 下载模板
    downloadTemplate() {
      const vm = this;
      const userId = this.$store.state.user.userId;
      const key = `meeting/meeting_person_template.xlsx`;
      let downloadUrl = null;
      getOssResourse(userId, { key })
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            downloadUrl = deepCopy(data);
            let downloadFile = {};
            if (typeof downloadFile.iframe === 'undefined') {
              const iframe = document.createElement('a');
              iframe.setAttribute('target', '_blank');
              iframe.setAttribute('download', 'meeting_person_template.xlsx');
              downloadFile.iframe = iframe;
              document.body.appendChild(downloadFile.iframe);
            }
            downloadFile.iframe.href = downloadUrl;
            downloadFile.iframe.click();
            downloadFile.iframe.style.display = 'none';
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '模板下载失败，请重试！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          window.console.log(err);
        });
    },

    // 上传excel文件
    beforeUpload(file) {
      const vm = this;
      uploadToOSS(file).then(res => {
        // 1、创建oss资源 ，拿到资源id，push到 resourceIds
        // 2、拿返回的objectKey去请求资源，得到资源路径，显示出来

        // 获取用户id
        const userId = vm.$store.state.user.userId;
        // 获取创建资源参数
        const data = {
          fileKey: res.key,
          name: file.name,
          size: file.size,
          desc: file.desc,
          md5: res.md5,
          fileType: 'Excel'
        };

        // 发送创建资源请求
        MeetingApi.saveResourse(userId, data)
          .fetch()
          .then(({ success, msg, data }) => {
            //
            if (success) {
              if (!data.resourceId) {
                vm.$Message.destroy();
                vm.$Message.warning({
                  content: '“' + file.name + '”' + '上传失败！',
                  duration: 5,
                  closable: true
                });
                return;
              }

              // 把返回的资源key值赋值
              vm.fileData = {
                resourceId: data.resourceId,
                name: file.name,
                size: file.size
              };
              vm.list = [];
              vm.status = 'reupload';
            } else {
              vm.$Message.destroy();
              vm.$Message.error({
                content: msg || '“' + file.name + '”' + '上传失败，请重试！',
                duration: 5,
                closable: true
              });
            }
          })
          .catch(err => {
            vm.$Message.destroy();
            vm.$Message.error({
              content: err.msg || '“' + file.name + '”' + '上传失败，请重试！',
              duration: 5,
              closable: true
            });
          });
      });
    },

    // 用上传资源获取的key去请求excel文件内的参会人列表
    getExcelPerson() {
      const vm = this;
      getExcelPerson(vm.fileData.resourceId)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            vm.list = deepCopy(data);
            vm.success = true;
          } else {
            vm.success = false;
          }
          vm.status = 'result';
        })
        .catch(err => {
          window.console.log(err.msg);
          vm.status = 'result';
          vm.success = false;
        });
    },

    // 转换资源大小值
    changeSize(limit) {
      var size = '';
      if (limit < 0.1 * 1024) {
        // 小于0.1KB，则转化成B
        size = limit.toFixed(2) + 'B';
      } else if (limit < 0.1 * 1024 * 1024) {
        // 小于0.1MB，则转化成KB
        size = (limit / 1024).toFixed(2) + 'KB';
      } else if (limit < 0.1 * 1024 * 1024 * 1024) {
        // 小于0.1GB，则转化成MB
        size = (limit / (1024 * 1024)).toFixed(2) + 'MB';
      } else {
        // 其他转化成GB
        size = (limit / (1024 * 1024 * 1024)).toFixed(2) + 'GB';
      }

      var sizeStr = size + ''; // 转成字符串
      var index = sizeStr.indexOf('.'); // 获取小数点处的索引
      var dou = sizeStr.substr(index + 1, 2); // 获取小数点后两位的值
      if (dou === '00') {
        // 判断后两位是否为00，如果是则删除00
        return sizeStr.substring(0, index) + sizeStr.substr(index + 3, 2);
      }
      return size;
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.excel-body {
  height: 200px;
  width: 100%;

  &-content {
    padding-top: 30px;
    text-align: center;

    &-text {
      height: 32px;
      line-height: 36px;
      font-family: PingFangSC-Medium;
      font-weight: 500;
    }

    &-download {
      color: #0050ff;
      cursor: pointer;
    }
  }

  &-footer {
    position: absolute;
    bottom: 70px;
    font-family: PingFangSC-Medium;
    font-weight: 500;
  }
}

.excel-file {
  padding-top: 42px;
  &-item {
    background: #f6f7f8;
    border-radius: 4px;
    padding: 8px;

    &-left {
      width: 48px;
      height: 48px;
      float: left;
      > img {
        width: 100%;
        height: 100%;
      }
    }

    &-center {
      float: left;
      width: ~'calc(100% - 100px)';

      &-title {
        font-family: PingFangSC-Medium;
        font-size: 14px;
        font-weight: 550;
        width: 100%;
        color: #333333;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      &-body {
        font-family: PingFangSC-Regular;
        font-size: 12px;
        color: #999999;
        margin-top: 6px;
        width: 100%;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
    }

    &-right {
      width: 64px;
      position: absolute;
      right: 46px;
      top: 132px;
    }
  }
}

.result {
  padding-top: 50px;
  text-align: center;

  &-top-text {
    font-weight: 550;
    margin-bottom: 14px;
  }
}
</style>
