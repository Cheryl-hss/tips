<template>
  <div>
    <div class="battery">
      <div class="battery-right">
        <div class="battery-right-icon">
          <img :src="batterysrc" />
        </div>
        <div class="battery-right-title"
             :class="this.battery <= 20 ? 'red' : 'default'">{{ battery + '%' }}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  // 不要忘记了 name 属性
  name: 'Battery',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    resuorcesNum: Number,
    battery: Number
  },
  // 变量
  data() {
    return {};
  },

  // 使用其它组件
  components: {},
  // 计算属性
  computed: {
    batterysrc() {
      if (this.battery <= 10) {
        return require(`@/assets/images/battery/battery_0%@2x.png`);
      } else if (this.battery <= 20) {
        return require(`@/assets/images/battery/battery_10%@2x.png`);
      } else if (this.battery <= 30) {
        return require(`@/assets/images/battery/battery_20%@2x.png`);
      } else if (this.battery <= 40) {
        return require(`@/assets/images/battery/battery_30%@2x.png`);
      } else if (this.battery <= 50) {
        return require(`@/assets/images/battery/battery_40%@2x.png`);
      } else if (this.battery <= 60) {
        return require(`@/assets/images/battery/battery_50%@2x.png`);
      } else if (this.battery <= 70) {
        return require(`@/assets/images/battery/battery_60%@2x.png`);
      } else if (this.battery <= 80) {
        return require(`@/assets/images/battery/battery_70%@2x.png`);
      } else if (this.battery <= 90) {
        return require(`@/assets/images/battery/battery_80%@2x.png`);
      } else if (this.battery <= 95) {
        return require(`@/assets/images/battery/battery_90%@2x.png`);
      } else if (this.battery < 100) {
        return require(`@/assets/images/battery/battery_95%@2x.png`);
      } else if (this.battery === 100) {
        return require(`@/assets/images/battery/battery_100%@2x.png`);
      }
    }
  },
  // 监听
  watch: {},
  // 方法
  methods: {
    red() {
      if (this.battery <= 20) {
        return true;
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
.battery {
  &-right {
    display: inline-flex;
    &-icon {
      width: 22px;
      height: 22px;
      > img {
        width: 100%;
        height: 100%;
      }
    }
    &-title {
      font-family: PingFangSC-Regular;
      font-size: 12px;
      line-height: 22px;
    }
  }
}

.red {
  color: #f02a2a;
  background: #fff;
}

.default {
  color: #666666;
  background: #fff;
}
</style>
