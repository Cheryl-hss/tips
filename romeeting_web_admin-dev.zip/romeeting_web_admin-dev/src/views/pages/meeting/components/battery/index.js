import Battery from './battery.vue';

export default Battery;
