<template>
  <div v-if="value">
    <Modal :value="value"
           :closable="false"
           footer-hide
           :width="400">
      <div class="end-content">
        <div class="end-content-top">
          <div class="end-content-top-icon">
            <img src="@/assets/images/icon-success@2x.png" />
          </div>
        </div>
        <div class="end-content-center">
          <div class="end-content-center-text">{{ $t('metting_finished') }}</div>
        </div>
        <div class="end-content-bottom">
          <Button class="margin-right-20"
                  size="large"
                  @click="onControlToHome">
            {{ $t('metting_end_to_home') }}
            <span>{{ '(' + countdown + ')' }}</span>
          </Button>
          <Button class="margin-left-20"
                  type="primary"
                  size="large"
                  @click="onControlDevShutdown">
            {{ $t('metting_end_shutdown') }}
          </Button>
        </div>
      </div>

    </Modal>
  </div>
</template>

<script>
import { Modal, Button } from 'view-design';

export default {
  // 不要忘记了 name 属性
  name: 'MeetingEndModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    value: Boolean, // 是否显示
    countdown: {
      // 倒计时，秒
      type: Number,
      default() {
        return 5;
      }
    }
  },
  // 变量
  data() {
    return {};
  },

  // 使用其它组件
  components: { Modal, Button },
  // 计算属性
  computed: {},
  // 监听
  watch: {
    countdown(newVal) {
      if (newVal === 0) {
        this.onControlToHome();
      }
    }
  },
  // 方法
  methods: {
    // 控制设备返回首页
    onControlToHome() {
      this.$emit('on-control-to-home');
    },

    // 控制设备批量关机
    onControlDevShutdown() {
      this.$emit('on-control-dev-shutdown');
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.end-content {
  &-top {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 30px;
    &-icon {
      width: 35px;
      height: 35px;
      > img {
        width: 100%;
        height: 100%;
      }
    }
  }

  &-center {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 30px;
    &-text {
      font-size: 20px;
      color: #333333;
      line-height: 24px;
      text-align: center;
    }
  }

  &-bottom {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 30px;
    margin-bottom: 30px;
  }
}
</style>
