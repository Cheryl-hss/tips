import MeetingEndModal from './meeting-end-modal.vue';

export default MeetingEndModal;
