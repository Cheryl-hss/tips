import VoteResultItem from './vote-result-item.vue';

export default VoteResultItem;
