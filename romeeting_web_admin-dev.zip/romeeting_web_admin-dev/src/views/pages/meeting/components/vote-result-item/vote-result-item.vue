<template>
  <div>
    <div class="option">
      <RadioGroup class="option-radio"
                  v-model="option"
                  type="button">
        <Radio class="custom-radio"
               v-for="(item, index) in optionList"
               :label="item.value"
               :key="index">{{ item.name }}</Radio>
      </RadioGroup>
      <div v-if="!voteData.anonymous"
           class="option-text border">
        <span v-if="option === 'optionA'"
              v-for="(person, index) in voteData.optionA.persons"
              :key="index">{{ person.personName }}</span>
        <span v-if="option === 'optionB'"
              v-for="(person, index) in voteData.optionB.persons"
              :key="index">{{ person.personName }}</span>
        <span v-if="option === 'optionC'"
              v-for="(person, index) in voteData.optionC.persons"
              :key="index">{{ person.personName }}</span>
        <span v-if="option === 'unknown'"
              v-for="(person, index) in voteData.unknown.persons"
              :key="index">{{ person.personName }}</span>
      </div>
      <div v-else
           class="option-text border">
        匿名投票
      </div>
    </div>
  </div>
</template>

<script>
import { RadioGroup, Radio } from 'view-design';

export default {
  // 不要忘记了 name 属性
  name: 'VoteResultItem',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    voteData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  // 变量
  data() {
    return {
      optionList: [
        { name: '赞成', value: 'optionA' },
        { name: '反对', value: 'optionB' },
        { name: '弃权', value: 'optionC' },
        { name: '未投票', value: 'unknown' }
      ],
      option: 'optionA' // 默认显示赞成选项
    };
  },

  // 使用其它组件
  components: { RadioGroup, Radio },
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {},
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.custom-radio {
  width: 120px;
  text-align: center;
  border-radius: 0;
}

.option {
  position: relative;
  top: -218px;
  left: 50%;
  width: 480px;
  height: 50px;
  background: #ffffff;
  &-radio {
    width: 480px;
  }

  &-text {
    font-family: PingFangSC-Regular;
    font-size: 14px;
    color: #666666;
    width: 480px;
    height: 160px;
    border-top: 0px;
    padding: 10px;
    background: #ffffff;
    > span {
      padding: 8px;
    }
  }
}
</style>
