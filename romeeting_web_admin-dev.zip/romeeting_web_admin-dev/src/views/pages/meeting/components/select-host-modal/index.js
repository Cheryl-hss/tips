import SelectHostModal from './select-host-modal.vue';

export default SelectHostModal;
