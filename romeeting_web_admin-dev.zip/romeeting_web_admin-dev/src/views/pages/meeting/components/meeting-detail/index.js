import MeetingDetail from './meeting-detail.vue';

export default MeetingDetail;
