<template>
  <div v-if="value">
    <Modal :value="value"
           class="keywords"
           :mask-closable="false"
           :width="500"
           @on-visible-change="onChange">
      <p slot="header"
         class="header">
        <span>{{ title }}</span>
      </p>
      <div slot="close"
           @click="onClose"
           class="margin-right">
        <Icon type="ios-close"
              :size="35"
              color="#999999" />
      </div>

      <Input v-model="data.title"
             placeholder="请输入标题" />
      <Input v-model="data.keyword"
             class="margin-top-12"
             type="textarea"
             :autosize="{ minRows: 10, maxRows: 16}"
             placeholder="请输入正文" />
      <div class="keywords-scope margin-top-16">
        <div class="keywords-scope-text">接收人：</div>
        <div class="keywords-scope-select">
          <Select v-model="data.personId">
            <Option v-for="(item, index) in userList"
                    :value="item.id"
                    :key="index">{{ item.name }}</Option>
          </Select>
        </div>
      </div>
      <div slot="footer">
        <Button class="button-width"
                @click="onClose">取消</Button>
        <Button v-if="data.title && data.keyword &&  data.personId"
                class="button-width"
                type="primary"
                @click="onOk">保存</Button>
        <Button v-else
                class="button-width"
                disabled>保存</Button>
      </div>
    </Modal>
  </div>
</template>

<script>
import { Modal, Icon, Button, Input, RadioGroup, Radio, Select, Option } from 'view-design';

export default {
  // 不要忘记了 name 属性
  name: 'KeywordModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    value: {
      // 是否显示
      type: Boolean,
      default() {
        return false;
      }
    },

    data: {
      // 提词器数据
      type: Object,
      default() {
        return {};
      }
    },

    userList: {
      // 可选参会人
      type: Array,
      default() {
        return [];
      }
    },

    title: String // 模态框标题
  },
  // 变量
  data() {
    return {
      selectScope: 'assign' // 设置默认选中所以用户
    };
  },

  // 使用其它组件
  components: {
    Modal,
    Icon,
    Button,
    Input,
    RadioGroup,
    Radio,
    Select,
    Option
  },
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    // 关闭对话框
    onClose() {
      this.$emit('on-close');
    },

    onOk() {
      this.$emit('on-ok', this.data);
    },

    // 显示状态发生变化时触发
    onChange(value) {
      if (!value) {
        this.onClose();
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.keywords {
  .ivu-modal-body {
    padding: 32px 32px;
  }

  &-scope {
    display: inline-flex;

    &-text {
      height: 32px;
      line-height: 32px;
    }

    &-select {
      width: 100px;
      margin-left: 12px;
    }
  }
}
</style>
