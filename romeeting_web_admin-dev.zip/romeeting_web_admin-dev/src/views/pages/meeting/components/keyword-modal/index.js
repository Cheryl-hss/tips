import KeywordModal from './keyword-modal.vue';

export default KeywordModal;
