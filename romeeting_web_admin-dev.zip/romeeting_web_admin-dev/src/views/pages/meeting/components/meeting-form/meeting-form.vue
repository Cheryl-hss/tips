<template>
  <div v-if="value">
    <div class="title-bar-header">
      <TitleBar ref="titleBar"
                :name="name"
                show-to-back
                @to-back="onEditCancle">
        <div slot="button">
          <Button v-if="formType === 'add_2'"
                  class="margin-right"
                  :disabled="!formDataCopy.name || !formDataCopy.devices.length"
                  @click="onDelete">
            {{ $t('meeting_add_delete') }}
          </Button>
          <Button v-if="formType === 'add' || formType === 'add_2'"
                  class="margin-right"
                  :disabled="!formDataCopy.name || !formDataCopy.devices.length"
                  @click="addMeeting(formDataCopy, false)">
            {{ $t('meeting_add_save') }}
          </Button>
          <Button v-if="formType === 'edit'"
                  type="primary"
                  :disabled="!formDataCopy.name || !formDataCopy.devices.length"
                  icon="md-paper-plane"
                  @click="addMeeting(formDataCopy, true)">
            {{ $t('meeting_edit_meeting') }}
          </Button>
          <Button v-else
                  type="primary"
                  :disabled="!formDataCopy.name || !formDataCopy.devices.length"
                  icon="md-paper-plane"
                  @click="addMeeting(formDataCopy, true)">
            {{ $t('meeting_add_meeting') }}
          </Button>
        </div>
      </TitleBar>
    </div>
    <Form ref="mainForm"
          :model="formDataCopy"
          :rules="ruleValidate"
          :label-width="100"
          @submit.native.prevent>
      <div class="form-content">
        <div class="form-content-thumb">
          <Row :gutter="60">
            <Col span="7">
            <FormItem :label="$t('meeting_name')"
                      prop="name">
              <Input v-model="formDataCopy.name"
                     ref="name"
                     placeholder="必填"
                     maxlength="24"
                     @click.native="focusInput('name')"
                     @on-keydown="showMessageOfOverLimit($event, formDataCopy.name, 24, '会议名称' )" />
            </FormItem>
            </Col>
            <Col span="17"
                 float-right
                 style="display: inline-flex; justify-content: flex-end;">
            <FormItem :label="$t('meeting_date')"
                      prop="date">
              <DatePicker :value="formDataCopy.date"
                          :options="optionsDate"
                          type="date"
                          format="yyyy-MM-dd"
                          :clearable="false"
                          :capture="false"
                          :placeholder="$t('meeting_start_date')"
                          @on-change="onChangeDate"
                          style="width: 140px" />
            </FormItem>
            <FormItem :label="$t('meeting_time')"
                      prop="time">
              <TimePicker :value="formDataCopy.startTime"
                          format="HH:mm"
                          :capture="false"
                          :placeholder="$t('meeting_start_time')"
                          @on-change="onChangeStartTime"
                          style="width: 140px" />
              -
              <TimePicker class="margin-right"
                          :value="formDataCopy.endTime"
                          format="HH:mm"
                          :capture="false"
                          :placeholder="$t('meeting_end_time')"
                          @on-change="onChangeEndTime"
                          style="width: 140px" />
            </FormItem>

            </Col>
          </Row>
        </div>
        <div class="form-content-attendee">
          <div class="form-content-attendee-header">

            <div class="form-content-attendee-header-title">
              <div class="form-content-attendee-header-title-icon">
                <img src="~@/assets/images/icon-set-name@2x.png" />
              </div>
              <div class="form-content-attendee-header-title-text">{{ $t('meeting_name_setting') }}</div>
            </div>

            <div class="form-content-attendee-header-button">
              <div class="form-content-attendee-header-button-center">
                <Checkbox v-model="showDefaultDeviceName">
                  <span class="margin-left-6">{{ $t('meeting_default_device_name') }}</span>
                </Checkbox>
              </div>
              <Button class="margin-left"
                      @click="openSelectHostModal">
                <div class="form-content-attendee-header-button-right">
                  <div class="form-content-attendee-header-button-right-icon">
                    <img src="~@/assets/images/icon-host@2x.png" />
                  </div>
                  <div v-if="formDataCopy.host"
                       class="form-content-attendee-header-button-right-text"> 主持人： {{ hostName }}</div>
                  <div v-else
                       class="form-content-attendee-header-button-right-text"> {{ $t('meeting_appointed_presenter') }}</div>

                </div>
              </Button>
              <Dropdown class="margin-left"
                        @on-click="onClickImport">
                <Button>
                  <div class="form-content-attendee-header-button-right">
                    <div class="form-content-attendee-header-button-right-icon">
                      <img src="~@/assets/images/icon-bulk-import@2x.png" />
                    </div>
                    <div class="form-content-attendee-header-button-right-text"> {{ $t('meeting_bulk_import') }}</div>
                  </div>
                </Button>
                <DropdownMenu slot="list">
                  <DropdownItem name="persons">
                    {{ $t('meeting_bulk_import_persons') }}
                  </DropdownItem>
                  <DropdownItem name="devices">
                    {{ $t('meeting_bulk_import_devices') }}
                  </DropdownItem>
                </DropdownMenu>
              </Dropdown>
              <Button class="margin-left"
                      @click="openExcelUploadModal">
                Excel导入
              </Button>
            </div>
          </div>
          <div class="form-content-attendee-body">
            <Table :columns="columns"
                   :data="formDataCopy.devices">

              <template slot-scope="{ row, index }"
                        slot="name">
                <Form v-if="row._editing"
                      :ref="'nameForm_' + index"
                      :model="formDataCopy.devices[index]._copy.person"
                      @submit.native.prevent>
                  <FormItem prop="name"
                            :label-width="0"
                            :show-message="false"
                            :rules="{ required: true, message: '必填', trigger: 'change'}">

                    <div style="display: flex;">
                      <span style="color: #F02A2A; margin-right: 4px;">*</span>
                      <AutoComplete v-model="formDataCopy.devices[index]._copy.person.name"
                                    :transfer="true"
                                    :events-enabled="true"
                                    :capture="false"
                                    placeholder="姓名"
                                    style="width: 100%;"
                                    @on-select="onSelectAttendee($event, formDataCopy.devices[index]._copy, index)"
                                    @on-focus="getAttendeeList"
                                    @on-blur="onBlurAttendee($event, formDataCopy.devices[index]._copy)"
                                    @on-change="showPersonNameMessage(formDataCopy.devices[index]._copy, 24, '姓名' )">
                        <Option v-if="!attendeeList.length"
                                :value="0"
                                disabled>请手动输入</Option>
                        <Option v-else
                                v-for="item in attendeeList"
                                :value="item.id"
                                :key="item.id">{{ item.name }}</Option>

                      </AutoComplete>
                    </div>

                  </FormItem>
                </Form>

                <span v-else>{{ row.person.name }}</span>
              </template>

              <template slot-scope="{ row, index }"
                        slot="company">
                <Input v-model="formDataCopy.devices[index]._copy.person.company"
                       v-if="row._editing"
                       :ref="'company_'+ index"
                       placeholder="公司"
                       maxlength="16"
                       @click.native="focusInput('company_'+ index)"
                       @on-keydown="showMessageOfOverLimit($event,formDataCopy.devices[index]._copy.person.company, 16, '公司' )" />
                <span v-else>{{ row.person.company || '-' }}</span>
              </template>

              <template slot-scope="{ row, index }"
                        slot="logo">
                <div v-if="row._editing"
                     @click="getUploadIndex(index)">
                  <Upload class="margin-top-10"
                          action=""
                          accept=".jpg, .png"
                          :format="['.jpg', '.png']"
                          :before-upload="beforeUpload"
                          ref="uploader">
                    <div v-if="row._copy.person.logo"
                         :title="$t('meeting_select_logo')"
                         class="table-icon pointer margin-top-2">
                      <img :src="row._copy.person.logoUrl" />
                    </div>
                    <Button v-else
                            type="info"
                            size="small"
                            ghost>{{$t('meeting_select_logo')}}</Button>
                  </Upload>
                </div>
                <div v-else
                     class="table-icon">
                  <img v-if="row.person.logoUrl"
                       :src="row.person.logoUrl" />
                  <span v-else></span>
                </div>
              </template>

              <template slot-scope="{ row, index }"
                        slot="position">
                <Input v-model="formDataCopy.devices[index]._copy.person.position"
                       v-if="row._editing"
                       :ref="'position_'+ index"
                       placeholder="职位"
                       maxlength="18"
                       @click.native="focusInput('position_'+ index)"
                       @on-keydown="showMessageOfOverLimit($event,formDataCopy.devices[index]._copy.person.position, 18, '职位' )" />
                <span v-else>{{ row.person.position || '-'}}</span>
              </template>

              <template slot-scope="{ row, index }"
                        slot="devId">
                <Form v-if="row._editing"
                      :ref="'devIdForm_'+index"
                      :model="formDataCopy.devices[index]._copy"
                      style=" width: 100%; "
                      @submit.native.prevent>
                  <FormItem prop="devId"
                            :label-width="0"
                            :show-message="false"
                            :rules="{ required: true, message: '必填', trigger: 'change'}">
                    <!-- 默认显示devName,如果devName为空则显示'铭牌'+ number -->
                    <div style="display: flex;">
                      <span style="color: #F02A2A; margin-right: 4px;">*</span>
                      <Select v-model="formDataCopy.devices[index]._copy.devId"
                              :transfer="true"
                              :events-enabled="true"
                              :capture="false"
                              style="min-width: 120px"
                              @on-select="onSelectDevice($event, formDataCopy.devices[index]._copy)"
                              @on-open-change="onOpenSelectDevice">
                        <Option v-for="item in deviceList"
                                :label="getLable(item)"
                                :value="item.devId"
                                :key="item.devId"
                                :disabled="getDevicesOptionDisabled(item, index)">
                          <span>{{ item.devName || '铭牌' + item.number }}</span>
                          <span style="float: right; margin-left: 5px;">
                            {{ item.meetingStatus === 'Doing' && item.online ? '会议中' : item.online ? '待机' : '未连接' }}
                            <span v-if="item.online"
                                  style="white-space: pre;">{{ '/'+ getBattery(item.shadow) }}</span>
                            <span v-else
                                  class="margin-left-20"
                                  style="white-space: pre;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                          </span>
                        </Option>
                      </Select>
                    </div>
                  </FormItem>
                </Form>
                <span v-else>
                  <span>{{ row.devName || '铭牌' + row.number }}</span>
                  <span style="margin-left: 12px;">
                    {{ getSelectedDev(row) }}
                    <span v-if="row.online"
                          style="white-space: pre;">{{ '/'+ getBattery(row.shadow) }}</span>
                    <span v-else
                          class="margin-left-20"
                          style="white-space: pre;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                  </span>
                </span>
              </template>

              <template slot-scope="{ row, index }"
                        slot="comment">
                <Input v-model="formDataCopy.devices[index]._copy.comment"
                       v-if="row._editing"
                       :ref="'comment_'+ index"
                       placeholder="备注"
                       @click.native="focusInput('comment_'+ index)" />
                <span v-else>{{ row.comment || '-' }}</span>
              </template>

              <template class="form-content-attendee-body-action"
                        slot-scope="{ row, index }"
                        slot="action">
                <Button v-if="row._editing && !row._add"
                        class="submit-btn"
                        type="primary"
                        size="small"
                        float-left
                        @click="submitDataRow(formDataCopy.devices[index], index)">
                  {{ $t('meeting_table_save') }}
                </Button>
                <Button v-if="row._editing&& !row._add"
                        class="submit-btn"
                        size="small"
                        float-left
                        @click="cancel(formDataCopy.devices[index])">
                  {{ $t('meeting_table_cancel') }}
                </Button>
                <div v-if='!row._editing'
                     class="form-content-attendee-body-action-edit"
                     @click="editTableDataRow(formDataCopy.devices[index], index)">
                  <img src="@/assets/images/icon-edit@2x.png" />
                </div>
                <Button v-if="row._editing && row._add"
                        class="submit-btn"
                        type="primary"
                        size="small"
                        float-left
                        @click="submitDataRow(formDataCopy.devices[index], index)">
                  {{ $t('meeting_table_submit') }}
                </Button>
                <div v-if='!row._editing || row._add'
                     class="form-content-attendee-body-action-close"
                     @click="remove(index)">
                  <img src="@/assets/images/icon-close@2x.png" />
                </div>
              </template>
            </Table>

          </div>
          <Button class="margin-top-12"
                  long
                  type="primary"
                  ghost
                  @click="openAddAttendee">
            <div class="form-content-attendee-body-add margin-right-8"
                 float-left>
              <img src="~@/assets/images/icon-add-blue@2x.png">
            </div>
            {{ $t('meeting_table_add') }}
          </Button>
        </div>

        <!-- 铭牌样式 -->
        <div class="form-content-type">
          <!-- 标题 -->
          <div class="form-content-type-title">
            <div class="form-content-type-title-icon">
              <img src="~@/assets/images/icon-set-device@2x.png" />
            </div>
            <div class="form-content-type-title-text">{{ $t('meeting_device_style_setting') }}</div>
          </div>

          <Row class=" margin-top-28">
            <Col span="10">
            <!-- 铭牌壁纸 -->
            <div class="device-wallpaper">
              <FormItem class="device-style-margin"
                        :label="$t('meeting_device_wallpaper')"
                        prop="wallpaper">
                <div class="form-content-type-wallpaper">
                  <div class="form-content-type-wallpaper-select">
                    <img v-if="background"
                         width="100%"
                         height="100%"
                         :src="background" />
                  </div>
                  <div class="form-content-type-wallpaper-button">
                    <Button @click="handleOpenWallpaperModal">
                      <div class="defalut-inline-content">
                        <div class="defalut-inline-content-icon"><img src="~@/assets/images/icon-change@2x.png" /></div>
                        <div class="defalut-inline-content-text">{{ $t('meeting_device_wallpaper_change') }}</div>
                      </div>
                    </Button>
                  </div>
                </div>
              </FormItem>
            </div>
            </Col>
            <Col span="14">
            <FormItem class="device-style-margin"
                      style="margin-top: 28px;"
                      :label="$t('meeting_device_font')"
                      prop="font">
              <Select v-model="formDataCopy.style.font"
                      :class="`form-content-type-font-${formDataCopy.style.font.toLowerCase()}`"
                      :transfer="true"
                      style="width:196px"
                      @on-change="onStyleChange">
                <Option v-for="item in fontList"
                        :class="`form-content-type-font-option-${item.value.toLowerCase()}`"
                        :value="item.value"
                        :label="item.name"
                        :key="item.value">
                </Option>
              </Select>
            </FormItem>
            </Col>
          </Row>

          <!-- 铭牌logo -->
          <Row class="device-style-logo margin-top-20">
            <Col span="10">
            <FormItem class="device-style-margin"
                      :label="$t('meeting_device_logo_position')"
                      prop="logoPosition">
              <RadioGroup v-model="formDataCopy.style.logoPosition">
                <Radio v-for="item in logoPositionList"
                       :key="item.value"
                       :label="item.value"
                       border
                       @on-change="onStyleChange">{{item.name}}</Radio>
              </RadioGroup>

            </FormItem>
            </Col>
            <Col span="14">
            <FormItem class="device-style-margin device-style-font-color"
                      :label="$t('meeting_device_font_color')"
                      prop="fontColor">
              <RadioGroup v-model="formDataCopy.style.fontColor"
                          @on-change="onStyleChange">
                <Radio v-for="item in fontColorList"
                       :key="item.value"
                       :label="item.value"
                       style="margin-left: -2px;">
                  <div class="form-content-type-fontcolor">
                    <div class="form-content-type-fontcolor-icon">
                      <img :src="item.url" />
                      <img style="margin-left: -20px"
                           v-if="item.value === formDataCopy.style.fontColor"
                           src="@/assets/images/icon-check@2x.png" />
                    </div>
                    <div>{{ item.name }}</div>
                  </div>
                </Radio>
              </RadioGroup>
            </FormItem>
            </Col>
          </Row>

          <!-- 铭牌字体 -->
          <Row class="device-style-logo margin-top-24">
            <Col span="10">
            <FormItem class="device-style-margin"
                      :label="$t('meeting_device_logo_size')"
                      prop="logoSize"
                      float-left>
              <RadioGroup v-model="formDataCopy.style.logoSize">
                <Radio v-for="item in logoSizeList"
                       :key="item.value"
                       :label="item.value"
                       border
                       @on-change="onStyleChange">{{item.name}}</Radio>
              </RadioGroup>
            </FormItem>
            </Col>
            <Col span="14">
            <FormItem class="device-style-margin"
                      :label="$t('meeting_device_font_action')"
                      prop="dynamic">
              <ISwitch v-model="formDataCopy.style.dynamic"></ISwitch>
            </FormItem>
            </Col>
          </Row>

        </div>

        <!-- 会议内容 -->
        <div class="form-content-file">
          <!-- 标题 -->
          <div class="form-content-file-title">
            <div class="form-content-file-title-icon">
              <img src="~@/assets/images/icon-set-content@2x.png" />
            </div>
            <div class="form-content-file-title-text">{{ $t('meeting_content') }}</div>
          </div>

          <!-- 会议议程 -->
          <FormItem class="device-style-margin margin-top-30"
                    :label="$t('meeting_agenda')"
                    prop="agenda">
            <div class="upload-entrance">
              <Button>
                <div class="upload-entrance-btn">
                  <div class="upload-entrance-btn-icon margin-right-4">
                    <img src="~@/assets/images/icon-upload@2x.png" />
                  </div>
                  {{$t('meeting_content_upload_file')}}
                </div>
              </Button>
              <div class="upload-entrance-list"
                   style="width: 276px">
                <div class="upload-entrance-list-body">
                  <IconButton class="upload-entrance-list-body-item"
                              v-for="(item, index) in AgendaIconButtonList"
                              :key="index"
                              :value="item.value === 'Image'"
                              :data="item"
                              @before-upload="handleOpenAgendaModal($event, item.value)"
                              @on-click="openAgendaModal(item.value)" />
                </div>
              </div>

            </div>
          </FormItem>
          <!-- 会议议程文件列表 -->

          <div class="margin-top-24 file-margin-left">
            <Row :gutter="24"
                 type="flex"
                 justify="start"
                 align="middle">
              <Col class="margin-bottom-24"
                   :sm="{ span: 24 }"
                   :lg="{ span: 12 }"
                   :xxl="{ span: 8 }"
                   v-for="(item, index) in formDataCopy.agendaResources"
                   :key="'agenda' + index">
              <FileItem :file-data="item"
                        :user-list="userList"
                        :show-users="true"
                        :show-delete="true"
                        @on-click="deleteAgendaFile(index)" />
              </Col>
            </Row>

          </div>

          <!-- 会议资料 -->
          <FormItem class="device-style-margin margin-top-24 "
                    :label="$t('meeting_documents')"
                    prop="documents">
            <div class="upload-entrance">
              <Button>
                <div class="upload-entrance-btn">
                  <div class="upload-entrance-btn-icon  margin-right-4">
                    <img src="~@/assets/images/icon-upload@2x.png" />
                  </div>
                  {{$t('meeting_content_upload_file')}}
                </div>
              </Button>
              <div class="upload-entrance-list">
                <div class="upload-entrance-list-body">
                  <IconButton class="upload-entrance-list-body-item"
                              v-for="(item, index) in NormalIconButtonList"
                              :key="index"
                              :value="item.value === 'Image'"
                              :data="item"
                              @before-upload="handleOpenNormalFileModal($event, item.value)"
                              @on-click="openNormalFileModal(item.value)" />
                </div>
              </div>

            </div>
          </FormItem>

          <div class="margin-top-24 file-margin-left">
            <Row :gutter="24"
                 type="flex"
                 justify="start"
                 align="middle">
              <Col class="margin-bottom-24"
                   :sm="{ span: 24 }"
                   :lg="{ span: 12 }"
                   :xxl="{ span: 8 }"
                   v-for="(item, index) in formDataCopy.normalResources"
                   :key="'normal' + index">
              <FileItem :file-data="item"
                        :user-list="userList"
                        :show-users="true"
                        :show-delete="true"
                        @on-click="deleteNormalFile(index)" />
              </Col>
            </Row>
          </div>

          <!-- 提词器 -->
          <FormItem class="device-style-margin margin-top-24"
                    :label="$t('meeting_keywords')"
                    prop="keywords">
            <Button @click="handleOpenKeywordModal">
              <div class="upload-entrance-btn">
                <div class="upload-entrance-btn-icon  margin-right-4">
                  <img src="~@/assets/images/icon-add@2x.png" />
                </div>
                {{$t('meeting_keywords_add')}}
              </div>
            </Button>
            <Row class="form-content-vote-row margin-top-24"
                 :gutter="24"
                 type="flex"
                 justify="start"
                 align="middle">
              <Col class="margin-bottom-24"
                   :sm="{ span: 24 }"
                   :lg="{ span: 12 }"
                   :xxl="{ span: 8 }"
                   v-for="(item, index) in formDataCopy.keywords"
                   :key="'keywords_' + index">
              <ContentItem :data="item"
                           :index="index+1"
                           show-edit
                           show-users
                           show-delete
                           :user-list="userList"
                           @on-edit="onEditKeyword(item)"
                           @on-close="onCloseKeyword(index)" />
              </Col>
            </Row>
          </FormItem>

          <!-- 投票 -->
          <FormItem class="device-style-margin margin-top-24"
                    :label="$t('meeting_vote')"
                    prop="vote">
            <div class="margin-bottom-24">
              <Button @click="handleOpenVoteModal">
                <div class="upload-entrance-btn">
                  <div class="upload-entrance-btn-icon  margin-right-4">
                    <img src="~@/assets/images/icon-add@2x.png" />
                  </div>
                  {{$t('meeting_vote_add')}}
                </div>
              </Button>
              <Row class="form-content-vote-row margin-top-24"
                   :gutter="24"
                   type="flex"
                   justify="start"
                   align="middle">
                <Col class="margin-bottom-24"
                     :sm="{ span: 24 }"
                     :lg="{ span: 12 }"
                     :xxl="{ span: 8 }"
                     v-for="(item, index) in formDataCopy.votes"
                     :key="'votes' + index">
                <VoteItem :vote-data="item"
                          :index="index+1"
                          show-edit
                          @on-edit="onEditVote(item)"
                          @on-close="onCloseVote(index)" />
                </Col>
              </Row>
            </div>
          </FormItem>

        </div>
      </div>
    </Form>
    <CropModal :value="showCropModal"
               :src="src"
               :file-name="fileName"
               @on-close="onCloseCropModal"
               @on-ok="onOkCropModal"></CropModal>

    <!-- 批量导入铭牌弹窗 -->
    <ImportDevicesModal :value="showImportDevicesModal"
                        :devices="modalDeviceList"
                        @on-close="closeImportDevicesModal"
                        @on-ok="onOkImportDevicesModal" />
    <!-- 批量导入联系人弹窗 -->
    <ImportPersonsModal :value="showImportPersonsModal"
                        :persons="modalAttendeeList"
                        @on-close="closeImportPersonsModal"
                        @on-ok="onOkImportPersonsModal" />
    <!-- 选择主持人弹窗 -->
    <SelectHostModal :value="showSelectHostModal"
                     :persons="hostList"
                     :meeting-host="formDataCopy.host"
                     @on-close="closeSelectHostModal"
                     @on-ok="onOkSelectHostModal" />
    <!-- 选择壁纸弹窗 -->
    <WallpaperModal :value="showWallpaperModal"
                    :selected="formDataCopy.style.background"
                    :custom-data="customWallpaperList"
                    :file-data="defaultWallpaperList"
                    @on-close="closeWallpaperModal"
                    @on-ok="onOkWallpaperModal" />
    <!-- 选择会议议程文件弹窗 -->
    <!-- png、jpg -->
    <AgendaImgModal :value="showAgendaImgModal"
                    :file-list="agendaFileList"
                    :file-data="fileData"
                    :user-list="userList"
                    @on-close="closeAgendaModal('Image')"
                    @on-ok="onOkAgendaModal" />
    <!-- PDF/PPT/Word -->
    <AgendaDefaultModal :value="showAgendaDefaultModal"
                        :title="agendaTitle"
                        :file="file"
                        :file-list="agendaFileList"
                        :file-data="fileData"
                        :user-list="userList"
                        :resources="formDataCopy.agendaResources"
                        @on-close="closeAgendaModal('Default')"
                        @on-ok="onOkAgendaModal" />
    <!-- 选择会议资料文件弹窗 -->
    <!-- png、jpg -->
    <NormalImgModal :value="showNormalImgModal"
                    :normal-file-list="normalFileList"
                    :normal-file-data="normalFileData"
                    :user-list="userList"
                    @on-close="closeNormalFileModal('Image')"
                    @on-ok="onOkNormalFileModal($event, 'Image')" />
    <!-- PDF/MP4/PPT/Word -->
    <NormalDefaultModal :value="showNormalDefaultModal"
                        :title="normalFileTitle"
                        :file="file"
                        :normal-file-list="normalFileList"
                        :normal-file-data="normalFileData"
                        :resources="formDataCopy.normalResources"
                        :user-list="userList"
                        @on-close="closeNormalFileModal()"
                        @on-ok="onOkNormalFileModal($event)" />

    <!-- 创建提词窗口 -->
    <KeywordModal :value="showAddKeywordModal"
                  :data="keywordsData"
                  :user-list="userList"
                  :title="contentItemTitle"
                  @on-close="closeKeywordModal"
                  @on-ok="onOkKeywordModal" />

    <!-- 创建投票弹窗 -->
    <VoteModal :value="showVoteModal === 'Create'"
               @on-close="closeVoteModal"
               @on-cancel="closeVoteModal"
               @on-confirm="onOkVoteModal" />

    <VoteModifyModal :value="showVoteModal === 'Modify'"
                     :vote-data="voteData"
                     @on-close="closeVoteModal"
                     @on-cancel="closeVoteModal"
                     @on-modify="onOkVoteModal" />
    <!-- 通过Excel上传参会人弹窗 -->
    <div v-if="showExcelUploadModal">
      <ExcelUploadModal :value="showExcelUploadModal"
                        @on-close="closeExcelUploadModal"
                        @on-ok="onOkExcelUploadModal" />
    </div>
  </div>
</template>

<script>
import {
  Form,
  FormItem,
  Row,
  Col,
  Input,
  DatePicker,
  TimePicker,
  Button,
  Table,
  AutoComplete,
  Select,
  Option,
  Checkbox,
  RadioGroup,
  Radio,
  Avatar,
  Upload,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  Tooltip,
  Switch,
  Icon
} from 'view-design';

import TitleBar from '@/views/pages/components/title-bar';
import IconButton from '../icon-button';
import { FileItem } from '../file-item';
import ContentItem from '../content-item';
import { VoteItem } from '../vote-item';
import CropModal from '../../../me/components/crop-modal';
import ImportDevicesModal from '../import-devices-modal';
import ImportPersonsModal from '../import-persons-modal';
import SelectHostModal from '../select-host-modal';
import WallpaperModal from '../wallpaper-modal';
import { AgendaImgModal, AgendaDefaultModal } from '../agenda-file-modal';
import { NormalImgModal, NormalDefaultModal } from '../normal-file-modal';
import { VoteModal, VoteModifyModal } from '../vote-modal';
import KeywordModal from '../keyword-modal';
import CustomInput from '../custom-input';
import ExcelUploadModal from '../excel-upload-modal';

import { indexOfByKeyAndValue, deepCopy, getMaxLength } from '@/utils/tools';
import PersonApi from '@/api/person';
import MeetingApi from '@/api/meeting';
import {
  uploadToOSS,
  addOssResourse,
  getDefaultResourses,
  getOssResourse,
  getScreenshot
} from '@/api/upload';

import ColorGolden from '@/assets/images/color-golden@2x.png';
import ColorWhite from '@/assets/images/color-white@2x.png';
import ColorBlack from '@/assets/images/color-black@2x.png';

import IconImage from '@/assets/images/file-image@2x.png';
import IconMp4 from '@/assets/images/file-video@2x.png';
import IconPdf from '@/assets/images/file-pdf@2x.png';
import IconPpt from '@/assets/images/file-ppt@2x.png';
import IconWord from '@/assets/images/file-doc@2x.png';

export default {
  // 不要忘记了 name 属性
  name: 'MeetingForm',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    formData: {
      type: Object,
      default() {
        return {
          devices: []
        };
      }
    },
    formType: {
      type: String,
      default() {
        return 'add';
      }
    },
    value: Boolean,

    name: {
      type: String,
      default() {
        return '';
      }
    }
  },

  // 使用其它组件
  components: {
    Form,
    FormItem,
    Row,
    Col,
    Input,
    DatePicker,
    TimePicker,
    Button,
    Table,
    AutoComplete,
    Select,
    Option,
    Checkbox,
    RadioGroup,
    Radio,
    Avatar,
    Upload,
    Dropdown,
    DropdownMenu,
    DropdownItem,
    ISwitch: Switch,

    // 自定义组件
    TitleBar,
    IconButton,
    FileItem,
    ContentItem,
    VoteItem,
    CropModal,
    ImportDevicesModal,
    ImportPersonsModal,
    SelectHostModal,
    WallpaperModal,
    AgendaImgModal,
    AgendaDefaultModal,
    NormalImgModal,
    NormalDefaultModal,
    KeywordModal,
    VoteModal,
    VoteModifyModal,
    CustomInput,
    ExcelUploadModal
  },

  // 变量
  data() {
    return {
      optionsDate: {
        disabledDate(date) {
          return date && date.valueOf() < Date.now() - 86400000;
        }
      },
      isSel: false, // 由于选中和输入内容都会触发onchange，设置此变量进行区分两种情况
      uploadIndex: -1, // 上传logo的table行的index
      formDataCopy: deepCopy(this.formData),
      fileName: '', // logo图片名称
      src: '', // 需要截得图片路径
      showDefaultDeviceName: false, // 是否显示铭牌默认名，请求接口
      showCropModal: false,
      showWallpaperModal: false, // 是否打开选择壁纸对话框
      showAgendaImgModal: false, // 是否打开选择会议议程图片对话框
      showAgendaDefaultModal: false, // 是否打开选择会议议程pdf对话框
      showNormalImgModal: false, // 是否打开选择文件对话框
      showNormalDefaultModal: false, // 是否打开选择文件对话框
      showAddKeywordModal: false, // 是否打开创建提词对话框
      showVoteModal: false, // 是否打开创建投票对话框
      showImportDevicesModal: false, // 是否打开导入铭牌对话框
      showImportPersonsModal: false, // 是否打开导入联系人对话框
      showSelectHostModal: false, // 是否打开选择主持人对话框
      showExcelUploadModal: false, // 是否打开选择Excel文件上传对话框
      editVoteType: false, // 是否为已有投票编辑
      currVoteData: {}, // 当前选中编辑的投票数据
      hostList: [], // 主持人列表，从已选参会人中选择
      attendeeList: [], // 参会人列表
      modalAttendeeList: [], // 已过滤已选参会人的参会人列表
      deviceList: [], // 设备列表
      modalDeviceList: [], // 已过滤已选设备的设备列表
      customWallpaperList: [], // 用户自定义壁纸资源
      defaultWallpaperList: [], // 设备内置壁纸资源
      background: '', // 壁纸显示url
      file: null, // 已选择待上传的文件
      agendaFileList: [], // 会议议程图片文件列表， 默认打开弹出对话框时是空数组
      agendaTitle: '上传PDF文件', // 会议议程资料上传弹框title
      fileData: {
        name: '',
        personIds: [], // 资源推送目标参会人id
        resourceIds: [] // 资源id列表
      },
      normalFileList: [], // 文件列表， 默认打开弹出对话框时时空数组
      normalFileTitle: '上传PDF文件', // 会议资料上传弹框title
      normalFileAccept: '.pdf', // 文件列表， 默认打开弹出对话框时时空数组
      normalFileFormat: ['.pdf'], // 文件列表， 默认打开弹出对话框时时空数组
      normalFileData: {
        name: '',
        personIds: [], // 资源推送目标参会人id
        resourceIds: [] // 资源id列表
      },
      AgendaIconButtonList: [
        {
          icon: IconImage,
          text: '图片',
          value: 'Image',
          url: '',
          accept: '.jpg, .png',
          format: ['.jpg', '.png'],
          multiple: true
        },
        {
          icon: IconPdf,
          text: 'PDF',
          value: 'PDF',
          url: '',
          accept: '.pdf',
          format: ['.pdf'],
          multiple: false
        },
        {
          icon: IconPpt,
          text: 'PPT',
          value: 'PPT',
          url: '',
          accept: '.ppt, .pptx',
          format: ['ppt', '.pptx'],
          multiple: false
        },
        {
          icon: IconWord,
          text: 'Word',
          value: 'Word',
          url: '',
          accept: '.doc, .docx',
          format: ['.doc', '.docx'],
          multiple: false
        }
      ], // 会议议程icon-button列表
      NormalIconButtonList: [
        {
          icon: IconImage,
          text: '图片',
          value: 'Image',
          url: '',
          accept: '.jpg, .png',
          format: ['.jpg', '.png'],
          multiple: true
        },
        {
          icon: IconMp4,
          text: '视频',
          value: 'Video',
          url: '',
          accept: '.mp4',
          format: ['.mp4'],
          multiple: false
        },
        {
          icon: IconPdf,
          text: 'PDF',
          value: 'PDF',
          url: '',
          accept: '.pdf',

          format: ['.pdf'],
          multiple: false
        },
        {
          icon: IconPpt,
          text: 'PPT',
          value: 'PPT',
          url: '',
          accept: '.ppt, .pptx',
          format: ['ppt', '.pptx'],
          multiple: false
        },
        {
          icon: IconWord,
          text: 'Word',
          value: 'Word',
          url: '',
          accept: '.doc, .docx',
          format: ['.doc', '.docx'],
          multiple: false
        }
      ], // 会议资料icon-button列表
      userList: [], // 查看资料可选用户列表
      contentItemTitle: '新增提词',
      editKeywordType: false, // 是否为已有提词编辑
      currKeywordData: {}, // 当前选中编辑的提词数据
      keywordsData: {
        // 新建提词器属性
        title: '', // 提词标题
        keyword: '', // 提词内容
        personId: null // 提词目标显示人ID
      },
      voteData: {
        // 新建投票属性
        title: '',
        anonymous: false
      },
      logoSizeList: [
        // 铭牌logo size
        { name: '标准', value: 'Normal' },
        { name: '加大', value: 'Large' }
      ],
      logoPositionList: [
        // 铭牌logo定位（居左，居中，居右）
        { name: '居左', value: 'Left' },
        { name: '居中', value: 'Center' },
        { name: '居右', value: 'Right' }
      ],
      fontList: [
        // 铭牌字体（系统字体，黑体，宋体，楷体）
        { name: '系统字体', value: 'Default' },
        { name: '黑体', value: 'Black' },
        { name: '宋体', value: 'Song' },
        { name: '楷体', value: 'Regular' }
      ],
      fontColorList: [
        // 铭牌字体（系统字体颜色，白色，金色，黑色）
        { name: '白色', value: 'White', url: ColorWhite },
        { name: '金色', value: 'Golden', url: ColorGolden },
        { name: '黑色', value: 'Black', url: ColorBlack }
      ],
      ruleValidate: {
        name: [{ required: true, type: 'string', message: '此项不允许为空', trigger: 'change' }]
      },
      columns: [
        {
          title: this.$t('meeting_table_name'),
          slot: 'name',
          className: 'table-head-style require-col'
        },
        {
          title: this.$t('meeting_table_company'),
          slot: 'company',
          minWidth: 60,
          className: 'table-head-style'
        },
        {
          title: this.$t('meeting_table_logo'),
          slot: 'logo',
          className: 'table-head-style'
        },
        {
          title: this.$t('meeting_table_position'),
          slot: 'position',
          className: 'table-head-style'
        },
        {
          title: this.$t('meeting_table_device'),
          slot: 'devId',
          minWidth: 120,
          className: 'table-head-style',
          renderHeader: (h, params) => {
            return h('div', [
              h(
                'span',
                {
                  style: {
                    color: '#ed4014',
                    'margin-right': '4px',
                    'line-height': 1
                  }
                },
                '*'
              ),
              h('span', {}, this.$t('meeting_table_device') + ' '),
              h('span', [
                h(
                  Tooltip,
                  {
                    props: {
                      content: this.$t('meeting_table_status_tips'),
                      trigger: 'hover',
                      placement: 'top',
                      transfer: true,
                      'max-width': 200
                    }
                  },
                  [
                    h(Icon, {
                      props: {
                        type: 'ios-alert-outline',
                        size: '16'
                      }
                    })
                  ]
                )
              ])
            ]);
          }
        },
        {
          title: this.$t('meeting_table_remark'),
          slot: 'comment',
          className: 'table-head-style'
        },
        {
          title: this.$t('meeitng_table_action'),
          slot: 'action',
          width: 150,
          align: 'center',
          className: 'table-head-style'
        }
      ]
    };
  },

  // 计算属性
  computed: {
    hostName() {
      if (this.formDataCopy.host) {
        const hostList = [];
        this.formDataCopy.devices.map((item, index) => {
          if (item.person && item.person.id) {
            hostList.push(item.person);
          }
        });
        const index = indexOfByKeyAndValue(hostList, 'id', this.formDataCopy.host);
        if (index !== -1) {
          return hostList[index].name;
        }
      }
      return '-';
    },

    avatarSrc() {
      if (this.formDataCopy.style.fontColor === 'Golden') {
        return this.fontColorList[0].url;
      } else if (this.formDataCopy.style.fontColor === 'Black') {
        return this.fontColorList[2].url;
      }
      return this.fontColorList[1].url;
    }
  },
  // 监听
  watch: {
    showDefaultDeviceName(newValue) {
      // 请求接口，让铭牌端是否显示默认设备名
      this.onCenterControl(newValue);
    }
  },
  // 方法
  methods: {
    // 获取设备lable名
    getLable(item) {
      var name = item.devName || '铭牌' + item.number;
      var battary = this.getBattery(item.shadow);
      var status =
        item.meetingStatus === 'Doing' && item.online
          ? '会议中 / ' + battary
          : item.online
            ? '待机 / ' + battary
            : '未连接';

      return name + ' ' + ' ' + status;
    },

    // 解决点击AutoComplete或Select后在点击Input不聚焦的问题
    focusInput(name) {
      this.$nextTick(() => {
        this.$refs[name].focus();
        // window.console.log('使聚焦');
      });
    },

    // 获取选择设备option是否禁选
    getDevicesOptionDisabled(op, index) {
      let flag = false;
      for (let i = 0; i < this.formDataCopy.devices.length; i++) {
        if (i === index) {
          continue;
        }
        let item = this.formDataCopy.devices[i];
        item = item._editing ? item._copy : item;
        flag = item.devId === op.devId;
        if (flag) {
          return true;
        }
      }
      return flag;
    },

    // 获取设备电量，并处理没有返回电量值相关数据状况
    getBattery(item) {
      if (
        !item ||
        !item.state ||
        !item.state.reported ||
        !item.state.reported.common ||
        !item.state.reported.common.battery
      ) {
        return '-';
      }
      if (item.state.reported.common.battery === 100) {
        return item.state.reported.common.battery + '%';
      }
      return `  ` + item.state.reported.common.battery + '%';
    },

    // 获取上传logo所在行index
    getUploadIndex(index) {
      this.uploadIndex = index;
    },

    // 获取参会人列表
    getAttendeeList() {
      const vm = this;
      const userId = this.$store.state.user.userId;
      PersonApi.getAttendeeList()
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            vm.attendeeList = deepCopy(data);
            vm.attendeeList.map((item, index) => {
              if (item.logo) {
                getOssResourse(userId, { id: item.logo })
                  .fetch()
                  .then(({ success, msg, data }) => {
                    if (success) {
                      vm.attendeeList[index].logoUrl = data;
                    }
                  })
                  .catch(err => {
                    window.console.log(err);
                  });
              }
            });
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: msg,
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          this.$Message.destroy();
          this.$Message.error({
            content: err.msg,
            duration: 5,
            closable: true
          });
        });
    },

    // 获取设备列表
    getDeviceList(callback) {
      PersonApi.getDeviceList()
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            this.deviceList = data;
            if (callback) {
              callback();
            }
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: msg,
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          this.$Message.destroy();
          this.$Message.error({
            content: err.msg,
            duration: 5,
            closable: true
          });
        });
    },

    // 会议日期改变时 触发
    onChangeDate(date) {
      this.formDataCopy.date = date;
    },

    // 开始时间、结束时间改变时 触发
    onChangeStartTime(time) {
      this.formDataCopy.startTime = time;
      this.saveFormDataToLocalStorage();
    },

    onChangeEndTime(time) {
      this.formDataCopy.endTime = time;
      this.saveFormDataToLocalStorage();
    },

    // 触发设备端是否显示设备默认名
    onCenterControl(show) {
      MeetingApi.onDeviceControl('ShowName', { show })
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            this.$Message.destroy();
            this.$Message.success({
              content: show ? '铭牌显示默认名称成功' : '铭牌已取消默认名称显示',
              duration: 5,
              closable: true
            });
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: show ? '铭牌显示默认名称失败' : '铭牌取消默认名称显示失败',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(() => {
          this.$Message.destroy();
          this.$Message.error({
            content: show ? '铭牌显示默认名称失败' : '铭牌取消默认名称显示失败',
            duration: 5,
            closable: true
          });
        });
    },

    // 编辑参会人列
    editTableDataRow(row, index) {
      this.$set(row, '_editing', true);
      this.$set(row, '_copy', deepCopy(this.formDataCopy.devices[index]));
    },

    // 提交参会人行数据
    submitDataRow(row, index) {
      if (!row._editing || !row._copy) {
        return;
      }
      const vm = this;

      // 表单校验
      vm.validateTableData(index);

      if (!row._copy.person.name) {
        vm.$Message.destroy();
        vm.$Message.warning({
          content: '姓名必填！',
          duration: 5,
          closable: true
        });
        return;
      }

      if (!row._copy.devId) {
        vm.$Message.destroy();
        vm.$Message.warning({
          content: '铭牌必选！',
          duration: 5,
          closable: true
        });
        return;
      }

      if (!row._copy.person.id) {
        const dataList = [];
        const person = {
          name: row._copy.person.name,
          company: row._copy.person.company,
          position: row._copy.person.position,
          logo: row._copy.person.logo,
          disable: true // 不添加到常用联系人列表
        };

        dataList.push(person);

        vm.addAttendee(dataList, data => {
          row._copy.person.id = data[0].id;
          Object.assign(row, row._copy);
          row._copy = undefined;
          row._editing = false;
          row._add = false;
          vm.saveFormDataToLocalStorage();
        });
      } else {
        if (JSON.stringify(row._copy.person) === JSON.stringify(row.person)) {
          Object.assign(row, row._copy);
          row._copy = undefined;
          row._editing = false;
          return;
        }

        const dataList = [];
        const alterData = {
          id: row._copy.person.id,
          name: row._copy.person.name,
          company: row._copy.person.company,
          position: row._copy.person.position,
          logo: row._copy.person.logo
        };

        dataList.push(alterData);

        vm.alterAttendee(dataList, () => {
          Object.assign(row, row._copy);
          row._copy = undefined;
          row._editing = false;
          row._add = false;
          vm.saveFormDataToLocalStorage();
        });
      }
    },

    // 提交所有修改或新增的参会人数据
    submitDataAll(dataList, callback) {
      const vm = this;
      vm.addAttendee(dataList, callback);
    },

    // 对参会人表格行进行校验
    validateTableData(index) {
      // 表单校验
      const $nameForm = this.$refs['nameForm_' + index];
      const $devIdForm = this.$refs['devIdForm_' + index];

      $nameForm && $nameForm.validate();
      $devIdForm && $devIdForm.validate();
    },

    // 新增参会人请求接口，dataList为数组
    addAttendee(dataList, callback) {
      const vm = this;
      PersonApi.addAttendee(dataList)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            if (callback !== undefined) {
              callback(data);
            }
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '添加参会人失败，请稍后重试！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg || '添加参会人失败，请稍后重试！',
            duration: 5,
            closable: true
          });
        });
    },

    // 修改参会人请求接口，dataList为数组
    alterAttendee(dataList, callback) {
      const vm = this;
      PersonApi.alterAttendee(dataList)
        .fetch()
        .then(({ success, msg }) => {
          if (success) {
            if (callback !== undefined) {
              callback();
            }
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: msg || '修改参会人失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg || '修改参会人失败！',
            duration: 5,
            closable: true
          });
        });
    },

    // 取消编辑参会人行数据
    cancel(row) {
      //
      if (!row._editing || !row._copy) {
        return;
      }
      row._copy = undefined;
      row._editing = false;
      this.saveFormDataToLocalStorage();
    },

    // 删除参会人列行
    remove(index) {
      const vm = this;
      if (vm.formDataCopy.devices[index].person && vm.formDataCopy.devices[index].person.id) {
        const id = vm.formDataCopy.devices[index].person.id;

        if (id === vm.formDataCopy.host) {
          vm.formDataCopy.host = null;
        }
        // 如果删除的参会人又关联提词，则把关联的提词一起删除
        for (let i = vm.formDataCopy.keywords.length - 1; i >= 0; i--) {
          if (id === vm.formDataCopy.keywords[i].personId) {
            vm.formDataCopy.keywords.splice(i, 1);
          }
        }
      }

      // 删除某一行
      vm.formDataCopy.devices.splice(index, 1);
      // 遍历table行取消校验
      for (let i = 0; i < vm.formDataCopy.devices.length; i++) {
        if (vm.formDataCopy.devices[i]._editing) {
          vm.$refs['nameForm_' + i].fields[0].validateDisabled = true;
          vm.$refs['devIdForm_' + i].fields[0].validateDisabled = true;
        }
      }
      vm.saveFormDataToLocalStorage();
    },

    // 打开新一行添加参会人
    openAddAttendee() {
      this.formDataCopy.devices.push({
        _editing: true,
        _add: true,
        _copy: {
          devId: '',
          devName: '',
          number: '',
          online: '',
          shadow: { state: { reported: { common: { battery: '' } } } }, // 设备电量状态
          comment: '',
          meetingStatus: null,
          person: {
            id: '',
            name: '',
            company: '',
            logo: '',
            logoUrl: '',
            position: ''
          }
        }
      });
    },

    // 选中参会人时触发
    onSelectAttendee(item, row, devIndex) {
      const vm = this;
      vm.isSel = true;
      vm.$nextTick(() => {
        const userId = vm.$store.state.user.userId;
        const index = indexOfByKeyAndValue(vm.attendeeList, 'id', item);
        // row.person.id = item;
        row.person.name = vm.attendeeList[index].name;
        row.person.company = vm.attendeeList[index].company;
        row.person.position = vm.attendeeList[index].position;
        row.person.logo = vm.attendeeList[index].logo;
        vm.$forceUpdate();
        // 获取
        if (row.person.logo) {
          getOssResourse(userId, { id: row.person.logo })
            .fetch()
            .then(({ success, msg, data }) => {
              if (success) {
                row.person.logoUrl = data;
              }
            })
            .catch(err => {
              window.console.log(err);
            });
        }
        // 给选中的参会人自动分配铭牌
        if (!row.devId) {
          this.autoAssignDev(row);
        }
        localStorage.setItem('formData', JSON.stringify(this.formDataCopy));
      });
    },

    // 参会人框失焦是触发
    onBlurAttendee(item, row) {
      if (!row.devId && row.person.name) {
        this.autoAssignDev(row);
      }
    },

    // 自动分配铭牌
    autoAssignDev(row) {
      // 自动分配一个铭牌
      // 分配规则：
      // 1、待机（开机联网），电量由高到低
      // 2、未连接（未联网），没有电量要求
      // 3、不符合规则或铭牌不够则不匹配

      // 选出可分配的设备列表
      const optionalDevList = deepCopy(this.deviceList);
      this.formDataCopy.devices.map(deviceItem => {
        if (deviceItem.devId || deviceItem._copy.devId) {
          var index = '';
          if (deviceItem.devId) {
            index = indexOfByKeyAndValue(optionalDevList, 'devId', deviceItem.devId);
          } else if (deviceItem._copy.devId) {
            index = indexOfByKeyAndValue(optionalDevList, 'devId', deviceItem._copy.devId);
          }
          if (index !== -1) {
            optionalDevList.splice(index, 1);
          }
        }
      });
      const optionalDevListCopy = deepCopy(optionalDevList);
      optionalDevListCopy.map((opItem, index) => {
        if (opItem.meetingStatus && opItem.online) {
          const opIndex = indexOfByKeyAndValue(
            optionalDevList,
            'devId',
            optionalDevListCopy[index].devId
          );
          if (opIndex !== -1) {
            optionalDevList.splice(opIndex, 1);
          }
        }
      });
      // 分配铭牌
      if (optionalDevList.length) {
        row.devId = optionalDevList[0].devId;
        row.online = optionalDevList[0].online;
        row.shadow = optionalDevList[0].shadow;
        row.devName = optionalDevList[0].devName;
        row.number = optionalDevList[0].number;
      }
    },

    // 获取已选中设备列表中的设备会议状态
    getSelectedDev(row) {
      const index = indexOfByKeyAndValue(this.deviceList, 'devId', row.devId);
      return index === -1
        ? '-'
        : this.deviceList[index].meetingStatus === 'Doing' && row.online
          ? '会议中'
          : row.online
            ? '待机'
            : '未连接';
    },

    // 刚选中时触发
    onSelectDevice(item, row) {
      const index = indexOfByKeyAndValue(this.deviceList, 'devId', item.value);
      row.meetingStatus = this.deviceList[index].meetingStatus;
      row.online = this.deviceList[index].online;
      row.shadow = this.deviceList[index].shadow;
      row.devName = this.deviceList[index].devName;
      row.number = this.deviceList[index].number;
      row.devId = this.deviceList[index].devId;
      localStorage.setItem('formData', JSON.stringify(this.formDataCopy));
    },

    // 打开选择设备下拉框触发
    onOpenSelectDevice(value) {
      if (value) {
        this.getDeviceList();
      }
    },

    // 上传logo
    beforeUpload(file) {
      const vm = this;
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = event => {
        vm.src = event.srcElement.result;
        vm.fileName = file.name;
        vm.showCropModal = true;
      };

      return false;
    },

    // 关闭剪裁图片modal框
    onCloseCropModal() {
      this.showCropModal = false;
    },

    // 剪裁图片确认按钮点击事件
    onOkCropModal(file) {
      this.loading = true;
      this.uploadCropperImg(file);
    },

    // 上传截图
    uploadCropperImg(file) {
      const vm = this;
      uploadToOSS(file).then(res => {
        // 1、创建oss资源 ，拿到资源id，push到 resourceIds
        // 2、拿返回的objectKey去请求资源，得到资源路径，显示出来

        // 获取用户id
        const userId = vm.$store.state.user.userId;
        // 获取创建资源参数
        const fileData = {
          fileKey: res.key,
          name: file.name,
          size: file.size,
          desc: file.desc,
          md5: res.md5,
          fileType: 'Image'
        };
        // 发送创建资源请求
        addOssResourse(userId, fileData)
          .fetch()
          .then(({ success, msg, data }) => {
            //
            if (success) {
              vm.getOssResourse(fileData, userId, { id: data.resourceId });
            } else {
              vm.$Message.destroy();
              vm.$Message.error({
                content: msg || file.name + '上传失败，请重试！',
                duration: 5,
                closable: true
              });
              vm.loading = false;
              vm.showCropModal = false;
            }
          })
          .catch(err => {
            vm.$Message.destroy();
            vm.$Message.error({
              content: err.msg || file.name + '上传失败，请重试！',
              duration: 5,
              closable: true
            });
            vm.loading = false;
            vm.showCropModal = false;
          });
      });
    },

    getOssResourse(file, userId, params) {
      const vm = this;
      getOssResourse(userId, params)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            if (vm.uploadIndex === -1) {
              return;
            }
            vm.formDataCopy.devices[vm.uploadIndex]._copy.person.logoUrl = data;
            vm.formDataCopy.devices[vm.uploadIndex]._copy.person.logo = params.id;
            vm.loading = false;
            vm.showCropModal = false;
            vm.saveFormDataToLocalStorage();
            vm.$forceUpdate();
          } else {
            vm.$Message.destroy();
            vm.loading = false;
            vm.$Message.error({
              content: msg || file.name + '获取失败',
              duration: 5,
              closable: true
            });
            vm.showCropModal = false;
          }
        })
        .catch(err => {
          vm.loading = false;
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg,
            duration: 5,
            closable: true
          });
          vm.showCropModal = false;
        });
    },

    // 获取壁纸资源
    getDefaultWallpaper(flag) {
      const type = 'WallPaper';
      const vm = this;
      const params = {
        additional: flag
      };
      getDefaultResourses(type, params)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            const userId = vm.$store.state.user.userId;
            // flag为true：获取的是用户图片列表
            // flag为false：获取的是设备内置图片列表
            if (flag) {
              vm.customWallpaperList = deepCopy(data);
              // 获取图片URL
              vm.customWallpaperList.map((item, index) => {
                if (item.fileType === 'Image') {
                  getOssResourse(userId, { key: item.resKey })
                    .fetch()
                    .then(({ success, msg, data }) => {
                      if (success) {
                        vm.customWallpaperList[index].url = data;
                      }
                    });
                } else if (item.fileType === 'Video') {
                  getScreenshot(item.resourceId)
                    .fetch()
                    .then(({ success, msg, data }) => {
                      if (success) {
                        vm.customWallpaperList[index].url = data;
                      }
                    });
                }
              });
            } else {
              // 把获取到的默认壁纸添加资源链接
              vm.defaultWallpaperList = deepCopy(data);
              // 获取图片URL
              vm.defaultWallpaperList.map((item, index) => {
                getOssResourse(userId, { key: item.resKey })
                  .fetch()
                  .then(({ success, msg, data }) => {
                    if (success) {
                      vm.defaultWallpaperList[index].url = data;
                      if (
                        !vm.formDataCopy.style.background ||
                        !vm.formDataCopy.style.background.length
                      ) {
                        if (index === 0) {
                          vm.background = vm.defaultWallpaperList[index].url;
                          vm.formDataCopy.style.background = vm.defaultWallpaperList[index].resKey;
                          vm.formDataCopy.style.bkType = vm.defaultWallpaperList[index].fileType;
                          vm.formDataCopy.style.bkId = vm.defaultWallpaperList[index].resourceId;
                        }
                      }
                    }
                  });
              });
            }
          } else {
            if (flag) {
              vm.$Message.destroy();
              vm.$Message.error({
                content: msg || '获取用户自定义壁纸列表失败！',
                duration: 5,
                closable: true
              });
            } else {
              vm.$Message.destroy();
              vm.$Message.error({
                content: msg || '获取设备内置壁纸列表失败！',
                duration: 5,
                closable: true
              });
            }
          }
        })
        .catch(err => {
          if (flag) {
            vm.$Message.destroy();
            vm.$Message.error({
              content: err.msg || '获取用户自定义壁纸列表失败！',
              duration: 5,
              closable: true
            });
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: err.msg || '获取设备内置壁纸列表失败！',
              duration: 5,
              closable: true
            });
          }
        });
    },

    // 打开选择壁纸对话框
    handleOpenWallpaperModal() {
      this.showWallpaperModal = true;
    },

    // 关闭壁纸对话框
    closeWallpaperModal() {
      this.showWallpaperModal = false;
    },

    // 提交选定壁纸
    onOkWallpaperModal(item) {
      this.background = item.url;
      this.formDataCopy.style.background = item.resKey;
      this.formDataCopy.style.bkType = item.fileType;
      this.formDataCopy.style.bkId = item.resourceId;
      this.showWallpaperModal = false;
      this.$forceUpdate();
      this.saveFormDataToLocalStorage();
    },

    // 铭牌样式选择框改变事件
    onStyleChange() {
      this.saveFormDataToLocalStorage();
    },

    // // 会议议程
    // 打开上传会议议程文件（PDF、Word、PPT）
    handleOpenAgendaModal(file, key) {
      switch (key) {
        case 'PDF':
          this.agendaTitle = '上传PDF文件';
          this.openAgendaModal(key, file);
          break;

        case 'PPT':
          this.agendaTitle = '上传PPT文件';
          this.openAgendaModal(key, file);
          break;

        case 'Word':
          this.agendaTitle = '上传Word文件';
          this.openAgendaModal(key, file);
          break;
      }
    },

    // 打开选择会议议程对话框
    openAgendaModal(key, file) {
      this.fileData = {
        name: '',
        personIds: [], // 资源推送目标参会人id
        resourceIds: [], // 资源id列表
        fileType: key === 'Word' ? 'Doc' : key, // 文件类型
        size: 0 // 文件大小
      };
      this.agendaFileList = [];
      this.userList = [];
      // 筛选出可选资料接收人列表
      this.formDataCopy.devices.map((item, index) => {
        if (!item._editing && item.person && item.person.id) {
          this.userList.push(item.person);
        }
      });
      // 在非图片的文件下有file
      if (file) {
        this.file = file;
        this.fileData.name = file.name;
        this.fileData.size = file.size;
      }
      if (key === 'Image') {
        this.showAgendaImgModal = true;
      } else {
        this.showAgendaDefaultModal = true;
      }
    },

    // 关闭选择会议议程对话框
    closeAgendaModal(key) {
      if (key === 'Image') {
        this.showAgendaImgModal = false;
      } else {
        this.showAgendaDefaultModal = false;
      }

      this.agendaFileList = [];
      this.fileData = {
        name: '',
        personIds: [], // 资源推送目标参会人id
        resourceIds: [], // 资源id列表
        fileType: '', // 文件类型
        size: 0 // 文件大小
      };
    },

    // 提交已选择会议议程图片
    onOkAgendaModal(fileData, flag) {
      if (flag) {
        this.formDataCopy.agendaResources.push(fileData);
        if (fileData.fileType === 'Image') {
          this.showAgendaImgModal = false;
        } else {
          this.showAgendaDefaultModal = false;
        }
        this.saveFormDataToLocalStorage();
      }
    },

    // 删除会议议程图片
    deleteAgendaFile(index) {
      this.$Modal.confirm({
        title: '确定删除该份资料吗？',
        onOk: () => {
          this.formDataCopy.agendaResources.splice(index, 1);
          this.saveFormDataToLocalStorage();
        }
      });
    },

    // // 会议资料
    // 1、会议资料：图片
    // 打开选择会议资料文件对话框
    handleOpenNormalFileModal(file, value) {
      switch (value) {
        case 'PDF':
          this.normalFileTitle = '上传PDF文件';
          this.openNormalFileModal(value, file);
          break;

        case 'Video':
          this.normalFileTitle = '上传视频文件';
          this.openNormalFileModal(value, file);
          break;

        case 'PPT':
          this.normalFileTitle = '上传PPT文件';
          this.openNormalFileModal(value, file);
          break;

        case 'Word':
          this.normalFileTitle = '上传Word文件';
          this.openNormalFileModal(value, file);
          break;
      }
    },

    // 打开选择会议议程对话框
    openNormalFileModal(key, file) {
      this.normalFileData = {
        name: '',
        personIds: [], // 资源推送目标参会人id
        resourceIds: [], // 资源id列表
        fileType: key === 'Word' ? 'Doc' : key, // 文件类型
        size: 0 // 文件大小
      };
      this.normalFileList = [];
      this.userList = [];
      // 筛选出可选资料接收人列表
      this.formDataCopy.devices.map((item, index) => {
        if (!item._editing && item.person && item.person.id) {
          this.userList.push(item.person);
        }
      });
      // 在非图片的文件下有file
      if (file) {
        this.file = file;
        this.normalFileData.name = file.name;
        this.normalFileData.size = file.size;
      }
      if (key === 'Image') {
        this.showNormalImgModal = true;
      } else {
        this.showNormalDefaultModal = true;
      }
    },

    // 关闭选择会议议程文件对话框
    closeNormalFileModal(value) {
      switch (value) {
        case 'Image':
          this.showNormalImgModal = false;
          break;

        default:
          this.showNormalDefaultModal = false;
      }
      this.normalFileList = [];
      this.normalFileData = {
        name: '',
        personIds: [], // 资源推送目标参会人id
        resourceIds: [], // 资源id列表
        fileType: '', // 文件类型
        size: 0 // 文件大小
      };
    },

    // 提交已选择图片
    onOkNormalFileModal($event, value) {
      if ($event.flag) {
        this.formDataCopy.normalResources.push($event.normalFileData);
        switch (value) {
          case 'Image':
            this.showNormalImgModal = false;
            break;

          default:
            this.showNormalDefaultModal = false;
            break;
        }
        this.saveFormDataToLocalStorage();
      }
    },

    // 删除会议资料资源
    deleteNormalFile(index) {
      this.$Modal.confirm({
        title: '确定删除该份资料吗？',
        onOk: () => {
          this.formDataCopy.normalResources.splice(index, 1);
          this.saveFormDataToLocalStorage();
        }
      });
    },

    // 点击添加会议
    addMeeting(formDataCopy, flag) {
      const vm = this;
      formDataCopy.startNow = flag;
      if (!formDataCopy.name) {
        vm.$Message.destroy();
        vm.$Message.error({
          content: '会议名称不能为空！',
          duration: 5,
          closable: true
        });
        return;
      }
      if (!formDataCopy.devices || !formDataCopy.devices.length) {
        vm.$Message.destroy();
        vm.$Message.error({
          content: '参会人不能为空！',
          duration: 5,
          closable: true
        });
        return;
      }

      // 校验行表单
      const validateValue = vm.validateAllRowForm();
      if (!validateValue) {
        vm.$Message.error({
          content: '请完整填写铭牌与姓名信息！',
          duration: 5,
          closable: true
        });
        return;
      }

      // 把已有参会人和设备的行数据提交
      // 1、获取在编辑的新增行数量，并把下标放到一个数组
      //    获取在编辑的修改行数量，并把下标放到一个数组
      // 2、没有在编辑状态的数据是直接推送会议
      // 3、调用批量请求接口
      var status = false;
      const indexAddArr = []; // 新增的行数据下标index数组
      const indexAlterArr = []; // 修改的行数据下标index数组

      const addDataList = []; // 批量新增参会人数据
      const alterDataList = []; // 批量修改的参会人数据

      for (let i = 0; i < formDataCopy.devices.length; i++) {
        var row = formDataCopy.devices[i];
        if (row._editing) {
          var person = {
            name: row._copy.person.name,
            company: row._copy.person.company,
            position: row._copy.person.position,
            logo: row._copy.person.logo
          };
          if (row._copy.person.id) {
            indexAlterArr.push(i);
            person.id = row._copy.person.id;
            alterDataList.push(person);
          } else {
            indexAddArr.push(i);
            person.disable = true;
            addDataList.push(person);
          }
        }
      }

      // 没有在编辑状态的数据是直接推送会议
      if (!indexAddArr.length && !indexAlterArr.length) {
        vm.$emit('on-save', this.convertFormData(formDataCopy));
        return;
      }

      // 有修改参会人时批量修改并在回调中赋值
      if (alterDataList.length) {
        vm.alterAttendee(alterDataList, () => {
          for (let j = 0; j < indexAlterArr.length; j++) {
            var row = vm.formDataCopy.devices[indexAlterArr[j]];
            Object.assign(row, row._copy);
            row._copy = undefined;
            row._editing = false;
            row._add = false;
            vm.saveFormDataToLocalStorage();
          }

          // 当所有在编辑状态的修改完再推送会议
          status = vm.getStatus();
          if (status) {
            vm.$emit('on-save', this.convertFormData(formDataCopy));
          }
        });
      }

      // 有新增参会人时批量添加并在回调中把返回数据赋值给参会人列表
      if (addDataList.length) {
        vm.addAttendee(addDataList, data => {
          const dataList = deepCopy(data);
          for (let m = 0; m < dataList.length; m++) {
            var row = vm.formDataCopy.devices[indexAddArr[m]];
            row._copy.person.id = dataList[m].id;
            Object.assign(row, row._copy);
            row._copy = undefined;
            row._editing = false;
            row._add = false;
            vm.saveFormDataToLocalStorage();
          }

          // 当所有在编辑状态的修改完再推送会议
          status = vm.getStatus();
          if (status) {
            vm.$emit('on-save', this.convertFormData(formDataCopy));
          }
        });
      }
    },
    convertFormData(formData) {
      formData.votes &&
        (formData.votes = formData.votes.map(vote => {
          const options = [];
          vote.optionA && options.push(vote.optionA.name);
          vote.optionB && options.push(vote.optionB.name);
          vote.optionC && options.push(vote.optionC.name);
          vote.optionD && options.push(vote.optionD.name);
          vote.optionE && options.push(vote.optionE.name);
          return {
            id: vote.id,
            title: vote.title,
            anonymous: vote.anonymous,
            options: options
          };
        }));
      return formData;
    },
    getStatus() {
      var flag = true;
      for (let n = 0; n < this.formDataCopy.devices.length; n++) {
        if (this.formDataCopy.devices[n]._editing) {
          return false;
        }
      }
      return flag;
    },

    // 表单为编辑时 取消修改
    onEditCancle() {
      this.$emit('on-cancle');
    },

    // 删除已创建但开始会议
    onDelete() {
      this.$emit('on-delete');
    },

    // 点击弹出导入设备对话框/导入联系人对话框
    onClickImport(name) {
      const vm = this;
      const attendeeListCopy = deepCopy(vm.attendeeList);
      if (name === 'persons') {
        vm.modalAttendeeList = [];
        // 从联系人列表中剔除已选联系人
        vm.formDataCopy.devices.map(deviceItem => {
          if (
            (deviceItem.person && deviceItem.person.id) ||
            (deviceItem._copy.person && deviceItem._copy.person.id)
          ) {
            var index = '';
            if (deviceItem.person && deviceItem.person.id) {
              index = indexOfByKeyAndValue(attendeeListCopy, 'id', deviceItem.person.id);
            } else if (deviceItem._copy.person && deviceItem._copy.person.id) {
              index = indexOfByKeyAndValue(attendeeListCopy, 'id', deviceItem._copy.person.id);
            }
            if (index !== -1) {
              attendeeListCopy.splice(index, 1);
            }
          }
        });
        vm.modalAttendeeList = deepCopy(attendeeListCopy);
        vm.showImportPersonsModal = true;
      } else if (name === 'devices') {
        vm.getDeviceList(() => {
          vm.modalDeviceList = [];
          const deviceListCopy = deepCopy(vm.deviceList);

          // 从设备列表中剔除已选设备
          vm.formDataCopy.devices.map(deviceItem => {
            if (deviceItem.devId || deviceItem._copy.devId) {
              var index = '';
              if (deviceItem.devId) {
                index = indexOfByKeyAndValue(deviceListCopy, 'devId', deviceItem.devId);
              } else if (deviceItem._copy.devId) {
                index = indexOfByKeyAndValue(deviceListCopy, 'devId', deviceItem._copy.devId);
              }
              if (index !== -1) {
                deviceListCopy.splice(index, 1);
              }
            }
          });
          vm.modalDeviceList = deepCopy(deviceListCopy);
          vm.showImportDevicesModal = true;
        });
      }
    },

    // 关闭导入设备对话框
    closeImportDevicesModal() {
      // 关闭批量导入设备对话框
      this.showImportDevicesModal = false;
    },

    // 确认导入设备
    onOkImportDevicesModal(selection) {
      const vm = this;
      // 把选中的push到设备列表中
      var count = 0;
      vm.formDataCopy.devices.map((item, index) => {
        if (item._editing && !item._copy.devId) {
          count = count + 1;
        }
      });

      if (selection.length <= count) {
        for (let i = 0; i < selection.length; i++) {
          for (let j = 0; j < vm.formDataCopy.devices.length; j++) {
            const row = vm.formDataCopy.devices[j];
            if (row._editing && !row._copy.devId) {
              row._copy.devId = selection[i].devId;
              row._copy.devName = selection[i].devName;
              row._copy.number = selection[i].number;
              row._copy.online = selection[i].online;
              row._copy.meetingStatus = selection[i].meetingStatus;
              row._copy.shadow = selection[i].shadow;
              break;
            }
          }
        }
      } else {
        for (let i = 0; i < selection.length; i++) {
          if (i < count) {
            for (let j = 0; j < vm.formDataCopy.devices.length; j++) {
              const row = vm.formDataCopy.devices[j];
              if (row._editing && !row._copy.devId) {
                row._copy.devId = selection[i].devId;
                row._copy.devName = selection[i].devName;
                row._copy.number = selection[i].number;
                row._copy.online = selection[i].online;
                row._copy.meetingStatus = selection[i].meetingStatus;
                row._copy.shadow = selection[i].shadow;
                break;
              }
            }
          } else {
            const deviceItem = {
              _editing: true,
              _add: true,
              _copy: {
                devId: '',
                devName: '',
                number: '',
                online: '',
                shadow: { state: { reported: { common: { battery: '' } } } }, // 设备电量状态
                comment: '',
                meetingStatus: null,
                person: {
                  id: '',
                  name: '',
                  company: '',
                  logo: '',
                  logoUrl: '',
                  position: ''
                }
              }
            };
            deviceItem._copy.devId = selection[i].devId;
            deviceItem._copy.devName = selection[i].devName;
            deviceItem._copy.number = selection[i].number;
            deviceItem._copy.online = selection[i].online;
            deviceItem._copy.meetingStatus = selection[i].meetingStatus;
            deviceItem._copy.shadow = selection[i].shadow;
            vm.formDataCopy.devices.push(deviceItem);
          }
        }
      }

      // 关闭批量导入设备对话框
      vm.showImportDevicesModal = false;
      vm.saveFormDataToLocalStorage();
    },

    // 关闭导入联系人对话框
    closeImportPersonsModal() {
      // 关闭批量导入设备对话框
      this.showImportPersonsModal = false;
    },

    // 确认导入已选择的联系人
    onOkImportPersonsModal(selection) {
      const vm = this;
      // 把选中的push到设备列表中
      const userId = vm.$store.state.user.userId;

      // 定义参会人列表行中可添加参会人的行数量
      var count = 0;
      vm.formDataCopy.devices.map((item, index) => {
        if (item._editing && !item._copy.person.id && !item._copy.person.name) {
          count = count + 1;
        }
      });
      // 当批量导入的参会人大于count时，可顺序遇空补位
      if (selection.length <= count) {
        for (let i = 0; i < selection.length; i++) {
          for (let j = 0; j < vm.formDataCopy.devices.length; j++) {
            const row = vm.formDataCopy.devices[j];
            if (row._editing && !row._copy.person.id && !row._copy.person.name) {
              row._copy.person = deepCopy(selection[i]);
              // 统一重置person的id，提交时都新创建参会人
              row._copy.person.id = '';
              if (row._copy.person.logo) {
                getOssResourse(userId, { id: row._copy.person.logo })
                  .fetch()
                  .then(({ success, msg, data }) => {
                    if (success) {
                      row._copy.person.logoUrl = data;
                    }
                  })
                  .catch(err => {
                    window.console.log(err);
                  });
              }
              break;
            }
          }
        }
      } else {
        // 当批量导入的参会人小于count时
        for (let i = 0; i < selection.length; i++) {
          // 小于count，按顺序遇空补位
          if (i < count) {
            for (let j = 0; j < vm.formDataCopy.devices.length; j++) {
              const row = vm.formDataCopy.devices[j];
              if (row._editing && !row._copy.person.id && !row._copy.person.name) {
                row._copy.person = deepCopy(selection[i]);
                // 统一重置person的id，提交时都新创建参会人
                row._copy.person.id = '';
                if (row._copy.person.logo) {
                  getOssResourse(userId, { id: row._copy.person.logo })
                    .fetch()
                    .then(({ success, msg, data }) => {
                      if (success) {
                        row._copy.person.logoUrl = data;
                      }
                    })
                    .catch(err => {
                      window.console.log(err);
                    });
                }
                break;
              }
            }
          } else {
            // 大于等于count，则需创建新的一行再导入
            const deviceItem = {
              _editing: true,
              _add: true,
              _copy: {
                devId: '',
                devName: '',
                number: '',
                online: '',
                shadow: { state: { reported: { common: { battery: '' } } } }, // 设备电量状态
                comment: '',
                meetingStatus: null,
                person: {
                  id: '',
                  name: '',
                  company: '',
                  logo: '',
                  logoUrl: '',
                  position: ''
                }
              }
            };
            deviceItem._copy.person = deepCopy(selection[i]);
            // 统一重置person的id，提交时都新创建参会人
            deviceItem._copy.person.id = '';
            vm.formDataCopy.devices.push(deviceItem);

            if (deviceItem._copy.person.logo) {
              getOssResourse(userId, { id: deviceItem._copy.person.logo })
                .fetch()
                .then(({ success, msg, data }) => {
                  if (success) {
                    const devList = deepCopy(vm.formDataCopy.devices);
                    for (let n = 0; n < devList.length; n++) {
                      if (devList[n]._copy.person.logo === deviceItem._copy.person.logo) {
                        vm.formDataCopy.devices[n]._copy.person.logoUrl = data;
                      }
                    }
                  }
                })
                .catch(err => {
                  window.console.log(err);
                });
            }
          }
        }
      }

      vm.formDataCopy.devices.map((item, index) => {
        if (
          item._editing &&
          (item._copy.person.id || item._copy.person.name) &&
          !item._copy.devId
        ) {
          vm.autoAssignDev(item._copy);
        }
      });

      // 关闭批量导入联系人对话框
      vm.showImportPersonsModal = false;
      vm.saveFormDataToLocalStorage();
    },

    // 打开选择支持人对话框
    openSelectHostModal() {
      this.hostList = [];
      this.formDataCopy.devices.map((item, index) => {
        if (item.person && item.person.id) {
          this.hostList.push(item.person);
        }
      });
      this.showSelectHostModal = true;
    },

    // 关闭选择主持人对话框
    closeSelectHostModal() {
      this.showSelectHostModal = false;
    },

    // 确认已导入联系人
    onOkSelectHostModal(host) {
      this.formDataCopy.host = host;
      this.hostList = [];
      this.formDataCopy.devices.map((item, index) => {
        if (!item._editing) {
          this.hostList.push(item.person);
        }
      });
      this.showSelectHostModal = false;
      this.saveFormDataToLocalStorage();
    },

    // 打开导入excel文件的modal
    openExcelUploadModal() {
      //
      this.showExcelUploadModal = true;
    },

    // 关闭导入excel文件的modal
    closeExcelUploadModal() {
      this.showExcelUploadModal = false;
    },

    // 上传结果页面，点击“完成”按钮触发
    onOkExcelUploadModal(list) {
      const vm = this;
      if (list.length) {
        vm.onOkImportPersonsModal(list);
      }
      vm.showExcelUploadModal = false;
    },

    // 获取公司logoUrl
    getLogoUrl(row, index, callback) {
      const vm = this;
      const userId = this.$store.state.user.userId;
      var id = '';
      if (row._editing) {
        id = row._copy.person.logo;
      } else {
        id = row.person.logo;
      }

      getOssResourse(userId, { id })
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            if (row._editing) {
              vm.formData.devices[index]._copy.person.logoUrl = data;
            } else {
              vm.formData.devices[index].person.logoUrl = data;
            }
            callback();
          } else {
            callback();
          }
        })
        .catch(err => {
          window.console.log(err);
        });
    },

    // 获取铭牌壁纸
    getBackground(style) {
      const vm = this;
      const userId = vm.$store.state.user.userId;
      // 判断壁纸类型是图片还是视频
      // 壁纸类型为图片
      if (style.bkType === 'Image') {
        const key = { key: style.background };
        getOssResourse(userId, key)
          .fetch()
          .then(({ success, msg, data }) => {
            if (success) {
              vm.background = data;
            }
          })
          .catch(err => {
            window.console.log(err);
          });
      } else if (style.bkType === 'Video') {
        if (style.bkId) {
          getScreenshot(style.bkId)
            .fetch()
            .then(({ success, msg, data }) => {
              if (success) {
                vm.background = data;
              }
            })
            .catch(err => {
              window.console.log(err);
            });
        }
      }
    },

    // 打开创建提词对话框
    handleOpenKeywordModal() {
      this.userList = [];
      // 筛选出可选资料接收人列表
      this.formDataCopy.devices.map((item, index) => {
        if (!item._editing && item.person && item.person.id) {
          this.userList.push(item.person);
        }
      });
      // 如果没有可选参会人则不打开
      if (!this.userList.length) {
        this.$Message.info({
          content: '请先创建参会人，并点击“添加”确认',
          duration: 5,
          closable: true
        });
        return;
      }
      this.keywordsData = {
        title: '',
        keyword: '',
        personId: null
      };
      this.contentItemTitle = '新增提词';
      this.showAddKeywordModal = true;
    },

    // 关闭新建提词对话框
    closeKeywordModal() {
      this.showAddKeywordModal = false;
      this.editKeywordType = false;
    },

    // 点击确认新建提词
    onOkKeywordModal(data) {
      const vm = this;
      const dataCopy = deepCopy(vm.formDataCopy);
      if (vm.formDataCopy.id && !data.meetingId) {
        data.meetingId = vm.formDataCopy.id;
      }
      if (!dataCopy.keywords) {
        dataCopy.keywords = [];
      }
      if (vm.editKeywordType) {
        Object.keys(vm.keywordsData).forEach(key => {
          vm.currKeywordData[key] = vm.keywordsData[key];
        });
      } else {
        dataCopy.keywords.push(data);
        vm.formDataCopy = deepCopy(dataCopy);
      }
      vm.showAddKeywordModal = false;
      vm.editKeywordType = false;
      vm.saveFormDataToLocalStorage();
    },

    // 打开编辑提词
    onEditKeyword(item) {
      this.contentItemTitle = '编辑提词';
      this.currKeywordData = item;
      this.keywordsData = deepCopy(item);
      this.showAddKeywordModal = true;
      this.editKeywordType = true;
    },

    // 删除提词
    onCloseKeyword(index) {
      this.$Modal.confirm({
        title: '确定要删除该条提词内容吗？',
        onOk: () => {
          this.formDataCopy.keywords.splice(index, 1);
          this.saveFormDataToLocalStorage();
        }
      });
    },

    // 打开创建投票对话框
    handleOpenVoteModal() {
      this.voteData = {
        title: '',
        anonymous: false
      };
      this.showVoteModal = 'Create';
    },

    // 关闭新建投票对话框
    closeVoteModal() {
      this.showVoteModal = '';
    },

    // 点击确认新建投票
    onOkVoteModal(voteData) {
      let flag = true;
      if (!this.formDataCopy.votes) {
        this.formDataCopy.votes = [];
      }
      if (this.showVoteModal === 'Modify') {
        for (let index in this.formDataCopy.votes) {
          const vote = this.formDataCopy.votes[index];
          if (vote.title === voteData.oldTitle) {
            this.setVote(vote, voteData);
            break;
          }
        }
      } else {
        this.formDataCopy.votes.map((item, index) => {
          if (item.title === voteData.title) {
            this.$Message.destroy();
            this.$Message.info({
              content: '投票内容已存在',
              duration: 5,
              closable: true
            });
            flag = false;
          }
          this.showVoteModal = '';
        });
        if (flag) {
          const vote = {};
          this.setVote(vote, voteData);
          this.formDataCopy.votes.push(vote);
        }
      }
      if (flag) {
        this.showVoteModal = '';
        this.editVoteType = false;
        this.saveFormDataToLocalStorage();
      }
    },

    // 打开编辑投票内容
    onEditVote(vote) {
      this.voteData = {
        id: vote.id,
        title: vote.title,
        oldTitle: vote.title,
        optionA: null,
        optionB: null,
        optionC: null,
        optionD: null,
        optionE: null,
        anonymous: vote.anonymous
      };
      vote.optionA && (this.voteData.optionA = vote.optionA.name);
      vote.optionB && (this.voteData.optionB = vote.optionB.name);
      vote.optionC && (this.voteData.optionC = vote.optionC.name);
      vote.optionD && (this.voteData.optionD = vote.optionD.name);
      vote.optionE && (this.voteData.optionE = vote.optionE.name);
      this.showVoteModal = 'Modify';
      this.editVoteType = true;
    },

    setVote(vote, voteData) {
      vote.title = voteData.title;
      vote.anonymous = voteData.anonymous;
      vote.status = 'Created';
      vote.optionA = null;
      vote.optionB = null;
      vote.optionC = null;
      vote.optionD = null;
      vote.optionE = null;
      voteData.options.forEach((item, option) => {
        const opt = {
          name: item
        };
        switch (option) {
          case 0:
            vote.optionA = opt;
            break;
          case 1:
            vote.optionB = opt;
            break;
          case 2:
            vote.optionC = opt;
            break;
          case 3:
            vote.optionD = opt;
            break;
          case 4:
            vote.optionE = opt;
            break;
          default:
            break;
        }
      });
    },

    // 删除投票
    onCloseVote(index) {
      this.$Modal.confirm({
        title: '确定要删除该项投票吗？',
        onOk: () => {
          this.formDataCopy.votes.splice(index, 1);
          this.saveFormDataToLocalStorage();
        }
      });
    },

    // 校验所有行表单
    validateAllRowForm() {
      if (!this.formDataCopy.devices || !this.formDataCopy.devices.length) {
        return;
      }

      let passed = true;

      for (let i = 0; i < this.formDataCopy.devices.length; i++) {
        // 表单校验
        const $nameForm = this.$refs['nameForm_' + i];
        const $devIdForm = this.$refs['devIdForm_' + i];

        $nameForm &&
          $nameForm.validate(valid => {
            passed = passed && valid;
          });
        $devIdForm &&
          $devIdForm.validate(valid => {
            passed = passed && valid;
          });
      }
      return passed;
    },

    showPersonNameMessage(row, limit, name) {
      if (this.isSel) {
        // 如果输入框的改变是选中内容引发的，就什么也不做，同时重新初始化标识，为了解决选中同一内容两次引发的bug
        this.isSel = false;
        return false;
      }
      const text = row.person.name.replace(/^[\s\n]+/gm, '');
      this.$nextTick(() => {
        row.person.name = text;
        if (row.person.name.length > limit) {
          this.$Message.destroy();
          this.$nextTick(() => {
            row.person.name = row.person.name.substring(0, limit);
            if (name === '姓名') {
              localStorage.setItem('formData', JSON.stringify(this.formDataCopy));
            }
          });
          this.$forceUpdate();
          this.$Message.info({
            content: name + '不超过' + limit + '个字符',
            duration: 5,
            closable: true
          });
        }
      });
    },

    // 超出输入框最大长度弹出提示
    showMessageOfOverLimit($event, text, limit, name) {
      // 在Chrome下keyCode=229 而不是13
      if (
        ($event.keyCode >= 48 && $event.keyCode <= 57) ||
        ($event.keyCode >= 65 && $event.keyCode <= 90) ||
        ($event.keyCode >= 96 && $event.keyCode <= 111) ||
        $event.keyCode === 13 ||
        $event.keyCode === 32 ||
        $event.keyCode === 229
      ) {
        if (text.length >= limit) {
          this.$Message.destroy();
          this.$forceUpdate();
          this.$Message.info({
            content: name + '不超过' + limit + '个字符',
            duration: 5,
            closable: true
          });
        }
        this.saveFormDataToLocalStorage();
      }
    },

    // 获取最大长度
    getMaxLength(text, Cnlength, EnLength) {
      return getMaxLength(text, Cnlength, EnLength);
    },

    // 保存表单数据到localStorage
    saveFormDataToLocalStorage() {
      if (this.formType === 'add') {
        if (this.formDataCopy.name || this.formDataCopy.devices.length) {
          localStorage.setItem('formData', JSON.stringify(this.formDataCopy));
        }
      }
    },

    // 返回首页
    toBack() {
      this.$emit('to-back');
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
    const vm = this;
    // 获取参会人列表
    vm.getAttendeeList();
    // 获取设备列表
    vm.getDeviceList();
    // 获取默认壁纸列表
    vm.getDefaultWallpaper(true);
    vm.getDefaultWallpaper(false);
    // 获取参会人表格数据公司logo
    vm.userList = [];
    vm.formDataCopy.devices.length &&
      vm.formDataCopy.devices.map((deviceItem, index) => {
        if (!deviceItem._add && !deviceItem._editing) {
          vm.hostList.push(deviceItem.person);
          vm.userList.push(deviceItem.person);
        }

        if (
          (deviceItem._editing && deviceItem._copy.person && deviceItem._copy.person.logo) ||
          (deviceItem.person && deviceItem.person.logo)
        ) {
          vm.getLogoUrl(deviceItem, index, function callback() {
            vm.formDataCopy = deepCopy(vm.formData);
          });
        }
      });
    // 获取铭牌壁纸
    if (vm.formDataCopy.style.background) {
      vm.getBackground(vm.formDataCopy.style);
    }
    // 如果是编辑状态
    // 会议议程
    if (vm.formData.agendaResources.length) {
      vm.formData.agendaResources.map((agendaResource, agendaIndex) => {
        if (
          vm.formData.agendaResources[agendaIndex].resources &&
          vm.formData.agendaResources[agendaIndex].resources.length
        ) {
          vm.formData.agendaResources[agendaIndex].resourceIds = [];
          vm.formData.agendaResources[agendaIndex].resources.map((item, index) => {
            vm.formData.agendaResources[agendaIndex].resourceIds.push(item.resourceId);
          });
        }
      });
    }
    // 会议资料
    if (vm.formData.normalResources.length) {
      vm.formData.normalResources.map((normalResource, normalIndex) => {
        if (
          vm.formData.normalResources[normalIndex].resources &&
          vm.formData.normalResources[normalIndex].resources.length
        ) {
          vm.formData.normalResources[normalIndex].resourceIds = [];
          vm.formData.normalResources[normalIndex].resources.map((item, index) => {
            vm.formData.normalResources[normalIndex].resourceIds.push(item.resourceId);
          });
        }
      });
    }

    vm.formDataCopy = vm.formData;
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
    this.$emit('on-destroy', null);
  }
};
</script>
<style lang='less'>
th.table-head-style {
  background: #e8eef8;
}

th.require-col {
  .ivu-table-cell :before {
    content: '*';
    color: #ff1818;
    margin-right: 4px;
  }
}

.ivu-auto-complete.ivu-select-dropdown {
  max-height: 200px;
}

.submit-btn {
  font-size: 12px;
  width: 42px;
  height: 22px;
  margin-left: 17px;
  margin-right: -9px;
}

.device-style-margin {
  margin-left: -19px;
}

.device-style-logo {
  .ivu-radio {
    display: none;
  }

  .ivu-radio-wrapper {
    margin-right: 12px;
  }

  .ivu-radio-wrapper-checked {
    color: #0050ff;
    font-family: PingFangSC-Medium;
    font-weight: 550;
  }
}

.device-wallpaper {
  .ivu-form-item-label {
    margin-top: 28px;
  }
}

.device-style-font {
  &-color {
    .ivu-radio {
      display: none;
    }
  }
}

.defalut-inline-content {
  display: inline-flex;
  &-icon {
    width: 18px;
    height: 18px;
    margin-top: 5px;
    margin-right: 4px;

    > img {
      width: 100%;
      height: 100%;
    }
  }

  &-text {
    margin-top: 4px;
  }
}

.upload-entrance {
  width: 106px;

  &-btn {
    display: inline-flex;
    margin-top: 5px;
    &-icon {
      width: 18px;
      height: 18px;

      > img {
        width: 100%;
        height: 100%;
      }
    }
  }

  &-list {
    display: none;
    position: absolute;
    width: 342px;
    height: 88px;
    background: #ffffff;
    border: 1px solid #dbdee2;
    box-shadow: 0px 6px 12px 0px rgba(0, 0, 0, 0.12);
    border-radius: 4px;
    z-index: 3;

    &-body {
      display: inline-flex;
      .center();

      &-item {
        height: 58px;
        margin-right: 15px;
        margin-left: 15px;
      }
    }
  }

  &:hover &-list {
    display: block;
  }
}

.title-bar {
  width: 100%;

  &-header {
    width: 100%;
    position: absolute;
    top: 64px;
    left: 0;
  }
}

.form-content {
  color: #666666;
  font-size: 14px;

  .ivu-form-item {
    margin-bottom: 0 !important;
  }

  &-thumb {
    background: #ffffff;
    height: 76px;
    padding: 22px 38px;
  }

  &-attendee {
    background: #ffffff;
    margin-top: 12px;
    padding: 24px 54px;

    &-header {
      height: 32px;
      margin-bottom: 24px;

      &-title {
        display: inline-flex;

        &-icon {
          width: 30px;
          height: 30px;
          > img {
            width: 100%;
            height: 100%;
          }
        }

        &-text {
          font-family: PingFangSC-Semibold;
          font-size: 16px;
          height: 30px;
          color: #333333;
          line-height: 30px;
          margin-left: 12px;
          font-weight: 600;
        }
      }

      &-button {
        float: right;
        display: inline-flex;

        &-center {
          height: 32px;
          line-height: 32px;
        }

        &-right {
          display: inline-flex;
          margin-top: 5px;
          &-icon {
            width: 18px;
            height: 18px;
            margin-right: 4px;
            > img {
              width: 100%;
              height: 100%;
            }
          }

          &-text {
            height: 18px;
            font-family: PingFangSC-Regular;
            font-size: 14px;
            color: #333333;
            line-height: 18px;
            font-weight: 400;
          }
        }
      }
    }

    &-body {
      position: relative;

      &-action {
        &-edit {
          float: left;
          width: 22px;
          height: 22px;
          margin-left: 28px;

          > img {
            width: 82%;
            height: 82%;
          }

          &:hover {
            cursor: pointer;
          }
        }

        &-close {
          float: left;
          width: 22px;
          height: 22px;
          margin-left: 24px;

          > img {
            width: 82%;
            height: 82%;
          }

          &:hover {
            cursor: pointer;
          }
        }
      }

      &-add {
        float: left;
        width: 18px;
        height: 18px;

        > img {
          width: 100%;
          height: 100%;
        }
      }
    }
  }

  &-type {
    background: #ffffff;
    margin-top: 12px;
    padding: 24px 54px;

    &-title {
      display: inline-flex;

      &-icon {
        width: 30px;
        height: 30px;
        > img {
          width: 100%;
          height: 100%;
        }
      }

      &-text {
        font-family: PingFangSC-Semibold;
        font-size: 16px;
        height: 30px;
        color: #333333;
        line-height: 30px;
        margin-left: 12px;
        font-weight: 600;
      }
    }

    &-wallpaper {
      display: inline-flex;

      &-select {
        width: 45px;
        height: 60px;
        background: #e9eaeb;
      }

      &-button {
        margin-left: 16px;
        margin-top: 28px;
      }
    }

    &-font {
      &-default {
        .ivu-select-selected-value {
          font-family: Arial, Helvetica, sans-serif;
        }
      }

      &-black {
        .ivu-select-selected-value {
          font-family: SimHei, STHeiti;
          font-weight: bold;
        }
      }

      &-song {
        .ivu-select-selected-value {
          font-family: SimSun, STSong;
        }
      }

      &-regular {
        .ivu-select-selected-value {
          font-family: KaiTi, STKaiti;
        }
      }

      &-option {
        &-default {
          font-family: 'Arial,Helvetica,sans-serif;';
        }

        &-black {
          font-family: SimHei, STHeiti;
          font-weight: bold;
        }

        &-song {
          font-family: SimSun, STSong;
        }

        &-regular {
          font-family: KaiTi, STKaiti;
        }
      }
    }

    &-fontcolor {
      display: inline-flex;

      &-icon {
        width: 20px;
        height: 20px;
        margin-right: 6px;
        margin-top: 5px;

        > img {
          width: 100%;
          height: 100%;
        }
      }
    }
  }

  &-file {
    background: #ffffff;
    margin-top: 12px;
    padding: 24px 54px;
    font-size: 14px;
    color: #666666;

    &-title {
      display: inline-flex;

      &-icon {
        width: 30px;
        height: 30px;
        > img {
          width: 100%;
          height: 100%;
        }
      }

      &-text {
        font-family: PingFangSC-Semibold;
        font-size: 16px;
        height: 30px;
        color: #333333;
        line-height: 30px;
        margin-left: 12px;
        font-weight: 600;
      }
    }

    &-tips {
      font-family: PingFangSC-Regular;
      font-size: 12px;
      color: #999999;
      line-height: 12px;
      margin-top: 12px;
    }
  }

  &-vote {
    height: 100%;
  }
}

.table-icon {
  width: 77px;
  height: 21px;
  background: #e8eef8;

  > img {
    width: 100%;
    height: 100%;
  }
}

.pointer {
  cursor: pointer;
}

.file-margin-left {
  margin-left: 82px;
}
</style>
