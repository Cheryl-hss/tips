import MeetingForm from './meeting-form.vue';

export default MeetingForm;
