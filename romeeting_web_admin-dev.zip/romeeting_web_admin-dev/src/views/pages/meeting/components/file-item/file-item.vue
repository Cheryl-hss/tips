<template>
  <div>
    <div class="file-item"
         :class="showWhiteBackaground ? 'white' : 'default'">
      <Row>
        <Col span="24">
        <div class="file-item-left">
          <img :src="fileIcon" />
        </div>
        <div class="file-item-center margin-left">
          <div class="file-item-center-title"
               :title="fileData.name ">{{ fileData.name }}</div>
          <div class="file-item-center-body">
            <span> {{ fileData.size && changeSize(fileData.size) }}</span>
            <span class="margin-left">
              {{ fileData.resources && fileData.resources.length || fileData.id && fileData.id.length || fileData.resourceIds && fileData.resourceIds.length || 1 }}
              <span v-if="fileData.fileType && fileData.fileType === 'Image'">张</span>
              <span v-else>份</span>
            </span>
          </div>
        </div>
        </Col>
        <div v-if="showDownload || showDelete"
             class="file-item-right"
             @click="onClick">
          <img v-if="showDownload"
               src="@/assets/images/icon-download@2x.png" />
          <img v-if="showDelete"
               src="@/assets/images/icon-close@2x.png" />
        </div>
      </Row>

      <div v-if="showUsers">
        <div v-if="fileData.personIds && fileData.personIds.length"
             class="file-item-person"
             :title="personsName">接收人：{{ personsName }}</div>
        <div v-else
             class="file-item-person">接收人：所有人</div>
      </div>

      <Progress v-if="showProgress"
                :percent="progressPercent"
                :stroke-width="2"
                hide-info />
    </div>
  </div>
</template>

<script>
import { Row, Col, Progress } from 'view-design';

import { indexOfByKeyAndValue } from '@/utils/tools';

export default {
  // 不要忘记了 name 属性
  name: 'FileItem',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    fileData: {
      // 文件类型（jpg，pdf）
      type: Object,
      default() {
        return {};
      }
    },

    progressPercent: {
      // 进度条进度
      type: Number,
      default() {
        return 0;
      }
    },

    showDownload: {
      // 是否显示文件下载按钮，否，则显示删除文件按钮
      type: Boolean,
      default() {
        return false;
      }
    },

    showDelete: {
      // 是否显示文件下载按钮，否，则显示删除文件按钮
      type: Boolean,
      default() {
        return false;
      }
    },

    showProgress: {
      // 是否显示文件进度
      type: Boolean,
      default() {
        return false;
      }
    },

    showUsers: {
      // 是否显示可查看资料的用户范围
      type: Boolean,
      default() {
        return false;
      }
    },

    showWhiteBackaground: {
      // 是否显示白色背景
      type: Boolean,
      default() {
        return false;
      }
    },

    userList: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  // 变量
  data() {
    return {};
  },

  // 使用其它组件
  components: { Row, Col, Progress },
  // 计算属性
  computed: {
    fileIcon() {
      if (this.fileData.fileType) {
        return require(`@/assets/images/file-${this.fileData.fileType.toLowerCase()}@2x.png`);
      }
      return require(`@/assets/images/file-image@2x.png`);
    },

    personsName() {
      var names = '';
      if (this.fileData.personIds && this.fileData.personIds.length) {
        this.fileData.personIds.map(id => {
          if (this.userList.length) {
            const index = indexOfByKeyAndValue(this.userList, 'id', id);
            if (index !== -1) {
              if (names.length) {
                names = names + '，' + this.userList[index].name;
              } else {
                names = names + this.userList[index].name;
              }
            }
          }
        });
      }
      return names;
    }
  },
  // 监听
  watch: {},
  // 方法
  methods: {
    // 点击事件
    onClick() {
      this.$emit('on-click');
    },

    changeSize(limit) {
      var size = '';
      if (limit < 0.1 * 1024) {
        // 小于0.1KB，则转化成B
        size = limit.toFixed(2) + 'B';
      } else if (limit < 0.1 * 1024 * 1024) {
        // 小于0.1MB，则转化成KB
        size = (limit / 1024).toFixed(2) + 'KB';
      } else if (limit < 0.1 * 1024 * 1024 * 1024) {
        // 小于0.1GB，则转化成MB
        size = (limit / (1024 * 1024)).toFixed(2) + 'MB';
      } else {
        // 其他转化成GB
        size = (limit / (1024 * 1024 * 1024)).toFixed(2) + 'GB';
      }

      var sizeStr = size + ''; // 转成字符串
      var index = sizeStr.indexOf('.'); // 获取小数点处的索引
      var dou = sizeStr.substr(index + 1, 2); // 获取小数点后两位的值
      if (dou === '00') {
        // 判断后两位是否为00，如果是则删除00
        return sizeStr.substring(0, index) + sizeStr.substr(index + 3, 2);
      }
      return size;
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.white {
  background: #ffffff;
}

.default {
  background: #f6f7f8;
}

.modal {
  width: auto;
}

.file-item {
  height: 108px;
  width: 100%;
  padding: 18px;
  .clearFix();

  &-left {
    width: 48px;
    height: 48px;
    float: left;
    > img {
      width: 100%;
      height: 100%;
    }
  }

  &-center {
    float: left;
    width: ~'calc(100% - 100px)';

    &-title {
      font-family: PingFangSC-Medium;
      font-size: 14px;
      font-weight: 550;
      width: 100%;
      color: #333333;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    &-body {
      font-family: PingFangSC-Regular;
      font-size: 12px;
      color: #999999;
      margin-top: 6px;
      width: 100%;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  }

  &-right {
    width: 18px;
    height: 18px;
    position: absolute;
    right: 6px;
    top: -7px;

    > img {
      width: 100%;
      height: 100%;
      cursor: pointer;
    }
  }

  &-person {
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #999999;
    margin-left: 64px;
    margin-top: 8px;
    white-space: nowrap; /*强制文本不能换行*/
    overflow: hidden; /*隐藏溢出内容*/
    text-overflow: ellipsis;
  }
}
</style>
