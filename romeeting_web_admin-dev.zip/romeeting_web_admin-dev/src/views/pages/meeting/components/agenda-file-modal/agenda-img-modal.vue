<template>
  <div v-if="value">
    <Modal :value="value"
           :mask-closable="false"
           :width="showUserScope? 500: 750"
           @on-visible-change="onChange">
      <p slot="header"
         class="header">
        <span>上传图片</span>
      </p>
      <div slot="close"
           @click="onClose"
           class="margin-right">
        <Icon type="ios-close"
              :size="35"
              color="#999999" />
      </div>
      <div v-if="!showUserScope">
        <div class="agenda-file">
          <Upload float-left
                  :action="agendaUploadURL"
                  :accept="accept"
                  :format="format"
                  :before-upload="beforeUpload"
                  ref="uploader"
                  multiple>
            <Button icon="md-cloud-upload">
              选择文件
            </Button>
          </Upload>
          <span class="margin-left-12 agenda-file-tips">一次最多30张图片</span>
          <div class="agenda-file-name">
            <div class="agenda-file-name-key">名称：&nbsp;</div>
            <Input class="agenda-file-name-value"
                   v-model="fileData.name"
                   :title="fileData.name"
                   placeholder="必填"
                   maxlength="48"
                   required />
          </div>
        </div>
        <Row class="agenda-file-list"
             :gutter="18"
             type="flex"
             justify="start"
             :styles="{height: '600px'}">
          <Col span="4"
               v-for="(item, index) in fileList"
               :key="index">
          <div class="agenda-file-list-item">
            <img v-if="item.fileType === 'Image'"
                 :src="item.url"
                 :width="item.width / item.height >= 1 ? '90px' : (item.width / item.height)*90 + 'px'"
                 :height="item.height / item.width >= 1 ? '90px' : (item.height / item.width)*90 + 'px'" />
            <div class="agenda-file-list-item-close"
                 @click="handleRemove(index)">
              <img src="@/assets/images/icon-close-img@2x.png" />
            </div>
          </div>
          </Col>
        </Row>
      </div>
      <div v-if="showUserScope">
        <FileItem :file-data="fileData"
                  :show-progress="true"
                  :progress-percent="progressPercent"
                  :show-white-backaground="true" />
        <div style="width: 420px; padding: 0 24px; margin-top: 16px">
          <div>查看范围：</div>
          <div class="modal-scope">
            <div class="modal-scope-radio">
              <RadioGroup v-model="selectScope">
                <Radio label="all">所有人</Radio>
                <Radio class="margin-left"
                       label="assign">指定用户</Radio>
              </RadioGroup>
            </div>
            <div v-if="selectScope === 'assign'"
                 class="modal-scope-select">
              <Select v-model="userScope"
                      multiple>
                <Option v-for="item in userList"
                        :value="item.id"
                        :key="item.id">{{ item.name }}</Option>
              </Select>
            </div>
          </div>
        </div>
      </div>
      <div slot="footer">
        <Button class="button-width"
                @click="onClose">取消</Button>
        <!-- 选择图片后确定 -->
        <Button v-if="fileData.resourceIds.length && !showUserScope"
                class="button-width"
                type="primary"
                :loading="loading"
                @click="onOkShowUserScope">确定</Button>
        <Button v-if="fileData.resourceIds.length === 0 && !showUserScope"
                class="button-width"
                disabled>确定</Button>

        <!-- 选择资料查看人后确定 -->
        <Button v-if="fileData.resourceIds.length && (userScope.length || selectScope === 'all') && showUserScope"
                class="button-width"
                type="primary"
                :loading="loading"
                @click="onOk">确定</Button>
        <Button v-if="!userScope.length && selectScope === 'assign' && showUserScope"
                class="button-width"
                disabled>确定</Button>
      </div>
    </Modal>
  </div>
</template>

<script>
import {
  Modal,
  Icon,
  Upload,
  Button,
  Input,
  Row,
  Col,
  RadioGroup,
  Radio,
  Select,
  Option
} from 'view-design';
import { FileItem } from '../file-item';

import { uploadToOSS, addOssResourse, getOssResourse } from '@/api/upload';
import { deepCopy } from '@/utils/tools';
import Timer from '@/utils/timer';

export default {
  // 不要忘记了 name 属性
  name: 'AgendaImgModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    accept: {
      // 接受上传的文件类型
      type: String,
      default() {
        return '.jpg, .png';
      }
    },

    format: {
      // 上传组件支持的文件类型
      type: Array,
      default() {
        return ['.jpg', '.png'];
      }
    },

    fileList: {
      // 已上传文件列表
      type: Array,
      default() {
        return [];
      }
    },

    fileData: {
      // 已上传的文件对象
      type: Object,
      default() {
        return {};
      }
    },

    userList: {
      // 可选用户列表
      type: Array,
      default() {
        return [];
      }
    },

    value: Boolean // 是否显示
  },
  // 变量
  data() {
    return {
      agendaUploadURL: '', // 会议议程文件上传url
      loading: false, // modal框关闭前确认按钮loading
      flag: false, // modal框是否可以关闭
      clickOk: false,
      showUserScope: false, // 显示选择可查看用户选择框
      selectableLength: 30, // 可选上传文件数量，上线为30
      progressPercent: 0, // 进度条百分比
      selectScope: 'all', // 设置默认选中所以用户
      userScope: [] // 用户id数组
    };
  },

  // 使用其它组件
  components: {
    Modal,
    Icon,
    Upload,
    Button,
    Input,
    Row,
    Col,
    RadioGroup,
    Radio,
    Select,
    Option,
    FileItem
  },
  // 计算属性
  computed: {},
  // 监听
  watch: {
    flag(value) {
      if (!value) {
        this.clickOk = false;
      }
      if (value && this.clickOk) {
        this.$emit('on-ok', this.fileData, value);
      }
      this.loading = false;
    },

    value(value) {
      if (!value) {
        this.selectScope = 'all';
        this.userScope = [];
      }
    }
  },
  // 方法
  methods: {
    // 确认显示选择用户范围选择框
    onOkShowUserScope() {
      this.showUserScope = true;
      this.progressPercent = 0;
      let timer = new Timer({
        interval: 200,
        limit: 4,
        auto: false,
        fn: () => {
          this.progressPercent = this.progressPercent + 25;
          if (this.progressPercent === 100) {
            timer.stop();
            timer.destroy();
          }
        }
      });
      timer.start();
    },

    // 关闭对话框
    onClose() {
      this.clickOk = false;
      // 关闭对话框时恢复可选文件的数量
      this.selectableLength = 30;
      this.showUserScope = false;
      this.$emit('on-close');
    },

    onOk() {
      this.loading = true;
      this.clickOk = true;
      // 关闭对话框时恢复可选文件的数量
      this.selectableLength = 30;
      this.showUserScope = false;
      if (this.selectScope === 'assign') {
        this.fileData.personIds = deepCopy(this.userScope);
      }
      this.$emit('on-ok', this.fileData, this.flag);
    },

    // 显示状态发生变化时触发
    onChange(value) {
      if (!value) {
        this.onClose();
      }
    },

    checkImageWH(file) {
      return new Promise((resolve, reject) => {
        let filereader = new FileReader();
        filereader.onload = e => {
          let src = e.target.result;
          const image = new Image();
          image.onload = () => {
            const response = {
              width: image.width,
              height: image.height
            };
            resolve(response);
          };
          image.onerror = reject;
          image.src = src;
        };
        filereader.readAsDataURL(file);
      });
    },

    // 上传文件前获取到生成的参数信息
    beforeUpload(file) {
      const vm = this;

      if (!vm.fileData.name) {
        vm.fileData.name = file.name;
      }
      if (vm.fileData.resourceIds.length < 30) {
        if (vm.selectableLength > 0) {
          vm.selectableLength = this.selectableLength - 1;
        } else {
          vm.$Message.destroy();
          vm.$Message.warning({
            content: '一次最多上传30张图片',
            duration: 10,
            closable: true
          });
          return;
        }
        vm.flag = false;

        uploadToOSS(file, e => {
          // 拿到onProgress回调e，可以拿到已上传大小和总大小
          window.console.log(e);
        }).then(res => {
          // 当model框被关闭时，阻止继续调用请求
          if (!vm.value) {
            return;
          }
          vm.checkImageWH(file).then(({ width, height }) => {
            // 1、创建oss资源 ，拿到资源id，push到 resourceIds
            // 2、拿返回的objectKey去请求资源，得到资源路径，显示出来

            // 获取用户id
            const userId = this.$store.state.user.userId;
            // 获取创建资源参数
            const fileData = {
              fileKey: res.key,
              name: file.name,
              size: file.size,
              desc: file.desc,
              md5: res.md5,
              fileType: 'Image',
              width,
              height
            };
            vm.fileData.fileType = fileData.fileType;
            // 判断是否存在size，有则加新的size，没有则赋值
            if (vm.fileData.size) {
              vm.fileData.size = vm.fileData.size + fileData.size;
            } else {
              vm.fileData.size = fileData.size;
            }
            // 发送创建资源请求
            addOssResourse(userId, fileData)
              .fetch()
              .then(({ success, msg, data }) => {
                //
                if (success) {
                  // 判断会议议程列表里面是否已存在此文件
                  // 已存在：提示已存在并结束当前程序
                  // 不存在：则继续执行程序 把返回的resourceId push到resourceIds里
                  for (var i = 0; i < vm.fileData.resourceIds.length; i++) {
                    if (vm.fileData.resourceIds[i] === data.resourceId) {
                      vm.$Message.destroy();
                      vm.$Message.warning({
                        content: '“' + file.name + '”' + '在图片列表里已存在！',
                        duration: 5,
                        closable: true
                      });
                      // 文件已在列表里，selectableLength要加1
                      vm.selectableLength = vm.selectableLength + 1;
                      // 这里设置flag为true，防止点击确认按钮时不添加到文件列表里
                      vm.flag = true;
                      return;
                    }
                  }

                  // 把返回资源id push到资源resourceIds
                  vm.fileData.resourceIds.push(data.resourceId);
                  vm.getOssResourse(fileData, userId, { key: res.key });
                } else {
                  vm.$Message.destroy();
                  vm.$Message.error({
                    content: msg || '“' + file.name + '”' + '上传失败，请重试！',
                    duration: 5,
                    closable: true
                  });
                  // 文件上传失败，selectableLength要加1
                  vm.selectableLength = vm.selectableLength + 1;
                }
              })
              .catch(err => {
                vm.$Message.destroy();
                vm.$Message.error({
                  content: err.msg || '“' + file.name + '”' + '上传失败，请重试！',
                  duration: 5,
                  closable: true
                });
                // 文件上传失败，selectableLength要加1
                vm.selectableLength = vm.selectableLength + 1;
              });
          });
        });
      } else {
        // 当文件数量达到30个时不再添加，并提醒用户
        vm.$Message.destroy();
        vm.$Message.warning({
          content: '文件数量已达到上线30个!',
          duration: 5,
          closable: true
        });
      }

      return false;
    },

    getOssResourse(file, userId, key) {
      getOssResourse(userId, key)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            const obj = {
              name: file.name,
              fileType: 'Image',
              url: data,
              width: file.width,
              height: file.height
            };
            this.fileList.push(obj);
            this.flag = true;
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: msg || '“' + file.name + '”' + '获取失败',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          window.console.log(err);
        });
    },

    // 删除资源
    handleRemove(index) {
      this.fileList.splice(index, 1);
      this.fileData.resourceIds.splice(index, 1);
      this.selectableLength = this.selectableLength + 1; // 删除时恢复一个可选项

      if (this.fileData.resourceIds.length === 0) {
        this.fileData.name = '';
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.header {
  text-align: center;
  font-family: PingFangSC-Regular;
  height: 18px;
}

.agenda-file {
  padding: 14px;
  .clearFix();
  &-tips {
    height: 32px;
    line-height: 32px;
    display: inline-block;
  }

  &-name {
    width: 234px;
    height: 32px;
    line-height: 32px;
    display: inline-flex;
    justify-content: flex-end;
    margin-left: 32%;
    &-value {
      width: 180px;
    }
  }

  &-list {
    padding: 0 14px 14px 14px;

    &-item {
      width: 90px;
      height: 90px;
      margin-bottom: 12px;
      background: #f0f0f0;
      > img {
        position: absolute;
        top: 50%;
        left: 50%;
        .transform(translate(-50%, -50%));
        margin-left: -5px;
        margin-top: -6px;
      }
      &-close {
        position: absolute;
        top: 0px;
        right: 20px;
        &:hover {
          cursor: pointer;
        }
      }
    }
  }
}

.button-width {
  width: 92px;
  margin-right: 15px;
}

.modal-divider {
  width: 420px;
  height: 1px;
  border: solid #e8e8e8 0.5px;
  margin: 0 auto;
  margin-top: 4px;
  margin-bottom: 24px;
}

.modal-scope {
  .clearFix();
  width: 420px;
  &-radio {
    float: left;
    height: 32px;
    line-height: 32px;
  }

  &-select {
    float: left;
    width: 250px;
    margin-right: 0;
  }
}
</style>
