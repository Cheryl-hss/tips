import AgendaImgModal from './agenda-img-modal.vue';
import AgendaDefaultModal from './agenda-default-modal.vue';

export { AgendaImgModal, AgendaDefaultModal };
