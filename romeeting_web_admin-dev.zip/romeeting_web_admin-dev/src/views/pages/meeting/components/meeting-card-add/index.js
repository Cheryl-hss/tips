import MeetingCardAdd from './meeting-card-add.vue';

export default MeetingCardAdd;
