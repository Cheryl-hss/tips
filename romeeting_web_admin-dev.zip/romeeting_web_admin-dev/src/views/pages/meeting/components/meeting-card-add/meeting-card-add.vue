<template>
  <div>
    <div @click="onClick">
      <Card class="meeting-add-card"
            dis-hover>
        <div class="meeting-add-card-icon">
          <img src="@/assets/images/add@2x.png"></img>
        </div>
        <div class="meeting-add-card-text">{{ $t('meeting_add') }}</div>
      </Card>
    </div>
  </div>
</template>

<script>
import { Card } from 'view-design';

export default {
  // 不要忘记了 name 属性
  name: 'MeetingCardAdd',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
  },
  // 变量
  data() {
    return {};
  },

  // 使用其它组件
  components: { Card },
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    onClick() {
      this.$emit('on-click');
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.meeting-add-card {
  width: 100%;
  // min-width: 300px;
  height: 160px;
  background: url('~@/assets/images/bg-add@2x.png') !important;
  background-repeat: no-repeat !important;
  background-size: 100% 160px !important;
  border-radius: 6px !important;

  .ivu-card {
    border-radius: 6px !important;
    background: none !important;

    &:hover {
      border-color: #0050ff !important;
    }
  }

  .ivu-card-body {
    padding: 0;
  }

  &:hover {
    cursor: pointer;
  }

  &-icon {
    position: relative;
    left: 50%;
    width: 32px;
    height: 32px;
    margin-left: -16px;
    margin-top: 44px;

    > img {
      width: 100%;
      height: 100%;
    }
  }

  &-text {
    font-family: PingFangSC-Medium;
    font-size: 20px;
    color: #ffffff;
    height: 20px;
    line-height: 20px;
    font-weight: 500;
    text-align: center;
    margin-top: 24px;
  }
}
</style>
