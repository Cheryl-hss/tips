import MeetingHomeHead from './meeting-home-head';

export default MeetingHomeHead;
