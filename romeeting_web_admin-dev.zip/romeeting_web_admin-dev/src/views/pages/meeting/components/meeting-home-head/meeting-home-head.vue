<template>
  <div v-if="value">
    <div class="meeting-home">
      <div class="meeting-home-head">
        <div class="meeting-home-head-logo"></div>
        <div class="meeting-home-head-title">{{ $t('ro_meeting_title') }}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  // 不要忘记了 name 属性
  name: 'MeetingHomeHead',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    value: {
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {};
  },

  // 使用其它组件
  components: {},
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {},
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.meeting-home {
  width: 100%;
  height: 100%;
  background: url('~@/assets/images/bg-home-page@2x.png');
  background-repeat: no-repeat;
  background-position: center;
  background-size: 100% 100%;
  &-head {
    padding-top: 60px;
    &-logo {
      width: 160px;
      height: 26px;
      margin: 0 auto;
      background: url('~@/assets/images/romeeting-login@2x.png');
      background-repeat: no-repeat;
      background-position: center;
      background-size: 160px 26px;
      z-index: 2;
    }

    &-title {
      height: 28px;
      font-family: FZLTHJW--GB1-0;
      font-size: 28px;
      color: #ffffff;
      text-align: center;
      line-height: 28px;
      font-weight: 400;
      margin-top: 24px;
    }
  }
}
</style>
