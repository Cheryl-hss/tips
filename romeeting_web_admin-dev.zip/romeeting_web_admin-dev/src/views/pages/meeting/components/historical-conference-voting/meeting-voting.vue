<template>
  <div class="meeting-vote">
    <div class="meeting-vote-card">
        <div style="border: 1px solid #e8e8e8; margin-bottom: 15px">
          <div class="meeting-vote-card-top" :title="voteData.title">
            <img src="@/assets/images/icon-votingpictures@2x.png"
                 style="height: 18px; width: 18px; margin-top: 11px; margin-right: 12px" />
            <p style="width: 100%;
                      text-align: left;
                      overflow: hidden;
                      white-space: nowrap;
                      -webkit-line-clamp: 1;
                      text-overflow: ellipsis;">{{voteData.title}}</p>
            <div style="width:3%;">
            <img v-if="showDownload"
                 @click="onDownload"
                 src="@/assets/images/icon-download@2x.png"
                 style="height: 18px; width: 18px; position: absolute; margin-top: 11px; right: 30px" />
            </div>
          </div>
          <div style="height: 260px; padding: 10px 30px; overflow: auto;margin-bottom: 20px;">
            <VoteHistoricalModal :value="showMeetingVote"
                                 :vote-data="voteData" />
          </div>
        </div>
    </div>
  </div>
</template>

<script>
import { Row, Col } from 'view-design';
import VoteHistoricalModal from '../vote-modal/vote-historical-modal.vue';
export default {
  // 不要忘记了 name 属性
  name: 'MeetingVoting',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    voteData: {
      type: Object,
      default() {
        return {};
      }
    },
    // 按字母顺序
    showDownload: {
      // 是否显示文件下载按钮
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      showMeetingVote: true
    };
  },

  // 使用其它组件
  components: {
    Row,
    Col,
    VoteHistoricalModal
  },
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    // 下载投票
    onDownload() {
      this.$emit('on-download');
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
.meeting-vote {
  width: 100%;

  &-row {
    margin-left: 22px;
    height: 100%;
  }

  &-head {
    width: 100%;
    height: 240px;
  }

  &-card {
    width: 100%;
    height: 100%;
    &-top {
      display: flex;
      height: 40px;
      background: #f6f7f8;
      line-height: 40px;
      position: relative;
      padding: 0px 30px;
      font-size: 14px;
      color: #333333;
      font-weight: 400;
    }
    &-item {
      margin-bottom: 6%;
      height: 100%;
    }
  }

  &-end-list {
    width: 100%;
    height: 100%;
    padding: 0 10%;
    margin-top: 18px;
    margin-bottom: 30px;
  }

  &-no-end-list {
    margin-top: 60px;
    position: absolute;
    left: 50%;
    margin-left: -60px;
  }

  &-add {
    padding: 12px 8% 0 8%;
    background: #f6f7f8;
  }

  &-detail {
    padding: 32px 7% 0 7%;
    min-height: 100%;
  }
}
</style>
