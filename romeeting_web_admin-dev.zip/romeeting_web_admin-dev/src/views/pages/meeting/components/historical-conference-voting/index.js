import MeetingVoting from './meeting-voting.vue';
export default MeetingVoting;
