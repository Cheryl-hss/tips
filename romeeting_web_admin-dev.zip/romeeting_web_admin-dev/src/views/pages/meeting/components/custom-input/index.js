import CustomInput from './custom-input';

export default CustomInput;
