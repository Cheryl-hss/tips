<template>
  <div class="meeting-end-list">
    <div class="meeting-end-list-head">
      <div class="meeting-end-list-head-title">{{ $t('meeting_end_list')}} </div>
      <div v-if="endMeetingList.length"
           class="meeting-end-list-head-icon"
           @click="onClickPullDown">
        <img v-if="showIconPullUp"
             :src="IconPullUp" />
        <img v-else
             :src="IconPullDown" />
      </div>

    </div>
    <div class="meeting-end-list-item"
         v-if="showIconPullUp"
         v-for="(item, index) in endMeetingList"
         :key="index">
      <MeetingEndListItem :meeting-data="item"
                          @on-click-item="onClickItem(item)"
                          @on-delete="onDelete(item)" />
    </div>
  </div>
</template>

<script>
import IconPullDown from '@/assets/images/icon-pull-down@2x.png';
import IconPullUp from '@/assets/images/icon-pull-up@2x.png';

import MeetingEndListItem from '../meeting-end-list-item';

export default {
  // 不要忘记了 name 属性
  name: 'MeetingEndList',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    endMeetingList: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  // 变量
  data() {
    return {
      IconPullDown: IconPullDown, // 可展开
      IconPullUp: IconPullUp, // 可收起
      showIconPullUp: true
    };
  },

  // 使用其它组件
  components: { MeetingEndListItem },
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    // 点击是否展开历史会议列表
    onClickPullDown() {
      this.showIconPullUp = !this.showIconPullUp;
    },

    // 点击打开详情
    onClickItem(item) {
      this.$emit('on-click-item', item);
    },

    // 点击删除
    onDelete(item) {
      this.$emit('on-delete', item.id);
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.meeting-end-list {
  &-head {
    margin-bottom: 20px;
    .clearFix();

    &-title {
      float: left;
      height: 24px;
      font-family: PingFangSC-Regular;
      font-size: 20px;
      color: #333333;
      line-height: 24px;
      font-weight: 400;
    }

    &-icon {
      float: right;
      width: 18px;
      height: 18px;
      padding-top: 3px;
      margin-right: 24px;

      &:hover {
        cursor: pointer;
      }

      > img {
        width: 100%;
      }
    }
  }

  &-item {
    margin-bottom: 12px;
  }
}
</style>
