<template>
  <div :class="classes">
    <div :class="[prefixCls + '-body']">
      <div v-if="showEdit"
           :class="[prefixCls + '-close']"
           @click="onClose">
        <img src="@/assets/images/icon-close@2x.png" />
      </div>
      <div :class="[prefixCls + '-left']">
        <img :src="icon" />
      </div>

      <div :class="[prefixCls + '-right']">

        <div :class="[prefixCls + '-header']"
             :title="data.title">{{ data.title }}</div>

        <div :class="[prefixCls + '-text']"
             :title="data.keyword"> {{ data.keyword }}</div>

        <div v-if="showEdit"
             :class="[prefixCls + '-tail']">
          <div :class="[prefixCls + '-tail-left']">
            <span v-if="showUsers">{{ users }}</span>
          </div>
          <div :class="[prefixCls + '-tail-right']"
               @click="onEdit">
            <img src="@/assets/images/icon-edit@2x.png" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Row, Col } from 'view-design';
import VoteIcon from '@/assets/images/icon-prompt@2x.png';

import { indexOfByKeyAndValue } from '@/utils/tools';

export default {
  // 不要忘记了 name 属性
  name: 'ContentItem',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    data: {
      // item对象数据
      type: Object,
      default() {
        return {};
      }
    },

    icon: {
      // 图标src
      type: String,
      default() {
        return VoteIcon;
      }
    },

    showEdit: {
      // 是否显示编辑
      type: Boolean,
      default() {
        return false;
      }
    },

    showUsers: {
      // 是否显示接收人
      type: Boolean,
      default() {
        return false;
      }
    },

    userList: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  // 变量
  data() {
    return {
      prefixCls: 'content-item'
    };
  },

  // 使用其它组件
  components: { Row, Col },
  // 计算属性
  computed: {
    classes() {
      return [this.prefixCls, {}];
    },

    users() {
      var names = '';
      if (this.data.personId) {
        if (this.userList.length) {
          const index = indexOfByKeyAndValue(this.userList, 'id', this.data.personId);
          if (index !== -1) {
            names = this.userList[index].name;
          }
        }
      }
      return '接收人：' + names;
    }
  },
  // 监听
  watch: {},
  // 方法
  methods: {
    onEdit() {
      this.$emit('on-edit');
    },

    // 删除投票
    onClose() {
      this.$emit('on-close');
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
@prefix: content-item;

.@{prefix} {
  &-body {
    padding: 12px 18px;
    max-height: 120px;
    background: #f6f7f8;
  }

  &-close {
    width: 18px;
    height: 18px;
    position: absolute;
    right: 6px;
    top: -7px;

    > img {
      width: 100%;
      height: 100%;
      cursor: pointer;
    }
  }

  &-left {
    position: absolute;
    width: 42px;
    height: ~'calc(100% - 24px )';
    padding-right: 12px;
    padding-top: 0;
    > img {
      width: 30px;
      height: 30px;
    }
  }

  &-right {
    display: inline-block;
    width: ~'calc(100% - 42px)';
    // height: 100%;
    margin-left: 42px;
  }

  &-header {
    width: 100%;
    font-family: PingFangSC-Medium;
    font-size: 14px;
    color: #333333;
    height: 14px;
    line-height: 14px;
    font-weight: 550;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  &-text {
    margin: 10px 0 12px 0;
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #666666;
    height: 36px;
    line-height: 18px;
    font-weight: 400;
    text-overflow: -o-ellipsis-lastline;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    -webkit-box-orient: vertical;
  }

  &-tail {
    height: 18px;

    &-left {
      display: inline-block;
      width: ~'calc(100% - 30px)';
      height: 18px;
      padding: 3px 0;
      line-height: 12px;
      font-size: 12px;
      color: #999999;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    &-right {
      display: inline-block;
      width: 18px;
      height: 18px;
      margin-left: 12px;

      > img {
        width: 18px;
        height: 18px;
      }
    }
  }
}
</style>
