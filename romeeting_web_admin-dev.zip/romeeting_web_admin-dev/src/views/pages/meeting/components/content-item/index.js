import ContentItem from './content-item.vue';

export default ContentItem;
