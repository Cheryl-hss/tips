<template>
  <div>
    <div class="vote-item">
      <div class="vote-item-left">
        <img src="@/assets/images/icon-vote@2x.png" />
      </div>
      <div class="vote-item-center">
        <div class="vote-item-center-head" :title="voteData.title">{{ voteData.title }}</div>
        <Row class="vote-item-center-body">
          <Col span="24">
            <div class="vote-item-center-body-left">
              <div class="vote-item-center-body-left-title" :title="options.join('/')">选项: {{options.join('/')}}</div>
            </div>
          </Col>
        </Row>
      </div>
      <div class="vote-item-right" v-if="showDownload" @click="onDownload">
        <img src="@/assets/images/icon-download@2x.png" />
      </div>
      <div v-if="showEdit && voteData.status === 'Created'" @click="onEdit" class="vote-item-right">
        <img src="@/assets/images/icon-edit@2x.png" />
      </div>
      <div v-if="this.voteData.status === 'Created'" class="vote-item-close">
        <div class="vote-item-close" @click="onClose">
          <img src="@/assets/images/icon-close@2x.png" />
        </div>
      </div>
      <!-- <div class="vote-item-left">
        <div class="vote-item-left-icon">
          <img src="@/assets/images/icon-vote@2x.png" />
        </div>
        <div class="vote-item-left-name margin-left">投票{{ index }}</div>
        <div class="vote-item-left-title">{{ voteData.title}}</div>
      </div>
      <div v-if="showDownload"
           class="vote-item-right"
           @click="onDownload">
        <img src="@/assets/images/icon-download@2x.png" />
      </div>
      <div v-if="showEdit"
           class="vote-item-edit">
        <div class="vote-item-edit-left"
             @click="onEdit">
          <img src="@/assets/images/icon-edit@2x.png" />
        </div>
        <div class="vote-item-edit-right"
             @click="onClose">
          <img src="@/assets/images/icon-close@2x.png" />
        </div>
      </div> -->
    </div>
  </div>
</template>

<script>
import { Row, Col, Button } from 'view-design';

export default {
  // 不要忘记了 name 属性
  name: 'VoteItem',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    showDownload: {
      // 是否显示文件下载按钮
      type: Boolean,
      default() {
        return false;
      }
    },
    showEdit: {
      // 是否显示文件编辑按钮、删除按钮
      type: Boolean,
      default() {
        return false;
      }
    },
    index: Number, // 第几个投票议题
    voteData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  // 变量
  data() {
    return {};
  },

  // 使用其它组件
  components: { Row, Col, Button },
  // 计算属性
  computed: {
    options() {
      const options = [];
      this.voteData.optionA && options.push(this.voteData.optionA.name);
      this.voteData.optionB && options.push(this.voteData.optionB.name);
      this.voteData.optionC && options.push(this.voteData.optionC.name);
      this.voteData.optionD && options.push(this.voteData.optionD.name);
      this.voteData.optionE && options.push(this.voteData.optionE.name);
      return options;
    }
  },
  // 监听
  watch: {},
  // 方法
  methods: {
    // 下载投票
    onDownload() {
      this.$emit('on-download');
    },
    // 打开编辑
    onEdit() {
      this.$emit('on-edit');
    },
    // 删除投票
    onClose() {
      this.$emit('on-close');
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.vote-item {
  height: 108px;
  width: 100%;
  display: flex;
  padding: 12px 18px;
  max-height: 120px;
  background: #f6f7f8;
  &-left {
    width: 30px;
    height: 30px;
    > img {
      width: 100%;
      height: 100%;
    }
  }
  &-close {
    width: 18px;
    height: 18px;
    position: absolute;
    right: 3px;
    top: -5px;
    > img {
      width: 100%;
      height: 100%;
      cursor: pointer;
    }
  }
  &-center {
    display: inline-block;
    width: 90%;
    margin-left: 12px;
    &-head {
      width: 100%;
      font-family: PingFangSC-Medium;
      font-size: 14px;
      color: #333333;
      font-weight: 550;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    &-body {
      &-left {
        &-title {
          width: 100%;
          font-size: 12px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          margin-left: 2px;
        }
      }
    }
  }
  &-right {
    width: 18px;
    height: 18px;
    position: absolute;
    right: 30px;
    bottom: 18px;
    > img {
      width: 100%;
      height: 100%;
    }
  }
}
</style>
