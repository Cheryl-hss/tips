<template>
  <div>

    <div class="end-vote-item">
      <div class="end-vote-item-left">
        <div class="end-vote-item-left-icon">
          <img src="@/assets/images/icon-vote@2x.png" />
        </div>
        <div class="end-vote-item-left-name margin-left">投票{{ index }}</div>
        <div class="end-vote-item-left-title">{{ voteData.title}}</div>
      </div>
      <div v-if="showDownload"
           class="end-vote-item-right"
           @click="onDownload">
        <img src="@/assets/images/icon-download@2x.png" />
      </div>
      <div v-if="showEdit"
           class="end-vote-item-edit">
        <div class="end-vote-item-edit-left"
             @click="onEdit">
          <img src="@/assets/images/icon-edit@2x.png" />
        </div>
        <div class="end-vote-item-edit-right"
             @click="onClose">
          <img src="@/assets/images/icon-close@2x.png" />
        </div>
      </div>

    </div>
  </div>
</template>

<script>
export default {
  // 不要忘记了 name 属性
  name: 'EndVoteItem',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    showDownload: {
      // 是否显示文件下载按钮
      type: Boolean,
      default() {
        return false;
      }
    },
    showEdit: {
      // 是否显示文件编辑按钮、删除按钮
      type: Boolean,
      default() {
        return false;
      }
    },
    index: Number, // 第几个投票议题
    voteData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  // 变量
  data() {
    return {};
  },

  // 使用其它组件
  components: {},
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    // 下载投票
    onDownload() {
      this.$emit('on-download');
    },
    // 打开编辑
    onEdit() {
      this.$emit('on-edit');
    },
    // 删除投票
    onClose() {
      this.$emit('on-close');
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.end-vote-item {
  height: 42px;
  width: 100%;
  background: #f6f7f8;
  padding: 12px 24px;
  .clearFix();

  &-left {
    height: 18px;
    font-family: PingFangSC-Regular;
    font-size: 14px;
    color: #333333;
    float: left;
    line-height: 18px;
    &-icon {
      float: left;
      height: 18px;
      width: 18px;

      > img {
        width: 100%;
        height: 100%;
      }
    }

    &-name {
      float: left;
    }

    &-title {
      float: left;
      margin-left: 34px;
    }
  }

  &-right {
    float: right;
    height: 18px;
    width: 18px;
    line-height: 18px;
    margin-right: 9px;
    > img {
      width: 100%;
      height: 100%;
      cursor: pointer;
    }
  }

  &-edit {
    float: right;
    &-left {
      float: left;
      height: 18px;
      width: 18px;
      line-height: 18px;
      margin-right: 25px;
      > img {
        width: 100%;
        height: 100%;
        cursor: pointer;
      }
    }

    &-right {
      float: right;
      height: 18px;
      width: 18px;
      line-height: 18px;
      margin-right: 9px;
      > img {
        width: 100%;
        height: 100%;
        cursor: pointer;
      }
    }
  }
}
</style>
