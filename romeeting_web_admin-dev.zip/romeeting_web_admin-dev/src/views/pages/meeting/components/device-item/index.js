import DeviceItem from './device-item.vue';

export default DeviceItem;
