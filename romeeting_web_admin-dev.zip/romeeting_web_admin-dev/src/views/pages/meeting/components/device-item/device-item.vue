<template>
  <div>
    <div @click="onClick">
      <Card v-if="deviceData.online === 1"
            ref="online"
            class="device-card">
        <div slot="title"
             :class="['device-card-title', 'margin-bottom-4', showHost ? 'bg-blue' : battery > 20 ? 'bg-default' : 'bg-red' ]"
             :title="deviceData.devName || '铭牌' + deviceData.number">
          {{ deviceData.devName || '铭牌' + deviceData.number }}
        </div>

        <div v-if="deviceData.online === 1"
             class="device-card-extra">
          <Battery slot="extra"
                   :battery="battery" />
        </div>

        <div slot="title"
             class="device-card-host">
          <div v-if="showHost"
               class="device-card-host-text"> 主持人</div>
        </div>
        <div class="device-card-content">
          <div class="device-card-content-top"
               :title="deviceData.person.company">{{ deviceData.person.company }}</div>
          <div class="device-card-content-center"
               :title="deviceData.person.name">{{ deviceData.person.name }}</div>
          <div class="device-card-content-bottom"
               :title="deviceData.person.position">{{ deviceData.person.position }}</div>
          <div v-if="showProgress"
               class="device-card-content-progress">
            <Progress class="device-card-content-progress-left"
                      :percent="progressData.progress"
                      :stroke-width="2"
                      hide-info />
            <div class="device-card-content-progress-right">{{ progressData.bps }}</div>
          </div>
        </div>

      </Card>

      <Card v-else
            ref="offline"
            class="not-device-card">
        <div slot="title"
             class="not-device-card-title"
             :title="deviceData.devName || '铭牌' + deviceData.number">
          {{ deviceData.devName || '铭牌' + deviceData.number }}
        </div>
        <div class="not-device-card-content">未连接</div>
      </Card>
    </div>
  </div>
</template>

<script>
import { Card, Progress } from 'view-design';
import Battery from '../battery';
import Timer from '@/utils/timer';

export default {
  // 不要忘记了 name 属性
  name: 'DeviceItem',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    deviceData: Object, // 设备数据
    host: Number // 主持人id
  },
  // 变量
  data() {
    return {
      showProgress: false, // 是否显示设备下载文件进度条
      progressData: {
        progress: 0, // 下载进度
        bps: '0 Mb/s' // 下载速率
      }
    };
  },

  // 使用其它组件
  components: { Card, Progress, Battery },
  // 计算属性
  computed: {
    // 设备电量
    battery() {
      return this.deviceData.shadow.state.reported.common.battery || '-';
    },

    showHost() {
      if (this.deviceData.person.id === this.host) {
        return true;
      }
      return false;
    }
  },
  // 监听
  watch: {
    'progressData.progress'(value) {
      const vm = this;
      if (value === 100) {
        // 当所有设备均推送完成
        // 设置定时器隐藏进度条
        let timer = new Timer({
          interval: 5000,
          limit: 1,
          auto: false,
          fn: () => {
            vm.showProgress = false;
            timer.destroy();
          }
        });
      }
    }
  },
  // 方法
  methods: {
    onClick() {
      this.$emit('on-click');
    },

    getMqttMsg(event) {
      const vm = this;
      if (event.topic.indexOf('/DATACHANGE') === -1) {
        return;
      }

      window.console.log(event);
      const message = event.msg;
      const msg = JSON.parse(message);
      const data = msg.shadow.state.reported.StartStatus;

      if (vm.deviceData.devId === msg.devId) {
        if (vm.progressData.progress !== 100) {
          vm.showProgress = true;
        }
        if (data.progress > vm.progressData.progress) {
          vm.progressData.progress = data.progress;
          vm.progressData.bps = data.bps;
        }
      }
    },

    onNewMessage() {
      const vm = this;
      vm.$root.eventHub.$on('MQTT_MSG', vm.getMqttMsg);
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
    this.onNewMessage();
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  },
  destroyed() {
    this.$root.eventHub.$off('MQTT_MSG', this.getMqttMsg);
  }
};
</script>
<style lang='less'>
.bg-default {
  background: #697898;
}

.bg-blue {
  background: #0050ff;
}

.bg-red {
  background: #f02a2a;
}

.ivu-card-head {
  border-bottom: 0;
  padding: 10px 12px 0;
}

.device-card {
  width: 100%;
  height: 180px;
  padding: 0;

  .ivu-card-body {
    padding: 0;
  }

  &-title {
    width: 60px;
    height: 24px;
    border-radius: 3px;
    font-family: PingFangSC-Regular;
    font-size: 14px;
    color: #ffffff;
    line-height: 24px;
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    padding: 0px 4px;
  }

  &-extra {
    position: absolute;
    right: 12px;
    top: 10px;
    height: 24px;
    line-height: 24px;
  }

  &-host {
    height: 24px;

    &-text {
      height: 100%;
      width: 60px;
      background: #dce8ff;
      border-radius: 3px;
      font-family: PingFangSC-Regular;
      font-size: 12px;
      color: #0050ff;
      text-align: center;
      line-height: 24px;
    }
  }

  &-content {
    .horizontalCenter();
    font-family: PingFangSC-Regular;
    font-size: 14px;
    color: #666666;
    text-align: center;
    width: 100%;
    padding: 0 10px;

    &-top {
      height: 24px;
      padding: 5px 0;
      line-height: 14px;
      font-size: 12px;
    }

    &-center {
      font-family: PingFangSC-Regular;
      font-size: 26px;
      color: #333333;
      height: 38px;
      line-height: 28px;
      padding: 5px 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    &-bottom {
      height: 24px;
      padding: 5px 0;
      line-height: 14px;
      font-size: 12px;
    }

    &-progress {
      width: 100%;
      display: inline-flex;

      &-left {
        width: ~'calc(100% - 94px)';
        margin-right: 8px;
      }

      &-right {
        width: 86px;
      }
    }
  }
}

.not-device-card {
  width: 100%;
  min-width: 240px;
  height: 180px;
  padding: 0;
  background: #f5f6f8;

  &-title {
    width: 60px;
    height: 24px;
    background: #c5cbd7;
    border-radius: 3px;
    font-family: PingFangSC-Regular;
    font-size: 14px;
    color: #ffffff;
    line-height: 24px;
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    padding: 0px 4px;
  }

  &-content {
    font-family: PingFangSC-Regular;
    font-size: 26px;
    color: #b9bdc5;
    text-align: center;
    line-height: 26px;
    margin-left: -4px;
    margin-top: 30px;
  }
}
</style>
