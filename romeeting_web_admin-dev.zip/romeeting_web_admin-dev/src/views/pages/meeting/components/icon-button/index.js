import IconButton from './icon-button.vue';

export default IconButton;
