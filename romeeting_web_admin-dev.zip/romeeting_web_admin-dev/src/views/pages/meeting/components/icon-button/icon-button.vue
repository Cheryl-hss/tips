<template>
  <div>
    <slot>
      <div v-if="value"
           class="icon-button"
           @click="onClick">
        <div class="icon-button-head">
          <img :src="data.icon" />
        </div>
        <div class="icon-button-tail">{{ data.text }}</div>
      </div>
      <Upload v-else
              :ref="'uploader' + data.value"
              float-left
              :action="data.url"
              :accept="data.accept"
              :format="data.format"
              :before-upload="beforeUpload"
              :multiple="data.multiple">
        <div class="icon-button">
          <div class="icon-button-head">
            <img :src="data.icon" />
          </div>
          <div class="icon-button-tail">{{ data.text }}</div>
        </div>
      </Upload>

    </slot>
  </div>
</template>

<script>
import { Upload } from 'view-design';

export default {
  // 不要忘记了 name 属性
  name: 'IconButton',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    data: {
      type: Object,
      default() {
        return {};
      }
    },

    value: {
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {};
  },

  // 使用其它组件
  components: { Upload },
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    beforeUpload(flie) {
      this.$emit('before-upload', flie);
      return false;
    },

    onClick() {
      this.$emit('on-click');
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
@import '~@/index.less';

.icon-button {
  width: 36px;

  &-head {
    width: 36px;
    height: 36px;
    padding: 3px;
    border-radius: 4px;
    > img {
      width: 100%;
      height: 100%;
    }
  }

  &-tail {
    height: 12px;
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #666666;
    line-height: 12px;
    font-weight: 400;
    text-align: center;
    margin-top: 7px;
  }

  &:hover {
    cursor: pointer;
  }

  &:hover &-head {
    background: #e8eef8;
  }

  &:hover &-tail {
    color: @primary-color;
  }
}
</style>
