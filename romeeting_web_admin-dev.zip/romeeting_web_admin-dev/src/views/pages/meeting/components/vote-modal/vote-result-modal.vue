<template>
  <div v-if="value">
    <Modal :mask="true"
           :value="value"
           :width="500"
           :mask-closable="false">
      <div slot="close"
           class="margin-right">
      </div>
      <div class="bordervote">
        <p>投票详情</p>
        <img src="~@/assets/images/icon-closevoting@2x.png"
             @click="onClose" />
      </div>
      <div slot="footer">
      <div class="Style">
        <div class="singinHHstyle">
          <p class="stateStyle">投票议题：</p>
          <p style="width: 80%;text-align: left;word-break: break-all;">{{voteData.title}}</p>
        </div>
        <Row>
          <Col>
            <div class="singinHHstyle select">
              <p style="width:70px;font-size: 14px;font-weight: 400;color: black;">选择项：</p>
            </div>
            </Col>
            <Col style="width:364px">
            <VoteHistoricalModal :vote-data="voteData" />
            </Col>
          </Row>
        </div>
        <div v-if="voteData.status === 'Publish'"
             class="vote">
          <span class="NumberOfPeople">{{numberOfPeople}}</span>
          <Button type="primary"
                  size="small"
                  @click="endclick">结束投票</Button>
        </div>
      </div>
    </Modal>
  </div>
</template>
<script>
import { Row, Col, Icon, Modal, Button, Progress } from 'view-design';
import VoteHistoricalModal from '../vote-modal/vote-historical-modal.vue';

export default {
  // 不要忘记了 name 属性
  name: 'VoteResultModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    voteData: {
      type: Object,
      default() {
        return {};
      }
    },
    value: Boolean // 是否显示
  },
  // 变量
  data() {
    return {
      showMeetingVote: true
    };
  },

  // 使用其它组件
  components: {
    Modal,
    Button,
    Row,
    Col,
    Icon,
    Progress,
    VoteHistoricalModal
  },
  // 计算属性
  computed: {
    numberOfPeople() {
      let count = 0;
      this.voteData.optionA &&
        this.voteData.optionA.persons &&
        (count += this.voteData.optionA.persons.length);
      this.voteData.optionB &&
        this.voteData.optionB.persons &&
        (count += this.voteData.optionB.persons.length);
      this.voteData.optionC &&
        this.voteData.optionC.persons &&
        (count += this.voteData.optionC.persons.length);
      this.voteData.optionD &&
        this.voteData.optionD.persons &&
        (count += this.voteData.optionD.persons.length);
      this.voteData.optionE &&
        this.voteData.optionE.persons &&
        (count += this.voteData.optionE.persons.length);
      return count + '/' + this.voteData.total;
    }
  },
  // 监听
  watch: {},
  // 方法
  methods: {
    // 结束投票按钮
    endclick() {
      this.$emit('on-end', this.voteData.id);
    },
    onClose() {
      this.$emit('on-close', {});
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
// 发起投票样式
.stateStyle {
  text-align: left;
  font-size: 14px;
  font-weight: 400;
  color: black;
}
.vote {
  margin-top: 40px;
  padding-bottom: 20px;
  padding-right: 10px;
}
.bordervote {
  display: flex;
  height: 40px;
  line-height: 40px;
  font-size: 18px;
  text-align: center;
  justify-content: center;
  > img {
    width: 20px;
    height: 20px;
    position: absolute;
    right: 22px;
    top: 26px;
  }
}
.footerStyle {
  height: 60px;
  padding-left: 16px;
}
.singinHHstyle {
  margin-top: 20px;
  font-size: 14px;
  display: flex;
}
// 发起投票样式
// 投票中样式
.Style {
  margin-left: 10px;
  margin-bottom: 20px;
}

.NumberOfPeople {
  margin-right: 10px;
  height: 32px;
  line-height: 32px;
}
.ivu-progress {
  display: inline-block;
  width: 100%;
  font-size: 12px;
  position: relative;
  top: 26px;
}
</style>
