<template>
  <div>
      <div v-if="voteData.optionA"
           class="VotingResults">
        <span class="VotingResults-favor" :title="voteData.optionA.name">{{voteData.optionA.name}}</span>
        <span class="percentage">{{optionA.res}}</span>
        <Progress :percent="optionA.percent"
                  stroke-color="#0050FF"
                  hide-info
                  :stroke-width="2" />
        <div v-if="!voteData.anonymous && voteData.optionA.persons.length"
              class="VotingResults-namelist">
          <span v-for="person in voteData.optionA.persons"
                :key="'vote_p'+person.personId"
                style="margin-left:10px;" >{{person.personName}}</span>
        </div>
      </div>
      <div v-if="voteData.optionB"
           class="VotingResults">
        <span class="VotingResults-favor" :title="voteData.optionB.name">{{voteData.optionB.name}}</span>
        <span class="percentage">{{optionB.res}}</span>
        <Progress :percent="optionB.percent"
                  stroke-color="#0050FF"
                  hide-info
                  :stroke-width="2" />
        <div v-if="!voteData.anonymous && voteData.optionB.persons.length"
              class="VotingResults-namelist">
          <span v-for="person in voteData.optionB.persons"
                :key="'vote_p'+person.personId"
                style="margin-left:10px;" >{{person.personName}}</span>
        </div>
      </div>
      <div  v-if="voteData.optionC"
            class="VotingResults">
        <span class="VotingResults-favor" :title="voteData.optionC.name">{{voteData.optionC.name}}</span>
        <span class="percentage">{{optionC.res}}</span>
        <Progress :percent="optionC.percent"
                  stroke-color="#0050FF"
                  hide-info
                  :stroke-width="2" />
        <div v-if="!voteData.anonymous && voteData.optionC.persons.length"
              class="VotingResults-namelist">
          <span v-for="person in voteData.optionC.persons"
                :key="'vote_p'+person.personId"
                style="margin-left:10px;" >{{person.personName}}</span>
        </div>
      </div>
          <div v-if="voteData.optionD"
               class="VotingResults">
            <span class="VotingResults-favor" :title="voteData.optionD.name">{{voteData.optionD.name}}</span>
            <span class="percentage">{{optionD.res}}</span>
            <Progress :percent="optionD.percent"
                      stroke-color="#0050FF"
                      hide-info
                      :stroke-width="2" />
            <div v-if="!voteData.anonymous && voteData.optionD.persons.length"
                 class="VotingResults-namelist">
              <span v-for="person in voteData.optionD.persons"
                    :key="'vote_p'+person.personId"
                    style="margin-left:10px;" >{{person.personName}}</span>
            </div>
          </div>
          <div v-if="voteData.optionE"
               class="VotingResults">
            <span class="VotingResults-favor" :title="voteData.optionE.name">{{voteData.optionE.name}}</span>
            <span class="percentage">{{optionE.res}}</span>
            <Progress :percent="optionE.percent"
                      stroke-color="#0050FF"
                      hide-info
                      :stroke-width="2" />
            <div v-if="!voteData.anonymous && voteData.optionE.persons.length"
                 class="VotingResults-namelist">
              <span v-for="person in voteData.optionE.persons"
                    :key="'vote_p'+person.personId"
                    style="margin-left:10px;" >{{person.personName}}</span>
            </div>
          </div>
            <div v-if="voteData.status === 'End'"
                class="VotingResults">
              <span class="VotingResults-favor">未投票</span>
              <span class="percentage">{{unknown.res}}</span>
              <Progress :percent="unknown.percent"
                        stroke-color="#0050FF"
                        hide-info
                        :stroke-width="2" />
              <div v-if="!voteData.anonymous && voteData.unknown.persons.length"
                  class="VotingResults-namelist">
                <span v-for="person in voteData.unknown.persons"
                      :key="'vote_p'+person.personId"
                      style="margin-left:10px;">{{person.personName}}</span>
              </div>
            </div>
  </div>
</template>
<script>
import { Progress } from 'view-design';
export default {
  // 不要忘记了 name 属性
  name: 'VoteHistoricalModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    voteData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  // 变量
  data() {
    return {};
  },

  // 使用其它组件
  components: {
    Progress
  },
  // 计算属性
  computed: {
    optionA() {
      let percent = 0;
      let res = '0票 0.00%';
      if (this.voteData.optionA.value) {
        percent = this.voteData.optionA.value;
        res = this.voteData.optionA.persons.length + '票 ' + percent + '%';
      }
      return {
        res: res,
        percent: Math.round(percent)
      };
    },
    optionB() {
      let percent = 0;
      let res = '0票 0.00%';
      if (this.voteData.optionB.value) {
        percent = this.voteData.optionB.value;
        res = this.voteData.optionB.persons.length + '票 ' + percent + '%';
      }
      return {
        res: res,
        percent: Math.round(percent)
      };
    },
    optionC() {
      let percent = 0;
      let res = '0票 0.00%';
      if (this.voteData.optionC.value) {
        percent = this.voteData.optionC.value;
        res = this.voteData.optionC.persons.length + '票 ' + percent + '%';
      }
      return {
        res: res,
        percent: Math.round(percent)
      };
    },
    optionD() {
      let percent = 0;
      let res = '0票 0.00%';
      if (this.voteData.optionD.value) {
        percent = this.voteData.optionD.value;
        res = this.voteData.optionD.persons.length + '票 ' + percent + '%';
      }
      return {
        res: res,
        percent: Math.round(percent)
      };
    },
    optionE() {
      let percent = 0;
      let res = '0票 0.00%';
      if (this.voteData.optionE.value) {
        percent = this.voteData.optionE.value;
        res = this.voteData.optionE.persons.length + '票 ' + percent + '%';
      }
      return {
        res: res,
        percent: Math.round(percent)
      };
    },
    unknown() {
      let percent = 0;
      let res = '0票 0.00%';
      if (this.voteData.unknown.value) {
        percent = this.voteData.unknown.value;
        res = this.voteData.unknown.persons.length + '票 ' + percent + '%';
      }
      return {
        res: res,
        percent: Math.round(percent)
      };
    }
  },
  // 监听
  watch: {},
  // 方法
  methods: {
    // 结束投票按钮
    endclick() {
      this.$emit('on-end', this.voteData.id);
    },
    onClose() {
      this.$emit('on-close', {});
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
.VotingResults {
  height: 40px;
  width: 100%;
  position: relative;
  margin-bottom: 40px;
  min-width: 100px;
  &-namelist {
    background: #e8e8e8e8;
    text-align: left;
    width: 100%;
    height: 24px;
    vertical-align: middle;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    margin-top: 40px;
    font-size: 12px;
    line-height: 24px;
  }
  &-favor {
    position: absolute;
    left: 0;
    bottom: -2px;
    color: #666666;
    width: 60%;
    text-align: left;
    overflow: hidden;
    white-space: nowrap;
    -webkit-line-clamp: 1;
    text-overflow: ellipsis;
    -box-orient: vertical;
  }
}
.percentage {
  position: absolute;
  right: 0;
  top: 21px;
  color: #666666;
}
.ivu-progress {
  display: inline-block;
  width: 100%;
  font-size: 12px;
  position: relative;
  top: 40px;
}
</style>
