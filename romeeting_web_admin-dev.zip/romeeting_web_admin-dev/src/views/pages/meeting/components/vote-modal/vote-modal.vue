<template>
  <div v-if="value">
    <Modal
      :mask="true"
      :value="showUserScope"
      :width="500"
      :mask-closable="false"
      :model="voteData"
      @on-visible-change="onVisibleChange"
    >
      <p slot="header" class="header">
        <span>新建投票</span>
      </p>
      <div slot="close" class="margin-right" @click="onClose">
        <Icon type="ios-close" :size="35" color="#999999" />
      </div>
      <div class="Style">
        <Form ref="voteForm" :model="voteData" :rules="rules">
          <div class="singinHHstyle">
            <p style="margin-right: 10px">投票议题</p>

            <FormItem prop="title">
              <Input
                @on-keydown="onChange"
                maxlength="60"
                :rows="4"
                v-model="voteData.title"
                type="textarea"
                placeholder="请输入投票议题"
                style="width: 386px; border-color: #dcdee2"
              />
            </FormItem>
          </div>
          <div style="width: 100%">
            <p style="margin-left: 10px">选择项</p>
            <ul style="list-style: none; margin-top: -22px">
              <li
                v-if="voteData['option' + item] !== null"
                v-for="item in ['A', 'B', 'C', 'D', 'E']"
                :key="'key_option' + item"
              >
                <FormItem :prop="'option' + item" style="margin-left: 64px">
                  <Input
                    v-model="voteData['option' + item]"
                    @on-keydown="change(item)"
                    maxlength="60"
                    type="text"
                    style="width: 386px"
                    placeholder="赞成 / 反对"
                  />
                  <div class="singinHHstyle-images" @click="deleteFixedrow('option' + item)">
                    <img src="~@/assets/images/icon-close@2x.png" />
                  </div>
                </FormItem>
              </li>
            </ul>
          </div>
        </Form>
        <div style="margin-left: 64px">
          <Tooltip content="最多支持五个选择" placement="top" :disabled="options.length !== 5">
            <Button
              :disabled="options.length === 5"
              class="margin-top-12"
              style="width: 386px; margin-bottom: 33px"
              long
              type="primary"
              ghost
              @click="openAddAttendee"
            >
              <div class="form-content-attendee-body-add margin-right-8" float-left>
                <Icon type="ios-add" :size="18" />
              </div>
              <p style="width: 76px">添加选项</p>
            </Button>
          </Tooltip>
        </div>
        <div class="anonymous">
          <Radio class="anonymous-radio" v-model="voteData.anonymous" size="small" float-left>
            <span class="margin-left-6">匿名投票</span>
          </Radio>
          <div class="anonymous-click-radio" @click="voteData.anonymous = !voteData.anonymous" />
        </div>
      </div>
      <div slot="footer">
        <div class="vote">
          <Button v-if="interaction" style="width: 60px" @click="onSave">保存</Button>
          <Button v-if="interaction" type="primary" style="width: 60px" @click="onPublish"
            >发布</Button
          >
          <Button v-if="!interaction" style="width: 60px" @click="onCancel">取消</Button>
          <Button v-if="!interaction" type="primary" @click="onConfirm" style="width: 60px"
            >确定</Button
          >
        </div>
      </div>
    </Modal>
  </div>
</template>

<script>
import { Modal, Icon, Button, Input, Radio, Form, FormItem, Tooltip } from 'view-design';
import { FileItem } from '../file-item';

export default {
  // 不要忘记了 name 属性
  name: 'MeetingNewlyAdded',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    votaRules: {
      type: Array,
      default: () => {
        return [{ required: true, message: '此项不能为空', trigger: 'change' }];
      }
    },
    interaction: {
      // 是否互动编辑
      type: Boolean,
      default() {
        return false;
      }
    },
    value: Boolean // 是否显示
  },
  // 变量
  data() {
    return {
      showUserScope: true,
      voteData: {
        title: null,
        anonymous: false,
        optionA: '',
        optionB: '',
        optionC: null,
        optionD: null,
        optionE: null
      }
    };
  },

  // 使用其它组件
  components: {
    Modal,
    Icon,
    Button,
    Input,
    Radio,
    Option,
    FileItem,
    Form,
    Tooltip,
    FormItem
  },
  // 计算属性
  computed: {
    rules() {
      return {
        title: this.votaRules,
        optionA: this.votaRules,
        optionB: this.votaRules,
        optionC: this.votaRules,
        optionD: this.votaRules,
        optionE: this.votaRules
      };
    },
    options() {
      const options = [];
      this.voteData.optionA !== null && options.push(this.voteData.optionA);
      this.voteData.optionB !== null && options.push(this.voteData.optionB);
      this.voteData.optionC !== null && options.push(this.voteData.optionC);
      this.voteData.optionD !== null && options.push(this.voteData.optionD);
      this.voteData.optionE !== null && options.push(this.voteData.optionE);
      return options;
    }
  },

  // 监听
  watch: {},
  // 方法
  methods: {
    onSubmit(action) {
      this.$refs['voteForm'].validate(valid => {
        if (valid) {
          this.$emit(action, {
            title: this.voteData.title,
            anonymous: this.voteData.anonymous,
            options: this.options,
            unknown: this.unknown
          });
          window.setTimeout(() => {
            this.initialization();
          }, 500);
        }
      });
    },
    // 提示框
    onChange() {
      if (this.voteData.title === null) {
        return;
      }
      if (this.voteData.title.length >= 60) {
        this.keyboardCode();
      }
    },
    keyboardCode() {
      if (
        window.event.code === 'Backspace' ||
        window.event.code === 'ControlLeft' ||
        window.event.code === 'KeyC' ||
        window.event.code === 'Enter'
      ) {
        //
      } else {
        this.message();
      }
    },
    message() {
      this.$Message.destroy();
      this.$Message.error({
        content: '最多输入60个字符',
        duration: 5,
        closable: true
      });
    },
    change(item) {
      switch (item) {
        case 'A':
          if (this.voteData.optionA === null) {
            return;
          }
          if (this.voteData.optionA.length >= 60) {
            this.keyboardCode();
          }
          break;
        case 'B':
          if (this.voteData.optionB === null) {
            return;
          }
          if (this.voteData.optionB.length >= 60) {
            this.keyboardCode();
          }
          break;
        case 'C':
          if (this.voteData.optionC === null) {
            return;
          }
          if (this.voteData.optionC.length >= 60) {
            this.keyboardCode();
          }
          break;
        case 'D':
          if (this.voteData.optionD === null) {
            return;
          }
          if (this.voteData.optionD.length >= 60) {
            this.keyboardCode();
          }
          break;
        case 'E':
          if (this.voteData.optionE === null) {
            return;
          }
          if (this.voteData.optionE.length >= 60) {
            this.keyboardCode();
          }
          break;
      }
    },
    initialization() {
      this.voteData = {
        title: null,
        anonymous: false,
        optionA: '',
        optionB: '',
        optionC: null,
        optionD: null,
        optionE: null
      };
    },
    // 关闭新建投票
    onClose() {
      this.$emit('on-close');
      this.initialization();
    },
    onCancel() {
      this.$emit('on-cancel');
      this.initialization();
    },
    // 确定按钮
    onConfirm() {
      this.onSubmit('on-confirm');
    },
    // 发布按钮
    onPublish() {
      this.onSubmit('on-publish');
    },
    // 保存按钮
    onSave() {
      this.onSubmit('on-save');
    },
    // 删除选项
    deleteFixedrow(option) {
      if (this.options.length < 3) {
        this.$Message.error('选项不能少于2个');
        return;
      }
      this.voteData[option] = null;
      const options = this.options;
      ['A', 'B', 'C', 'D', 'E'].forEach((item, index) => {
        this.voteData['option' + item] = index < options.length ? options[index] : null;
      });
    },
    // 点击添加按钮新增一行
    openAddAttendee() {
      switch (this.options.length) {
        case 2:
          this.voteData.optionC = '';
          break;
        case 3:
          this.voteData.optionD = '';
          break;
        case 4:
          this.voteData.optionE = '';
          break;
      }
    },
    onVisibleChange(value) {
      if (!value) {
        this.onClose();
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
// 新增投票样式
.Style {
  margin-left: 10px;
  font-size: 14px;

  &-Radio {
    border-radius: 10px;
  }
}

.form-content-attendee {
  background: #ffffff;
  margin-left: 60px;
}

.singinHHstyle {
  margin-top: 20px;
  display: flex;
  position: relative;

  &-images {
    width: 18px;
    height: 18px;
    position: absolute;
    right: 0px;
    top: -8px;

    > img {
      width: 100%;
      height: 100%;
    }
  }
}

.anonymous {
  height: 25px;

  &-radio {
    position: absolute;
    width: 80px;
    z-index: 998;
  }

  &-click-radio {
    position: absolute;
    background-color: #000000;
    opacity: 0;
    width: 80px;
    height: 24px;
    z-index: 999;
  }
}
</style>
