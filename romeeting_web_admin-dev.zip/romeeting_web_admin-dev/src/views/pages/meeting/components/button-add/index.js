import ButtonAdd from './button-add.vue';

export default ButtonAdd;
