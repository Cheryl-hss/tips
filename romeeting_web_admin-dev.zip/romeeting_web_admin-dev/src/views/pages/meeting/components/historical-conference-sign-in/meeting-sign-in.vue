<template>
  <div class="meeting-signin" @on-visible-change="onVisible">
    <div class="meeting-signin-card" v-show="isShow">
      <Row class="meeting-signin-row" :gutter="24" type="flex" justify="start" align="middle">
        <Col
          style="margin-bottom: 10px"
          :sm="{ span: 12 }"
          :md="{ span: 14 }"
          :lg="{ span: 16 }"
          :xxl="{ span: 12 }"
        >
          <div class="meeting-signin-divStyle">
            <div class="meeting-signin-divStyle-top">
              <div slot="title" style="display: flex; padding: 0 30px">
                <img
                  src="~@/assets/images/icon-checkin@2x.png"
                  style="height: 18px; width: 18px; margin-right: 12px; margin-top: 11px"
                />
                <p style="margin-right: 12px">签到时间</p>
                <p>{{ dateFormat(checkinDate.deadline, 'HH:mm') }}</p>
              </div>
            </div>
            <div class="meeting-signin-divStyle-bottom">
              <div class="meeting-signin-divStyle-bottom-left">
                <div id="statistics" style="width: 308px; height: 260px"></div>
              </div>
              <div class="meeting-signin-divStyle-bottom-right">
                <div class="meeting-signin-divStyle-bottom-right-top">
                  <p style="margin-left: 10px">参会人</p>
                  <p>签到时间</p>
                  <p v-if="isNumber" style="margin-right: 37px">状态</p>
                  <p v-if="!isNumber" style="margin-right: 24px">状态</p>
                </div>
                <div class="meeting-signin-divStyle-bottom-right-scroll">
                  <div
                    ref="normal"
                    class="meeting-signin-divStyle-bottom-right-normal"
                    v-for="(item, index) in checkinDate.results"
                    :key="index"
                  >
                    <p style="width: 60px; text-align: center">{{ item.name }}</p>
                    <p>{{ item.checkinTime ? dateFormat(item.checkinTime, 'HH:mm') : '-' }}</p>
                    <p
                      style="width: 47px; text-align: center; margin-right: 15px"
                      v-if="checkinResult(item) === '正常'"
                      class="meeting-signin-divStyle-bottom-right-normal-bule"
                    >
                      {{ checkinResult(item) }}
                    </p>
                    <p
                      style="width: 47px; text-align: center; margin-right: 15px"
                      v-else-if="checkinResult(item) === '迟到'"
                      class="meeting-signin-divStyle-bottom-right-normal-Three"
                    >
                      {{ checkinResult(item) }}
                    </p>
                    <p
                      style="width: 47px; text-align: center; margin-right: 15px"
                      v-else-if="checkinResult(item) === '未签到'"
                      class="meeting-signin-divStyle-bottom-right-normal-notsignin"
                    >
                      {{ checkinResult(item) }}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Col>
      </Row>
    </div>
  </div>
</template>

<script>
import { Row, Col, Icon, DropdownItem } from 'view-design';
import * as echarts from 'echarts';
import { dateFormat } from '@/utils/tools';

export default {
  // 不要忘记了 name 属性
  name: 'MeetingSignIn',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    voteData: {
      type: Object,
      default() {
        return {};
      }
    },
    checkinDate: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  // 变量
  data() {
    return {
      normal: [], // 正常
      late: [], // 迟到
      nosignin: [], // 未签到
      checkinDeadline: new Date(new Date().getTime() + 5 * 60 * 1000),
      isShow: false
    };
  },

  // 使用其它组件
  components: { Row, Col, Icon, DropdownItem },
  // 计算属性
  computed: {
    isNumber() {
      return this.normal.length + this.late.length + this.nosignin.length > 7;
    }
  },
  // 监听
  watch: {
    checkinDate(value) {
      if (value) {
        if (this.checkinDate.deadline !== null) {
          this.isShow = true;
          const punchinstatus = this.checkinDate.results;
          punchinstatus.map((item, index) => {
            if (item.checkinTime === null) {
              // 未签到
              this.nosignin.push(item.checkinTime);
            } else if (item.checkinTime > this.checkinDate.deadline) {
              // 迟到
              this.late.push(item.checkinTime);
            } else if (item.checkinTime !== null && !item.checkinTime < this.checkinDate.deadline) {
              this.normal.push(item.checkinTime);
              // 正常
              // 修改样式
            }
          });
        }
      }
      this.echarts();
    }
  },
  // 方法
  methods: {
    echarts() {
      var myChart = echarts.init(document.getElementById('statistics'));
      let option = {
        grid: {
          left: '0'
        },
        // x轴
        xAxis: {
          type: 'category',
          data: ['正常', '迟到', '未签到'],
          axisLine: {
            show: true,
            lineStyle: {
              width: 1, // 线的宽度
              type: 'solide' // 显得类型
            }
          },
          // 坐标轴 刻度 就是纵向多出来的小线
          axisTick: {
            show: false
          }
        },
        // y轴
        yAxis: {
          show: true, // 是否显示
          position: 'left', // 显示位置
          offset: 0, // y轴相对于默认位置的偏移
          type: 'value', // 轴的类型
          nameGap: 20, // 坐标名称和轴线的距离
          axisLine: {
            show: true,
            lineStyle: {
              width: 1, // 线的宽度
              type: 'solide' // 显得类型
            }
          },
          // 坐标轴标签 坐标轴显示的数值
          axisLabel: {
            show: true, // ---是否显示
            inside: false, // ---是否朝内
            rotate: 0, // ---旋转角度
            margin: 8, // ---刻度标签与轴线之间的距离
            textStyle: {
              color: '#999'
            }
          },
          // --网格区域
          splitArea: {
            show: false // ---是否显示，默认false
          },
          splitLine: {
            show: false
          }
        },
        // 数据区域的缩放
        dataZoom: [
          {
            type: 'inside'
          }
        ],
        // 内容数据
        series: [
          {
            type: 'bar',
            label: {
              normal: {
                show: true,
                position: 'top'
              }
            },
            itemStyle: {
              normal: {
                // 定制显示（按顺序）
                color: function(params) {
                  var colorList = ['rgb(5, 172, 228)', 'rgb(161, 132, 185)', 'rgb(143, 146, 148)'];
                  return colorList[params.dataIndex];
                },
                label: {
                  formatter: '{c}' + '人',
                  show: true,
                  position: 'top',
                  textStyle: {
                    fontSize: '12',
                    color: 'black'
                  }
                }
              }
            },
            barWidth: '30', // 调节柱子的宽度
            barCategoryGap: '1%', // 调节柱子之间的距离
            data: [this.normal.length || 0, this.late.length || 0, this.nosignin.length || 0]
          }
        ]
      };
      // 实例化显示图表
      myChart.setOption(option);
    },
    onVisible(visible) {
      if (visible) {
        this.checkinDeadline = this.checkinDate.deadline
          ? new Date(this.checkinDate.deadline)
          : new Date(new Date().getTime() + 5 * 60 * 1000);
      }
    },

    dateFormat(timestamp, format) {
      return (timestamp && dateFormat(timestamp, format)) || '';
    },
    checkinResult(item) {
      if (this.checkinDate.checkinStatus === 'None') {
        return '-';
      } else if (this.checkinDate.checkinStatus === 'Publish') {
        return !item.checkinTime
          ? '-'
          : item.checkinTime < this.checkinDate.deadline
            ? '正常'
            : '迟到';
      }
      // End
      return !item.checkinTime
        ? '未签到'
        : item.checkinTime < this.checkinDate.deadline
          ? '正常'
          : '迟到';
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
.meeting-signin {
  width: 100%;
  &-row {
    margin-left: 22px;
    height: 100%;
  }
  &-card {
    width: 100%;
    height: 100%;
  }
  &-divStyle {
    width: 100%;
    border: 1px solid #e8e8e8;
    &-top {
      height: 40px;
      line-height: 40px;
      width: 100%;
      font-size: 14px;
      font-weight: 400;
      background: #f6f7f8;
      color: #333333;
    }
    &-bottom {
      width: 100%;
      display: flex;
      padding: 0 16px;
      height: 260px;
      &-left {
        width: 50%;
        height: 260px;
      }
      &-right {
        width: 50%;
        margin-left: 30px;
        font-size: 12px;
        &-scroll {
          height: 220px;
          overflow-x: hidden;
        }
        &-top {
          display: flex;
          height: 30px;
          line-height: 30px;
          align-items: flex-end;
          justify-content: space-between;
          border-bottom: 1px solid #e8e8e8;
          color: #333333;
        }
        &-normal {
          display: flex;
          height: 30px;
          align-items: flex-end;
          justify-content: space-between;
          &-bule {
            color: green;
          }
          &-Three {
            color: grey;
          }
          &-notsignin {
            color: #bbbbbb;
          }
        }
      }
    }
  }
}
</style>
