import MeetingCardOperate from './meeting-card-operate.vue';

export default MeetingCardOperate;
