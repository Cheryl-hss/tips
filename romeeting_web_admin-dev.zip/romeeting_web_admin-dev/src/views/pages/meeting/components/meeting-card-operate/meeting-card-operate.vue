<template>
  <div>
    <div class="meeting-card-operate">
      <div class="meeting-card-operate-mask"
           @click="onClickMask"></div>

      <div class="meeting-card-operate-button">
        <div v-if="status === 'Doing'"
             class="meeting-card-operate-button-center"
             @click="onClickEnd">
          <div class="meeting-card-operate-button-center-content">
            <div class="meeting-card-operate-button-icon">
              <img src="~@/assets/images/icon-stop@2x.png" />
            </div>
            <div>结束会议</div>
          </div>
        </div>

        <div v-if="status === 'Waiting'"
             class="meeting-card-operate-button-side">
          <div class="meeting-card-operate-button-side-left"
               @click="onClickStart">
            <div class="meeting-card-operate-button-side-left-content">
              <div class="meeting-card-operate-button-icon">
                <img src="~@/assets/images/icon-put@2x.png" />
              </div>
              <div>立即推送</div>
            </div>
          </div>
          <div class="meeting-card-operate-button-side-right"
               @click="onClickDelete">
            <div class="meeting-card-operate-button-side-right-content">
              <div class="meeting-card-operate-button-icon">
                <img src="~@/assets/images/icon-trash-white@2x.png" />
              </div>
              <div>删除</div>
            </div>
          </div>
        </div>

        <div v-if="status === 'Completed'"
             class="meeting-card-operate-button-center"
             @click="onClickDelete">
          <div class="meeting-card-operate-button-center">
            <div class="meeting-card-operate-button-icon">
              <img src="~@/assets/images/icon-trash-white@2x.png" />
            </div>
            <div>删除</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  // 不要忘记了 name 属性
  name: 'MeetingCardOperate',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    status: String
  },
  // 变量
  data() {
    return {};
  },

  // 使用其它组件
  components: {},
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    // 点击遮罩层触发
    onClickMask() {
      this.$emit('on-click-mask');
    },

    // 点击结束会议按钮触发
    onClickEnd() {
      this.$emit('on-click-end');
    },

    // 点击立即推送按钮触发
    onClickStart() {
      this.$emit('on-click-start');
    },

    // 点击删除按钮触发
    onClickDelete() {
      this.$emit('on-click-delete');
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
@import '~@/index.less';
.meeting-card-operate {
  width: 100%;
  height: 100%;
  z-index: 122;
  color: #fff;

  &-mask {
    width: 100%;
    height: ~'calc(100% - 32px)';

    &:hover {
      cursor: pointer;
    }
  }

  &-button {
    width: 100%;
    height: 32px;
    border-radius: 0 0 4px 4px;
    border-color: @primary-color;
    font-family: PingFangSC-Regular;
    font-size: 12px;
    font-weight: 400;

    &-icon {
      width: 18px;
      height: 18px;
      margin-top: 5px;
      margin-right: 4px;
      > img {
        width: 100%;
        height: 100%;
      }
    }

    &-center {
      height: 32px;
      line-height: 32px;
      background: @primary-color;
      text-align: center;
      border-radius: 0 0 4px 4px;

      &:hover {
        background: @primary-color;
        cursor: pointer;
      }

      &-content {
        display: inline-flex;
      }
    }

    &-side {
      height: 33px;
      line-height: 33px;
      display: inline-flex;
      width: ~'calc(100% + 1px)';
      border: none;

      &-left {
        width: 50%;
        background: @primary-color;
        border-radius: 0 0 0 4px;
        text-align: center;

        &:hover {
          cursor: pointer;
        }

        &-content {
          display: inline-flex;
        }
      }

      &-right {
        width: ~'calc(50% + 1px)';
        background: #97a4c2;
        border-style: solid;
        border-color: #97a4c2;
        border-width: 0 1px 1px 0;
        border-radius: 0 0 4px 0;
        text-align: center;

        &:hover {
          cursor: pointer;
        }

        &-content {
          display: inline-flex;
        }
      }
    }
  }
}
</style>
