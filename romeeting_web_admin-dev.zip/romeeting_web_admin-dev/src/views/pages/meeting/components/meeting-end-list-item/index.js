import MeetingEndListItem from './meeting-end-list-item.vue';

export default MeetingEndListItem;
