<template>
  <div>
    <div class="end-list-item"
         @click="onClick">
      <div class="end-list-item-left">{{ meetingData.name }}</div>
      <MeetingCardInfoItem v-if="meetingData.startTime"
                           class="end-list-item-center"
                           :icon="iconClock"
                           :label="$t('meeting_card_info_item_time')"
                           :text="dateTime" />
      <div class="end-list-item-right"
           @click="onDelete">
      </div>
    </div>
  </div>
</template>

<script>
import MeetingCardInfoItem from '../meeting-card-info-item';

import { getDate } from '@/utils/tools';

const IconClock = require('@/assets/images/clock@2x.png');

export default {
  // 不要忘记了 name 属性
  name: 'MeetingEndListItem',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    meetingData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  // 变量
  data() {
    return {
      iconClock: IconClock // 时钟图标
    };
  },

  // 使用其它组件
  components: { MeetingCardInfoItem },
  // 计算属性
  computed: {
    dateTime() {
      var date = '';
      // 有日期和时间
      if (this.meetingData.startTime && this.meetingData.endTime) {
        var startDateTime = getDate(this.meetingData.startTime / 1000, 'year');
        const startTimeArr = startDateTime.split(' ');
        date = new Date(this.meetingData.startTime);
        date = date.getMonth() + 1 + '月' + date.getDate() + '日';
        const startTime = startTimeArr[1].slice(0, -3);

        var endDateTime = getDate(this.meetingData.endTime / 1000, 'year');
        const endTimeArr = endDateTime.split(' ');
        const endTime = endTimeArr[1].slice(0, -3);

        return date + ' ' + startTime + '-' + endTime;
      }

      // 只有日期
      if (this.meetingData.startTime) {
        date = new Date(this.meetingData.startTime);
        date = date.getMonth() + 1 + '月' + date.getDate() + '日';
        return date;
      }
    }
  },
  // 监听
  watch: {},
  // 方法
  methods: {
    onClick() {
      this.$emit('on-click-item');
    },

    // 删除
    onDelete() {
      this.$emit('on-delete');
      this.stopPro();
    },

    stopPro(evt) {
      var e = evt || window.event;
      // returnValue如果设置了该属性，它的值比事件句柄的返回值优先级高。把这个属性设置为 fasle，
      // 可以取消发生事件的源元素的默认动作。
      // window.event?e.returnValue = false:e.preventDefault();
      window.event ? (e.cancelBubble = true) : e.stopPropagation();
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
@import '~@/index.less';

.end-list-item {
  width: 100%;
  height: 66px;
  padding: 24px;
  background: #ffffff;
  .clearFix();
  z-index: 1;

  &:hover {
    cursor: pointer;
    color: @primary-color;
  }

  &-left {
    float: left;
    width: 65%;
    height: 20px;
    font-family: PingFangSC-Medium;
    font-size: 18px;
    color: #333333;
    line-height: 17px;
    font-weight: 500;
    white-space: nowrap; /*强制文本不能换行*/
    overflow: hidden; /*隐藏溢出内容*/
    text-overflow: ellipsis;

    &:hover {
      color: @primary-color;
    }
  }

  &-center {
    float: left;
    width: ~'calc(35% - 18px)';
    right: 10%;
    height: 18px;
    white-space: nowrap; /*强制文本不能换行*/
    overflow: hidden; /*隐藏溢出内容*/
    text-overflow: ellipsis;
  }

  &-right {
    float: right;
    width: 18px;
    height: 18px;
    padding: 9px;
    white-space: nowrap; /*强制文本不能换行*/
    overflow: hidden; /*隐藏溢出内容*/
    text-overflow: ellipsis;
    background: url('~@/assets/images/icon-trash-black@2x.png');
    background-repeat: no-repeat;
    background-position: center;
    background-size: 18px 18px;
    z-index: 2;

    &:hover {
      width: 18px;
      height: 18px;
      padding: 9px;
      background: url('~@/assets/images/icon-trash-hover@2x.png');
      background-repeat: no-repeat;
      background-position: center;
      background-size: 18px 18px;
      z-index: 2;
      cursor: pointer;
    }
  }
}
</style>
