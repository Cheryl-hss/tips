import ImportPersonsModal from './import-persons-modal.vue';

export default ImportPersonsModal;
