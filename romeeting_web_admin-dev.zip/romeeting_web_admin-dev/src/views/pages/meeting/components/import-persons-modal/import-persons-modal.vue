<template>
  <div v-if="value">
    <Modal :value="value"
           :mask-closable="false"
           :width="750"
           @on-visible-change="onChange">
      <p slot="header"
         class="header">
        <span>从常用联系人中选择</span>
      </p>
      <div slot="close"
           @click="onClose"
           class="margin-right">
        <Icon type="ios-close"
              :size="35"
              color="#999999" />
      </div>
      <Table ref="personsTable"
             :max-height="tableHeight"
             :columns="columns"
             :data="persons"
             @on-row-click="clickRow"
             @on-selection-change="onSelectChange">
        <template slot-scope="{ row, index }"
                  slot="company">
          <span>{{ row.company || '-' }}</span>
        </template>
        <template slot-scope="{ row, index }"
                  slot="logoUrl">
          <div v-if="row.logoUrl"
               class="table-icon">
            <img :src="row.logoUrl" />
          </div>
          <span v-else>-</span>
        </template>
        <template slot-scope="{ row, index }"
                  slot="position">
          <span>{{ row.position || '-' }}</span>
        </template>
      </Table>
      <div slot="footer">
        <Button class="button-width"
                @click="onClose">取消</Button>
        <Button v-if="selection.length"
                class="button-width"
                type="primary"
                @click="onOk">确定</Button>
        <Button v-else
                class="button-width"
                disabled>确定</Button>
      </div>
    </Modal>
  </div>
</template>

<script>
import { Modal, Icon, Table, Button } from 'view-design';

export default {
  // 不要忘记了 name 属性
  name: 'ImportPersonsModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    value: Boolean,
    persons: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  // 变量
  data() {
    return {
      tableHeight: 750, // 初始化表格高度
      selection: [], // 选中项
      columns: [
        {
          title: '序号',
          type: 'selection',
          width: 60,
          align: 'center',
          className: 'table-head-style'
        },
        {
          title: '姓名',
          key: 'name',
          className: 'table-head-style',
          sortable: true
        },
        {
          title: '公司',
          slot: 'company',
          className: 'table-head-style',
          sortable: true
        },
        {
          title: 'Logo',
          slot: 'logoUrl',
          className: 'table-head-style'
        },
        {
          title: '职位',
          slot: 'position',
          className: 'table-head-style'
        }
      ]
    };
  },

  // 使用其它组件
  components: { Modal, Icon, Table, Button },
  // 计算属性
  computed: {},
  // 监听
  watch: {
    value(newVal) {
      if (newVal) {
        this.selection = [];
        this.tableHeight = (window.innerHeight * 86) / 100 - 51 - 57 - 32;
      }
    }
  },
  // 方法
  methods: {
    // 关闭对话框
    onClose() {
      this.$emit('on-close');
    },

    // 确定选项并关闭对话框
    onOk() {
      this.$emit('on-ok', this.selection);
    },

    // 显示状态发生变化时触发
    onChange(value) {
      if (!value) {
        this.onClose();
      }
    },

    // 单击某一行时触发
    clickRow(row, index) {
      this.$refs.personsTable.toggleSelect(index); // 多选触发
    },

    // 表格选项发生变化时触发，返回所有选项selection
    onSelectChange(selection) {
      this.selection = selection;
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
</style>
