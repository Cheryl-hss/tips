import StatusInfo from './status-info.vue';

export default StatusInfo;
