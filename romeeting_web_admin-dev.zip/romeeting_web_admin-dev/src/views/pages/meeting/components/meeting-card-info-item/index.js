import MeetingCardInfoItem from './meeting-card-info-item.vue';

export default MeetingCardInfoItem;
