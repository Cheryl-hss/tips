import ImportDevicesModal from './import-devices-modal.vue';

export default ImportDevicesModal;
