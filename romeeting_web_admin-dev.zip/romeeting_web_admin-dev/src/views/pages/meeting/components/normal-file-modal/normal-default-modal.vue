<template>
  <div v-if="value">
    <Modal :value="value"
           :mask-closable="false"
           :width="500"
           @on-visible-change="onChange">
      <p slot="header"
         class="header">
        <span>{{ title }}</span>
      </p>
      <div slot="close"
           @click="onClose"
           class="margin-right">
        <Icon type="ios-close"
              :size="35"
              color="#999999" />
      </div>

      <div>
        <FileItem :file-data="normalFileData"
                  :show-progress="true"
                  :progress-percent="progressPercent"
                  :show-white-backaground="true" />
        <div style="width: 420px; padding: 0 24px; margin-top: 16px;">
          <div>查看范围：</div>
          <div class="modal-scope">
            <div class="modal-scope-radio">
              <RadioGroup v-model="selectScope">
                <Radio label="all">所有人</Radio>
                <Radio class="margin-left"
                       label="assign">指定用户</Radio>
              </RadioGroup>
            </div>
            <div v-if="selectScope === 'assign'"
                 class="modal-scope-select">
              <Select v-model="userScope"
                      multiple>
                <Option v-for="item in userList"
                        :value="item.id"
                        :key="item.id">{{ item.name }}</Option>
              </Select>
            </div>
          </div>
        </div>
      </div>

      <div slot="footer">
        <Button class="button-width"
                @click="onClose">取消</Button>
        <Button v-if="normalFileData.resourceIds.length && (userScope.length || selectScope === 'all')"
                class="button-width"
                type="primary"
                :loading="loading"
                @click="onOk">确定</Button>
        <Button v-if="!normalFileData.resourceIds.length || !userScope.length && selectScope === 'assign'"
                class="button-width"
                disabled>确定</Button>
      </div>
    </Modal>
  </div>
</template>

<script>
import {
  Modal,
  Icon,
  Upload,
  Button,
  Input,
  Row,
  Col,
  RadioGroup,
  Radio,
  Select,
  Option
} from 'view-design';
import { FileItem } from '../file-item';

import { uploadToOSS, getOssResourse } from '@/api/upload';
import MeetingApi from '@/api/meeting';
import { indexOfByKeyAndValue, deepCopy } from '@/utils/tools';

export default {
  // 不要忘记了 name 属性
  name: 'NormalPdfModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    file: {
      // 待上传的文件
      type: File,
      default() {
        return null;
      }
    },

    normalFileList: {
      // 已上传文件列表
      type: Array,
      default() {
        return [];
      }
    },

    normalFileData: {
      // 已上传的文件对象
      type: Object,
      default() {
        return {};
      }
    },

    resources: {
      // 会议资料列表文件
      type: Array,
      default() {
        return [];
      }
    },

    title: {
      // 弹出框title
      type: String,
      default() {
        return '';
      }
    },

    userList: {
      // 可选用户列表
      type: Array,
      default() {
        return [];
      }
    },

    value: Boolean // 是否显示
  },
  // 变量
  data() {
    return {
      normalUploadURL: '', // 会议资料文件上传url
      loading: false, // modal框关闭前确认按钮loading
      flag: false, // modal框是否可以关闭
      clickOk: false,
      progressPercent: 0, // 进度条百分比
      selectScope: 'all', // 设置默认选中所以用户
      userScope: [] // 用户id数组
    };
  },

  // 使用其它组件
  components: {
    Modal,
    Icon,
    Upload,
    Button,
    Input,
    Row,
    Col,
    RadioGroup,
    Radio,
    Select,
    Option,
    FileItem
  },
  // 计算属性
  computed: {},
  // 监听
  watch: {
    flag(value) {
      if (!value) {
        this.clickOk = false;
      }
      if (value && this.clickOk) {
        const data = {
          normalFileData: this.normalFileData,
          flag: value
        };
        this.$emit('on-ok', data);
      }
      this.loading = false;
    },

    value(value) {
      if (value) {
        this.beforeUpload(this.file);
      } else {
        this.selectScope = 'all';
        this.userScope = [];
      }
    }
  },
  // 方法
  methods: {
    // 关闭对话框
    onClose() {
      this.clickOk = false;
      this.$emit('on-close');
    },

    onOk() {
      this.loading = true;
      this.clickOk = true;
      if (this.selectScope === 'assign') {
        this.normalFileData.personIds = deepCopy(this.userScope);
      }
      const data = {
        normalFileData: this.normalFileData,
        flag: this.flag
      };
      this.$emit('on-ok', data);
    },

    // 显示状态发生变化时触发
    onChange(value) {
      if (!value) {
        this.onClose();
      }
    },

    // 上传文件前获取到生成的参数信息
    beforeUpload(file) {
      const vm = this;

      vm.progressPercent = 0;

      if (!vm.normalFileData.name) {
        vm.normalFileData.name = file.name;
      }

      vm.flag = false;

      uploadToOSS(file, e => {
        // 拿到onProgress回调e，可以拿到已上传大小和总大小
        vm.progressPercent = Math.floor((e.loaded / e.total) * 1000) / 10;
        // window.console.log(e);
      }).then(res => {
        // 当model框被关闭时，阻止继续调用请求
        if (!vm.value) {
          return;
        }
        // 1、创建oss资源 ，拿到资源id，push到 resourceIds
        // 2、拿返回的objectKey去请求资源，得到资源路径，显示出来

        // 获取用户id
        const userId = vm.$store.state.user.userId;
        // 获取创建资源参数
        const data = {
          fileKey: res.key,
          name: file.name,
          size: file.size,
          desc: file.desc,
          md5: res.md5,
          fileType: vm.normalFileData.fileType
        };

        // 发送创建资源请求
        MeetingApi.saveResourse(userId, data)
          .fetch()
          .then(({ success, msg, data }) => {
            //
            if (success) {
              // 判断会议资料列表里面是否已存在此文件
              // 已存在：提示已存在并结束当前程序
              // 不存在：则继续执行程序返回的resourceId push到resourceIds里
              const resourcesCopy = deepCopy(vm.resources);
              resourcesCopy.map(item => {
                item.resourceIds = item.resourceIds.toString();
              });
              const index = indexOfByKeyAndValue(
                resourcesCopy,
                'resourceIds',
                data.resourceId.toString()
              );
              if (index !== -1) {
                vm.$Message.destroy();
                vm.$Message.warning({
                  content: '“' + file.name + '”' + '在会议资料列表里已存在！',
                  duration: 5,
                  closable: true
                });
                return;
              }

              // 把返回资源id push到资源resourceIds
              vm.normalFileData.resourceIds.push(data.resourceId);
              vm.progressPercent = 100;
              vm.getOssResourse(data, userId, { key: res.key });
            } else {
              vm.$Message.destroy();
              vm.$Message.error({
                content: msg || '“' + file.name + '”' + '上传失败，请重试！',
                duration: 5,
                closable: true
              });
            }
          })
          .catch(err => {
            vm.$Message.destroy();
            vm.$Message.error({
              content: err.msg || '“' + file.name + '”' + '上传失败，请重试！',
              duration: 5,
              closable: true
            });
          });
      });

      return false;
    },

    getOssResourse(file, userId, key) {
      getOssResourse(userId, key)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            const obj = {
              name: file.name,
              fileType: file.fileType,
              url: data
            };
            this.normalFileList.push(obj);
            this.flag = true;
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: msg || '“' + file.name + '”' + '获取失败',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          window.console.log(err);
        });
    },

    // 删除资源
    handleRemove(index) {
      this.normalFileList.splice(index, 1);
      this.normalFileData.resourceIds.splice(index, 1);

      if (this.normalFileData.resourceIds.length === 0) {
        this.normalFileData.name = '';
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.header {
  text-align: center;
  font-family: PingFangSC-Regular;
  height: 18px;
}

.normal-pdf-file {
  padding: 14px;
  .clearFix();
  &-tips {
    height: 32px;
    line-height: 32px;
    display: inline-block;
  }

  &-name {
    width: 234px;
    height: 32px;
    line-height: 32px;
    display: inline-flex;
    justify-content: flex-end;
    margin-left: 32%;
    &-value {
      width: 180px;
    }
  }

  &-list {
    display: flex;
    height: 30px;
    line-height: 30px;
    padding-left: 14px;

    &-close {
      height: 30px;
      width: 30px;
      padding: 2px 0;
      cursor: pointer;
    }
  }
}

.button-width {
  width: 92px;
  margin-right: 15px;
}

.file-name {
  color: blue;
}
</style>
