import NormalImgModal from './normal-img-modal';
import NormalDefaultModal from './normal-default-modal';

export { NormalImgModal, NormalDefaultModal };
