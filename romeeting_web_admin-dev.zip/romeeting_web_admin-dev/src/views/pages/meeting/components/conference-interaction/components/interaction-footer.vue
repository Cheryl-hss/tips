<template>
  <div>
    <div class="detail-tail">
      <div class="detail-tail-button">
        <Button class="margin-right"
                style="width: 92px"
                @click="edit">编辑</Button>
        <Button class="margin-right"
                style="width: 92px"
                type="primary"
                @click="endMeeting">结束会议</Button>
        <Button style="width: 92px"
                @click="toBack">返回首页</Button>
      </div>
    </div>
  </div>
</template>
<script>
import { Button } from 'view-design';

export default {
  name: 'InteractionFooter',
  // 组件属性、变量
  props: {},
  computed: {},
  // 变量
  data() {
    return {};
  },

  // 使用其它组件
  components: {
    Button
  },
  watch: {},
  // 方法
  methods: {
    // 编辑会议
    edit() {
      this.$emit('edit');
    },
    // 结束会议
    endMeeting() {
      this.$emit('end-meeting');
    },
    // 返回首页
    toBack() {
      this.$emit('to-back');
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
.detail-tail {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: #ffffff;
  border: 1px solid #dddddd;
  width: 100%;
  height: 72px;
  &-button {
    height: 72px;
    line-height: 72px;
    float: right;
    margin-right: 10%;
  }
}
</style>
