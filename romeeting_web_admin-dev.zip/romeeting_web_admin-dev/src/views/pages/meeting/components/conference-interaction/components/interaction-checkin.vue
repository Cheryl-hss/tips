<template>
  <Dropdown trigger="click"
            @on-visible-change="onVisible"
            placement="bottom-start"
            class="checkin">
    <div class="buttonClass-icon">
      <div class="buttonClass-icon-img">
        <img src="~@/assets/images/icon-checkin@2x.png" />
      </div>
      <Badge v-if="this.checkinData.checkinStatus !== 'Publish'"
             dot
             :count="0"
             style="margin-top: -10px" />
      <Badge v-else
             status="error"
             :offset="[-4, 10]"
             style="margin-top: -10px; margin-left: -6px" />
      <div v-if="this.checkinData.checkinStatus !== 'Publish'"
           style="margin-left: 7px">签到</div>
      <div v-else
           style="margin-left: 1px">签到</div>
    </div>

    <DropdownMenu slot="list"
                  class="mess-posi">
      <p class="buttonClass-signinstyle">签到</p>
      <DropdownItem divided
                    disabled
                    class="buttonClass-dropdownStyleone">
        <p class="buttonClass-time">签到时间</p>
        <TimePicker class="time"
                    v-if="checkinData.checkinStatus === 'None'"
                    :value="checkinDeadline"
                    @on-change="onChangeStartTime"
                    format="HH:mm"
                    style="width: 110px; margin-left: 97px; margin-top: 12px; font-size: 12px">
        </TimePicker>
        <span v-else
              style="width: 32px; margin-top: 18px; margin-left: 178px; font-size: 12px">{{
          dateFormat(checkinData.deadline, 'HH:mm')
        }}</span>
        <Icon v-if="checkinData.checkinStatus === 'None'"
              style="
              width: 18px;
              height: 18px;
              z-index: 999;
              position: absolute;
              right: 26px;
              top: 71px;
              color: #999;"
              type="ios-time-outline" />
      </DropdownItem>
      <DropdownItem disabled
                    class="dropdownStyle"
                    v-if="checkinData.checkinStatus !== 'None'">
        <p class="dropdownStyle-attendee">参会人</p>
        <span class="dropdownStyle-checkintime">签到时间</span>
        <p v-if="isLength"
           class="checkinState">状态</p>
        <p v-else
           class="dropdownStyle-state">状态</p>
      </DropdownItem>
      <DropdownItem disabled
                    class="dropdownItem">
        <div disabled
             class="dropdownItemDiv"
             v-if="checkinData.checkinStatus !== 'None'"
             v-for="item in checkinData.results"
             :key="'checkin_' + item.id">
          <p class="dropdownStyle-attendee">{{ item.name }}</p>
          <span class="dropdownStyle-checkintime">{{
            item.checkinTime ? dateFormat(item.checkinTime, 'HH:mm') : '-'
          }}</span>
          <p v-if="checkinResult(item) === '正常'"
             class="dropdownStyle-state-bule">
            {{ checkinResult(item) }}
          </p>
          <p v-else-if="checkinResult(item) === '迟到'"
             class="dropdownStyle-state-Three">
            {{ checkinResult(item) }}
          </p>
          <p v-else-if="checkinResult(item) === '未签到'"
             class="dropdownStyle-state-nosigin">
            {{ checkinResult(item) }}
          </p>
        </div>
      </DropdownItem>
      <Button @click="onCheckin"
              v-if="checkinData.checkinStatus === 'None'"
              style="margin-top: 200px"
              type="primary"
              size="large"
              class="checkin-initiateSignin">发起签到</Button>
      <Button v-else-if="checkinData.checkinStatus === 'Publish'"
              @click="onEndCheckin"
              class="checkin-initiateSignin">结束签到</Button>
    </DropdownMenu>
  </Dropdown>
</template>
<script>
import { TimePicker, Button, Dropdown, DropdownMenu, DropdownItem, Icon, Badge } from 'view-design';

import { dateFormat } from '@/utils/tools';

export default {
  name: 'Conference',
  // 组件属性、变量
  props: {
    // 按字母顺序
    formData: {
      type: Object,
      default() {
        return {
          devices: []
        };
      }
    },
    checkinData: {
      type: Object,
      default() {
        return {};
      }
    },
    value: Boolean
  },
  computed: {
    isLength() {
      return this.checkinData.results.length >= 9;
    }
  },
  // 变量
  data() {
    return {
      checkinDeadline: new Date(new Date().getTime() + 5 * 60 * 1000)
    };
  },

  // 使用其它组件
  components: {
    TimePicker,
    Button,
    Dropdown,
    DropdownMenu,
    DropdownItem,
    Icon,
    Badge
  },
  watch: {},
  // 方法
  methods: {
    onVisible(visible) {
      if (visible) {
        this.checkinDeadline = this.checkinData.deadline
          ? new Date(this.checkinData.deadline)
          : new Date(new Date().getTime() + 5 * 60 * 1000);
        this.$emit('on-display');
      }
      if (visible) {
        this.checkinDeadline = new Date(new Date().getTime() + 5 * 60 * 1000);
      }
    },
    dateFormat(timestamp, format) {
      return (timestamp && dateFormat(timestamp, format)) || '';
    },
    checkinResult(item) {
      if (this.checkinData.checkinStatus === 'None') {
        return '-';
      } else if (this.checkinData.checkinStatus === 'Publish') {
        return !item.checkinTime
          ? '-'
          : item.checkinTime < this.checkinData.deadline
            ? '正常'
            : '迟到';
      }
      // End
      return !item.checkinTime
        ? '未签到'
        : item.checkinTime < this.checkinData.deadline
          ? '正常'
          : '迟到';
    },
    // 发起签到
    onCheckin() {
      if (!this.checkinData.deadline) {
        this.checkinData.deadline = this.checkinDeadline.getTime();
      }
      this.$emit('on-checkin');
    },
    // 点击结束签到按钮
    onEndCheckin() {
      this.$emit('on-endCheckin');
    },
    onChangeStartTime(time) {
      var data = new Date(dateFormat(new Date(), 'yyyy-MM-dd') + ' ' + time);
      this.checkinData.deadline = data.getTime();
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
.time /deep/ .ivu-input-suffix {
  display: none;
}
.time /deep/ .ivu-select-dropdown {
  color: #666666;
  font-size: 14px;
}
.checkinState {
  width: 60px;
  height: 16px;
  position: absolute;
  right: 25px;
  font-size: 12px;
  text-align: center;
}
.checkin {
  width: 52px;
  height: 37px;

  &:hover {
    cursor: pointer;
    color: #0050ff;
  }

  &-initiateSignin {
    position: absolute;
    bottom: 10px;
    left: 100px;
    width: 100px;
  }
}

.buttonClass {
  position: absolute;
  top: 0px;
  right: 60px;
  height: 37px;

  &-icon {
    display: inline-flex;
    align-items: center;
    height: 37px;
    width: 62px;
    &-img {
      width: 18px;
      height: 18px;

      > img {
        width: 100%;
        height: 100%;
      }
    }
  }

  &-onCenterControl {
    height: 37px;
  }

  &-signinstyle {
    line-height: 40px;
    font-weight: 600;
    font-size: 16px;
    padding-top: 4px;
    color: black;
    margin-left: 18px;
  }

  &-dropdownStyleone {
    display: flex;
    margin-bottom: 10px;
    padding-bottom: 10px;
    width: 300px;
    border-bottom: 1px solid #e8eaec;
    background: #f6f7f8;
  }

  &-time {
    margin-top: 16px;
    margin-left: 30px;
    color: black;
    font-size: 12px;
    width: 60px;
  }
}

.mess-posi {
  position: absolute;
  top: 10px;
  left: 70px;
  -webkit-transform: translate(-90%, -10px);
  transform: translate(-90%, -10px);
  -webkit-box-shadow: 0px 0px 2px 1px #ccc;
  box-shadow: 0px 0px 2px 1px #ccc;
  background: #fff;
  border-radius: 6px;
  width: 300px;
  height: 400px;
}

.dropdownStyle {
  display: flex;
  width: 300px;
  color: black;
  padding-bottom: 10px;

  &-attendee {
    width: 100px;
    height: 20px;
    text-align: left;
    font-size: 12px;
    color: black;
  }
  &-checkintime {
    font-size: 12px;
    color: black;
  }

  &-state {
    width: 60px;
    height: 16px;
    position: absolute;
    right: 12px;
    font-size: 12px;
    text-align: center;
    &-bule {
      width: 60px;
      text-align: center;
      position: absolute;
      right: 12px;
      color: green;
      font-size: 12px;
    }

    &-Three {
      width: 60px;
      text-align: center;
      position: absolute;
      right: 12px;
      color: grey;
      font-size: 12px;
    }
    &-nosigin {
      width: 60px;
      text-align: center;
      position: absolute;
      right: 12px;
      color: #bbb;
      font-size: 12px;
    }
  }
}
.dropdownItem {
  height: 220px;
  width: 300px;
  overflow-y: auto;
  position: relative;
}
.dropdownItemDiv {
  display: flex;
  height: 26px;
}
</style>
