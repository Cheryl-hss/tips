<template>
  <!-- ===============================投票================================ -->
  <Dropdown trigger="custom"
            :visible="visible"
            @on-clickoutside="visible = false"
            class="vote">
    <div class="buttonClass-icon"
         @click="onClick">
      <div class="buttonClass-icon-img">
        <img src="~@/assets/images/icon-votingpictures@2x.png" />
      </div>
      <div class="buttonClass-icon-text">投票</div>
    </div>
    <DropdownMenu slot="list"
                  class="mess-posi">
      <div class="newvoting">
        <p class="buttonClass-signinstyle">投票</p>
        <span class="newvoting-span" @click="onNewVote">
            <p class="newvoting-span-voteRight">新建投票</p>
            <img class="newvoting-span-iconcontent" src="~@/assets/images/icon-add-blue@2x.png" />
        </span>
      </div>
      <div class="scroll-container">
        <DropdownItem v-if="!votes || votes.length === 0">
          <div class="newvoting-Nocontent">
            <div class="newvoting-image">
              <img src="~@/assets/images/nocontent@2x.png" />
            </div>
            <span class="scroll-container-contentStyle">暂无投票</span>
          </div>
        </DropdownItem>
        <DropdownItem v-else
                      v-for="vote in votes"
                      :key="'vote_' + vote.id"
                      class="newvoting-styleDropdownItem">
          <div class="footerStyle">
            <div class="footerStyle-font"
                 @click="onItemClick(vote)">
              <p class="footerStyle-font-p">{{ vote.title }}</p>
              <p class="footerStyle-font-wint">选项: {{ options(vote).join('/') }}</p>
            </div>
            <div class="footerStyle-right">
              <Button v-if="vote.status === 'Created'"
                      class="footerStyle-right-release"
                      shape="circle">
                <p style="margin-left: -2px"
                   @click="onPublish(vote)">发布</p>
              </Button>
              <Button disabled
                      v-else-if="vote.status === 'Publish'"
                      class="footerStyle-button"
                      style="border-color: #0050ff"
                      type="primary"
                      shape="circle">
                <p class="footerStyle-button-p">投票中</p>
              </Button>
              <Button v-else
                      disabled
                      class="footerStyle-button"
                      style="background: #e0dddd"
                      shape="circle">
                <p class="footerStyle-button-p"
                   style="color: #fff">已结束</p>
              </Button>
            </div>
          </div>
        </DropdownItem>
      </div>
    </DropdownMenu>
  </Dropdown>
</template>
<script>
import { Button, Dropdown, DropdownMenu, DropdownItem, Icon } from 'view-design';

export default {
  name: 'InteractionVotes',
  // 组件属性、变量
  props: {
    // 按字母顺序
    votes: {
      type: Array,
      default() {
        return null;
      }
    },
    value: Boolean
  },
  computed: {},
  // 变量
  data() {
    return {
      visible: false
    };
  },

  // 使用其它组件
  components: {
    Button,
    Dropdown,
    DropdownMenu,
    DropdownItem,
    Icon
  },
  watch: {},
  // 方法
  methods: {
    options(vote) {
      const options = [];
      vote.optionA && options.push(vote.optionA.name);
      vote.optionB && options.push(vote.optionB.name);
      vote.optionC && options.push(vote.optionC.name);
      vote.optionD && options.push(vote.optionD.name);
      vote.optionE && options.push(vote.optionE.name);
      return options;
    },
    onClick() {
      this.visible = true;
      this.$emit('on-display');
    },
    onItemClick(vote) {
      this.visible = false;
      this.$emit('on-click', vote);
    },
    // 发布状态按钮
    onPublish(vote) {
      this.visible = false;
      this.$emit('on-publish', vote.id);
    },
    onNewVote() {
      this.visible = false;
      this.$emit('on-newVote');
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
.vote {
  width: 52px;
  height: 37px;

  &:hover {
    cursor: pointer;
    color: #0050ff;
  }
}

.buttonClass {
  position: absolute;
  top: 0px;
  right: 60px;
  height: 37px;

  &-icon {
    display: inline-flex;
    align-items: center;
    height: 37px;
    width: 52px;

    &-img {
      width: 18px;
      height: 18px;

      > img {
        width: 100%;
        height: 100%;
      }
    }

    &-text {
      margin-left: 6px;
    }
  }

  &-signinstyle {
    line-height: 40px;
    font-weight: 600;
    font-size: 16px;
    padding-top: 4px;
    color: black;
    margin-left: 18px;
    cursor: default;
  }
}

.mess-posi {
  position: absolute;
  top: 10px;
  left: 70px;
  -webkit-transform: translate(-90%, -10px);
  transform: translate(-90%, -10px);
  -webkit-box-shadow: 0px 0px 2px 1px #ccc;
  box-shadow: 0px 0px 2px 1px #ccc;
  background: #fff;
  border-radius: 6px;
  width: 300px;
  height: 400px;
}

// 新建投票样式
.newvoting {
  display: flex;
  border-bottom: 1px solid #e8eaec;
  line-height: 40px;
  font-weight: 600;
  font-size: 16px;
  padding-top: 4px;
  color: black;
  cursor: auto;
  justify-content: space-between;
  &-span {
    width: 85px;
    display: flex;
    cursor: pointer;
    &-voteRight {
      color: #666666;
      font-size: 12px;
      line-height: 40px;
      font-weight: 600;
      padding-top: 4px;
    }

    &-iconcontent {
      width: 18px;
      height: 18px;
      position: absolute;
      top: 18px;
      right: 11px;
    }
  }

  &-Nocontent {
    position: absolute;
    top: 45%;
    left: 40%;
    cursor: auto;
  }

  &-image {
    margin-left: 8px;
    > img {
      width: 42px;
      height: 42px;
    }
  }

  &-styleDropdownItem {
    border-bottom: #e8e8e8 1px solid;
    width: 300px;
  }
}

.footerStyle {
  height: 66px;
  position: relative;
  width: 100%;
  cursor: pointer;
  &-button {
    width: 50px;
    height: 20px;
    font-size: 12px;
    color: #0050ff;
    margin-top: 20px;
    background: #fff;
    &-p {
      color: blue;
      font-size: 12px;
      margin-left: -8px;
    }
  }
  &-font {
    color: black;
    position: absolute;
    top: 16px;
    width: 80%;
    &-p {
      // width: 260px;
      height: 20px;
      overflow: hidden;
      white-space: nowrap;
      /* display: -webkit-box; */
      -webkit-line-clamp: 1;
      text-overflow: ellipsis;
      -box-orient: vertical;
      font-size: 12px;
    }
    &-wint {
      height: 20px;
      overflow: hidden;
      white-space: nowrap;
      -webkit-line-clamp: 1;
      text-overflow: ellipsis;
      -box-orient: vertical;
      color: #999999;
      font-size: 12px;
    }
  }
  &-right {
    height: 66px;
    position: absolute;
    right: 0;
    padding-top: 4px;
    &-release {
      background: blue;
      color: white;
      font-size: 12px;
      width: 50px;
      height: 20px;
      margin-top: 20px;
    }
  }
}
.scroll-container {
  height: 350px;
  overflow: auto;
  overflow-x: hidden;
  text-align: left;
  cursor: auto;
  &-contentStyle {
    font-size: 14px;
    color: #bbbbbb;
    cursor: default;
  }
}
</style>
