<template>
  <div v-if="value"
       class="detail-body">
    <div class="title-bar-header">
      <TitleBar ref="titleBar"
                :name="formDataCopy.name"
                show-to-back
                @to-back="toBack">
        <div slot="content">
          <div v-if="showProgress"
               class="margin-left-24">
            <div class="header-center">
              <span>推送进度：</span>
              <Progress class="header-center-progress"
                        :percent="percent"
                        :stroke-width="6">
                <span>{{ count + '/' + formDataCopy.devices.length }}</span>
              </Progress>
            </div>
          </div>
          <div v-else
               class="header-warning">
            <div class="header-warning-icon">
              <img src="~@/assets/images/icon-status@2x.png" />
            </div>
            <div class="header-warning-text">
              <span>状态：</span>
              <span v-if="!formDataCopy.stat.unlinkSize && !formDataCopy.stat.eolSize"
                    slot="tail"
                    class="meeting-card-normal">正常</span>
              <span v-if="formDataCopy.stat.unlinkSize"
                    class="red">
                {{ formDataCopy.stat.unlinkSize }}台
              </span>
              <span v-if="formDataCopy.stat.unlinkSize"> 未连接 </span>
              <span v-if="formDataCopy.stat.eolSize"
                    class="red margin-left-8">
                {{ formDataCopy.stat.eolSize }}台
              </span>
              <span v-if="formDataCopy.stat.eolSize">低电量</span>
            </div>
          </div>
        </div>

        <div slot="button">
          <Button class="margin-right"
                  style="width: 92px"
                  @click="edit">编辑</Button>
          <Button style="width: 92px"
                  type="primary"
                  @click="endMeeting">结束会议</Button>
        </div>
      </TitleBar>
    </div>
    <div class="detail-body">
      <Tabs value="name1"
            class="tabs-style">
        <TabPane :label="$t('meeting_status')"
                 name="name1">
          <MeetingDetail :value="value"
                         :detail-data="formDataCopy" />
        </TabPane>
        <TabPane :label="$t('meeting_conference')"
                 name="name2">
          <Form ref="mainForm"
                :model="formDataCopy"
                :label-width="100">
            <div class="form-content">
              <!-- 会议议程 -->
              <FormItem class="device-style-margin margin-top-30"
                        :label="$t('meeting_agenda')"
                        prop="agenda">
                <!-- <div class="upload-entrance">
                      <Button>
                        <div class="upload-entrance-btn">
                          <div class="upload-entrance-btn-icon margin-right-4">
                            <img src="~@/assets/images/icon-upload@2x.png" />
                          </div>
                          {{$t('meeting_content_upload_file')}}
                        </div>
                      </Button>
                      <div class="upload-entrance-list"
                          style="width: 276px">
                        <div class="upload-entrance-list-body">
                          <IconButton class="upload-entrance-list-body-item"
                                      v-for="(item, index) in AgendaIconButtonList"
                                      :key="index"
                                      :value="item.value === 'Image'"
                                      :data="item"
                                      @before-upload="handleOpenAgendaModal($event, item.value)"
                                      @on-click="openAgendaModal(item.value)" />
                        </div>
                      </div>
                    </div> -->
              </FormItem>
              <!-- 会议议程文件列表 -->
              <div class="margin-top-18 file-margin-left">
                <Row :gutter="36"
                     type="flex"
                     justify="start"
                     align="middle">
                  <Col class="margin-bottom-24"
                       :sm="{ span: 24 }"
                       :lg="{ span: 12 }"
                       :xxl="{ span: 8 }"
                       v-for="(item, index) in formDataCopy.agendaResources"
                       :key="'agenda' + index">
                  <FileItem :file-data="item"
                            :user-list="userList"
                            :show-users="true"
                            @click.native="onSyncShow(item, 'show')">
                  </FileItem>
                  <div class="same-screen">
                    <Button v-if="item.personIds === null"
                            type="primary"
                            ghost
                            size="small"
                            style="width: 42px; height: 22px; padding-left: 8px"
                            @click="onSyncShow(item)">{{ $t('meeting_same_screen') }}</Button>
                  </div>
                  </Col>
                </Row>
              </div>
              <!-- 会议资料 -->
              <FormItem class="device-style-margin margin-top-24"
                        :label="$t('meeting_documents')"
                        prop="documents">
                <!-- <div class="upload-entrance">
                      <Button>
                        <div class="upload-entrance-btn">
                          <div class="upload-entrance-btn-icon  margin-right-4">
                            <img src="~@/assets/images/icon-upload@2x.png" />
                          </div>
                          {{$t('meeting_content_upload_file')}}
                        </div>
                      </Button>
                      <div class="upload-entrance-list">
                        <div class="upload-entrance-list-body">
                          <IconButton class="upload-entrance-list-body-item"
                                      v-for="(item, index) in NormalIconButtonList"
                                      :key="index"
                                      :value="item.value === 'Image'"
                                      :data="item"
                                      @before-upload="handleOpenNormalFileModal($event, item.value)"
                                      @on-click="openNormalFileModal(item.value)" />
                        </div>
                      </div>
                    </div> -->
              </FormItem>
              <!-- 会议资料文件列表 -->
              <div class="margin-top-18 file-margin-left">
                <Row :gutter="36"
                     type="flex"
                     justify="start"
                     align="middle">
                  <Col class="margin-bottom-24"
                       :sm="{ span: 24 }"
                       :lg="{ span: 12 }"
                       :xxl="{ span: 8 }"
                       v-for="(item, index) in formDataCopy.normalResources"
                       :key="'normal' + index">
                  <FileItem :file-data="item"
                            :user-list="userList"
                            :show-users="true"
                            @click.native="onSyncShow(item, 'show')">
                  </FileItem>
                  <div class="same-screen">
                    <Button v-if="item.personIds === null"
                            type="primary"
                            ghost
                            size="small"
                            style="width: 42px; height: 22px; padding-left: 8px"
                            @click="onSyncShow(item, 'syncShow')">{{ $t('meeting_same_screen') }}</Button>
                  </div>
                  </Col>
                </Row>
              </div>
            </div>
          </Form>
        </TabPane>
        <div slot="extra"
             class="buttonClass">
          <InteractionCheckin :checkinData="checkinData"
                              @on-checkin="onCheckin"
                              @on-endCheckin="onEndCheckin"
                              @on-display="meetingSign" />
          <InteractionVotes class="margin-left-30"
                            :votes="formDataCopy.votes"
                            @on-click="onMeetingVoteClick"
                            @on-publish="onVotePublish"
                            @on-newVote="okMeetingNewyVote" />
          <!-------------- 显示主页 ------------->
          <div class="margin-left-30">
            <Tooltip content="铭牌端统一显示有名字的页面"
                     placement="bottom"
                     :transfer="true">
              <div class="buttonClass-div dropdownvote"
                   @click="onCenterControl('Home')">
                <div class="buttonClass-icon">
                  <img src="~@/assets/images/icon-homepage@2x.png"
                       style="height: 100%; width: 100%" />
                </div>
                <div class="buttonClass-font">显示主页</div>
              </div>
            </Tooltip>
          </div>
          <!--------------- 临时关机按钮------------- -->
          <div class="margin-left-30">
            <Tooltip content="保存会议数据，铭牌端关机"
                     placement="bottom"
                     :transfer="true">
              <div class="buttonClass-div dropdownvote"
                   @click="onCenterControl('Shutdown')">
                <div class="buttonClass-icon">
                  <img src="~@/assets/images/icon-shutdown@2x.png"
                       style="height: 100%; width: 100%" />
                </div>
                <div class="buttonClass-font">临时关机</div>
              </div>
            </Tooltip>
          </div>
          <Select class="margin-left-30"
                  v-model="formDataCopy.host"
                  placeholder="主持人"
                  style="min-width: 155px"
                  @on-select="onSelectHost">
            <div slot="prefix"
                 class="host">
              <img src="~@/assets/images/icon-host@2x.png" />
              <div v-if="formDataCopy.host !== -1">主持人:</div>
            </div>
            <Option :value="0">控制端</Option>
            <Option v-for="(item, index) in persons"
                    :value="item.id"
                    :key="index">{{
              item.name
            }}</Option>
          </Select>
        </div>
      </Tabs>
    </div>
    <!-- 选择会议议程文件弹窗 -->
    <!-- png、jpg -->
    <!-- <AgendaImgModal :value="showAgendaImgModal"
                    :file-list="agendaFileList"
                    :file-data="fileData"
                    :user-list="userList"
                    @on-close="closeAgendaModal('Image')"
                    @on-ok="onOkAgendaModal" /> -->
    <!-- PDF/PPT/Word -->
    <!-- <AgendaDefaultModal :value="showAgendaDefaultModal"
                        :title="agendaTitle"
                        :file="file"
                        :file-list="agendaFileList"
                        :file-data="fileData"
                        :user-list="userList"
                        :resources="formDataCopy.agendaResources"
                        @on-close="closeAgendaModal('Default')"
                        @on-ok="onOkAgendaModal" /> -->
    <!-- 选择会议资料文件弹窗 -->
    <!-- png、jpg -->
    <!-- <NormalImgModal :value="showNormalImgModal"
                    :normal-file-list="normalFileList"
                    :normal-file-data="normalFileData"
                    :user-list="userList"
                    @on-close="closeNormalFileModal('Image')"
                    @on-ok="onOkNormalFileModal($event, 'Image')" /> -->
    <!-- PDF/MP4/PPT/Word -->
    <!-- <NormalDefaultModal :value="showNormalDefaultModal"
                        :title="normalFileTitle"
                        :file="file"
                        :normal-file-list="normalFileList"
                        :normal-file-data="normalFileData"
                        :resources="formDataCopy.normalResources"
                        :user-list="userList"
                        @on-close="closeNormalFileModal()"
                        @on-ok="onOkNormalFileModal($event)" /> -->
    <!-- 创建投票弹窗 -->
    <!-- <VoteModal :value="showVoteModal"
               :vote-data="voteData"
               @on-close="closeVoteModal"
               @on-ok="onOkVoteModal" /> -->
    <!-- PDF页面组件 -->
    <PdfPlug ref="PDFSyncViewer"
             :data="syncData"
             @on-sync="onSync"
             @on-cancel="onSync" />
    <Gallery ref="GallerySyncViewer"
             :data="syncData"
             @on-sync="onSync"
             @on-cancel="onSync" />
    <VideoPlayback ref="VideoPlaybackSyncViewer"
                   :data="syncData"
                   @on-sync="onSync"
                   @on-cancel="onSync" />
    <!-- 投票详情 -->
    <VoteResultModal :value="showVoteResult"
                     :vote-data="voteData"
                     @on-end="onEndVote"
                     @on-close="showVoteResult = false" />
    <VoteModal :value="showMeetingNewlyAdded"
               interaction
               @on-close="closeVoteModal"
               @on-save="onVoteSave"
               @on-publish="onVoteSaveAndPublish" />
    <VoteModifyModal :value="showVoteModify"
                     :vote-data="editVote"
                     interaction
                     @on-modify="onVoteModify"
                     @on-close="closeVoteModal"
                     @on-delete="onVoteDelete"
                     @on-publish="onVoteModifyAndPublish" />
  </div>
</template>
<script>
import {
  Form,
  FormItem,
  Row,
  Col,
  TimePicker,
  Button,
  Progress,
  Tabs,
  TabPane,
  Icon,
  Tooltip,
  Select,
  Option
} from 'view-design';

import TitleBar from '@/views/pages/components/title-bar';
import IconButton from '../icon-button';
import { FileItem } from '../file-item';
import { AgendaImgModal, AgendaDefaultModal } from '../agenda-file-modal';
import { NormalImgModal, NormalDefaultModal } from '../normal-file-modal';
import MeetingDetail from '../meeting-detail';
import { deepCopy, dateFormat } from '@/utils/tools';
import IconImage from '@/assets/images/file-image@2x.png';
import IconMp4 from '@/assets/images/file-video@2x.png';
import IconPdf from '@/assets/images/file-pdf@2x.png';
import IconPpt from '@/assets/images/file-ppt@2x.png';
import IconWord from '@/assets/images/file-doc@2x.png';
import { Gallery, PdfPlug, VideoPlayback } from '../../../components/sync-viewer';
import { InteractionFooter, InteractionCheckin, InteractionVotes } from './components';
import { VoteModal, VoteModifyModal, VoteResultModal } from '../vote-modal';

import Timer from '@/utils/timer';

import InteractionApi from '@/api/interaction';
import MeetingApi from '@/api/meeting';

export default {
  name: 'Conference',
  // 组件属性、变量
  props: {
    // 按字母顺序
    formData: {
      type: Object,
      default() {
        return {
          devices: []
        };
      }
    },
    formType: {
      type: String,
      default() {
        return 'add';
      }
    },
    value: {
      type: Boolean,
      default() {
        return false;
      }
    }
  },

  computed: {
    count() {
      return this.getStatus();
    },

    percent() {
      const count = this.getStatus();
      const precentNum = Math.floor((count / this.formDataCopy.devices.length) * 1000) / 10;
      return precentNum > 100 ? 100 : precentNum;
    },

    persons() {
      var users = [];
      this.formDataCopy.devices.map((item, index) => {
        if (item.person && item.person.id) {
          users.push(item.person);
        }
      });
      return users;
    }
  },
  // 变量
  data() {
    return {
      showVoteModify: false,
      showMeetingNewlyAdded: false,
      showProgress: false, // 是否显示设备端文件下载进度
      checkinData: {
        checkinStatus: 'None',
        deadline: null
      },
      successMsg: '', // 集中控制成功返回提示文字
      errorMsg: '', // 集中控制成功返回提示文字      showVideoPlayback: true,
      syncData: null,
      checkinDeadline: new Date(new Date().getTime() + 5 * 60 * 1000),
      MeetingTimeShow: true, // 签到时间框是否显示
      buttonOKShow: true, // 发起签到按钮是否显示
      buttonShow: false, // 结束签到按钮是否显示
      MeetingShow: false, // 签到时间不显示
      uploadIndex: -1, // 上传logo的table行的index
      formDataCopy: deepCopy(this.formData),
      showVoteResult: false, // 投票弹框是否显示
      showAgendaImgModal: false, // 是否打开选择会议议程图片对话框
      showAgendaDefaultModal: false, // 是否打开选择会议议程pdf对话框
      showNormalImgModal: false, // 是否打开选择文件对话框
      showNormalDefaultModal: false, // 是否打开选择文件对话框
      showVoteModal: false, // 是否打开创建投票对话框
      file: null, // 已选择待上传的文件
      agendaFileList: [], // 会议议程图片文件列表， 默认打开弹出对话框时是空数组
      agendaTitle: '上传PDF文件', // 会议议程资料上传弹框title
      fileData: {
        name: '',
        personIds: [], // 资源推送目标参会人id
        resourceIds: [] // 资源id列表
      },
      normalFileList: [], // 文件列表， 默认打开弹出对话框时时空数组
      normalFileTitle: '上传PDF文件', // 会议资料上传弹框title
      normalFileAccept: '.pdf', // 文件列表， 默认打开弹出对话框时时空数组
      normalFileFormat: ['.pdf'], // 文件列表， 默认打开弹出对话框时时空数组
      normalFileData: {
        name: '',
        personIds: [], // 资源推送目标参会人id
        resourceIds: [] // 资源id列表
      },
      string: '',
      AgendaIconButtonList: [
        {
          icon: IconImage,
          text: '图片',
          value: 'Image',
          url: '',
          accept: '.jpg, .png',
          format: ['.jpg', '.png'],
          multiple: true
        },
        {
          icon: IconPdf,
          text: 'PDF',
          value: 'PDF',
          url: '',
          accept: '.pdf',
          format: ['.pdf'],
          multiple: false
        },
        {
          icon: IconPpt,
          text: 'PPT',
          value: 'PPT',
          url: '',
          accept: '.ppt, .pptx',
          format: ['ppt', '.pptx'],
          multiple: false
        },
        {
          icon: IconWord,
          text: 'Word',
          value: 'Word',
          url: '',
          accept: '.doc, .docx',
          format: ['.doc', '.docx'],
          multiple: false
        }
      ], // 会议议程icon-button列表
      NormalIconButtonList: [
        {
          icon: IconImage,
          text: '图片',
          value: 'Image',
          url: '',
          accept: '.jpg, .png',
          format: ['.jpg', '.png'],
          multiple: true
        },
        {
          icon: IconMp4,
          text: '视频',
          value: 'Video',
          url: '',
          accept: '.mp4',
          format: ['.mp4'],
          multiple: false
        },
        {
          icon: IconPdf,
          text: 'PDF',
          value: 'PDF',
          url: '',
          accept: '.pdf',

          format: ['.pdf'],
          multiple: false
        },
        {
          icon: IconPpt,
          text: 'PPT',
          value: 'PPT',
          url: '',
          accept: '.ppt, .pptx',
          format: ['ppt', '.pptx'],
          multiple: false
        },
        {
          icon: IconWord,
          text: 'Word',
          value: 'Word',
          url: '',
          accept: '.doc, .docx',
          format: ['.doc', '.docx'],
          multiple: false
        }
      ], // 会议资料icon-button列表
      userList: [], // 查看资料可选用户列表
      voteData: {
        // 新建投票属性
        id: '',
        title: '',
        anonymous: false,
        // options: [],
        status: ''
      },
      editVote: {
        id: '',
        title: '',
        optionA: null,
        optionB: null,
        optionC: null,
        optionD: null,
        optionE: null,
        anonymous: false
      },
      type: ''
    };
  },
  // 使用其它组件
  components: {
    InteractionVotes,
    InteractionCheckin,
    InteractionFooter,
    Form,
    FormItem,
    Row,
    Col,
    TimePicker,
    Button,
    Progress,
    Tooltip,
    Select,
    Option,

    // 自定义组件
    TitleBar,
    IconButton,
    FileItem,
    AgendaImgModal,
    AgendaDefaultModal,
    NormalImgModal,
    NormalDefaultModal,
    PdfPlug,
    Tabs,
    TabPane,
    MeetingDetail,
    Icon,
    Gallery,
    VideoPlayback,
    VoteModal,
    VoteModifyModal,
    VoteResultModal
  },
  watch: {
    percent(newVal) {
      const vm = this;
      if (newVal === 100) {
        vm.$Message.success({
          content: '推送成功',
          duration: 3,
          closable: true
        });
        // 当所有设备均推送完成
        // 设置定时器隐藏进度条
        let timer = new Timer({
          interval: 5000,
          limit: 1,
          auto: false,
          fn: () => {
            vm.showProgress = false;
            timer.destroy();
          }
        });
      }
    },

    'formDataCopy.host'(newVal) {
      if (newVal === null) {
        this.formDataCopy.host = 0;
      }
    }
  },
  // 方法
  methods: {
    // 修改主持人
    onSelectHost(item) {
      const vm = this;
      if (!vm.formDataCopy.id || !item || item.value === null) {
        return;
      }
      MeetingApi.changeHost(vm.formDataCopy.id, item.value)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            vm.$Message.success({
              content: '修改主持人成功！',
              duration: 3,
              closable: true
            });
          }
        });
    },

    // 点击删除
    onVoteDelete(voteId) {
      const vm = this;
      vm.$Modal.confirm({
        title: '确定要删除投票信息吗？',
        onOk: () => {
          InteractionApi.deleteVote(this.formDataCopy.id, voteId)
            .fetch()
            .then(({ success, msg, data }) => {
              // window.console.log('进来', success);
              if (success) {
                // refresh data
                this.voteDelete(voteId);
              } else {
                vm.$Message.destroy();
                vm.$Message.error({
                  content: '删除失败！',
                  duration: 3,
                  closable: true
                });
              }
            })
            .catch(err => {
              vm.$Message.destroy();
              vm.$Message.error({
                content: err.msg || '删除失败！',
                duration: 3,
                closable: true
              });
            });
        }
      });
      this.showVoteModify = false;
    },
    voteDelete(voteId) {
      const index = this.formDataCopy.votes.findIndex(vote => vote.id === voteId);
      this.formDataCopy.votes.splice(index, 1);
    },
    // 获取已下载文件设备
    getStatus() {
      var count = 0;
      const devicesArr = deepCopy(this.formDataCopy.devices);
      if (devicesArr.length) {
        for (var i = 0; i < devicesArr.length; i++) {
          if (devicesArr[i].executions.Start.status === 'Success') {
            count = count + 1;
          }
        }
      }
      if (count !== devicesArr.length) {
        this.showProgress = true;
      }
      return count;
    },

    dateFormat(timestamp, format) {
      return (timestamp && dateFormat(timestamp, format)) || '';
    },

    checkinResult(item) {
      if (this.checkinData.checkinStatus === 'None') {
        return '-';
      } else if (this.checkinData.checkinStatus === 'Publish') {
        return !item.checkinTime
          ? '-'
          : item.checkinTime < this.checkinData.deadline
            ? '正常'
            : '迟到';
      }
      // End
      return !item.checkinTime
        ? '未签到'
        : item.checkinTime < this.checkinData.deadline
          ? '正常'
          : '迟到';
    },

    // 查询签到结果
    meetingSign() {
      InteractionApi.meetingSign(this.formDataCopy.id)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            this.checkinData = data;
            this.checkinData.results.sort((p1, p2) => {
              const a = p1.checkinTime;
              const b = p2.checkinTime;
              if (!b) {
                return !a ? 0 : -1;
              }
              return !a ? 1 : a - b;
            });
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: msg,
              duration: 3,
              closable: true
            });
          }
        });
    },
    // 发起签到
    onCheckin() {
      const vm = this;
      if (!this.checkinData.deadline || this.checkinData.deadline < new Date().getTime()) {
        vm.$Message.warning({
          content: '签到时间无效！',
          duration: 3,
          closable: true
        });
        return;
      }
      InteractionApi.initiateSignin(this.formDataCopy.id, this.checkinData.deadline)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            this.checkinData.checkinStatus = 'Publish';
            vm.$Message.destroy();
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: msg,
              duration: 3,
              closable: true
            });
          }
          this.buttonOKShow = false; // 发起签到按钮
          this.MeetingTimeShow = false; // 签到时间
          this.buttonShow = true; // 结束签到按钮
          this.MeetingShow = true; // 签到人列表
        });
    },
    // 点击结束签到按钮
    onEndCheckin() {
      const vm = this;
      var id = this.formDataCopy.id;
      InteractionApi.endSignIn(id)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            this.checkinData = data;
            this.checkinData.results.sort((p1, p2) => {
              const a = p1.checkinTime;
              const b = p2.checkinTime;
              if (!b) {
                return !a ? 0 : -1;
              }
              return !a ? 1 : a - b;
            });
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: msg,
              duration: 3,
              closable: true
            });
          }
        });
      this.buttonShow = false;
      this.buttonOKShow = false;
    },
    // 关闭结束投票按钮
    onEndVote(voteId) {
      InteractionApi.endVote(this.formDataCopy.id, voteId)
        .fetch()
        .then(res => {
          if (res.success) {
            for (const index in this.formDataCopy.votes) {
              const localVote = this.formDataCopy.votes[index];
              if (localVote.id === voteId) {
                this.voteEnd(localVote, res.data);
              }
            }
            this.showVoteResult = true;
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: res.msg,
              duration: 3,
              closable: true
            });
          }
        });
    },
    voteEnd(vote, data) {
      const unknowns = data.results.filter(res => res.choose === -1).map(res => {
        return {
          personId: res.personId,
          personName: res.personName
        };
      });
      vote.unknown = {
        persons: unknowns,
        value: ((unknowns.length / vote.total) * 100).toFixed(2)
      };
      vote.status = data.status;
    },
    // 集中控制
    onCenterControl(name) {
      switch (name) {
        case 'Home':
          this.successMsg = '所有铭牌已显示主页！';
          this.errorMsg = '显示主页失败，请稍后重试！';
          break;
        case 'Sleep':
          this.successMsg = '所有铭牌息屏成功！';
          this.errorMsg = '息屏失败，请稍后重试！';
          break;
        case 'Shutdown':
          this.successMsg = '所有铭牌已关机！';
          this.errorMsg = '关机失败，请稍后重试！';
          break;
      }
      const data = { command: name };
      InteractionApi.onCenterControl(this.formDataCopy.id, data)
        .fetch()
        .then(res => {
          if (res.success) {
            this.$Message.destroy();
            this.$Message.success({
              content: this.successMsg,
              duration: 3,
              closable: true
            });
          } else {
            this.$Message.destroy();
            this.$Message.success({
              content: res.msg || this.errorMsg,
              duration: 3,
              closable: true
            });
          }
        })
        .catch(err => {
          this.$Message.destroy();
          this.$Message.success({
            content: err.msg || this.errorMsg,
            duration: 3,
            closable: true
          });
        });
    },
    // 投票列表
    onMeetingVoteClick(vote) {
      if (vote.status !== 'Created') {
        this.voteData = vote;
        this.showVoteResult = true;
        return;
      }
      this.editVote = {
        id: vote.id,
        title: vote.title,
        optionA: null,
        optionB: null,
        optionC: null,
        optionD: null,
        optionE: null,
        anonymous: vote.anonymous
      };
      vote.optionA && (this.editVote.optionA = vote.optionA.name);
      vote.optionB && (this.editVote.optionB = vote.optionB.name);
      vote.optionC && (this.editVote.optionC = vote.optionC.name);
      vote.optionD && (this.editVote.optionD = vote.optionD.name);
      vote.optionE && (this.editVote.optionE = vote.optionE.name);
      this.showVoteModify = true;
    },
    onVoteSaveAndPublish(voteData) {
      this.onVoteSave(voteData, vote => {
        this.onVotePublish(vote.id);
      });
    },
    onVotePublish(voteId) {
      this.showMeetingNewlyAdded = false;
      this.showVoteModify = false;
      InteractionApi.releaseVote(this.formDataCopy.id, voteId)
        .fetch()
        .then(res => {
          if (res.success) {
            for (const index in this.formDataCopy.votes) {
              const localVote = this.formDataCopy.votes[index];
              if (localVote.id === voteId) {
                this.votePublish(localVote, res.data.total);
                this.voteData = localVote;
                break;
              }
            }
            this.$Message.destroy();
            this.$Message.success({
              content: '发布成功',
              duration: 3,
              closable: true
            });
            this.showVoteResult = true;
          } else {
            this.$Message.destroy();
            this.$Message.success({
              content: res.msg || this.errorMsg,
              duration: 3,
              closable: true
            });
          }
        })
        .catch(err => {
          this.$Message.destroy();
          this.$Message.success({
            content: err.msg || this.errorMsg,
            duration: 3,
            closable: true
          });
        });
    },
    votePublish(vote, total) {
      vote.status = 'Publish';
      vote['total'] = total;
      vote.optionA && (vote.optionA['value'] = '0.00');
      vote.optionB && (vote.optionB['value'] = '0.00');
      vote.optionC && (vote.optionC['value'] = '0.00');
      vote.optionD && (vote.optionD['value'] = '0.00');
      vote.optionE && (vote.optionE['value'] = '0.00');
    },
    // 新建投票
    okMeetingNewyVote() {
      this.showVoteModal = true; // 未更新的投票弹框
      this.showMeetingNewlyAdded = true;
    },
    // 签到时间
    onChangeStartTime(time) {
      var data = new Date(dateFormat(new Date(), 'yyyy-MM-dd') + ' ' + time);
      this.checkinDeadline = data;
      this.checkinData.deadline = data.getTime();
    },
    // 编辑会议
    edit() {
      this.$emit('edit');
    },
    // 结束会议
    endMeeting() {
      this.$emit('end-meeting');
    },
    // 返回首页
    toBack() {
      this.$emit('to-back');
    },
    // 点击文件列表
    onSyncShow(item, mode) {
      // window.console.log('打印所有', item);
      // if(item.personIds === null){

      // }
      // 默认同屏模式
      !mode && (mode = 'syncShow');
      this.type = item.fileType;
      const resource = item.resources[0];
      if (
        resource.fileType === 'PDF' ||
        resource.fileType === 'PPT' ||
        resource.fileType === 'Doc'
      ) {
        switch (resource.fileType) {
          case 'PPT':
          case 'Doc':
            InteractionApi.getPDFUrl(item.resources[0].resourceId)
              .fetch()
              .then(res => {
                // window.console.log('res', res);
                if (res.success) {
                  const url = res.data;
                  this.pdfSyncViewerShow(
                    item.resources[0].name,
                    item.resources[0].groupId,
                    url,
                    mode,
                    item.resources[0].sync
                  );
                } else {
                  this.$Message.destroy();
                  this.$Message.error({
                    content: res.msg,
                    duration: 3,
                    closable: true
                  });
                }
              });
            break;
          case 'PDF':
          case 'Video':
            const url = '/iot/resource/302/oss?id=' + item.resources[0].resourceId;
            this.pdfSyncViewerShow(
              item.resources[0].name,
              item.resources[0].groupId,
              url,
              mode,
              item.resources[0].sync
            );
            break;
        }
      } else if (resource.fileType === 'Image') {
        this.syncData = {
          meetingId: this.formDataCopy.id,
          items: item.resources
        };
        this.$nextTick(() => {
          mode === 'syncShow'
            ? this.$refs.GallerySyncViewer.syncShow()
            : this.$refs.GallerySyncViewer.show();
        });
      } else if (resource.fileType === 'Video') {
        const url = '/iot/resource/302/oss?id=' + item.resources[0].resourceId;
        this.syncData = {
          meetingId: this.formDataCopy.id,
          filename: item.resources[0].name,
          groupId: item.resources[0].groupId,
          sync: item.resources[0].sync,
          url: url
        };
        this.$nextTick(() => {
          mode === 'syncShow'
            ? this.$refs.VideoPlaybackSyncViewer.syncShow()
            : this.$refs.VideoPlaybackSyncViewer.show();
        });
      }
    },
    // 点击文件列表
    pdfSyncViewerShow(filename, groupId, url, mode, sync) {
      this.syncData = {
        meetingId: this.formDataCopy.id,
        filename: filename,
        groupId: groupId,
        url: url,
        sync: sync
      };
      this.$nextTick(() => {
        mode === 'syncShow' ? this.$refs.PDFSyncViewer.syncShow() : this.$refs.PDFSyncViewer.show();
      });
    },
    onSync(params) {
      InteractionApi.syncShow(params)
        .fetch()
        .then(res => {
          if (res.success) {
            //
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: res.msg,
              duration: 3,
              closable: true
            });
          }
        });
    },
    // 会议议程
    // 打开上传会议议程文件（PDF、Word、PPT）
    handleOpenAgendaModal(file, key) {
      switch (key) {
        case 'PDF':
          this.agendaTitle = '上传PDF文件';
          this.openAgendaModal(key, file);
          break;

        case 'PPT':
          this.agendaTitle = '上传PPT文件';
          this.openAgendaModal(key, file);
          break;

        case 'Word':
          this.agendaTitle = '上传Word文件';
          this.openAgendaModal(key, file);
          break;
      }
    },
    // 打开选择会议议程对话框
    openAgendaModal(key, file) {
      this.fileData = {
        name: '',
        personIds: [], // 资源推送目标参会人id
        resourceIds: [], // 资源id列表
        fileType: key === 'Word' ? 'Doc' : key, // 文件类型
        size: 0 // 文件大小
      };
      this.agendaFileList = [];
      this.userList = [];
      // 筛选出可选资料接收人列表
      this.formDataCopy.devices.map((item, index) => {
        if (!item._editing && item.person && item.person.id) {
          this.userList.push(item.person);
        }
      });
      // 在非图片的文件下有file
      if (file) {
        this.file = file;
        this.fileData.name = file.name;
        this.fileData.size = file.size;
      }
      if (key === 'Image') {
        this.showAgendaImgModal = true;
      } else {
        this.showAgendaDefaultModal = true;
      }
    },
    // 关闭选择会议议程对话框
    closeAgendaModal(key) {
      if (key === 'Image') {
        this.showAgendaImgModal = false;
      } else {
        this.showAgendaDefaultModal = false;
      }

      this.agendaFileList = [];
      this.fileData = {
        name: '',
        personIds: [], // 资源推送目标参会人id
        resourceIds: [], // 资源id列表
        fileType: '', // 文件类型
        size: 0 // 文件大小
      };
    },
    // 提交已选择会议议程图片
    onOkAgendaModal(fileData, flag) {
      if (flag) {
        this.formDataCopy.agendaResources.push(fileData);
        if (fileData.fileType === 'Image') {
          this.showAgendaImgModal = false;
        } else {
          this.showAgendaDefaultModal = false;
        }
        this.saveFormDataToLocalStorage();
      }
    },
    // 删除会议议程图片
    deleteAgendaFile(index) {
      this.$Modal.confirm({
        title: '确定删除该份资料吗？',
        onOk: () => {
          this.formDataCopy.agendaResources.splice(index, 1);
          this.saveFormDataToLocalStorage();
        }
      });
    },
    // // 会议资料
    // 1、会议资料：图片
    // 打开选择会议资料文件对话框
    handleOpenNormalFileModal(file, value) {
      switch (value) {
        case 'PDF':
          this.normalFileTitle = '上传PDF文件';
          this.openNormalFileModal(value, file);
          break;

        case 'Video':
          this.normalFileTitle = '上传视频文件';
          this.openNormalFileModal(value, file);
          break;

        case 'PPT':
          this.normalFileTitle = '上传PPT文件';
          this.openNormalFileModal(value, file);
          break;

        case 'Word':
          this.normalFileTitle = '上传Word文件';
          this.openNormalFileModal(value, file);
          break;
      }
    },
    // 打开选择会议议程对话框
    openNormalFileModal(key, file) {
      this.normalFileData = {
        name: '',
        personIds: [], // 资源推送目标参会人id
        resourceIds: [], // 资源id列表
        fileType: key === 'Word' ? 'Doc' : key, // 文件类型
        size: 0 // 文件大小
      };
      this.normalFileList = [];
      this.userList = [];
      // 筛选出可选资料接收人列表
      this.formDataCopy.devices.map((item, index) => {
        if (!item._editing && item.person && item.person.id) {
          this.userList.push(item.person);
        }
      });
      // 在非图片的文件下有file
      if (file) {
        this.file = file;
        this.normalFileData.name = file.name;
        this.normalFileData.size = file.size;
      }
      if (key === 'Image') {
        this.showNormalImgModal = true;
      } else {
        this.showNormalDefaultModal = true;
      }
    },
    // 关闭选择会议议程文件对话框
    closeNormalFileModal(value) {
      switch (value) {
        case 'Image':
          this.showNormalImgModal = false;
          break;

        default:
          this.showNormalDefaultModal = false;
      }
      this.normalFileList = [];
      this.normalFileData = {
        name: '',
        personIds: [], // 资源推送目标参会人id
        resourceIds: [], // 资源id列表
        fileType: '', // 文件类型
        size: 0 // 文件大小
      };
    },
    // 提交已选择图片
    onOkNormalFileModal($event, value) {
      if ($event.flag) {
        this.formDataCopy.normalResources.push($event.normalFileData);
        switch (value) {
          case 'Image':
            this.showNormalImgModal = false;
            break;

          default:
            this.showNormalDefaultModal = false;
            break;
        }
        this.saveFormDataToLocalStorage();
      }
    },
    // 关闭新建投票对话框
    closeVoteModal() {
      this.showVoteModal = false; // 未更新的投票弹框
      this.showMeetingNewlyAdded = false; // 更新后的投票弹框
      this.showVoteModify = false;
      // window.console.log('data数据里', this.voteData.options);
      // window.console.log('关闭', voteData);
    },
    // 点击保存新建投票
    onVoteSave({ title, anonymous, options }, callback) {
      let flag = true;
      this.formDataCopy.votes.map((item, index) => {
        if (item.title === title) {
          this.$Message.destroy();
          this.$Message.info({
            content: '投票内容已存在',
            duration: 3,
            closable: true
          });
          flag = false;
        }
        this.showMeetingNewlyAdded = false;
      });
      if (flag) {
        const vm = this;
        InteractionApi.newVote(this.formDataCopy.id, {
          title: title,
          anonymous: anonymous,
          options: options
        })
          .fetch()
          .then(res => {
            if (res.success) {
              const vote = this.pushNewVote(res.data);
              vm.showMeetingNewlyAdded = false; // 更新后的投票弹框
              if (callback) {
                callback(vote);
              } else {
                this.$Message.destroy();
                this.$Message.success({
                  content: '新建成功',
                  duration: 3,
                  closable: true
                });
              }
            } else {
              this.$Message.destroy();
              this.$Message.error({
                content: res.msg || this.errorMsg,
                duration: 3,
                closable: true
              });
            }
          })
          .catch(err => {
            this.$Message.destroy();
            this.$Message.error({
              content: err.msg || this.errorMsg,
              duration: 3,
              closable: true
            });
          });
      }
    },
    pushNewVote(data) {
      const vote = {
        id: data.id,
        status: data.status
      };
      this.refreshVote(vote, data);
      this.formDataCopy.votes.push(vote);
      return vote;
    },
    onVoteModifyAndPublish(voteData) {
      this.onVoteModify(voteData, vote => {
        this.onVotePublish(vote.id);
      });
    },
    onVoteModify(voteData, callback) {
      InteractionApi.modifyVote(this.formDataCopy.id, voteData.id, {
        title: voteData.title,
        anonymous: voteData.anonymous,
        options: voteData.options
      })
        .fetch()
        .then(res => {
          if (!res.success) {
            this.$Message.destroy();
            this.$Message.error({
              content: res.msg || this.errorMsg,
              duration: 3,
              closable: true
            });
            return;
          }
          // refresh data
          let vote = null;
          for (let index in this.formDataCopy.votes) {
            vote = this.formDataCopy.votes[index];
            if (vote.id === voteData.id) {
              this.refreshVote(vote, voteData);
              break;
            }
          }
          if (callback) {
            callback(vote);
          } else {
            this.showVoteModify = false;
            this.$Message.destroy();
            this.$Message.success({
              content: '修改成功',
              duration: 3,
              closable: true
            });
          }
        })
        .catch(err => {
          this.$Message.destroy();
          this.$Message.error({
            content: err.msg || this.errorMsg,
            duration: 3,
            closable: true
          });
        });
    },
    refreshVote(vote, voteData) {
      vote.title = voteData.title;
      vote.anonymous = voteData.anonymous;
      vote.optionA = null;
      vote.optionB = null;
      vote.optionC = null;
      vote.optionD = null;
      vote.optionE = null;
      voteData.options.forEach((item, option) => {
        const opt = {
          name: item,
          persons: [],
          value: 0
        };
        switch (option) {
          case 0:
            vote.optionA = opt;
            break;
          case 1:
            vote.optionB = opt;
            break;
          case 2:
            vote.optionC = opt;
            break;
          case 3:
            vote.optionD = opt;
            break;
          case 4:
            vote.optionE = opt;
            break;
          default:
            break;
        }
      });
    },

    // 保存表单数据到localStorage
    saveFormDataToLocalStorage() {
      if (this.formType === 'add') {
        if (this.formDataCopy.name || this.formDataCopy.devices.length) {
          localStorage.setItem('formData', JSON.stringify(this.formDataCopy));
        }
      }
    },

    getMqttMsg(event) {
      // window.console.log('收到MQTT_MSG', event);
      // 只处理Checkin和Vote相关的消息
      const vm = this;
      if (event.topic.indexOf('/NOTIFY') !== -1) {
        const message = event.msg;
        const msg = JSON.parse(message);
        const data = msg.notify.data;
        if (vm.formDataCopy.id !== msg.notify.meetingId) {
          // 不属于当前会议通知
          return;
        }

        if (msg.notify.type === 'Checkin') {
          for (const index in vm.checkinData.results) {
            const result = vm.checkinData.results[index];
            if (result.id === data.personId) {
              result['checkinTime'] = data.checkinTime;
              break;
            }
          }
          vm.checkinData.results.sort((p1, p2) => {
            const a = p1.checkinTime;
            const b = p2.checkinTime;
            if (!b) {
              return !a ? 0 : -1;
            }
            return !a ? 1 : a - b;
          });
        } else if (msg.notify.type === 'Vote') {
          data['id'] = data.voteId;
          if (data.action === 'Create') {
            // 新建投票通知
            vm.pushNewVote(data);
          } else {
            for (const index in this.formDataCopy.votes) {
              const localVote = this.formDataCopy.votes[index];
              if (localVote.id === data.voteId) {
                switch (data.action) {
                  case 'Vote':
                    const choose = this.index2Option(data.choose);
                    let option = localVote[choose];
                    !option.persons.find(voteRes => {
                      // 过滤了重复投票
                      return voteRes.personId === data.personId;
                    }) &&
                      option.persons.push({ personId: data.personId, personName: data.personName });
                    // 计算其它选项百分比
                    option['value'] = ((option.persons.length / localVote.total) * 100).toFixed(2);
                    break;
                  case 'Publish':
                    vm.votePublish(localVote, data.total);
                    break;
                  case 'End':
                    vm.voteEnd(localVote, data);
                    break;
                  case 'Modify':
                    vm.refreshVote(localVote, data);
                    break;
                  case 'Delete':
                    vm.voteDelete(data.voteId);
                    break;
                  default:
                    break;
                }
                break;
              }
            }
          }
        } else if (msg.notify.type === 'Command') {
          // 只处理设备下载进度和状态相关的消息
          const devicesArr = deepCopy(vm.formDataCopy.devices);
          for (var i = 0; i < devicesArr.length; i++) {
            if (devicesArr[i].executions.Start.devId === data.devId) {
              vm.formDataCopy.devices[i].executions.Start.status = data.status;
            }
          }
        }
      } else if (event.topic.indexOf(`/DEVICESTATUS`) !== -1) {
        // 1、设备电量通知
        // 2、设备在线状态通知
        // window.console.log('收到MQTT_MSG，设备在线状态通知', event);
        const message = event.msg;
        const msg = JSON.parse(message);
        const devicesArr = deepCopy(vm.formDataCopy.devices);
        for (var j = 0; j < devicesArr.length; j++) {
          if (devicesArr[j].devId === msg.devId) {
            if (msg.common) {
              // 更新设备电量信息
              vm.formDataCopy.devices[j].shadow.state.reported.common = msg.common;
            } else if (msg.online !== 'undefind') {
              // 更新设备在线信息
              vm.formDataCopy.devices[j].online = msg.online;
            }
          }
        }
        var unlinkSize = 0; // 未连接设备数量
        var eolSize = 0; // 低电量设备数量
        for (var m = 0; m < vm.formDataCopy.devices.length; m++) {
          if (vm.formDataCopy.devices[m].online === 0) {
            unlinkSize = unlinkSize + 1;
          }
          if (
            vm.formDataCopy.devices[m].online === 1 &&
            vm.formDataCopy.devices[m].shadow.state.reported.common.battery <= 20
          ) {
            eolSize = eolSize + 1;
          }
        }
        vm.formDataCopy.stat.unlinkSize = unlinkSize;
        vm.formDataCopy.stat.eolSize = eolSize;
      }
    },

    // 投票状态百分比
    onNewMessage() {
      const vm = this;
      vm.$root.eventHub.$on('MQTT_MSG', vm.getMqttMsg);
    },

    index2Option(index) {
      switch (index) {
        case 0:
          return 'optionA';
        case 1:
          return 'optionB';
        case 2:
          return 'optionC';
        case 3:
          return 'optionD';
        case 4:
          return 'optionE';
      }
      this.$Message.destroy();
      this.$Message.error({
        content: '未知选项',
        duration: 3,
        closable: true
      });
    }
  },

  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },

  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
    const vm = this;
    vm.userList = [];
    // 如果是编辑状态
    // 会议议程
    if (vm.formData.agendaResources.length) {
      vm.formData.agendaResources.map((agendaResource, agendaIndex) => {
        if (
          vm.formData.agendaResources[agendaIndex].resources &&
          vm.formData.agendaResources[agendaIndex].resources.length
        ) {
          vm.formData.agendaResources[agendaIndex].resourceIds = [];
          vm.formData.agendaResources[agendaIndex].resources.map((item, index) => {
            vm.formData.agendaResources[agendaIndex].resourceIds.push(item.resourceId);
          });
        }
      });
    }
    // 会议资料
    if (vm.formData.normalResources.length) {
      vm.formData.normalResources.map((normalResource, normalIndex) => {
        if (
          vm.formData.normalResources[normalIndex].resources &&
          vm.formData.normalResources[normalIndex].resources.length
        ) {
          vm.formData.normalResources[normalIndex].resourceIds = [];
          vm.formData.normalResources[normalIndex].resources.map((item, index) => {
            vm.formData.normalResources[normalIndex].resourceIds.push(item.resourceId);
          });
        }
      });
    }

    // 如果没有选择主持人
    if (vm.formData.host === null) {
      vm.formData.host = 0;
    }

    vm.formDataCopy = vm.formData;
  },

  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
    this.onNewMessage();
  },

  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
      this.openAgendaModal();
      this.openNormalFileModal();
      if (this.percent === 100) {
        this.showProgress = false;
      }
    });
  },

  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  },

  destroyed() {
    this.$root.eventHub.$off('MQTT_MSG', this.getMqttMsg);
  }
};
</script>
<style lang='less'>
.title-bar {
  width: 100%;

  &-header {
    width: 100%;
    position: absolute;
    top: 64px;
    left: 0;
  }
}

.header-center {
  display: inline-flex;
  justify-content: center;
  align-items: center;
  height: 32px;
  line-height: 32px;
  margin-left: -8%;

  &-progress {
    width: 240px;
    font-family: PingFangSC-Regular;

    .ivu-progress-inner {
      background-color: #dce8ff;
    }
  }
}

.header-warning {
  display: inline-flex;
  font-family: PingFangSC-Regular;
  font-size: 14px;
  color: #666666;
  height: 34;
  line-height: 14px;
  padding: 7px 0;

  &-icon {
    width: 18px;
    height: 18px;
    margin-right: 6px;

    > img {
      width: 100%;
      height: 100%;
    }
  }

  &-text {
    padding: 3px 0;
  }

  .red {
    color: #f02a2a;
  }
}

.detail-body {
  height: 100%;

  .ivu-tabs-nav {
    height: 50px;
    .ivu-tabs-tab {
      padding: 16px 16px;
    }
  }

  .ivu-tabs-nav-right {
    padding: 6px 0;
  }
}

.tabs-style {
  background: white;
  padding: 0 36px;
  min-height: ~'calc(100% - 30px)';
  margin-bottom: 30px;
}

.dropdownvote {
  height: 37px;
  padding: 0;
  display: inline-flex;
  align-items: center;

  &:hover {
    cursor: pointer;
    color: #0050ff;
  }
}

// 查看文件按钮样式
.same-screen {
  position: absolute;
  right: 38px;
  bottom: 14px;
  font-size: 12px;
}

.buttonClass {
  right: 60px;
  height: 37px;
  display: inline-flex;
  align-items: center;

  &-font {
    font-size: 14px;
  }

  &-div {
    display: inline-flex;
    align-items: center;
    width: 80px;
    height: 37px;
  }

  &-icon {
    width: 18px;
    height: 18px;
    margin-right: 6px;
  }
}

.host {
  display: inline-flex;
  align-items: center;
  height: 30px;
  padding: 6px;
  > img {
    width: 18px;
    height: 18px;
    margin-right: 6px;
  }
}

.ivu-btn-ghost {
  font-size: 12px;
}
</style>
