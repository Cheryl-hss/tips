import Conference from './conference-interaction.vue';

export default Conference;
