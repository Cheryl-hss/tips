<template>
  <div v-if="value">
    <Modal :value="value"
           :mask-closable="false"
           :width="750"
           @on-visible-change="onChange">
      <p slot="header"
         class="header">
        <span>壁纸</span>
      </p>
      <div slot="close"
           @click="onClose"
           class="margin-right">
        <Icon type="ios-close"
              :size="35"
              color="#999999" />
      </div>
      <div class="my-wallpaper"
           :style="'max-height:' + height + 'px'">
        <RadioGroup v-model="selectWallpaper">
          <div class="my-wallpaper-header">
            <div class="my-wallpaper-header-title">我的壁纸：</div>
            <div v-if="customData.length && showRadio"
                 class="my-wallpaper-header-action"
                 @click="deleteMyWallpaper">删除</div>
            <div v-if="customData.length && !showRadio"
                 class="my-wallpaper-header-action"
                 @click="cancelDelete">取消</div>
          </div>
          <Row :gutter="30"
               type="flex"
               justify="start">
            <Col span="4">
            <Upload class="my-wallpaper-item"
                    ref="uploader"
                    :action="uploadURL"
                    accept=".jpg, .png, .mp4"
                    :format="['.jpg', '.png', '.mp4']"
                    :before-upload="beforeUpload">
              <div class="my-wallpaper-add">
                <div class="my-wallpaper-add-icon">
                  <img src="@/assets/images/add@2x.png" />
                </div>
                <div>添加壁纸</div>
              </div>
            </Upload>
            </Col>
            <Col span="4"
                 v-for="(item, index) in customData"
                 :key="index">
            <div class="my-wallpaper-item">
              <img :src="item.url"
                   @click="selectRadio(item.resKey)" />
              <div v-if="showRadio"
                   class="my-wallpaper-item-cover">
                <Radio :label="item.resKey"><span></span></Radio>
              </div>
              <div v-else
                   class="my-wallpaper-item-close"
                   @click="handleRemoveMyWallpaper(index, item)">
                <img src="@/assets/images/icon-close-img@2x.png" />
              </div>
            </div>
            </Col>
          </Row>
          <div v-if="fileData.length">
            <div class="default-wallpaper-title">系统壁纸：</div>
            <Row :gutter="30"
                 type="flex"
                 justify="start">
              <Col span="4"
                   v-for="(item, index) in fileData"
                   :key="index">
              <div class="my-wallpaper-item">
                <img :src="item.url"
                     @click="selectRadio(item.resKey)" />
                <div class="my-wallpaper-item-cover">
                  <Radio :label="item.resKey"><span></span></Radio>
                </div>
              </div>
              </Col>
            </Row>
          </div>
        </RadioGroup>
      </div>
      <div slot="footer">
        <Button class="button-width"
                @click="onClose">取消</Button>
        <Button v-if="selectWallpaper !== selected"
                class="button-width"
                type="primary"
                @click="onOk">确定</Button>
        <Button v-else
                class="button-width"
                disabled>确定</Button>
      </div>
    </Modal>
  </div>
</template>

<script>
import { Modal, Upload, RadioGroup, Radio, Row, Col, Icon, Button } from 'view-design';
import { indexOfByKeyAndValue, deepCopy } from '@/utils/tools';

import {
  uploadToOSS,
  saveCustomResourses,
  getOssResourse,
  deleteCustomResourses,
  getScreenshot
} from '@/api/upload';

export default {
  // 不要忘记了 name 属性
  name: 'WallpaperModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    customData: {
      // 自定义壁纸列表
      type: Array,
      default() {
        return [];
      }
    },
    fileData: {
      // 系统内置壁纸列表
      type: Array,
      default() {
        return [];
      }
    },
    selected: {
      type: String,
      default() {
        return '';
      }
    },
    value: Boolean // 是否显示
  },
  // 变量
  data() {
    return {
      height: 750,
      wallpaperSrc: '', // 自定义壁纸src
      uploadURL: '', // 上传自定义壁纸路径
      selectWallpaper: deepCopy(this.selected), // 被选中的壁纸, 默认选中默认壁纸的第一个
      wallpaperObj: {},
      showRadio: true // 被选中的壁纸
    };
  },

  // 使用其它组件
  components: { Modal, Upload, RadioGroup, Radio, Row, Col, Icon, Button },
  // 计算属性
  computed: {},
  // 监听
  watch: {
    value(newVal) {
      if (newVal) {
        this.selectWallpaper = deepCopy(this.selected);
        this.height = (window.innerHeight * 86) / 100 - 51 - 57 - 32;
      }
    }
  },
  // 方法
  methods: {
    // 关闭对话框
    onClose() {
      this.$emit('on-close');
    },

    onOk() {
      if (this.fileData.length) {
        const index = indexOfByKeyAndValue(this.fileData, 'resKey', this.selectWallpaper);
        if (index !== -1) {
          this.wallpaperObj = this.fileData[index];
        }
      }
      if (this.customData.length) {
        const customIndex = indexOfByKeyAndValue(this.customData, 'resKey', this.selectWallpaper);
        if (customIndex !== -1) {
          this.wallpaperObj = this.customData[customIndex];
        }
      }
      this.$emit('on-ok', this.wallpaperObj);
    },

    // 显示状态发生变化时触发
    onChange(value) {
      if (!value) {
        this.onClose();
      }
    },

    // 上传文件失败后
    beforeUpload(file) {
      const vm = this;
      // 上传的文件要小于20M
      if (file.size > 20 * 1024 * 1024) {
        vm.$Message.destroy();
        vm.$Message.warning({
          content: '上传文件不能大于20M！',
          duration: 5,
          closable: true
        });
        return;
      }
      uploadToOSS(file).then(res => {
        // 当model框被关闭时，阻止继续调用请求
        if (!vm.value) {
          return;
        }
        // 1、创建oss资源 ，拿到资源id，push到 resourceIds
        // 2、拿返回的objectKey去请求资源，得到资源路径，显示出来

        // 先判断所上传文件是否已经在文件列表里
        const index = indexOfByKeyAndValue(vm.customData, 'resKey', res.key);
        if (index !== -1) {
          vm.$Message.destroy();
          vm.$Message.warning({
            content: '“' + file.name + '”' + '壁纸已存在，不能再次上传！',
            duration: 5,
            closable: true
          });
          return;
        }
        if (index === -1) {
          // 获取用户id
          const userId = vm.$store.state.user.userId;
          // 获取创建资源参数
          const wallpaperData = {
            fileKey: res.key,
            name: file.name,
            size: file.size,
            desc: file.desc,
            md5: res.md5,
            fileType: file.type === 'video/mp4' ? 'Video' : 'Image',
            type: 'Wallpaper'
          };
          // 发送创建资源请求
          saveCustomResourses(wallpaperData)
            .fetch()
            .then(({ success, msg, data }) => {
              //
              if (success) {
                vm.$Message.destroy();
                vm.$Message.success({
                  content: msg || '“' + file.name + '”' + '上传成功！',
                  duration: 5,
                  closable: true
                });
                wallpaperData.resourceId = data.resourceId;
                if (wallpaperData.fileType === 'Image') {
                  // 获取图片壁纸下载地址
                  vm.getOssResourse(wallpaperData, userId, { key: res.key });
                } else if (wallpaperData.fileType === 'Video') {
                  // 获取视频壁纸截图下载地址
                  vm.getScreenshot(wallpaperData);
                }
              } else {
                vm.$Message.destroy();
                vm.$Message.error({
                  content: msg || '“' + file.name + '”' + '上传失败，请重试！',
                  duration: 5,
                  closable: true
                });
              }
            })
            .catch(err => {
              vm.$Message.destroy();
              vm.$Message.error({
                content: err.msg || '“' + file.name + '”' + '上传失败，请重试！',
                duration: 5,
                closable: true
              });
            });
        }
      });
      return false;
    },

    // 获取OSS临时下载资源地址
    getOssResourse(file, userId, key) {
      getOssResourse(userId, key)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            const obj = {
              resourceId: file.resourceId,
              name: file.name,
              fileType: file.fileType,
              url: data,
              resKey: key.key
            };
            this.customData.push(obj);
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: msg || '“' + file.name + '”' + '获取失败',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          this.$Message.error({
            content: err.msg || '“' + file.name + '”' + '获取失败',
            duration: 5,
            closable: true
          });
        });
    },

    // 获取视频资源快照下载地址
    getScreenshot(file) {
      getScreenshot(file.resourceId)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            const obj = {
              resourceId: file.resourceId,
              name: file.name,
              fileType: file.fileType,
              url: data,
              resKey: file.fileKey
            };
            this.customData.push(obj);
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: msg || '“' + file.name + '”' + '获取失败',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          this.$Message.error({
            content: err.msg || '“' + file.name + '”' + '获取失败',
            duration: 5,
            closable: true
          });
        });
    },

    // 显示删除
    deleteMyWallpaper() {
      this.showRadio = false;
    },

    // 取消显示删除
    cancelDelete() {
      this.showRadio = true;
    },

    // 点击删除我的壁纸
    handleRemoveMyWallpaper(index, item) {
      const vm = this;
      if (item.resKey === vm.selected) {
        vm.$Message.destroy();
        vm.$Message.warning({
          content: '此选项已设置为铭牌壁纸，不能删除',
          duration: 5,
          closable: true
        });
        return;
      }
      // 请求接口删除用户自定义图片
      deleteCustomResourses(item.resourceId)
        .fetch()
        .then(({ success, msg }) => {
          if (success) {
            // 请求成功，从自定义列表里删除
            vm.customData.splice(index, 1);
            if (!vm.customData.length) {
              this.showRadio = true;
            }
            // 获取已选择的resKey是否还存在
            // 不存在，index为-1，恢复选择默认壁纸
            const indexCustom = indexOfByKeyAndValue(
              this.customData,
              'resKey',
              this.selectWallpaper
            );

            const indexDefault = indexOfByKeyAndValue(
              this.fileData,
              'resKey',
              this.selectWallpaper
            );

            // 恢复选择默认壁纸
            if (indexCustom === -1 && indexDefault === -1) {
              if (vm.fileData.length) {
                vm.selectWallpaper = vm.selected;
              }
            }
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: msg || '“' + item.name + '”' + '删除失败',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg || '“' + item.name + '”' + '删除失败',
            duration: 5,
            closable: true
          });
        });
    },

    // 选择radio
    selectRadio(value) {
      if (this.showRadio) {
        this.selectWallpaper = value;
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.ivu-radio-group {
  display: block;
}

.header {
  text-align: center;
  font-family: PingFangSC-Regular;
  height: 18px;
}

.my-wallpaper {
  width: 100%;
  font-family: PingFangSC-Regular;
  font-size: 14px;
  line-height: 14px;
  padding: 14px;
  overflow-y: auto;
  overflow-x: hidden;

  &-header {
    height: 14px;

    &-title {
      color: #333333;
      float: left;
    }

    &-action {
      color: #0050ff;
      float: right;

      &:hover {
        cursor: pointer;
      }
    }
  }

  &-add {
    width: 90px;
    height: 120px;
    background: #ecedee;
    text-align: center;
    padding-top: 36px;

    &-icon {
      width: 30px;
      height: 30px;
      margin-left: 30px;
      margin-bottom: 18px;
      > img {
        width: 100%;
        height: 100%;
      }
    }

    &:hover {
      cursor: pointer;
    }
  }

  &-item {
    width: 90px;
    height: 120px;
    margin-top: 12px;

    > img {
      width: 100%;
      height: 100%;
      cursor: pointer;
    }

    &-cover {
      margin-top: 18px;
      position: absolute;
      top: -2px;
      right: 3px;
    }

    &-close {
      position: absolute;
      top: 16px;
      right: 20px;
      width: 20px;
      height: 20px;

      > img {
        width: 100%;
      }

      &:hover {
        cursor: pointer;
      }
    }
  }
}

.default-wallpaper-title {
  height: 14px;
  margin-top: 20px;
}
</style>
