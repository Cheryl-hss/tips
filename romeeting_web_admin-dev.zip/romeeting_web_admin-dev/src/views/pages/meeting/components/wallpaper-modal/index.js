import WallpaperModal from './wallpaper-modal';

export default WallpaperModal;
