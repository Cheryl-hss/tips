import MeetingEndDetail from './meeting-end-detail.vue';

export default MeetingEndDetail;
