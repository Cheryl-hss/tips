<template>
  <div>
    <div class="title-bar-header">
      <TitleBar ref="titleBar" :name="titleBarName" show-to-back @to-back="toBack">
        <div slot="button">
          <Button @click="deleteMeeting">删除</Button>
        </div>
      </TitleBar>
    </div>
    <div class="end-detail">
      <div class="end-detail-header">
        <div>
          <span>会议名称：</span>
          <span class="end-detail-color">{{ detailData.name }}</span>
        </div>
        <div class="end-detail-header-right">
          <span>会议时间：</span>
          <span class="end-detail-color">{{ dateTime }}</span>
        </div>
      </div>

      <div class="end-detail-body">
        <div class="end-detail-body-item1 margin-bottom">
          <div class="end-detail-body-title">会议信息</div>
          <div class="margin-left-12 padding-4">
            <span>主持人：</span>
            <span class="end-detail-color">{{ hostName }}</span>
          </div>
          <div class="end-detail-body-item1-attendee margin-left-12 padding-4">
            <div class="end-detail-body-item1-attendee-left">参会人：</div>
            <div class="end-detail-body-item1-attendee-right">
              <span
                class="end-detail-color padding-right-12"
                v-for="(item, index) in detailData.devices"
                :key="index"
              >
                {{ item.person.name || '-' }}
              </span>
            </div>
          </div>
        </div>

        <div class="margin-bottom">
          <div class="end-detail-body-title">会议议程</div>
          <div
            class="margin-bottom"
            v-for="(item, index) in detailData.agendaResources"
            :key="index"
          >
            <EndFileItem :file-data="item" :show-download="true" @on-click="downloadFile(item)" />
          </div>
          <div v-if="detailData.agendaResources.length === 0">无</div>
        </div>

        <div class="margin-bottom">
          <div class="end-detail-body-title">会议资料</div>
          <div
            class="margin-bottom"
            v-for="(item, index) in detailData.normalResources"
            :key="index"
          >
            <EndFileItem
              :file-data="item"
              :show-users="false"
              :show-download="true"
              @on-click="downloadFile(item)"
            />
          </div>
          <div v-if="detailData.normalResources.length === 0">无</div>
        </div>

        <div class="margin-bottom">
          <div class="end-detail-body-title">提词</div>
          <Row :gutter="24" type="flex" justify="start" align="middle">
            <Col
              class="margin-bottom-24"
              :sm="{ span: 24 }"
              :lg="{ span: 12 }"
              :xxl="{ span: 8 }"
              v-for="(item, index) in detailData.keywords"
              :key="'keywords_' + index"
            >
              <ContentItem :data="item" :index="index + 1" />
            </Col>
          </Row>
          <div v-if="!detailData.keywords || detailData.keywords.length === 0">无</div>
        </div>

        <div class="margin-bottom">
          <div class="end-detail-body-title">会议签到</div>
          <div class="margin-bottom">
            <MeetingSignIn :checkin-date="checkinData" />
          </div>
          <div style="margin-top: -16px" v-show="showNothing">无</div>
        </div>

        <div class="margin-bottom">
          <div class="end-detail-body-title">会议投票</div>
          <Row :gutter="24" type="flex" justify="start" align="middle">
            <Col
              class="margin-bottom"
              :sm="{ span: 12 }"
              :md="{ span: 14 }"
              :lg="{ span: 16 }"
              :xxl="{ span: 12 }"
              v-for="(item, index) in detailData.votes"
              :key="index"
            >
              <MeetingVoting
                :vote-data="item"
                :index="index + 1"
                :show-download="item.status === 'End'"
                @on-download="downloadVote(item)"
              />
            </Col>
          </Row>
          <div v-if="detailData.votes.length === 0">无</div>
        </div>

        <div class="margin-bottom">
          <div class="end-detail-body-title">会议内容</div>
          <Input
            v-model="detailData.content"
            type="textarea"
            :rows="8"
            placeholder="请输入会议内容"
          />
        </div>
      </div>
    </div>
    <Table size="small" ref="table" class="download-table"></Table>
  </div>
</template>

<script>
import { Input, Button, Table, Row, Col } from 'view-design';
import TitleBar from '@/views/pages/components/title-bar';
import { EndFileItem } from '../file-item';
import ContentItem from '../content-item';
import { downloadfile, getFileType } from '@/utils/download';

import { getOssResourse } from '@/api/upload';

import MeetingSignIn from '../historical-conference-sign-in';
import MeetingVoting from '../historical-conference-voting';
import InteractionApi from '@/api/interaction';

export default {
  // 不要忘记了 name 属性
  name: 'MeetingEndDetail',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    detailData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  // 变量
  data() {
    return {
      titleBarName: this.$t('meeting_detail'),
      checkinData: {},
      showNothing: true
    };
  },

  // 使用其它组件
  components: {
    Input,
    Button,
    Table,
    Row,
    Col,
    TitleBar,
    EndFileItem,
    ContentItem,
    MeetingSignIn, // 签到
    MeetingVoting // 投票
  },
  // 计算属性
  computed: {
    // 显示会议时间
    dateTime() {
      if (this.detailData.date) {
        if (this.detailData.startTime && this.detailData.endTime) {
          return (
            this.detailData.date + ' ' + this.detailData.startTime + '-' + this.detailData.endTime
          );
        }
        return this.detailData.date;
      }
      return '-';
    },
    // 主持人姓名
    hostName() {
      for (var i = 0; i < this.detailData.devices.length; i++) {
        if (this.detailData.devices[i].person.id === this.detailData.host) {
          return this.detailData.devices[i].person.name;
        }
      }
      return '-';
    }
  },
  // 监听
  watch: {
    checkinData(val) {
      if (this.checkinData.deadline !== null) {
        this.showNothing = false;
      }
    }
  },
  // 方法
  methods: {
    getEndSignIn() {
      const vm = this;
      var id = this.detailData.id;
      InteractionApi.endSignIn(id)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            this.checkinData = data;
            this.checkinData.results.sort((p1, p2) => {
              const a = p1.checkinTime;
              const b = p2.checkinTime;
              if (!b) {
                return !a ? 0 : -1;
              }
              return !a ? 1 : a - b;
            });
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: msg,
              duration: 5,
              closable: true
            });
          }
        });
    },
    // 点击下载文件
    downloadFile(item) {
      // 1、获取oss临时下载地址
      // 2、创建iframe并下载资源
      const userId = this.$store.state.user.userId;
      if (item.resources.length) {
        item.resources.map((resource, index) => {
          this.getOssResourse(userId, { key: resource.resKey }, resource.name);
        });
      } else if (item.id.lenght) {
        item.id.map((resource, index) => {
          this.getOssResourse(userId, { key: item.resKey }, resource.name);
        });
      }
    },

    getBase64(imgUrl, cb) {
      window.URL = window.URL || window.webkitURL;
      var xhr = new XMLHttpRequest();
      xhr.open('get', imgUrl, true);
      // 至关重要
      xhr.responseType = 'blob';
      xhr.onload = function onload(params) {
        if (this.status === 200) {
          // 得到一个blob对象
          var blob = this.response;
          // 至关重要
          let oFileReader = new FileReader();
          oFileReader.onloadend = e => {
            let base64 = e.target.result;
            cb(base64);
          };
          oFileReader.readAsDataURL(blob);
        }
      };
      xhr.send();
    },

    // 向后端请求接口获取oss资源下载地址并下载
    getOssResourse(userId, data, fileName) {
      let downloadUrl = '';
      getOssResourse(userId, data)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            downloadUrl = data;
            const type = getFileType(fileName);
            downloadfile(downloadUrl, fileName, type);
          }
        });
    },
    // 投票饼状图
    getVotePieValue(item) {
      const valueA = Number(item.optionA.value);
      const valueB = Number(item.optionB.value);
      const valueC = Number(item.optionC.value);
      const valueUnknown = Number(item.unknown.value);
      const maxValue = Math.max(valueA, valueB, valueC, valueUnknown);

      return [
        {
          name: '赞同',
          y: valueA,
          selected: valueA === maxValue
        },
        {
          name: '反对',
          y: valueB,
          selected: valueB === maxValue
        },
        {
          name: '弃权',
          y: valueC,
          selected: valueC === maxValue
        },
        {
          name: '未投票',
          y: valueUnknown,
          selected: valueUnknown === maxValue
        }
      ];
    },

    // 下载投票结果
    downloadVote(item) {
      const columns = [
        {
          title: '选项',
          key: 'option'
        },
        {
          title: '人数',
          key: 'count'
        },
        {
          title: '占比',
          key: 'value'
        }
      ];
      // 非匿名投票时，加上投票人列
      if (!item.anonymous) {
        columns.push({
          title: '投票人',
          key: 'name'
        });
      }
      const dataList = [
        {
          option: item.optionA.name,
          count: item.optionA.persons.length,
          name: this.getVotePersonName(item.optionA.persons),
          value: item.optionA.value + '%'
        },
        {
          option: item.optionB.name,
          count: item.optionB.persons.length,
          name: this.getVotePersonName(item.optionB.persons),
          value: item.optionB.value + '%'
        }
      ];
      if (item.optionC !== null) {
        dataList.push({
          option: item.optionC.name,
          count: item.optionC.persons.length,
          name: this.getVotePersonName(item.optionC.persons),
          value: item.optionC.value + '%'
        });
      }
      if (item.optionD !== null) {
        dataList.push({
          option: item.optionD.name,
          count: item.optionD.persons.length,
          name: this.getVotePersonName(item.optionD.persons),
          value: item.optionD.value + '%'
        });
      }
      if (item.optionE !== null) {
        dataList.push({
          option: item.optionE.name,
          count: item.optionE.persons.length,
          name: this.getVotePersonName(item.optionE.persons),
          value: item.optionE.value + '%'
        });
      }
      dataList.push({
        option: item.unknown.name,
        count: item.unknown.persons.length,
        name: this.getVotePersonName(item.unknown.persons),
        value: item.unknown.value + '%'
      });
      this.$refs.table.exportCsv({
        filename: item.title,
        columns: columns,
        data: dataList
      });
    },

    // 删除会议
    deleteMeeting() {
      this.$emit('on-delete', this.detailData.id);
    },

    // 获取下载投票内容投票人名字
    getVotePersonName(persons) {
      const nameArr = [];
      persons.map((person, index) => {
        nameArr.push(person.personName);
      });
      // 把投票人名字数组转换成字符串返回
      const names = nameArr.join('、');
      return names;
    },

    // 返回首页
    toBack() {
      this.$emit('to-back');
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
      this.getEndSignIn();
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.download-table {
  display: none;
}

.title-bar {
  width: 100%;

  &-header {
    width: 100%;
    position: absolute;
    top: 64px;
    left: 0;
  }
}

.end-detail {
  font-family: PingFangSC-Regular;
  font-size: 14px;
  color: #666666;
  &-color {
    color: #333333;
  }

  &-header {
    width: 100%;
    display: inline-flex;
    background: #ffffff;
    height: 76px;
    line-height: 14px;
    padding: 31px 48px;

    &-right {
      margin-left: 30%;
    }
  }

  &-body {
    width: 100%;
    background: #ffffff;
    margin-top: 12px;
    padding: 31px 48px;

    &-title {
      font-family: PingFangSC-Semibold;
      font-size: 16px;
      color: #333333;
      line-height: 16px;
      padding: 20px 0;
      font-weight: 600;
    }

    &-item1 {
      &-attendee {
        .clearFix();

        &-left {
          float: left;
        }

        &-right {
          float: initial;
        }
      }
    }
  }

  &-tail {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: #ffffff;
    border: 1px solid #dddddd;
    width: 100%;
    height: 72px;
    z-index: 100;
    padding-right: 8%;

    &-button {
      height: 72px;
      line-height: 72px;
      float: right;
      padding-right: 63px;
    }
  }
}
</style>
