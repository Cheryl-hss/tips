<template>
  <div>
    <div class="meeting-card">
      <Card class="meeting-card"
            dis-hover>
        <p slot="title"
           class="meeting-card-title">
          {{ meetingData.name }}
        </p>
        <StatusInfo :status="meetingData.status"
                    slot="extra" />
        <MeetingCardInfoItem :icon="iconClock"
                             :label="$t('meeting_card_info_item_time')"
                             :text="dateTime" />
        <MeetingCardInfoItem v-if="meetingData.stat"
                             :icon="iconStatus"
                             :label="$t('meeting_card_info_item_status')">
          <div v-if="!meetingData.stat.unlinkSize && !meetingData.stat.eolSize"
               slot="tail"
               class="meeting-card-normal">正常</div>
          <div v-else
               slot="tail">
            <span v-if="meetingData.stat.unlinkSize">
              <span class="meeting-card-warning">{{ meetingData.stat.unlinkSize }}台</span>
              <span>未连接&nbsp;&nbsp;</span>
            </span>
            <span v-if="meetingData.stat.eolSize">
              <span class="meeting-card-warning">{{ meetingData.stat.eolSize }}台</span>
              <span>低电量</span>
            </span>
          </div>
        </MeetingCardInfoItem>
        <div class="meeting-card-operate">
          <MeetingCardOperate :status="meetingData.status"
                              @on-click-mask="onClickMask"
                              @on-click-end="onClickEnd"
                              @on-click-start="onClickStart"
                              @on-click-delete="onClickDelete" />
        </div>
      </Card>
    </div>
  </div>
</template>

<script>
import { Card } from 'view-design';
import StatusInfo from '../status-info';
import MeetingCardInfoItem from '../meeting-card-info-item';
import MeetingCardOperate from '../meeting-card-operate';

import { getDate } from '@/utils/tools';

const IconClock = require('@/assets/images/clock@2x.png');
const IconStatus = require('@/assets/images/icon-status@2x.png');

export default {
  // 不要忘记了 name 属性
  name: 'MeetingCard',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    meetingData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  // 变量
  data() {
    return {
      iconClock: IconClock,
      iconStatus: IconStatus
    };
  },

  // 使用其它组件
  components: { Card, StatusInfo, MeetingCardInfoItem, MeetingCardOperate },
  // 计算属性
  computed: {
    dateTime() {
      var date = '';

      // 有日期和时间
      if (this.meetingData.startTime && this.meetingData.endTime) {
        var startDateTime = getDate(this.meetingData.startTime / 1000, 'year');
        const startTimeArr = startDateTime.split(' ');
        date = new Date(this.meetingData.startTime);
        date = date.getMonth() + 1 + '月' + date.getDate() + '日';
        const startTime = startTimeArr[1].slice(0, -3);

        var endDateTime = getDate(this.meetingData.endTime / 1000, 'year');
        const endTimeArr = endDateTime.split(' ');
        const endTime = endTimeArr[1].slice(0, -3);

        return date + ' ' + startTime + '-' + endTime;
      }

      // 只有日期
      if (this.meetingData.startTime) {
        date = new Date(this.meetingData.startTime);
        date = date.getMonth() + 1 + '月' + date.getDate() + '日';
        return date;
      }

      return '待定';
    }
  },
  // 监听
  watch: {},
  // 方法
  methods: {
    onClickMask() {
      this.$emit('on-click-mask');
    },

    // 点击结束会议按钮触发
    onClickEnd() {
      this.$emit('on-click-end');
    },

    // 点击立即推送按钮触发
    onClickStart() {
      this.$emit('on-click-start');
    },

    // 点击删除按钮触发
    onClickDelete() {
      this.$emit('on-click-delete');
    },

    // 获取会议状态预警信息
    // devSize：设备总数
    // eolSize: 低电量设备数
    // unlinkSize: 未连接设备数
    getBatteryStatus({ devSize, eolSize, unlinkSize }) {
      if (devSize - unlinkSize === devSize) {
        return '正常';
      } else if (eolSize && unlinkSize === 0) {
        return eolSize + '台';
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.meeting-card {
  width: 100%;
  // min-width: 300px;
  height: 160px;
  border-radius: 6px !important;

  .ivu-card {
    &:hover {
      border-color: #0050ff !important;
    }
  }

  .ivu-card-head {
    border-bottom: 0;
    padding: 27px 12px 0 24px;
  }

  .ivu-card-head p,
  .ivu-card-head-inner {
    font-family: PingFangSC-Regular;
    color: #333333;
    font-size: 18px;
    height: 20px;
    line-height: 17px;
  }

  .ivu-card-extra {
    right: 12px;
    top: 21px;
  }

  .ivu-card-body {
    padding-top: 24px;
    padding-left: 24px;
  }

  &:hover &-operate {
    display: block;
  }

  &-title {
    height: 20px;
    max-width: ~'calc(100% - 80px)';
    font-family: PingFangSC-Medium;
    font-size: 18px;
    color: #333333;
    line-height: 17px;
    font-weight: 500;
  }

  &-icon {
    > img {
      width: 42px;
      height: 42px;
    }
  }

  &-text {
    font-family: PingFangSC-Regular;
    font-size: 16px;
    color: #515a6e;
    height: 16px;
    line-height: 16px;
    text-align: center;
  }

  &-normal {
    color: #199e31;
  }

  &-warning {
    color: #f02a2a;
  }

  &-operate {
    position: absolute;
    left: 0;
    bottom: 0;
    display: none;
  }
}
</style>
