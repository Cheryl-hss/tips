import MeetingCard from './meeting-card.vue';

export default MeetingCard;
