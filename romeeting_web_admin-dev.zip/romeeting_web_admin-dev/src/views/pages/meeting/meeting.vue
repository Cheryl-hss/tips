<template>
  <div class="meeting-content"
       ref="meeting_content">

    <div v-if="!showAddMeeting && !showMeetingDetail && !showMeetingEndDetail"
         class="meeting-content-body">
      <!-- 标题logo背景 -->
      <MeetingHomeHead class="meeting-content-body-head"
                       :value="true" />
      <!-- 会议列表 -->
      <div class="meeting-content-body-card">
        <Row class="meeting-content-body-row"
             :gutter="24"
             type="flex"
             justify="start"
             align="middle">
          <Col :sm="{ span: 24 }"
               :md="{ span: 12 }"
               :lg="{ span: 8 }"
               :xxl="{ span: 6 }">
          <MeetingCardAdd class="meeting-content-body-card-item"
                          @on-click="showAddMeetingForm(true)" />
          </Col>
          <Col :sm="{ span: 24 }"
               :md="{ span: 12 }"
               :lg="{ span: 8 }"
               :xxl="{ span: 6 }"
               v-for="(item, index) in meetingList"
               :key="index">
          <MeetingCard class="meeting-content-body-card-item on-hover"
                       :meeting-data="item"
                       @on-click-mask="showMeetingDetailForm(item, true)"
                       @on-click-end="endMeeting(item)"
                       @on-click-start="startMeeting(item)"
                       @on-click-delete="deleteMeeting(item.id)" />
          </Col>
        </Row>
      </div>
      <!-- 历史会议 -->
      <MeetingEndList class="meeting-content-body-end-list"
                      :end-meeting-list="endMeetingList"
                      @on-click-item="showEndMeetingDetail"
                      @on-delete="deleteMeetingEnd" />

      <NoMeetingEndList v-if="!endMeetingList.length"
                        class="meeting-content-body-no-end-list" />
    </div>

    <div v-if="showAddMeeting && !showMeetingDetail && !showMeetingEndDetail"
         class="meeting-content-add">
      <MeetingForm :value="showAddMeeting"
                   :form-data="formData"
                   :form-type="formType"
                   :name="titleBarName"
                   @on-save="addMeeting"
                   @on-cancle="onEditCancel"
                   @on-destroy="onFormDestroy"
                   @on-delete="deleteMeeting(formData.id)" />
    </div>
    <div v-if="!showAddMeeting && showMeetingDetail && !showMeetingEndDetail"
         class="meeting-content-detail">
      <Conference :value="showMeetingDetail"
                  :form-data="formData"
                  :form-type="formType"
                  @edit="edit(formData)"
                  @end-meeting="endMeeting(formData)"
                  @to-back="toBack" />
    </div>
    <div v-if="!showAddMeeting && !showMeetingDetail && showMeetingEndDetail"
         class="meeting-content-add">
      <MeetingEndDetail :detail-data="formData"
                        @on-delete="deleteMeeting"
                        @to-back="toBack" />
    </div>
    <MeetingEndModal :value="showMeetingEndModal"
                     :countdown="countdown"
                     @on-control-to-home="onControlToHome"
                     @on-control-dev-shutdown="onControlDevShutdown" />

  </div>
</template>

<script>
import { Row, Col, TabPane, Tabs } from 'view-design';
import TitleBar from '../components/title-bar';
import MeetingHomeHead from './components/meeting-home-head';
import MeetingCardAdd from './components/meeting-card-add';
import MeetingCard from './components/meeting-card';
import { MeetingEndList, NoMeetingEndList } from './components/meeting-end-list';
import MeetingForm from './components/meeting-form';
import MeetingEndDetail from './components/meeting-end-detail';
import MeetingEndModal from './components/meeting-end-modal';
import MeetingApi from '@/api/meeting';
import { getDate, deepCopy, PrefixZero, getUuid } from '@/utils/tools';
import Timer from '@/utils/timer';
import Conference from './components/conference-interaction';
export default {
  // 不要忘记了 name 属性
  name: 'Meeting',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    showMeetingList: {
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      isCancelEdit: false,
      titleBarName: '',
      status: 'Waiting,Doing',
      meetingList: [], // 代开始和进行中会议列表
      endMeetingList: [], // 已结束会议列表
      showAddMeeting: false, // 是否显示新增会议表单或修改会议表单
      showMeetingDetail: false, // 是否显示会议中会议详情
      showMeetingEndDetail: false, // 是否显示会议结束详情
      showMeetingEndModal: false, // 是否显示结束会议后的操作对话框
      formType: 'add', // 会议表单类型
      formData: {
        // 会议表单初始化数据
        name: '', // 会议名称
        startTime: '', // 开始时间
        endTime: '', // 结束时间
        startNow: '', // 是否立即推送
        devices: [], // 设备列表
        keywords: [], // 提词列表
        votes: [], // 投票列表
        normalResources: [], // 会议资料列表
        agendaResources: [], // 会议议程列表
        style: {
          // 铭牌样式
          background: '', // 壁纸
          logoSize: 'Normal', // logo大小
          logoPosition: 'Center', // logo位置
          font: 'Default', // 字体大小
          fontColor: 'White', // 字体颜色
          dynamic: false, // 字体动效
          bkType: '', // 背景资源类型（1、'Image'; 2.'Video'）
          bkId: ''
        }
      },
      countdown: 5, // 结束会议后的操作弹窗控制设备返回主菜单倒计时
      stoppedMeetingId: null, // 已点击删除的会议id
      defaultNameInfo: null // 会议默认名称规则信息
    };
  },

  // 使用其它组件
  components: {
    Row,
    Col,
    TitleBar,
    TabPane,
    Tabs,
    MeetingHomeHead,
    MeetingCardAdd,
    MeetingCard,
    MeetingEndList,
    NoMeetingEndList,
    MeetingForm,
    MeetingEndDetail,
    MeetingEndModal,
    Conference
  },
  // 计算属性
  computed: {},
  // 监听
  watch: {
    showMeetingList(newVal) {
      this.toHome();
      this.getMeetingList(this.status);
      this.getMeetingList('Completed');
    },
    showAddMeeting(newVal) {
      newVal && (this.isCancelEdit = false);
    }
  },
  // 方法
  methods: {
    // 获取会议列表数据
    getMeetingList(status) {
      const vm = this;
      MeetingApi.getMeetingList({ status })
        .fetch()
        .then(({ success, code, msg, data }) => {
          if (success) {
            if (status === 'Completed') {
              vm.endMeetingList = deepCopy(data);
            } else {
              vm.meetingList = deepCopy(data);
            }
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: '获取会议列表失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          this.$Message.destroy();
          this.$Message.error({
            content: err.msg || '获取会议列表失败！',
            duration: 5,
            closable: true
          });
        });
    },

    // 显示新增会议表单
    showAddMeetingForm(flag) {
      // 判断localStorage里面是否存有formData
      // 有：取出来用于新创建的会议的默认数据
      // 没有，则创建新的会议数据
      const localFormData = JSON.parse(localStorage.getItem('formData'));
      if (localFormData && !localFormData.id) {
        this.formData = localFormData;
      } else {
        if (localFormData) {
          localStorage.removeItem('formData');
        }
        // 设置默认会议名
        // 默认生成会议名称：会议+时间+序号
        const date = new Date();
        const y = date
          .getFullYear()
          .toString()
          .substr(-2);
        const m = PrefixZero(date.getMonth() + 1, 2).toString();
        const d = PrefixZero(date.getDate(), 2).toString();
        const h = PrefixZero(date.getHours(), 2).toString();
        const min = PrefixZero(date.getMinutes(), 2).toString();

        var name = '会议' + y + m + d + h + min;

        var dateCopy = getDate(date.getTime() / 1000, 'year');
        const dateCopyArr = dateCopy.split(' ');
        dateCopy = dateCopyArr[0];

        this.formData = {
          requestId: getUuid(),
          name: name,
          startTime: '',
          date: dateCopy,
          endTime: '',
          startNow: '',
          devices: [],
          keywords: [],
          votes: [],
          normalResources: [],
          agendaResources: [],
          style: {
            background: '', // 壁纸
            logoSize: 'Normal', // logo大小
            logoPosition: 'Center', // logo位置
            font: 'Default', // 字体大小
            fontColor: 'White', // 字体颜色
            dynamic: false, // 字体动效
            bkType: '', // 壁纸资源类型（1、'Image'; 2.'Video'）
            bkId: '' // 壁纸resourceId
          }
        };
      }

      this.showAddMeeting = flag;
      this.showMeetingDetail = !flag;
      this.showMeetingEndDetail = !flag;
      this.titleBarName = this.$t('meeting_add');
      this.formType = 'add';
    },

    // 打开会议详情
    // Doing:显示设备状态与参会人列表详情
    // Completed：显示会议结束详情
    // Wating：显示新增会议表单
    showMeetingDetailForm(item, flag) {
      const vm = this;
      MeetingApi.getMeetingDetail(item.id)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            vm.formData = deepCopy(data);

            if (vm.formData.startTime) {
              const dateTime = getDate(data.startTime / 1000, 'year');
              const dateTimeArr = dateTime.split(' ');
              const time = dateTimeArr[1];
              vm.formData.date = dateTimeArr[0];
              vm.formData.startTime = time;
            }
            if (vm.formData.endTime) {
              const dateTime = getDate(data.endTime / 1000, 'year');
              const dateTimeArr = dateTime.split(' ');
              const time = dateTimeArr[1];
              vm.formData.endTime = time;
            } else {
              vm.formData.startTime = null;
            }

            if (item.status === 'Doing') {
              vm.showAddMeeting = false;
              vm.showMeetingEndDetail = false;
              vm.showMeetingDetail = flag;
              vm.formType = 'edit';
            } else if (item.status === 'Completed') {
              vm.showAddMeeting = false;
              vm.showMeetingDetail = false;
              vm.titleBarName = vm.$t('meeting_detail');
              vm.showMeetingEndDetail = flag;
            } else {
              vm.showMeetingDetail = false;
              vm.showMeetingEndDetail = false;
              vm.titleBarName = vm.$t('meeting_add');
              vm.showAddMeeting = flag;
              vm.formType = 'add_2';
              vm.defaultNameInfo = null;
            }
            vm.$nextTick(() => {
              vm.$refs.meeting_content.parentElement.scrollTop = 0;
            });
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '获取会议详情失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg || '获取会议详情失败！',
            duration: 5,
            closable: true
          });
        });
    },

    // 点击打开历史会议详情
    showEndMeetingDetail(item) {
      this.showMeetingDetailForm(item, true);
    },

    // 提交新增会议数据
    addMeeting(formData) {
      const vm = this;
      const formDataCopy = deepCopy(formData);

      // 把时间格式转换成时间戳格式提交到后台
      // 只有日期，没有开始时间和结束时间
      if (formData.date) {
        var date = new Date((formData.date + ' ' + '00:00').replace(/-/g, '/'));
        formDataCopy.startTime = date.getTime();
        formDataCopy.endTime = null;
      }
      if (formData.startTime && formData.endTime) {
        var startTime = new Date((formData.date + ' ' + formData.startTime).replace(/-/g, '/'));
        formDataCopy.startTime = startTime.getTime();

        var endTime = new Date((formData.date + ' ' + formData.endTime).replace(/-/g, '/'));
        formDataCopy.endTime = endTime.getTime();
      }

      // 按接口改变devices的内部结构
      formDataCopy.devices = [];
      formData.devices.map((item, index) => {
        const itemObj = { devId: item.devId, personId: item.person.id, comment: item.comment };
        formDataCopy.devices.push(itemObj);
      });

      // 新增会议请求就提交数据
      MeetingApi.addMeeting(formDataCopy)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            if (formData.startNow) {
              vm.$Message.destroy();
              data.status = 'Doing';
              // 打开会议详情，data里面有会议id
              vm.showMeetingDetailForm(data, true);
            } else {
              vm.$Message.destroy();
              vm.$Message.success({
                content: '会议保存成功，即将回到首页',
                duration: 5,
                closable: true
              });
              vm.showAddMeeting = false;
              vm.showMeetingDetail = false;
              vm.showMeetingEndDetail = false;
              vm.getMeetingList(this.status);
              vm.getMeetingList('Completed');
              vm.$nextTick(() => {
                vm.$refs.meeting_content.parentElement.scrollTop = 0;
              });
            }
            localStorage.removeItem('formData');
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: msg || '会议保存失败！请重试',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg || '会议保存失败！请重试',
            duration: 5,
            closable: true
          });
        });
    },

    // 会议列表 “立即推送” 快捷操作
    startMeeting({ id }) {
      // 1、先获取会议详情
      // 2、立即推送会议接口请求
      const vm = this;
      MeetingApi.startMeeting(id)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            vm.$Message.destroy();
            // 打开会议详情
            MeetingApi.getMeetingDetail(id)
              .fetch()
              .then(({ success, msg, data }) => {
                if (success) {
                  vm.formData = deepCopy(data);
                  if (vm.formData.startTime) {
                    const dateTime = getDate(data.startTime / 1000, 'year');
                    const dateTimeArr = dateTime.split(' ');
                    const time = dateTimeArr[1];
                    vm.formData.date = dateTimeArr[0];
                    vm.formData.startTime = time;
                  }
                  if (vm.formData.endTime) {
                    const dateTime = getDate(data.endTime / 1000, 'year');
                    const dateTimeArr = dateTime.split(' ');
                    const time = dateTimeArr[1];
                    vm.formData.endTime = time;
                  } else {
                    vm.formData.startTime = null;
                  }
                  vm.showAddMeeting = false;
                  vm.showMeetingEndDetail = false;
                  vm.showMeetingDetail = true;
                  vm.formType = 'edit';
                }
              });
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: msg || '会议获取详情失败！请重试',
              duration: 5,
              closable: true
            });
          }
        });
    },

    // 打开编辑会议
    edit(data) {
      const vm = this;
      MeetingApi.alterMeetingEditType(data.id, true)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            vm.formData = deepCopy(data);
            if (vm.formData.startTime) {
              const dateTime = getDate(data.startTime / 1000, 'year');
              const dateTimeArr = dateTime.split(' ');
              const time = dateTimeArr[1];
              vm.formData.date = dateTimeArr[0];
              vm.formData.startTime = time;
            }
            if (vm.formData.endTime) {
              const dateTime = getDate(data.endTime / 1000, 'year');
              const dateTimeArr = dateTime.split(' ');
              const time = dateTimeArr[1];
              vm.formData.endTime = time;
            } else {
              vm.formData.startTime = null;
            }
            vm.titleBarName = vm.$t('meeting_edit');
            vm.showAddMeeting = true;
            vm.showMeetingDetail = false;
            vm.showMeetingEndDetail = false;
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '更改会议编辑状态失败，请重试',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg || '更改会议编辑状态失败，请重试',
            duration: 5,
            closable: true
          });
        });
    },

    // 取消编辑会议
    onEditCancel() {
      const vm = this;
      if (vm.formType === 'add' || vm.formType === 'add_2') {
        vm.toBack();
        localStorage.removeItem('formData');
      } else if (vm.formType === 'edit') {
        if (!vm.formData.id) {
          return;
        }
        this.onFormDestroy(data => {
          vm.formData = deepCopy(data);
          vm.showAddMeeting = false;
          vm.showMeetingDetail = true;
          vm.showMeetingEndDetail = false;
        });
        this.isCancelEdit = true;
      }
    },

    onFormDestroy(callback) {
      !this.isCancelEdit &&
        this.formData.id &&
        MeetingApi.alterMeetingEditType(this.formData.id, false)
          .fetch()
          .then(({ success, msg, data }) => {
            if (success) {
              callback && callback(data);
            } else {
              this.$Message.destroy();
              this.$Message.error({
                content: '更改会议编辑状态失败，请重试',
                duration: 5,
                closable: true
              });
            }
          })
          .catch(err => {
            this.$Message.destroy();
            this.$Message.error({
              content: err.msg || '更改会议编辑状态失败，请重试',
              duration: 5,
              closable: true
            });
          });
    },

    // 结束会议
    endMeeting({ id }) {
      this.$Modal.confirm({
        title: '确定要结束会议吗？',
        content: '退出会议后，所有铭牌将回到首页。',
        'z-index': 1200,
        onOk: () => {
          this.stopMeeting(id);
        }
      });
    },

    // 调取结束会议接口
    stopMeeting(meetingId) {
      const vm = this;
      MeetingApi.stopMeeting(meetingId)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            // 显示结束会议成功modal框
            vm.showMeetingEndModal = true;
            vm.stoppedMeetingId = meetingId;
            vm.countdown = 5;
            let timer = new Timer({
              interval: 1000,
              limit: 5,
              auto: false,
              fn: () => {
                vm.countdown = vm.countdown - 1;
                if (vm.countdown === 0) {
                  timer.stop();
                }
              }
            });
            timer.start();
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '结束会议失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg || '结束会议失败！',
            duration: 5,
            closable: true
          });
        });
    },

    // 删除会议
    deleteMeeting(id) {
      const vm = this;
      vm.$Modal.confirm({
        title: '确定要删除会议吗？',
        content: '删除会议后，将回到首页。',
        onOk: () => {
          MeetingApi.deleteMeeting(id)
            .fetch()
            .then(({ success, msg, data }) => {
              if (success) {
                this.isCancelEdit = true;
                vm.showAddMeeting = false;
                vm.showMeetingDetail = false;
                vm.showMeetingEndDetail = false;
                vm.getMeetingList(this.status);
                vm.getMeetingList('Completed');
              } else {
                vm.$Message.destroy();
                vm.$Message.error({
                  content: '删除会议失败！',
                  duration: 5,
                  closable: true
                });
              }
            })
            .catch(err => {
              vm.$Message.destroy();
              vm.$Message.error({
                content: err.msg || '删除会议失败！',
                duration: 5,
                closable: true
              });
            });
        }
      });
    },

    // 删除历史会议
    deleteMeetingEnd(id) {
      this.deleteMeeting(id);
    },

    toHome() {
      const vm = this;
      vm.showAddMeeting = false;
      vm.showMeetingDetail = false;
      vm.showMeetingEndDetail = false;
      vm.$nextTick(() => {
        vm.$refs.meeting_content.parentElement.scrollTop = 0;
      });
    },

    // 返回首页
    toBack() {
      this.getMeetingList(this.status);
      this.getMeetingList('Completed');
      this.toHome();
    },

    // 控制设备请求api
    onCenterControl(name, successMsg, errorMsg) {
      const vm = this;
      const data = { command: name };
      if (!vm.stoppedMeetingId) {
        return;
      }
      MeetingApi.onCenterControl(vm.stoppedMeetingId, data)
        .fetch()
        .then((success, msg, data) => {
          vm.stoppedMeetingId = null;
          if (success) {
            if (name === 'Shutdown') {
              vm.$Message.success({
                content: successMsg,
                duration: 5,
                closable: true
              });
              let timer = new Timer({
                interval: 3000,
                limit: 1,
                auto: false,
                fn: () => {
                  this.onControlToHome();
                  timer.stop();
                }
              });
              timer.start();
            }
          } else {
            vm.$Message.error({
              content: errorMsg,
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.error({
            content: err.msg || errorMsg,
            duration: 5,
            closable: true
          });
        });
    },

    // 控制设备返回首页
    onControlToHome() {
      if (!this.showMeetingEndModal) {
        return;
      }
      this.showMeetingEndModal = false;
      this.toBack();
    },

    // 控制设备批量关机
    onControlDevShutdown() {
      var name = 'Shutdown';
      var successMsg = '所有铭牌已关机！';
      var errorMsg = '关机失败，请稍后重试！';
      this.onCenterControl(name, successMsg, errorMsg);
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
    this.getMeetingList(this.status);
    this.getMeetingList('Completed');
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.meeting-content {
  width: 100%;
  height: ~'calc(100% - 64px)';

  &-body {
    &-row {
      margin-left: 22px;
      height: 100%;
    }

    &-head {
      width: 100%;
      height: 240px;
    }

    &-card {
      width: 100%;
      height: 100%;
      padding: 0 10%;
      margin-top: -40px;
      &-item {
        margin-bottom: 6%;
        height: 100%;
      }
    }

    &-end-list {
      width: 100%;
      height: 100%;
      padding: 0 10%;
      margin-top: 18px;
      margin-bottom: 30px;
    }

    &-no-end-list {
      margin-top: 60px;
      position: absolute;
      left: 50%;
      margin-left: -60px;
    }
  }

  &-add {
    margin-top: 64px;
    padding: 12px 6% 30px 6%;
    background: #f6f7f8;
  }

  &-detail {
    margin-top: 64px;
    padding: 12px 6% 0 6%;
    height: 100%;
  }
}
</style>
