<template>
  <div v-if="value"
       :class="classes">
    <Modal :value="value"
           :class="prefixCls+'-body'"
           :mask-closable="false"
           :width="630"
           @on-visible-change="onChange">
      <p slot="header"
         class="header">
        <span>设置</span>
      </p>
      <div slot="close"
           @click="onClose"
           class="margin-right">
        <Icon type="ios-close"
              :size="35"
              color="#999999" />
      </div>

      <Tabs :value="tabsName"
            capture-focus
            @on-click="onClickTabs">
        <TabPane :label="$t('call_setting_web')"
                 name="web">
          <FastReplyTable ref="webTable"
                          v-model="formData.web.list"
                          :title="$t('call_fast_reply')"
                          name="web"
                          @on-change="onChangeList($event, 'web')" />
        </TabPane>
        <TabPane :label="$t('call_setting_device')"
                 name="dev">
          <FastReplyTable ref="devTable"
                          v-model="formData.device.list"
                          :title="$t('call_fast_directive')"
                          name="dev"
                          @on-change="onChangeList($event, 'dev')" />
        </TabPane>
      </Tabs>

      <div slot="footer"
           :class="prefixCls+'-body-footer'">
        <div v-if="tabsName === 'web'"
             :class="prefixCls+'-body-footer-left'">
          <div :class="prefixCls+'-body-footer-left-text'">{{$t('call_fast_reply_web_clear')}}</div>
          <ISwitch v-model="formData.web.flag"
                   size="small"
                   :class="prefixCls+'-body-footer-left-switch'" />
        </div>
        <div v-else
             :class="prefixCls+'-body-footer-left'">
          <div :class="prefixCls+'-body-footer-left-text'">{{$t('call_fast_reply_devive')}}</div>
          <i-select v-model="formData.device.flag"
                    style="width:65px"
                    :class="prefixCls+'-body-footer-left-select'"
                    size="small">
            <i-option v-for="(item, index) in deviceMsgList"
                      :value="item.value"
                      :key="index">{{ item.label }}</i-option>
          </i-select>
          <div :class="prefixCls+'-body-footer-left-text'">{{$t('call_fast_reply_devive_close')}}</div>
        </div>
        <Button class="button-width"
                @click="onClose">取消</Button>
        <Button class="button-width"
                type="primary"
                :disabled="isDisabled"
                @click="onOk">确定</Button>
      </div>

    </Modal>
  </div>
</template>

<script>
import { Modal, Icon, Button, Tabs, TabPane, Switch, Select, Option } from 'view-design';
import FastReplyTable from './fast-reply-table.vue';

import CallApi from '@/api/call';
import { deepCopy } from '@/utils/tools';

export default {
  // 不要忘记了 name 属性
  name: 'SettingModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    value: {
      // 是否显示设置对话框
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      prefixCls: 'setting-modal',
      tabsName: 'web',
      formData: {
        web: { flag: true, list: [] },
        device: { flag: 'CLOSE', list: [] }
      },
      deviceMsgList: [
        { value: 'CLOSE', label: '手动' },
        { value: 'COUNTDOWN-10', label: '10s' },
        { value: 'COUNTDOWN-60', label: '60s' }
      ],
      isDisabled: false
    };
  },

  // 使用其它组件
  components: {
    Modal,
    Icon,
    Button,
    Tabs,
    TabPane,
    ISwitch: Switch,
    'i-select': Select,
    'i-option': Option,
    FastReplyTable
  },
  // 计算属性
  computed: {
    classes() {
      return [this.prefixCls, {}];
    }
  },
  // 监听
  watch: {
    value(newValue) {
      if (newValue) {
        this.tabsName = 'web';
        this.getWebReplyList();
        this.getDevReplyList();
      }
    }
  },
  // 方法
  methods: {
    // 获取快捷回复列表
    getFastReplyList(wordFlag, callback) {
      const params = { wordFlag };
      CallApi.getFastReplyList(params)
        .fetch()
        .then(res => {
          if (res.success) {
            callback(res);
            return;
          }
          this.$Message.error({
            content: res.msg,
            duration: 5,
            closable: true
          });
        })
        .catch(err => {
          this.$Message.error({
            content: err.msg,
            duration: 5,
            closable: true
          });
        });
    },

    // 获取web端快捷回复用语
    getWebReplyList() {
      const wordFlag = 'web';
      this.getFastReplyList(wordFlag, ({ success, msg, data }) => {
        this.formData.web = deepCopy(data);
      });
    },

    // 获去设备端快捷指令用语
    getDevReplyList() {
      const wordFlag = 'device';
      this.getFastReplyList(wordFlag, ({ success, msg, data }) => {
        this.formData.device = deepCopy(data);
      });
    },

    // 关闭对话框
    onClose() {
      this.$emit('on-close');
    },

    onOk() {
      this.$emit('on-ok', this.formData);
    },

    // 显示状态发生变化时触发
    onChange(value) {
      if (!value) {
        this.onClose();
      }
    },

    // 列表数据变化时出发
    onChangeList($event, name) {
      if (name === 'web') {
        this.formData.web.list = deepCopy($event.list);
      } else {
        this.formData.device.list = deepCopy($event.list);
      }
    },

    onClickTabs(name) {
      this.tabsName = name;
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
    // this.getWebReplyList();
    // this.getDevReplyList();
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
@prefix: setting-modal;

.button-width {
  width: 92px;
  margin-right: 15px;
}

.@{prefix} {
  &-body {
    .ivu-modal-body {
      padding: 0 34px;
      padding-top: 16px;
      padding-bottom: 34px;
    }

    .ivu-modal-footer {
      border: none;
    }

    &-footer {
      display: inline-flex;
      height: 32px;

      &-left {
        display: inline-flex;
        height: 32px;
        line-height: 32px;
        position: absolute;
        left: 36px;
        bottom: 12px;
        padding: 5px 0;

        &-text {
          height: 22px;
          font-family: PingFangSC-Regular;
          font-size: 12px;
          color: #999999;
          line-height: 22px;
          font-weight: 400;
        }

        &-switch {
          margin-left: 8px;
          margin-top: 3px;
        }

        &-select {
          margin: 0 5px;
        }
      }
    }
  }
}
</style>
