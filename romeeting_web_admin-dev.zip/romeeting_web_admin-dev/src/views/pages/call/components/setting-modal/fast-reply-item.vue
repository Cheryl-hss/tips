<template>
  <div :class="classes">
    <div :class="[prefixCls+'-left']">
      <span v-if="editIndex === -1"
            :class="[prefixCls+'-move','handle']" />
    </div>
    <div :class="prefixCls+'-content'">
      <span v-if="editing">
        <Poptip v-model="showSelectIconList"
                placement="bottom-start"
                width="320"
                padding="0"
                transfer>
          <span v-if="row.iconId"
                :class="[prefixCls+'-content-logo', 'hover']">
            <img :src="icon"
                 draggable="false" />
          </span>
          <div slot="content"
               :class="'icon'">
            <div :class="'icon-body'">
              <SelectIcon :class="'icon-body-item'"
                          v-for="(item, index) in selectIconList"
                          :key="index"
                          :icon="getIconUrl(item)"
                          @on-click="selectIcon(item)" />
            </div>
          </div>
        </Poptip>
      </span>
      <span v-if="!editing && row.iconId"
            :class="[prefixCls+'-content-logo']">
        <img :src="icon"
             draggable="false" />
      </span>
      <Form v-if="editing"
            :ref="'nameForm'+ index"
            :model="row"
            style="height: 42px"
            @submit.native.prevent>
        <FormItem prop="commonWord"
                  :label-width="0"
                  :show-message="false"
                  :rules="{ required: true, message: '必填', trigger: 'change'}">
          <Input v-model="row.commonWord"
                 style="width: 300px"
                 :class="prefixCls+'-content-text'"
                 @on-keydown="onKeydown" />
        </FormItem>
      </Form>
      <span v-if="!editing"
            :class="prefixCls+'-content-text'"
            :title="row.commonWord">{{ row.commonWord }}</span>
    </div>
    <div :class="prefixCls+'-right'">
      <div :class="prefixCls+'-right-content'">
        <Button v-if="editing"
                :class="prefixCls+'-right-add'"
                type="primary"
                size="small"
                @click="onAdd">添加</Button>
        <span v-else
              :class="prefixCls+'-right-edit'"
              @click="onEdit"></span>
        <span v-if="editIndex === -1 || editing"
              :class="prefixCls+'-right-close'"
              @click="onClose"></span>
      </div>
    </div>
  </div>
</template>

<script>
import { Input, Button, Form, FormItem, Poptip } from 'view-design';
import SelectIcon from './select-icon.vue';

import IconCoffee from '@/assets/images/icon-1-coffee@2x.png';
import IconCall from '@/assets/images/icon-2-call@2x.png';
import IconPen from '@/assets/images/icon-3-pen@2x.png';
import IconWater from '@/assets/images/icon-4-water@2x.png';
import IconTissue from '@/assets/images/icon-5-tissue@2x.png';
import IconOther from '@/assets/images/icon-6-other@2x.png';
import IconSelect from '@/assets/images/icon-7-select@2x.png';

import IconCoffeeSelect from '@/assets/images/icon-1-coffee-select@2x.png';
import IconCallSelect from '@/assets/images/icon-2-call-select@2x.png';
import IconPenSelect from '@/assets/images/icon-3-pen-select@2x.png';
import IconWaterSelect from '@/assets/images/icon-4-water-select@2x.png';
import IconTissueSelect from '@/assets/images/icon-5-tissue-select@2x.png';
import IconOtherSelect from '@/assets/images/icon-6-other-select@2x.png';

import { deepCopy, getRealSendText } from '@/utils/tools';

export default {
  // 不要忘记了 name 属性
  name: 'FastReplyItem',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序

    editIndex: {
      // 当前表格在编辑的行index
      type: Number,
      default() {
        return -1;
      }
    },

    editing: {
      // 是否编辑状态
      type: Boolean,
      default() {
        return false;
      }
    },

    value: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  // 变量
  data() {
    return {
      prefixCls: 'fast-reply-item',
      row: deepCopy(this.value.item),
      index: deepCopy(this.value.index),
      showSelectIconList: false,
      selectIconList: [1, 2, 3, 4, 5, 6]
    };
  },

  // 使用其它组件
  components: { Input, Button, Form, FormItem, Poptip, SelectIcon },
  // 计算属性
  computed: {
    classes() {
      return [this.prefixCls, {}];
    },

    icon() {
      var iconSrc = '';
      switch (this.row.iconId) {
        case 1:
          iconSrc = IconCoffee;
          break;

        case 2:
          iconSrc = IconCall;
          break;

        case 3:
          iconSrc = IconPen;
          break;

        case 4:
          iconSrc = IconWater;
          break;

        case 5:
          iconSrc = IconTissue;
          break;

        case 6:
          iconSrc = IconOther;
          break;

        case 7:
          iconSrc = IconSelect;
          break;
      }
      return iconSrc;
    }
  },
  // 监听
  watch: {
    value(newValue) {
      this.row = deepCopy(newValue.item);
      this.index = deepCopy(newValue.index);
    }
  },
  // 方法
  methods: {
    // 获取icon url
    getIconUrl(item) {
      var iconUrl = '';
      switch (item) {
        case 1:
          if (this.row.iconId !== item) {
            iconUrl = IconCoffee;
          } else {
            iconUrl = IconCoffeeSelect;
          }
          break;
        case 2:
          if (this.row.iconId !== item) {
            iconUrl = IconCall;
          } else {
            iconUrl = IconCallSelect;
          }
          break;
        case 3:
          if (this.row.iconId !== item) {
            iconUrl = IconPen;
          } else {
            iconUrl = IconPenSelect;
          }
          break;
        case 4:
          if (this.row.iconId !== item) {
            iconUrl = IconWater;
          } else {
            iconUrl = IconWaterSelect;
          }
          break;
        case 5:
          if (this.row.iconId !== item) {
            iconUrl = IconTissue;
          } else {
            iconUrl = IconTissueSelect;
          }
          break;
        case 6:
          if (this.row.iconId !== item) {
            iconUrl = IconOther;
          } else {
            iconUrl = IconOtherSelect;
          }
          break;
      }

      return iconUrl;
    },

    // 选择图片
    selectIcon(item) {
      this.row.iconId = item;
      this.showSelectIconList = false;
    },

    // 编辑
    onEdit() {
      this.showSelectIconList = false;
      this.$emit('on-edit');
    },

    // 新增一行
    onAdd() {
      const $nameForm = this.$refs['nameForm' + this.index];
      $nameForm && $nameForm.validate();
      if (!this.row.commonWord) {
        return;
      }
      if (this.row.hasOwnProperty('iconId') && this.row.iconId === 7) {
        this.$Message.destroy();
        this.$Message.info({
          content: '请选择图标',
          duration: 5,
          closable: true
        });
        return;
      }
      // 去掉输入字符串前后的空格
      this.row.commonWord = getRealSendText(this.row.commonWord);
      this.row.commonWord && this.$emit('on-add', this.row);
    },

    // 删除
    onClose() {
      this.$emit('on-close');
    },

    // 输入框时触发
    onKeydown(event) {
      if (event.keyCode === 13 || event.keyCode === 229) {
        return false;
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
@prefix: fast-reply-item;
@item-left-width: 40px;
@item-right-width: 102px;
@icon-size: 18px;

.ivu-poptip-popper[x-placement='bottom-start'] {
  padding: 8px 0 7px 0;
}

.ivu-poptip-popper[x-placement^='bottom'] .ivu-poptip-arrow {
  top: 10px;
  border-width: 0;
}

.btn(@url) {
  display: inline-block;
  width: @icon-size;
  height: @icon-size;
  .setBgImage(@url, no-repeat, center, 100%);
  cursor: pointer;
  vertical-align: middle;
  &:hover {
    opacity: 0.75;
  }
}

.icon {
  width: 320px;
  height: 70px;

  &-body {
    display: inline-flex;
    .center();

    &-item {
      margin: 10px;
    }
  }
}

.@{prefix} {
  position: relative;
  width: 100%;
  height: 42px;
  padding-left: @item-left-width;
  padding-right: @item-right-width;

  &-left {
    position: absolute;
    left: 0;
    width: @item-left-width;
    height: 100%;
  }

  &-move {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    .btn('~@/assets/images/icon-move-point@2x.png');
  }

  &-content {
    height: 100%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    display: flex;
    align-items: center;

    &-logo {
      width: 30px;
      height: 30px;
      margin-right: 22px;
      display: inline-block;
      vertical-align: middle;

      > img {
        width: 100%;
        height: 100%;
      }
    }

    &-text {
      line-height: 42px;
    }
  }

  &-right {
    position: absolute;
    right: 0;
    top: 0;
    width: @item-right-width;
    height: 100%;
    padding: 0 12px;

    &-content {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
    }

    &-edit {
      margin: 0 12px;
      .btn('~@/assets/images/icon-edit@2x.png');
    }

    &-add {
      font-size: 12px;
      width: 42px;
      height: 22px;
    }

    &-close {
      margin-left: 12px;
      .btn('~@/assets/images/icon-close@2x.png');
    }
  }
}
</style>
