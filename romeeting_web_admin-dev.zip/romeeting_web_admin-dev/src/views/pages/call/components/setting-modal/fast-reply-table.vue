<template>
  <div :class="classes">
    <div :class="prefixCls+'-head'">
      <div :class="prefixCls+'-head-left'">{{ title }}</div>
      <div :class="prefixCls+'-head-right'"
           @click="onClickOpen">
        <div :class="prefixCls+'-head-right-icon'">
          <img src="@/assets/images/icon-add-blue@2x.png"
               draggable="false" />
        </div>
        <div :class="prefixCls+'-head-right-text'">{{ $t('call_add') }}</div>
      </div>
    </div>
    <DragList v-model="tableList"
              :ref="'dragList_' + name"
              :class="prefixCls+'-content'"
              :disabled="editIndex !== -1"
              handle=".handle"
              @input="onChangeList">
      <FastReplyItem slot="drag-item"
                     slot-scope="props"
                     :value="props.value"
                     :editing="editIndex === props.value.index"
                     :edit-index="editIndex"
                     @on-edit="onEdit(props.value.index)"
                     @on-add="onAdd($event, props.value.index)"
                     @on-close="onClose(props.value.index)" />
    </DragList>
  </div>
</template>

<script>
import DragList from '@/components/drag-list';
import FastReplyItem from './fast-reply-item.vue';

import { deepCopy } from '@/utils/tools';

export default {
  // 不要忘记了 name 属性
  name: 'FastReplyTable',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    value: {
      // 可拖拽列表数据
      type: Array,
      default() {
        return [];
      }
    },

    name: {
      type: String,
      default() {
        return 'web';
      }
    },

    title: {
      // 表格名称
      type: String,
      default() {
        return '';
      }
    }
  },
  // 变量
  data() {
    return {
      prefixCls: 'fast-reply-table',
      tableList: deepCopy(this.value),
      editIndex: -1 // 在编辑行
    };
  },

  // 使用其它组件
  components: { DragList, FastReplyItem },
  // 计算属性
  computed: {
    classes() {
      return [this.prefixCls, {}];
    }
  },
  // 监听
  watch: {
    value(newValue) {
      this.tableList = deepCopy(newValue);
    },

    tableList(newVal) {
      if (this.editIndex === this.tableList.length - 1) {
        this.$nextTick(() => {
          // 新增行滚动条划到最底部
          if (this.name === 'web') {
            if (this.$refs.dragList_web) {
              this.$refs.dragList_web.$el.scrollTop = this.$refs.dragList_web.$el.scrollHeight;
            }
          } else {
            if (this.$refs.dragList_dev) {
              this.$refs.dragList_dev.$el.scrollTop = this.$refs.dragList_dev.$el.scrollHeight;
            }
          }
        });
      }
    }
  },
  // 方法
  methods: {
    // 表格新增一行
    onClickOpen() {
      // 还有在编辑行
      if (this.editIndex !== -1) {
        this.$Message.destroy();
        this.$Message.info({
          content: '请完成当前项',
          duration: 5,
          closable: true
        });
        return;
      }
      // web快捷
      if (this.name === 'web' && this.tableList.length < 10) {
        const item = {
          commonWord: ''
        };
        this.tableList.push(item);
        this.editIndex = this.tableList.length - 1;
      } else if (this.name === 'dev' && this.tableList.length < 5) {
        const item = {
          iconId: 7,
          commonWord: ''
        };
        this.tableList.push(item);
        this.editIndex = this.tableList.length - 1;
      } else {
        this.$Message.destroy();
        this.$Message.info({
          content: this.name === 'web' ? '快捷回复已达到10条上限' : '快捷指令已达到5条上限',
          duration: 5,
          closable: true
        });
      }
    },

    onEdit(index) {
      if (this.editIndex !== -1) {
        if (this.name === 'web') {
          if (!this.tableList[this.editIndex].commonWord) {
            this.$Message.destroy();
            this.$Message.info({
              content: '请完成当前项',
              duration: 5,
              closable: true
            });
            return;
          }
        } else if (this.name === 'dev') {
          if (
            !this.tableList[this.editIndex].commonWord ||
            this.tableList[this.editIndex].iconId === 7
          ) {
            this.$Message.destroy();
            this.$Message.info({
              content: '请完成当前项',
              duration: 5,
              closable: true
            });
            return;
          }
        }
      }
      this.editIndex = index;
    },

    // 修改或新增一行
    onAdd(row, index) {
      this.tableList[index] = deepCopy(row);
      const data = {
        list: this.tableList,
        editIndex: this.editIndex
      };
      this.$emit('on-change', data);
      this.editIndex = -1;
    },

    // 删除一行
    onClose(index) {
      if (this.editIndex !== index && this.editIndex !== -1) {
        this.$Message.destroy();
        this.$Message.info({
          content: '请先完成当前在编辑项',
          duration: 5,
          closable: true
        });
        return;
      }
      this.tableList.splice(index, 1);
      this.editIndex = -1;
      const data = {
        list: this.tableList,
        editIndex: this.editIndex
      };
      this.$emit('on-change', data);
    },

    // 拖动后触发
    onChangeList($event) {
      const data = {
        list: $event,
        editIndex: this.editIndex
      };
      this.$emit('on-change', data);
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
@prefix: fast-reply-table;

.@{prefix} {
  width: 100%;

  &-head {
    width: 100%;
    height: 42px;
    border: solid #e8e8e8;
    border-width: 0 0 1px 0;
    margin-bottom: 0;
    display: inline-flex;
    align-items: center;
    justify-content: space-between;

    &-left {
      width: 56px;
      height: 14px;
      font-family: PingFangSC-Medium;
      font-size: 14px;
      color: #333333;
      line-height: 14px;
      font-weight: 550;
    }

    &-right {
      display: inline-flex;
      align-items: center;
      &-icon {
        width: 18px;
        height: 18px;
        > img {
          width: 100%;
          height: 100%;
        }
      }

      &-text {
        margin-left: 6px;
        width: 28px;
        height: 14px;
        font-family: PingFangSC-Regular;
        font-size: 14px;
        color: #0050ff;
        line-height: 14px;
        font-weight: 400;
      }
    }
  }

  &-content {
    height: 220px;
    width: 100%;
    ::-webkit-scrollbar {
      display: none; /* Chrome Safari */
    }
    scrollbar-width: none; /* Firefox */
    -ms-overflow-style: none; /* IE 10+ */
    overflow-x: hidden;
    overflow-y: auto;
  }
}

.drag-list-item {
  border: solid #e8e8e8;
  border-width: 0 0 1px 0;
  margin-bottom: 0;
}
</style>
