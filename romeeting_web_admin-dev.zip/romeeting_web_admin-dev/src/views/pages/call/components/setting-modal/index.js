import SettingModal from './setting-modal';

export default SettingModal;
