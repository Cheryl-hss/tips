<template>
  <div :class="classes">
    <div ref="DialogueBox"
         :class="prefixCls+'-scroll'"
         v-if='nowDialogue'
         :key="'dialogue_'+nowDialogue.id">
      <div v-for=" ( item, index ) in mettingMsg"
           :key="index">
        <MessageItem :placement="userInfo.userId === item.subId ? 'left' : 'right'"
                     :data="item" />
      </div>
    </div>

    <div v-if="nowDialogue.meetingStatus === 'Doing'"
         :class="prefixCls+'-toolbar'">
      <QuickReply :list="quickReplyList"
                  @on-select="onQuickReplySelect" />
    </div>
  </div>
</template>

<script>
import MessageItem from './chat-message-item';
import QuickReply from './quick-reply';

import CallApi from '@/api/call';
import { deepCopy } from '@/utils/tools';

/**
 * 聊天框消息展示盒子
 */
export default {
  // 不要忘记了 name 属性
  name: 'ChatMessageBox',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件
  components: { MessageItem, QuickReply },
  // 组件属性、变量
  props: {
    // 按字母顺序
  },
  // 变量
  data() {
    return {
      prefixCls: 'chat-message-box'
      // quickReplyList: [
      //   {
      //     commonWord: '收到，正在准备'
      //   },
      //   {
      //     commonWord: '请稍等'
      //   },
      //   {
      //     commonWord: '收到，正在准备请稍等'
      //   }
      // ]
    };
  },
  // 计算值
  computed: {
    classes() {
      return [this.prefixCls, {}];
    },

    mqtt() {
      return this.$store.state.mqtt;
    },

    mettingMsg() {
      const chats = this.$store.state.nowDialogue.chats;
      return chats || [];
    },

    userInfo() {
      return this.$store.state.user;
    },

    nowDialogue() {
      return this.$store.state.nowDialogue;
    },

    // 快捷用语列表
    quickReplyList() {
      return this.$store.state.quickReplyList;
    }
  },
  // 监测
  watch: {
    mettingMsg() {
      this.$nextTick(() => {
        // Code that will run only after the
        // entire view has been rendered
        this.$refs.DialogueBox.scrollTop = this.$refs.DialogueBox.scrollHeight;
      });
    }
  },
  // 方法
  methods: {
    onQuickReplySelect(content) {
      // 如果非正在会议中，默认不发送
      if (this.nowDialogue.meetingStatus !== 'Doing') {
        return;
      }
      // window.console.log('快捷回复：', content);
      const subId = this.nowDialogue.person.id + '';
      const message = this.mqtt.chat(subId, this.nowDialogue.meetingId, content);
      if (!this.nowDialogue.chats) {
        this.nowDialogue.chats = [];
      }
      this.nowDialogue.chats.push({
        subId: subId,
        status: 'Sending',
        msg: message
      });
    },

    // 获取快捷回复用语列表
    getFastReplyList(wordFlag, callback) {
      const params = { wordFlag };
      CallApi.getFastReplyList(params)
        .fetch()
        .then(res => {
          if (res.success) {
            callback(res);
            return;
          }
          this.$Message.error({
            content: res.msg,
            duration: 5,
            closable: true
          });
        })
        .catch(err => {
          this.$Message.error({
            content: err.msg,
            duration: 5,
            closable: true
          });
        });
    },

    // 获取web端快捷回复用语
    getWebReplyList() {
      const wordFlag = 'web';
      this.getFastReplyList(wordFlag, ({ success, msg, data }) => {
        this.$store.commit('setValue', {
          key: 'quickReplyList',
          value: deepCopy(data.list)
        });
      });
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
    this.getWebReplyList();
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    window.visualViewport = state => {
      // window.console.log(state);
    };
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
      this.$refs.DialogueBox.scrollTop = this.$refs.DialogueBox.scrollHeight;
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>

<style lang="less" scoped>
@prefix: chat-message-box;
@toolbar-height: 42px;

.@{prefix} {
  position: relative;
  height: 100%;
  width: 100%;
  &-scroll {
    height: ~'calc(100% - @{toolbar-height})';
    width: 100%;
    padding: 24px 24px 42px;
    overflow-y: auto;
  }

  &-toolbar {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 30px;
    width: 100%;
    height: @toolbar-height;
    padding: 0 18px;
  }
}
</style>
