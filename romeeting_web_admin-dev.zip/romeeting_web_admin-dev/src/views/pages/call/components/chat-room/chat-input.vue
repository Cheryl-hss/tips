<template>
  <div :class="classes">
    <textarea ref="editor"
              :class="[{disabled: this.disabled}]"
              :value="text"
              type="text"
              :disabled="disabled"
              placeholder="发送消息，按“Enter（回车键）”直接发送，按“Alt + Enter”进行换行"
              :maxlength="maxlength"
              @input="onInput"
              @change="onChange"
              @keydown.enter="onEnterKeydown" />
    <div v-if="showWordLimit"
         :class="[prefixCls+'-word-limit']">{{ limitText }}</div>
  </div>
</template>

<script>
import { deepCopy, getRealSendText } from '@/utils/tools';
/**
 * 聊天输入框
 */
export default {
  // 不要忘记了 name 属性
  name: 'ChatInput',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件
  components: {},
  // 组件属性、变量
  props: {
    value: {
      type: String,
      default: ''
    },

    // 是否禁用输入框
    disabled: {
      type: Boolean,
      default: false
    },

    // 最大文本长度
    maxlength: {
      type: Number,
      default: 60
    },

    // 是否显示文本长度限制标志
    showWordLimit: {
      type: Boolean,
      default: true
    }
  },
  // 变量
  data() {
    return {
      prefixCls: 'chat-input',
      editor: null,
      text: deepCopy(this.value)
    };
  },
  // 计算值
  computed: {
    classes() {
      return [this.prefixCls, {}];
    },

    limitText() {
      return this.text.length + ' / ' + this.maxlength;
    },

    mqtt() {
      return this.$store.state.mqtt;
    },

    meetingDatail() {
      return this.$store.state.meetingDatail;
    },

    userInfo() {
      return this.$store.state.user;
    },

    nowDialogue() {
      return this.$store.state.nowDialogue;
    }
  },
  // 监测
  watch: {},
  // 方法
  methods: {
    onInput(e) {
      this.text = e.target.value;
      this.$emit('input', e.target.value);
    },

    onChange(e) {
      this.$emit('change', e.target.value);
    },

    onEnterKeydown(e) {
      const textDom = this.$refs.editor;
      // alt/ctrl/shift + enter 只会换行不会发送
      if (!e.altKey && !e.shiftKey && !e.ctrlKey) {
        const text = getRealSendText(textDom.value);
        if (this.meetingDatail.status !== 'Doing') {
          return;
        }
        if (text) {
          const subId = this.nowDialogue.person.id + '';
          const message = this.mqtt.chat(subId, this.nowDialogue.meetingId, text);
          if (!this.nowDialogue.chats) {
            this.nowDialogue.chats = [];
          }
          this.nowDialogue.chats.push({
            subId: subId,
            status: 'Sending',
            msg: message
          });
        }
        // 确认发送事件，发送的文件会去掉头尾空格和回车
        text && this.$emit('on-send', text);

        textDom.value = '';
        this.text = '';
        textDom.blur();
        window.setTimeout(() => {
          this.setCursorPosition(textDom, 0);
        }, 60);
      } else {
        // shift 不用处理
        if (!e.shiftKey) {
          // 插入文本
          const point = this.getCursortPosition();
          const leftPart = textDom.value.substring(0, point);
          const rightPart = textDom.value.substring(point);
          textDom.value = leftPart + '\n' + rightPart;
        }
      }
    },

    getCursortPosition() {
      // 获取光标位置
      const textDom = this.$refs.editor;
      let cursorPos = 0;
      if (document.selection) {
        textDom.focus();
        const selectRange = document.selection.createRange();
        selectRange.moveStart('character', -this.$refs.editor.value.length);
        cursorPos = selectRange.text.length;
      } else if (textDom.selectionStart || parseInt(textDom.selectionStart, 0) === 0) {
        cursorPos = textDom.selectionStart;
      }
      return cursorPos;
    },

    // 设置光标的位置
    setCursorPosition(ctrl, pos) {
      if (ctrl.setSelectionRange) {
        ctrl.focus();
        ctrl.setSelectionRange(pos, pos);
      } else if (ctrl.createTextRange) {
        var range = ctrl.createTextRange();
        range.collapse(true);
        range.moveEnd('character', pos);
        range.moveStart('character', pos);
        range.select();
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>

<style lang="less" scoped>
@prefix: chat-input;
.@{prefix} {
  position: relative;
  width: 100%;
  height: 100%;
  padding: 1px 1px 2px;

  > input,
  textarea {
    border: none;
    resize: none;

    margin: 0;
    padding: 23px;
    width: 100%;
    height: 100%;
    font-size: 14px;
    color: #333;

    &:focus {
      // outline: #03a9f4 solid 0.5px;
      outline: none;
    }
  }

  &-word-limit {
    position: absolute;
    right: 2px;
    bottom: 2px;
    padding: 4px 6px;
    border-radius: 12px 0 0 0;
    font-size: 12px;
    color: #999;
    background-color: #fff;
  }

  .disabled {
    background-color: #f3f3f3;
    opacity: 1;
    cursor: not-allowed;
    color: #ccc;
  }
}
</style>
