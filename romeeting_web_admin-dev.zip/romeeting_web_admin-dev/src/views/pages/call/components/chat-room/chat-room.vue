<template>
  <div :class="classes"
       v-if="itemDatil">
    <div :class="[prefixCls+'-contact-wrap']">
      <item-group ref="ChatRoom"
                  v-if="nowDialogue"
                  :key="'contact_group_' + nowDialogue.meetingId"
                  :active-name="nowDialogue.id"
                  @on-select="onContactItemSelect">
        <ContactItem v-for="(item, index) in contactList"
                     :key="'contact_item_'+index"
                     :name="item.id"
                     :data="item" />
      </item-group>
    </div>

    <div :class="[prefixCls+'-chat-wrap']">
      <ChatWindow :key="'chat_window_' + nowDialogue.meetingId" />
    </div>
  </div>
</template>

<script>
import ItemGroup from '../item-group';
import ContactItem from '../contact-item';
import ChatWindow from './chat-window';
/**
 * 呼叫服务聊天室
 */
export default {
  // 不要忘记了 name 属性
  name: 'CallChatRoom',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件
  components: { ItemGroup, ContactItem, ChatWindow },
  // 组件属性、变量
  props: {
    // 按字母顺序
    itemDatil: {
      type: Object,
      require: true,
      validator: val => {
        return val;
      },
      default(res) {
        return {};
      }
    }
  },
  // 变量
  data() {
    return {
      prefixCls: 'call-chat-room',
      // contactList: [
      //   {
      //     id: 1,
      //     name: 'bruce'
      //   },
      //   {
      //     id: 2,
      //     name: '说到发'
      //   },
      //   {
      //     id: 3,
      //     name: '大哥',
      //     avatar:
      //       'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=754931528,2574230403&fm=26&gp=0.jpg'
      //   },
      //   {
      //     id: 4,
      //     name: '姐姐',
      //     avatar:
      //       'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=754931528,2574230403&fm=26&gp=0.jpg'
      //   }
      // ], // 参会人列表
      talkList: [] // 对话列表
    };
  },
  // 计算值
  computed: {
    classes() {
      return [this.prefixCls, {}];
    },
    contactList() {
      return this.itemDatil && this.itemDatil.devices;
    },
    nowDialogue() {
      return this.$store.state.nowDialogue;
    }
  },
  // 监测
  watch: {},
  // 方法
  methods: {
    onContactItemSelect(index) {
      const _this = this;
      this.contactList.filter((item, i) => {
        if (item.id === index) {
          if (item.id !== _this.nowDialogue.id) {
            item._checked = true;
            _this.$store.commit('setValue', { key: 'nowDialogue', value: item });
          }
          //
        } else {
          delete item._checked;
        }
      });

      this.$forceUpdate();
    },
    onRefreshMeetingChats() {
      const _this = this;
      this.$root.eventHub.$on('REFRESH_MEETING_CHAT_NOTIFY', ({ chatId, chat }) => {
        const index = this.contactList.findIndex(device => chatId === device.person.id + '');
        if (index !== -1) {
          // 将当前消息的Device置顶
          const device = this.contactList[index];
          this.contactList.splice(index, 1);
          if (!device.chats) {
            device.chats = [];
          }
          device.chats.push(chat);
          this.contactList.unshift(device);
        }
        _this.$nextTick(() => {
          _this.$refs.ChatRoom.updateActive(_this.nowDialogue.id);
        });
      });
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
    // 监听新REFRESH_MEETING_CHAT_NOTIFY消息
    this.onRefreshMeetingChats();
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>

<style lang="less" scoped>
@prefix: call-chat-room;
.@{prefix} {
  width: 100%;
  height: 100%;
  background-color: #fff;

  &-contact-wrap {
    float: left;
    width: 250px;
    height: 100%;
    border-right: solid 1px #e8e8e8;
    overflow-y: auto;
  }

  &-chat-wrap {
    float: left;
    width: ~'calc(100% - 250px)';
    height: 100%;
  }
}
</style>
