export { default } from './chat-room.vue';
