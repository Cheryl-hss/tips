<template>
  <div :class="classes">
    <div :class="prefixCls+'-wrap'">
      <div :class="prefixCls+'-sider'">
        <ChatAvatar :src="avatarURL" />
      </div>
      <div :class="prefixCls+'-main'">
        <div :class="prefixCls+'-header'">
          <span>{{msg.data.chatId === nowHuiHua.person.id+'' ? nowHuiHua.person.name : '我'}}</span>
          <span>{{msgTime}}</span>
        </div>

        <div :class="prefixCls+'-body'">
          <div :class="prefixCls+'-content'">
            <div :class="prefixCls+'-content-arrow'"></div>
            <div :class="prefixCls+'-content-inner'">
              {{ msg && msg.data.content }}</div>
          </div>
          <div :class="prefixCls+'-body-tail'">
            <Spin v-if="status === 'Sending'">
              <Icon type="ios-loading"
                    size=18
                    class="spin-icon-load" />
            </Spin>
            <Icon v-else-if="status === 'Failure'"
                  type="ios-alert"
                  color="#F56C6C"
                  size=18 />
            <span v-else
                  :class="status !== 'Read' ? 'unread' : ''">{{ status === 'Read' ? '已读' : '未读' }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import ChatAvatar from '../chat-avatar';
import { Spin, Icon } from 'view-design';
import { dateFormat } from '@/utils/tools';
import Timer from '@/utils/timer';

/**
 * 聊天室消息项
 */
export default {
  // 不要忘记了 name 属性
  name: 'ChatMessageItem',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件
  components: { ChatAvatar, Spin, Icon },
  // 组件属性、变量
  props: {
    // 放置的方向，left 左边，right 右边，默认左边
    placement: {
      type: String,
      default: 'left'
    },
    data: {
      type: Object
    }
  },
  // 变量
  data() {
    return {
      prefixCls: 'chat-message-item',
      isFailure: false
    };
  },
  // 计算值
  computed: {
    userInfo() {
      return this.$store.state.user;
    },

    mqtt() {
      return this.$store.state.mqtt;
    },

    msg() {
      if (this.data.msg) {
        return JSON.parse(this.data.msg);
      }
    },

    msgTime() {
      const nowTimestamp = Math.floor(Date.parse(new Date()));
      // 判断是否都在同一天，不在则显示日期时间
      // 不在同一天，判断是否在同一年，同一年就只显示月日+时间
      // 以上都不，则显示年月+时间
      const toDay = dateFormat(new Date(nowTimestamp), 'yyyy-MM-dd');
      const timeDay = dateFormat(new Date(this.msg.timestamp), 'yyyy-MM-dd');
      const toYear = dateFormat(new Date(nowTimestamp), 'yyyy');
      const timeYear = dateFormat(new Date(this.msg.timestamp), 'yyyy');
      if (toDay === timeDay) {
        return '今天 ' + dateFormat(new Date(this.msg.timestamp), 'HH:mm');
      } else if (toYear === timeYear) {
        return dateFormat(new Date(this.msg.timestamp), 'MM-dd HH:mm');
      }
      return dateFormat(new Date(this.msg.timestamp), 'yyyy-MM-dd HH:mm');
    },

    status() {
      const vm = this;
      if (vm.data.status === 'Sending') {
        let timer = new Timer({
          interval: 10001,
          limit: 1,
          auto: false,
          fn: () => {
            vm.isFailure = vm.mqtt.isFailure(vm.data);
            timer.destroy();
          }
        });
      }
      if (vm.mqtt && vm.isFailure) {
        return 'Failure';
      }
      return vm.data.status;
    },

    nowHuiHua() {
      return this.$store.state.nowDialogue;
    },

    meetingList() {
      return this.$store.state.meetingList;
    },

    unreadMeetingChats() {
      return this.$store.state.unreadMeetingChats;
    },

    classes() {
      return [
        this.prefixCls,
        {
          [this.prefixCls + '-to-right']: this.placement === 'right'
        }
      ];
    },

    avatarURL() {
      return this.placement === 'right'
        ? require('@/assets/images/avatar_helper.png')
        : this.nowHuiHua.meetingStatus === 'Doing' && this.nowHuiHua.online === 1
          ? require('@/assets/images/avatar-default@2x.png')
          : require('@/assets/images/avatar-offline@2x.png');
    }
  },
  // 监测
  watch: {},
  // 方法
  methods: {
    read() {
      const msg = this.msg;
      this.mqtt.respRead(msg);
      this.data.status = 'Read';
      this.meetingList.forEach(meeting => {
        if (msg.data.mId === meeting.id) {
          meeting.stat && meeting.stat.unreadNum > 0 && meeting.stat.unreadNum--;
        }
      });
      // 更新全局未读消息
      if (this.unreadMeetingChats) {
        this.unreadMeetingChats.totalUnreadNum > 0 && this.unreadMeetingChats.totalUnreadNum--;
        for (const i in this.unreadMeetingChats.meetings) {
          const meeting = this.unreadMeetingChats.meetings[i];
          if (meeting.id === msg.data.mId) {
            for (const j in meeting.devices) {
              const device = meeting.devices[j];
              if (device.person.id + '' === msg.data.chatId) {
                device.chats = device.chats.filter(chat => {
                  const unreadMsg = JSON.parse(chat.msg);
                  return unreadMsg.msgId !== msg.msgId;
                });
                break;
              }
            }
            break;
          }
        }
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
    this.isFailure = this.mqtt.isFailure(this.data);
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
      const msg = this.msg;
      if (
        msg &&
        this.userInfo.userId !== msg.data.chatId &&
        this.status !== 'Read' &&
        this.status !== 'Failure'
      ) {
        // 消息变为已读
        const vm = this;
        if (this.mqtt) {
          this.read();
        } else {
          // mqtt 发生了重连等待1s后再更新
          window.setTimeout(() => {
            vm.read();
          }, 1000);
        }
      }
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>

<style lang="less" scoped>
.spin-icon-load {
  animation: ani-demo-spin 1s linear infinite;
}

.unread {
  color: #ffaa58;
}
@prefix: chat-message-item;
.@{prefix} {
  .clearFix();
  width: 100%;
  margin-bottom: 28px;
  font-size: 14px;

  &-wrap {
    .clearFix();
    float: left;
    max-width: 100%;

    @media screen and (min-width: 1048px) {
      max-width: 500px;
    }
  }

  &-sider {
    float: left;
    width: 40px;
  }
  &-main {
    float: left;
    width: ~'calc(100% - 40px)';
  }

  &-header {
    padding: 0 8px 2px 8px;
    font-size: 12px;
    color: #999;
    user-select: none;
    > span:first-child {
      margin-right: 14px;
    }
  }
  &-body {
    .clearFix();
    &-tail {
      float: left;
      width: 72px;
      padding: 12px;
      font-size: 12px;
      color: #aaa;
      user-select: none;
    }
  }
  &-content {
    position: relative;
    float: left;
    width: ~'calc(100% - 72px)';
    padding-left: 8px;
    &-arrow {
      position: absolute;
      top: 8px;
      left: 3px;
      width: 0;
      height: 0;
      border-color: transparent;
      border-style: solid;
      border-width: 5px 5px 5px 0;
      border-right-color: #ecedee;
    }
    &-inner {
      padding: 10px 18px;
      border-radius: 4px;
      background-color: #e6eeff;
      color: #333;
    }
  }
}

.@{prefix}-to-right {
  .@{prefix} {
    &-wrap {
      float: right;
    }
    &-sider {
      float: right;
      text-align: right;
    }
    &-main {
      float: right;
      text-align: right;
    }
    &-body {
      &-tail {
        float: right;
      }
    }
    &-content {
      float: right;
      padding-left: 0;
      padding-right: 8px;
      &-arrow {
        left: unset;
        right: 3px;
        border-width: 5px 0 5px 5px;
        border-left-color: #0050ff;
      }
      &-inner {
        background-color: #0050ff;
        color: #fff;
        text-align: left;
      }
    }
  }
}
</style>
