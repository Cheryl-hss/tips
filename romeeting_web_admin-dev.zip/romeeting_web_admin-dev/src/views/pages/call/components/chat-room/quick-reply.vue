<template>
  <div :class="classes">
    <div v-if="list && list.length"
         ref="bubbleList"
         :class="[prefixCls+'-list']">
      <div v-for="(item, index) in list"
           :key="index"
           :class="[prefixCls+'-item', 'ellipsis']"
           @click.stop="onItemClick(item.commonWord)">{{ item.commonWord }}</div>
    </div>

    <Dropdown v-if="showMore"
              :class="prefixCls+'-right'"
              trigger="click"
              placement="top-end"
              @on-click="onSelectItem">
      <div :class="prefixCls+'-right-body'">
        <div :class="prefixCls+'-right-body-icon'"></div>
      </div>
      <DropdownMenu slot="list"
                    :class="'reply'">
        <DropdownItem v-for='(item , index) in list'
                      :key="index"
                      :name="item.commonWord">
          <div :class="['reply-item', 'ellipsis']"
               :title="item.commonWord">
            {{ item.commonWord }}
          </div>
        </DropdownItem>
      </DropdownMenu>
    </Dropdown>
  </div>
</template>

<script>
import { Dropdown, DropdownMenu, DropdownItem } from 'view-design';

/**
 * 聊天室-快捷回复
 */
export default {
  // 不要忘记了 name 属性
  name: 'QuickReply',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件
  components: {
    Dropdown,
    DropdownMenu,
    DropdownItem
  },
  // 组件属性、变量
  props: {
    list: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  // 变量
  data() {
    return {
      prefixCls: 'quick-reply',
      showMore: false
    };
  },
  // 计算值
  computed: {
    classes() {
      return [this.prefixCls, {}];
    }
  },
  // 监测
  watch: {
    list(newVal) {
      this.$nextTick(() => {
        if (this.$refs.bubbleList && this.$refs.bubbleList.offsetHeight > 48) {
          this.showMore = true;
        } else {
          this.showMore = false;
        }
      });
    }
  },
  // 方法
  methods: {
    onItemClick(content) {
      this.$emit('on-select', content);
    },

    onSelectItem(content) {
      this.$emit('on-select', content);
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>

<style lang="less" scoped>
@prefix: quick-reply;
@url-more: '~@/assets/images/icon-reply-more@2x.png';
@url-more-blue: '~@/assets/images/icon-reply-more-hover@2x.png';

.@{prefix} {
  padding-top: 6px;

  &-list {
    max-width: ~'calc(100% - 54px)';
  }

  &-item {
    display: inline-block;
    height: 30px;
    padding: 7px 14px;
    margin: 0 6px 12px 6px;
    border: 1px solid #d8d8d8;
    border-radius: 18px;
    background-color: #fff;
    font-size: 14px;
    color: #999;
    line-height: 1;
    cursor: pointer;
    user-select: none;
    transition: all 0.2s ease-in-out;

    &:hover {
      color: #0050ff;
    }

    &:active {
      opacity: 1;
    }
  }

  &-right {
    position: absolute;
    right: 42px;
    top: 0;

    &-body {
      width: 30px;
      height: 30px;
      padding: 6px;
      margin: 7px -6px;
      border-radius: 18px;
      border: 1px solid #d8d8d8;

      &-icon {
        width: 18px;
        height: 18px;
        background-image: url('~@/assets/images/icon-reply-more@2x.png');
        background-repeat: 'no-repeat';
        background-position: 'center';
        background-size: 100%;
      }

      &:hover &-icon {
        width: 18px;
        height: 18px;
        background-image: url('~@/assets/images/icon-reply-more-hover@2x.png');
        background-repeat: 'no-repeat';
        background-position: 'center';
        background-size: 100%;
      }
    }
  }
}

.reply {
  position: absolute;
  bottom: 10px;
  right: 14px;
  width: 240px;
  background: #ffffff;
  box-shadow: 0px 4px 10px 0px rgba(204, 204, 204, 0.5);
  border-radius: 6px;

  li {
    width: 240px;
    height: auto;
    white-space: inherit;
  }

  .ivu-dropdown-item {
    padding: 0 12px;
  }
}

.reply-item {
  box-sizing: border-box;
  border-width: 0 0 1px 0;
  border-style: solid;
  border-color: rgba(242, 242, 242, 1);
  padding: 7px 0;
}
</style>
