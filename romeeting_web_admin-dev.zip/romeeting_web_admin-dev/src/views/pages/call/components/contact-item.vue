<template>
  <div :class="classes"
       @click.stop="onSelect">
    <div :class="[prefixCls+'-avatar-wrap']">
      <Badge v-if="countNewMsg"
             dot>
        <ChatAvatar :src="avatarIcon" />
      </Badge>
      <ChatAvatar v-else
                  :src="avatarIcon" />
    </div>
    <div :class="[prefixCls+'-content']">
      <div :class="[prefixCls+'-content-header']">
        <div :class="[prefixCls+'-title', 'ellipsis']">{{ data.person.name }}</div>
        <div :class="[prefixCls+'-label']">{{ latestMsgTime }}</div>
      </div>
      <div :class="[prefixCls+'-content-body', 'ellipsis']">
        <span v-if="countNewMsg > 1">{{'[' + countNewMsg + '条]' }}</span>
        {{  data.online === 0 || data.online === 1 ?  latestMsgContent : '未知' }}
      </div>
    </div>
  </div>
</template>

<script>
import ChatAvatar from './chat-avatar';
import { Badge } from 'view-design';
import { dateFormat } from '@/utils/tools';

/**
 * 呼叫服务-联系人项
 */
export default {
  // 不要忘记了 name 属性
  name: 'CallContactItem',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件
  components: { ChatAvatar, Badge },
  // 组件属性、变量
  props: {
    // 用于item-group的唯一标志
    name: {
      required: true,
      type: [String, Number],
      default: ''
    },
    data: {
      required: true,
      type: Object,
      default() {
        return {};
      }
    }
  },
  // 变量
  data() {
    return {
      prefixCls: 'call-contact-item',
      selected: false
    };
  },
  // 计算值
  computed: {
    avatarIcon() {
      return this.data.meetingStatus === 'Doing' && this.data.online === 1
        ? require('@/assets/images/avatar-default@2x.png')
        : require('@/assets/images/avatar-offline@2x.png');
    },

    userInfo() {
      return this.$store.state.user;
    },

    classes() {
      return [this.prefixCls, { selected: this.selected }];
    },

    latestMsg() {
      return this.data.chats && this.data.chats.length > 0
        ? JSON.parse(this.data.chats[this.data.chats.length - 1].msg)
        : null;
    },

    latestMsgContent() {
      const latestMsg = this.latestMsg;
      if (this.latestMsg && this.latestMsg.data.chatId === this.userInfo.userId) {
        return '我：' + latestMsg.data.content;
      }
      return latestMsg ? latestMsg.data.content : '暂无消息';
    },

    latestMsgTime() {
      const latestMsg = this.latestMsg;

      if (!latestMsg) {
        return '';
      }
      const nowTimestamp = Math.floor(Date.parse(new Date()));
      // 判断是否都在同一天，不在则显示日期时间
      // 不在同一天，判断是否在同一年，同一年就只显示月日+时间
      // 以上都不，则显示年月+时间
      const toDay = dateFormat(new Date(nowTimestamp), 'yyyy-MM-dd');
      const timeDay = dateFormat(new Date(latestMsg.timestamp), 'yyyy-MM-dd');
      const toYear = dateFormat(new Date(nowTimestamp), 'yyyy');
      const timeYear = dateFormat(new Date(latestMsg.timestamp), 'yyyy');
      if (toDay === timeDay) {
        return dateFormat(new Date(latestMsg.timestamp), 'HH:mm');
      } else if (toYear === timeYear) {
        return dateFormat(new Date(latestMsg.timestamp), 'MM-dd');
      }
      return timeYear + '年';
    },

    countNewMsg() {
      let count = 0;
      if (this.data.chats && this.data.chats.length > 0) {
        this.data.chats.forEach(chat => {
          if (
            this.userInfo.userId === chat.subId &&
            (chat.status === 'Unread' ||
              (chat.status === 'Sending' && this.mqtt && !this.mqtt.isFailure(chat)))
          ) {
            count++;
          }
        });
      }
      return count;
    },

    mqtt() {
      return this.$store.state.mqtt;
    }
  },
  // 监测
  watch: {},
  // 方法
  methods: {
    onSelect() {
      this.$emit('on-select', this.name);
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // window.console.log(this.data);
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>

<style lang="less" scoped>
@prefix: call-contact-item;

@item-active-bg: #ecedee;
@item-hover-bg: lighten(@item-active-bg, 5%);
.@{prefix} {
  height: 69px;
  padding: 16px 16px 16px 12px;
  border-bottom: solid 1px #e8e8e8;
  color: #999;
  cursor: pointer;
  user-select: none;
  transition: all 0.2s ease-in-out;

  &:hover {
    background-color: @item-hover-bg;
  }

  &:active {
    background-color: @item-active-bg;
  }

  &-avatar-wrap {
    float: left;
    height: 100%;
    width: 48px;
  }

  &-content {
    float: left;
    height: 100%;
    width: ~'calc(100% - 48px)';
    &-header {
      .clearFix();
      height: 14px;
      font-size: 14px;
      // line-height: 1;
      margin-bottom: 10px;
    }

    &-body {
      font-size: 12px;
      line-height: 1;
    }
  }

  &-title {
    float: left;
    width: ~'calc(100% - 48px)';
    color: #333;
  }

  &-label {
    float: right;
    width: 48px;
    font-size: 12px;
    text-align: right;
    line-height: 1.2;
  }

  &.selected {
    background-color: @item-active-bg;
  }
}
</style>
