<template>
  <div :class="classes"
       @click.stop="onSelect">
    <div :class="[prefixCls+'-title', 'ellipsis']"
         :title="data.name">
      {{data.name||'-'}}
      <Badge v-if="data.status === 'Doing' && unreadNum"
             style="position: absolute; right: 26px; margin-top: 2px;"
             dot />
    </div>
    <div :class="[prefixCls+'-content']">
      <div :class="[prefixCls+'-status', 'ellipsis']">
        <span :class="[prefixCls+'-status-point']"></span>{{statusText}}
      </div>
      <div :class="[prefixCls+'-count', 'ellipsis']">
        参会人：{{data.devices?data.devices.length:0}}
      </div>
    </div>
  </div>
</template>

<script>
import { Badge } from 'view-design';
/**
 * 呼叫服务-会议项
 */
export default {
  // 不要忘记了 name 属性
  name: 'CallMeetingItem',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件
  components: { Badge },
  // 组件属性、变量
  props: {
    // 用于item-group的唯一标志
    name: {
      type: [String, Number],
      default: ''
    },
    data: {
      required: true,
      type: Object,
      default() {
        return {};
      }
    }
  },
  // 变量
  data() {
    return {
      prefixCls: 'call-meeting-item',
      selected: false // 是否被选中
    };
  },
  // 计算值
  computed: {
    // Completed("会议正常结束"), Expired("会议未开始过期"), Doing("会议正在进行"), Waiting("待开始")
    classes() {
      return [
        this.prefixCls,
        // {
        //   online: this.data.status === 'online',
        //   offline: this.data.status === 'offline',
        //   selected: this.selected
        // }
        {
          online: this.data.status === 'Doing',
          offline:
            this.data.status === 'Expired' ||
            this.data.status === 'Waiting' ||
            this.data.status === 'Completed',
          selected: this.selected
        }
      ];
    },
    statusText() {
      // return this.data.status === 'online'
      //   ? '会议中'
      //   : this.data.status === 'offline'
      //     ? '离线'
      //     : '已结束';
      return this.data.status === 'Doing'
        ? '会议中'
        : this.data.status === 'Waiting'
          ? '待开始'
          : this.data.status === 'Completed'
            ? '已结束'
            : '未知';
    },
    unreadNum() {
      return (this.data && this.data.stat && this.data.stat.unreadNum) || 0;
    }
  },
  // 监测
  watch: {},
  // 方法
  methods: {
    onSelect() {
      this.$emit('on-select', this.data.id);
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>

<style lang="less" scoped>
@prefix: call-meeting-item;

@item-active-color: #0050ff;
@item-active-bg: #dce8ff;
@item-hover-bg: lighten(@item-active-bg, 5%);
@online-color: #199e31;
@offline-color: #999999;
.@{prefix} {
  height: 80px;
  padding: 20px 24px;
  border-bottom: solid 1px #fefefe;
  cursor: pointer;
  user-select: none;
  transition: all 0.2s ease-in-out;

  &:hover {
    background-color: @item-hover-bg;
  }
  &:active {
    background-color: @item-active-bg;
  }

  &-title {
    height: 22px;
    margin-bottom: 12px;
    font-size: 16px;
    line-height: 1;
    color: #666;
  }

  &-content {
    font-size: 12px;
    line-height: 1;
    color: #999;
  }

  &-status {
    float: left;
    max-width: ~'calc(50% - 12px)';
    &-point {
      display: inline-block;
      height: 6px;
      width: 6px;
      margin-right: 4px;
      margin-bottom: 1px;
      background-color: #999;
      border-radius: 6px;
    }
  }
  &-count {
    float: right;
    max-width: ~'calc(50% - 12px)';
  }

  &.selected {
    background-color: @item-active-bg;
    &.online,
    &.offline {
      .@{prefix} {
        &-title {
          color: @item-active-color;
        }
      }
    }
  }

  &.online .@{prefix} {
    &-title {
      color: #333;
    }

    &-status {
      color: @online-color;
      &-point {
        background-color: @online-color;
      }
    }
  }

  &.offline .@{prefix} {
    &-title {
      color: #333;
    }

    &-status {
      color: @offline-color;
      &-point {
        background-color: @offline-color;
      }
    }
  }
}
</style>
