<template>
  <div class="call-content">
    <TitleBar :name="titleBarName"
              :show-setting="true"
              @on-click-setting="onClickSettting" />
    <div class="call-content-body">

      <div class="call-content-sider">
        <div v-if="meetings">
          <item-group ref="MeetingGroup"
                      :active-name="activeMeeting"
                      @on-select='onMeetingItemSelect'>
            <MeetingItem v-for="(item, index) in meetings"
                         :key="'meeting_item_'+item.id+'_'+index"
                         :name="item.id"
                         :data="item" />
          </item-group>
        </div>

        <!-- <div class="call-content-footer">
          <div class="call-content-footer-btn">清除</div>
        </div> -->
      </div>

      <div class="call-content-main">
        <ChatRoom :itemDatil="meetingDatail" />
      </div>

    </div>

    <SettingModal :value="showSettingModal"
                  @on-close="onClose"
                  @on-ok="onOk" />
  </div>
</template>

<script>
import TitleBar from '../components/title-bar';
import ItemGroup from './components/item-group';
import MeetingItem from './components/meeting-item';
import ChatRoom from './components/chat-room';
import SettingModal from './components/setting-modal';

import CallApi from '@/api/call';
import { deepCopy } from '@/utils/tools';
/**
 * 呼叫服务页面
 */
export default {
  // 不要忘记了 name 属性
  name: 'Call',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 使用其它组件
  components: { TitleBar, ItemGroup, MeetingItem, ChatRoom, SettingModal },
  // 组件属性、变量
  props: {
    // 按字母顺序
  },
  // 变量
  data() {
    return {
      titleBarName: '呼叫服务',
      client: null,
      activeMeeting: null,
      activeDialogue: null,
      account: {
        password: 'MM6n1srBVOg0sxeq20MIZIxaNyWtbZ'
      },
      status: 'Waiting,Doing',
      meetings: null,
      showSettingModal: false // 是否显示设置快捷回复用语对话框
    };
  },

  // 计算属性
  computed: {
    meetingDatail() {
      return this.$store.state.meetingDatail;
    },
    meetingList() {
      return this.$store.state.meetingList;
    }
  },
  // 监听
  watch: {
    $route(newRoute) {
      if (
        newRoute.query &&
        (this.$route.query.meetingId !== this.activeMeeting + '' ||
          this.$route.query.dId !== this.activeDialogue) + ''
      ) {
        // 重新加载数据
        this.clear();
        this.activeMeeting = this.$route.query && Number(this.$route.query.meetingId);
        this.activeDialogue = this.$route.query && Number(this.$route.query.dId);
        this.fetchData();
        this.$nextTick(() => {
          this.$refs.MeetingGroup.updateActive(this.activeMeeting);
        });
      }
    }
  },
  // 方法
  methods: {
    // 清除聊天会议数据
    clear() {
      this.$store.commit('setValue', { key: 'meetingDatail', value: null });
      this.$store.commit('setValue', {
        key: 'nowDialogue',
        value: null
      });
    },

    // 请求接口获取会议列表数据
    fetchData() {
      let vm = this;
      CallApi.getMeetings()
        .fetch()
        .then(({ success, code, msg, data }) => {
          if (success) {
            if (!data || data.length === 0) {
              return;
            }
            // 将正在进行中的会议放到数据前面
            let waitList = data.filter(
              item => item.status === 'Waiting' || item.status === 'Completed'
            );
            let doingList = data.filter(item => item.status === 'Doing');
            let allList = [];
            if (doingList.length > 0) {
              allList = doingList.concat(waitList);
            } else {
              allList = waitList;
            }
            vm.meetings = allList;
            vm.$store.commit('setValue', { key: 'meetingList', value: allList });

            vm.activeMeeting = vm.activeMeeting || allList[0].id;
            vm.$forceUpdate();
            this.getMeetingChats(this.activeMeeting);
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: '获取会议列表失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(() => {
          // window.console.log('error ==> ', err);
          this.$Message.destroy();
          this.$Message.error({
            content: '获取会议列表失败！',
            duration: 5,
            closable: true
          });
        });
    },

    // 请求接口获取某个会议的聊天数据
    getMeetingChats(id) {
      const vm = this;
      CallApi.getChats(id)
        .fetch()
        .then(res => {
          if (res.success) {
            // window.console.log(res);
            let _data = res.data;
            vm.$store.commit('setValue', { key: 'meetingDatail', value: _data });

            // 设置当前参会人的chats
            const nowDialogue = vm.activeDialogue
              ? _data.devices.find(device => device.id === vm.activeDialogue)
              : _data.devices[0];
            vm.$store.commit('setValue', {
              key: 'nowDialogue',
              value: nowDialogue
            });
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '获取会议信息列表失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(() => {
          this.$Message.destroy();
          // ignored
          // window.console.log('error ==> ', err);
          this.$Message.error({
            content: '获取会议信息列表失败！',
            duration: 5,
            closable: true
          });
        });
    },

    // 选中某个会议触发
    onMeetingItemSelect(index) {
      // 初始化时会自动触发
      const vm = this;
      this.meetingList.filter((item, i) => {
        if (item.id === index) {
          if (this.meetingDatail && this.meetingDatail.id === item.id) {
            return;
          }
          item._checked = true;
          this.clear();
          vm.activeDialogue = null;
          this.getMeetingChats(item.id);
        } else {
          delete item._checked;
        }
      });

      this.$forceUpdate();
    },

    // 点击触发设置快捷回复用语
    onClickSettting() {
      // 显示设置快捷用语对话框
      this.showSettingModal = true;
    },

    // 设置快捷回复对话框取消按钮事件触发
    onClose() {
      //
      this.showSettingModal = false;
    },

    // 设置快捷回复对话框确定按钮事件触发
    onOk(data) {
      const vm = this;
      CallApi.submitFastReply(data)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            vm.showSettingModal = false;
            vm.getWebReplyList();
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '快捷用语设置失败，请重新提交',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.error || '快捷用语设置失败，请重新提交',
            duration: 5,
            closable: true
          });
        });
    },

    // 获取快捷回复用语列表
    getFastReplyList(wordFlag, callback) {
      const params = { wordFlag };
      CallApi.getFastReplyList(params)
        .fetch()
        .then(res => {
          if (res.success) {
            callback(res);
            return;
          }
          this.$Message.error({
            content: res.msg,
            duration: 5,
            closable: true
          });
        })
        .catch(err => {
          this.$Message.error({
            content: err.msg,
            duration: 5,
            closable: true
          });
        });
    },

    // 获取web端快捷回复用语
    getWebReplyList() {
      const wordFlag = 'web';
      this.getFastReplyList(wordFlag, ({ success, msg, data }) => {
        this.$store.commit('setValue', {
          key: 'quickReplyList',
          value: deepCopy(data.list)
        });
      });
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
    this.clear();
    this.activeMeeting = this.$route.query && Number(this.$route.query.meetingId);
    this.activeDialogue = this.$route.query && Number(this.$route.query.dId);
    this.fetchData();
    // this.getMeetingChats(this.activeMeeting);
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
.call-content {
  width: 100%;
  height: 100%;

  &-body {
    height: ~'calc(100% - 64px)';
    padding: 0;
    background: #f6f7f8;
  }
  &-sider {
    position: relative;
    float: left;
    height: 100%;
    width: 250px;
    border-right: solid 1px #e8e8e8;
    padding-bottom: 52px;
    background-color: #fff;
    overflow-y: auto;
  }
  &-main {
    position: relative;
    float: left;
    height: 100%;
    width: ~'calc(100% - 250px)';
    background-color: #fff;
  }
  &-footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 42px;
    z-index: 1;
    text-align: center;

    &-btn {
      display: inline-block;
      height: 24px;
      padding: 5px 16px;
      border: 1px solid #d8d8d8;
      border-radius: 12px;
      font-size: 12px;
      line-height: 1;
      cursor: pointer;
      user-select: none;
      transition: all 0.2s ease-in-out;

      &:hover {
        opacity: 0.75;
      }
      &:active {
        opacity: 1;
      }
    }
  }
}
</style>
