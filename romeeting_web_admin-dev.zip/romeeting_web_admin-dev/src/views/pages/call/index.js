import Call from './call.vue';

export default Call;
