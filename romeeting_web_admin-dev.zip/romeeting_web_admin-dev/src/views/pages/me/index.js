import Me from './me.vue';

export default Me;
