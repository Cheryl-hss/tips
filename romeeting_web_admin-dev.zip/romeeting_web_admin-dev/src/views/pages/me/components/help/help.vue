<template>
  <div v-if="value">
    <div class="me-help">
      <!-- 关于我们 -->
      <div>
        <div class="me-help-subhead">{{ $t('me_help_about_us') }}</div>
        <div class="me-help-bottom">
          <div class="margin-bottom">{{ $t('me_help_about_us_desc') }}</div>
          <div class="margin-bottom"
               v-if="isSuper">{{ versionName }}</div>
          <div class="margin-bottom"
               v-if="isSuper">
            <div>{{ $t('me_help_about_us_update') }}</div>

            <!-- i18n 嵌入<Upload>组件后display：inline-flex会分块，每块可能会多行显示 -->
            <!-- <i18n path="me_help_about_us_update_by_self"
                tag="div">
            <a :href="url"
               place="link"
               target="_blank">{{ $t('me_help_about_us_update_by_self_link') }}</a>
            <Upload :action="uploadURL"
                    :accept="accept"
                    :format="format"
                    :before-upload="beforeUpload"
                    ref="uploadPackage"
                    place="upload">
              <a href="#">{{ $t('me_help_about_us_update_by_self_upload') }}</a>
            </Upload>
          </i18n> -->
            <!-- <i18n class="inline"
                path="me_help_about_us_update_by_hand"
                tag="div">
            <Upload :action="uploadURL"
                    :accept="accept"
                    :format="format"
                    :before-upload="beforeUpload"
                    ref="uploadPackage"
                    place="upload">
              <a href="#">{{ $t('me_help_about_us_update_by_self_upload') }}</a>
            </Upload>
          </i18n> -->
            <div>
              <span>{{ $t('me_help_about_us_update_by_self_left') }}</span>
              <span>
                <a href="#"
                   @click="checkUpgradePackage">{{
                $t('me_help_about_us_update_by_self_link')
              }}</a>
              </span>
              <span>{{ $t('me_help_about_us_update_by_self_center') }}</span>
              <span class="inline-flex">
                <Upload :action="uploadURL"
                        :accept="accept"
                        :format="format"
                        :before-upload="beforeUpload"
                        ref="uploadPackage"
                        place="upload">
                  <a id="upload"
                     href="#">{{ $t('me_help_about_us_update_by_self_upload') }}</a>
                </Upload>
              </span>
              <span>{{ $t('me_help_about_us_update_by_self_right') }}</span>
            </div>

            <div>
              <span>{{ $t('me_help_about_us_update_by_hand_left') }}</span>
              <span class="inline-flex">
                <Upload :action="uploadURL"
                        :accept="accept"
                        :format="format"
                        :before-upload="beforeUpload"
                        ref="uploadPackage"
                        place="upload">
                  <a href="#">{{ $t('me_help_about_us_update_by_self_upload') }}</a>
                </Upload>
              </span>
              <span>{{ $t('me_help_about_us_update_by_hand_right') }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 帮助文档 -->

      <div class="me-help-subhead">{{ $t('me_help_document') }}</div>
      <div class="me-help-bottom">
        <Button type="primary"
                ghost
                @click="downloadDocument">{{
          $t('me_help_document')
        }}</Button>
      </div>

      <!-- 报告问题 -->
      <div class="me-help-subhead">{{ $t('me_help_issues') }}</div>
      <div class="me-help-bottom">
        <div>{{ $t('me_help_issues_p1') }}</div>
        <i18n path="me_help_issues_p2"
              tag="div">
          <a href="#"
             place="log"
             @click="downloadLogs">{{ $t('me_help_issues_p2_log') }}</a>
        </i18n>
      </div>
    </div>

    <!-- 升级包上传进度弹出框 -->
    <UpgradeModal :value="showUpgrageModal"
                  :file-data="fileData"
                  :progress-percent="progressPercent"
                  :showOkBtn="showOkBtn"
                  :btn-disabled="btnDisabled"
                  @on-upload-again="onUploadAgain"
                  @on-close="onClose"
                  @on-ok="onOk">
    </UpgradeModal>
    <!-- 升级包上传成功后升级日志显示弹出框 -->
    <UpgradeTextModal :value="showUpgradeTextModal"
                      :text="upgradeText"
                      @on-close="onCloseTextModal" />
  </div>
</template>

<script>
import { Button, Upload } from 'view-design';
import UpgradeModal from './components/upgrade-modal';
import UpgradeTextModal from './components/upgrade-text-modal';

import { getOssResourse, uploadToOSS, getUpgradeVersion, upgrade, getLogsKey } from '@/api/upload';
import { deepCopy } from '@/utils/tools';
import { downloadfile, getFileType } from '@/utils/download';
import axios from 'axios';

export default {
  // 不要忘记了 name 属性
  name: 'Help',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    value: {
      // 是否显示帮助模块
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      uploadURL: '',
      accept: '.zip',
      format: ['.zip'], // 支持的文件类型，识别文件后缀名
      showUpgrageModal: false, // 是否显示上传升级包进度弹出框
      showUpgradeTextModal: false, // 是否显示上传升级包成功后的升级日志信息弹出框
      fileData: {}, // 上传文件
      progressPercent: 0, // 升级包文件上传进度
      btnDisabled: true, // 默认disabled确认按钮
      showOkBtn: true, // 默认显示确认按钮
      upgradeText: '', // 更新日志
      versionCode: '', // 软件版本号
      versionName: '', // 软件版本名
      packageName: '', // 软件包名
      isSuper: false // 是否是超级管理员
    };
  },

  // 使用其它组件
  components: { Button, Upload, UpgradeModal, UpgradeTextModal },
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    // 检查版本
    checkVersion() {
      const vm = this;
      getUpgradeVersion()
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            // versionCode定义：10000 为 1.0.0
            // 和后端定义第二位和第四位都为0，默认转换为小数点
            vm.versionCode = data.versionCode;
            vm.packageName = data.packageName;
            const versionArr = JSON.stringify(vm.versionCode).split('');
            vm.versionName = 'V' + versionArr[0] + '.' + versionArr[2] + '.' + versionArr[4];
          }
        });
    },

    // 由于下载升级包的URl是重定向后的链接，所以需要打开重定向链接后再下载
    downloadApk(downloadUrl) {
      let downloadFile = {};
      if (typeof downloadFile.iframe === 'undefined') {
        const iframe = document.createElement('a');
        iframe.setAttribute('target', '_blank');
        iframe.setAttribute('download', '');
        downloadFile.iframe = iframe;
        document.body.appendChild(downloadFile.iframe);
      }
      downloadFile.iframe.href = downloadUrl;
      downloadFile.iframe.click();
      downloadFile.iframe.style.display = 'none';
    },
    isHiddenUpdate() {
      //
      var auth = JSON.parse(localStorage.getItem('userInfo')).auth;
      if (auth.indexOf('help-upgrade') > -1) {
        this.isSuper = true;
      }
    },

    // 检查是否有新版本
    checkUpgradePackage() {
      const vm = this;
      const params = {
        packageName: this.packageName,
        versionCode: this.versionCode
      };
      // axios请求：域名写死（服务器不能访问外网）
      axios
        .get('/market/client/version/check', {
          baseURL: 'https://rowrite.royole.com',
          params
        })
        .then(({ status, statusText, data }) => {
          if (status === 200) {
            const hasNew = data.hasNew;
            if (hasNew) {
              // 获取返回的升级包下载链接并默认下载
              const apkUrl = data.app.apkUrl;
              vm.downloadApk(apkUrl);

              return;
            }
            vm.$Message.destroy();
            vm.$Message.info({
              content: '现有版本为当前最新版本，暂无可更新版本',
              duration: 5,
              closable: true
            });
          } else {
            vm.$Message.destroy();
            vm.$Message.info({
              content: statusText || '请求失败，请稍后再尝试',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(() => {
          vm.$Message.destroy();
          vm.$Message.info({
            content: '请求失败，请稍后再尝试',
            duration: 5,
            closable: true
          });
        });
    },

    onUploadAgain() {
      const btn = document.getElementById('upload');
      btn.click();
      this.showUpgrageModal = false;
    },

    // 上传升级包
    beforeUpload(file) {
      const vm = this;
      vm.progressPercent = 0;

      // 1、先判断上传文件是否为“royole.zip”，是则下一步，否则弹出提示不上传
      if (file.name.search('royole-') === -1) {
        vm.$Message.warning({
          content: '请选择正确的文件！',
          duration: 5,
          closable: true
        });
        return;
      }

      vm.fileData = {
        name: file.name,
        fileType: 'Zip',
        size: file.size
      };
      // 打开上传升级包过程弹出框
      vm.showUpgrageModal = true;
      vm.showOkBtn = true;
      vm.btnDisabled = true;

      // 2、上传文件
      uploadToOSS(file, e => {
        // 拿到onProgress回调e，可以拿到已上传大小和总大小
        vm.progressPercent = Math.floor((e.loaded / e.total) * 1000) / 10;
        // window.console.log(e);
      }).then(res => {
        const fileNameArr1 = file.name.split('.');
        const fileNameArr2 = fileNameArr1[0].split('-');
        const versionCode = Number(fileNameArr2[fileNameArr2.length - 1]);
        // 如果文件已存在，不会出现上传，则直接
        const data = {
          fileKey: res.key,
          md5: res.md5,
          versionCode
        };
        upgrade(data)
          .fetch()
          .then(({ success, msg, data }) => {
            if (success) {
              // 发布升级包成功，获取升级日志信息
              vm.btnDisabled = false;
              vm.progressPercent = 100;
              vm.upgradeText = data;
            } else {
              vm.$Message.destroy();
              vm.$Message.error({
                content: msg || '上传失败，请重新上传',
                duration: 5,
                closable: true
              });
              vm.showOkBtn = false;
            }
          })
          .catch(() => {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '上传失败，请重新上传',
              duration: 5,
              closable: true
            });
            vm.showOkBtn = false;
          });
      });
    },

    // 关闭上传升级包弹出框
    onClose() {
      this.showUpgrageModal = false;
    },

    // 点击确认
    onOk() {
      this.showUpgrageModal = false;
      // 打开升级日志弹出框
      this.showUpgradeTextModal = true;
    },

    // 关闭升级日志弹出框
    onCloseTextModal() {
      this.showUpgradeTextModal = false;
    },

    // 下载帮助文档
    downloadDocument() {
      const vm = this;
      const userId = vm.$store.state.user.userId;
      const params = {
        key: 'meeting/help'
      };
      let downloadUrl = null;
      getOssResourse(userId, params)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            downloadUrl = deepCopy(data);
            let downloadFile = {};
            if (typeof downloadFile.iframe === 'undefined') {
              const iframe = document.createElement('a');
              iframe.setAttribute('target', '_blank');
              iframe.setAttribute('download', 'help.pdf');
              downloadFile.iframe = iframe;
              document.body.appendChild(downloadFile.iframe);
            }
            downloadFile.iframe.href = downloadUrl;
            downloadFile.iframe.click();
            downloadFile.iframe.style.display = 'none';
          }
        });
    },

    // 下载错误日志
    downloadLogs() {
      const vm = this;
      // 1、获取下载日志资源的key
      const identifier = 'server';
      getLogsKey(identifier)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            // 下载错误日志的key数组
            var keyArr = deepCopy(data);
            if (keyArr.length) {
              const userId = vm.$store.state.user.userId;
              for (var i = 0; i < keyArr.length; i++) {
                const params = { key: keyArr[i] };
                const key = keyArr[i].split('/');
                const fileName = key[key.length - 1];
                // 2、下载日志
                vm.downloadLogsUrl(userId, params, fileName);
              }
            }
          }
        });
    },

    // 下载日志请求
    downloadLogsUrl(userId, params, fileName) {
      getOssResourse(userId, params)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            var downloadUrl = data;
            const type = getFileType(fileName);
            downloadfile(downloadUrl, fileName, type);
            // this.downloadFile(downloadUrl);
          }
        });
    },

    // 下载方法
    downloadFile(url) {
      var iframe = document.createElement('iframe');
      iframe.style.display = 'none'; // 防止影响页面
      iframe.style.height = 0; // 防止影响页面
      iframe.src = url;
      document.body.appendChild(iframe); // 这一行必须，iframe挂在到dom树上才会发请求
      window.setTimeout(() => {
        iframe.remove();
      }, 5000);
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
      this.checkVersion();
      this.isHiddenUpdate();
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.inline-flex {
  display: inline-flex;
  height: 21px;
  line-height: 21px;
}

.me-help {
  padding-right: 5%;
  &-subhead {
    font-size: 18px;
    color: #333333;
    height: 18px;
    line-height: 18px;
    margin-bottom: 20px;
    font-weight: bold;
  }

  &-bottom {
    margin-bottom: 50px;
  }
}
</style>
