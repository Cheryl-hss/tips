import UpgradeModal from './upgrade-modal.vue';

export default UpgradeModal;
