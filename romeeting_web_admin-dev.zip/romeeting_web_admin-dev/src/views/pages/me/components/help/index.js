import Help from './help.vue';

export default Help;
