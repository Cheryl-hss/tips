import UpgradeTextModal from './upgrade-text-modal.vue';

export default UpgradeTextModal;
