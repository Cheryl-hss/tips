<template>
  <div v-if="value">
    <Modal class="account-create"
           :value="value"
           :mask-closable="false"
           :width="500"
           footer-hide
           @on-visible-change="onChange">
      <p slot="header"
         class="header">
        <span>{{ '创建子账号' }}</span>
      </p>
      <div slot="close"
           @click="onClose"
           class="margin-right">
        <Icon type="ios-close"
              :size="35"
              color="#999999" />
      </div>
      <Form ref="formValidate"
            :model="formValidate"
            :rules="ruleValidate"
            :label-width="80"
            @submit.native.prevent>
        <div class="account-create-body">
          <!-- 用户名模块开始 -->
          <FormItem label="账号"
                    prop="username">
            <Input v-model="formValidate.username"
                   placeholder="字母/数字"
                   v-on:keyup="check_name($event)"></Input>
          </FormItem>
          <!-- 用户名模块结束 -->
          <!-- 密码模块开始 -->
          <FormItem label="
                   密码"
                    prop="password">
            <Input type="text"
                   v-model="formValidate.password"
                   placeholder="不少于6位字母、数字"></Input>
          </FormItem>
          <!-- 密码模块结束 -->
          <!-- 角色模块开始 -->
          <!-- <FormItem label="角色"
                    prop="role">
            <Select v-model="formValidate.role"
                    placeholder="子管理员"
                    @change="selectRole($event)">
              <Option v-for="item in items"
                      :value="item.id"
                      :key="item.id">{{ item.name }}</Option>
            </Select>
          </FormItem> -->
          <!-- 角色模块结束 -->
          <!-- 权限模块开始 -->
          <!-- <FormItem label="权限"
                    prop="auth">
            <CheckboxGroup v-model="formValidate.auth">
              <Checkbox label="meeting"> 会议</Checkbox>
              <Checkbox style="margin-left: 16px;"
                        label="call"> 呼叫管理</Checkbox>
            </CheckboxGroup>
          </FormItem> -->
          <!-- 底部确定和取消按钮 -->
          <FormItem>
            <Button @click="onClose">取消</Button>
            <Button type="primary"
                    @click="handleSubmit('formValidate')"
                    style="margin-left: 20px">确定</Button>
          </FormItem>
        </div>
      </Form>

    </Modal>
  </div>
</template>

<script>
import {
  Modal,
  Icon,
  Input,
  Button,
  Select,
  Option,
  Checkbox,
  CheckboxGroup,
  Form,
  FormItem
} from 'view-design';

export default {
  // 不要忘记了 name 属性
  name: 'AccountCreateModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 是否显示弹窗
    value: {
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      items: [{ id: 'admin', name: '子管理员' }],
      formValidate: {
        username: '',
        password: ''
        // role: '',
        // auth: []
      },
      ruleValidate: {
        username: [
          {
            pattern: /^[A-Za-z0-9]+$/,
            required: true,
            message: '请使用字母或数字注册',
            trigger: 'blur'
          }
        ],
        password: [
          {
            pattern: /^[a-z0-9]{6,}$/,
            required: true,
            message: '不少于6位字母、数字',
            trigger: 'blur'
          }
        ]
        // role: [{ required: true, message: '请选择一个账户角色', trigger: 'change' }],
        // auth: [
        //   { required: true, type: 'array', min: 1, message: '最少选择一个', trigger: 'change' },
        //   { type: 'array', max: 2, message: '', trigger: 'change' }
        // ]
      }
    };
  },

  // 使用其它组件
  components: {
    Modal,
    Icon,
    Input,
    Button,
    Select,
    Option,
    Checkbox,
    CheckboxGroup,
    Form,
    FormItem
  },
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    // 关闭对话框
    onClose() {
      this.$emit('on-close');
    },

    // 显示状态发生变化时触发
    onChange(value) {
      if (!value) {
        this.onClose();
      }
    },
    handleSubmit(formValidate) {
      this.$refs[formValidate].validate(valid => {
        if (valid) {
          var username = this.formValidate.username;
          var password = this.formValidate.password;
          // var role = this.formValidate.role;
          // var auth = this.formValidate.auth;
          this.$emit('on-ok', { username, password });

          // this.$emit('on-ok', { username, password, role, auth: auth.join(',') });
        }
      });
    }
  },

  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.header {
  text-align: center;
  font-family: PingFangSC-Regular;
  height: 18px;
}
.account-create {
  .ivu-modal-header {
    padding: 21px 22px;
  }

  .ivu-modal-body {
    padding: 24px 30px;
  }

  &-body {
    &-text {
      height: 14px;
      font-family: PingFangSC-Regular;
      font-size: 14px;
      color: #999999;
      line-height: 14px;
      font-weight: 400;
      margin-top: 16px;
    }
    &-user {
      margin-top: 20px;
      position: relative;
      height: 30px;
      &-left {
        display: inline-block;
        position: absolute;
        line-height: 30px;
        left: 0;
        text-align: right;
        width: 50px;
      }
      &-right {
        display: inline-block;
        position: absolute;
        left: 80px;
        width: 50%;
      }
    }
    &-password {
      // width: 500px;
      margin-top: 20px;
      position: relative;
      height: 30px;
      &-left {
        display: inline-block;
        position: absolute;
        line-height: 30px;
        left: 0;
        width: 50px;
        text-align: right;
      }
      &-right {
        display: inline-block;
        position: absolute;
        width: 50%;
        left: 80px;
      }
    }
    &-role {
      margin-top: 20px;
      height: 30px;
      position: relative;
      &-left {
        display: inline-block;
        position: absolute;
        line-height: 30px;
        left: 0;
        width: 50px;
        text-align: right;
      }

      &-right {
        display: inline-block;
        position: absolute;
        left: 80px;
        width: 50%;
      }
    }

    &-limit {
      margin-top: 20px;
      height: 30px;
      position: relative;
      &-left {
        display: inline-block;
        position: absolute;
        line-height: 30px;
        left: 0;
        width: 50px;
        text-align: right;
      }
      &-right {
        display: inline-block;
        position: absolute;
        line-height: 30px;
        left: 80px;
      }
    }
  }
  &-footer {
    .clearFix();
    width: 100%;
    margin-top: 84px;
    &-button {
      float: right;
    }
  }
}
</style>
