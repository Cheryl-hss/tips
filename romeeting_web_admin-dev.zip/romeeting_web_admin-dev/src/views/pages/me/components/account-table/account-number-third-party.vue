<template>
  <div v-if="value">
    <Modal
      class="account-number"
      :value="value"
      :mask-closable="false"
      :width="500"
      footer-hide
      @on-visible-change="onChange"
    >
      <p slot="header"
         class="header">
        <span>{{ '第三方配置' }}</span>
      </p>
      <div slot="close"
           @click="onClose"
           class="margin-right">
        <Icon type="ios-close"
              :size="35"
              color="#999999" />
      </div>
      <Form
        ref="inputData"
        :model="inputData"
        :label-width="90"
        :rules="ruleValidate"
        @submit.native.prevent>
        <div class="account-number-body">
          <FormItem label="渠道" class="redDot" prop="channel">
            <Select
              style="width:88%;position: relative;left: 20px;"
              @on-select="onSelect"
              v-model="inputData.channel"
              placeholder="请选择渠道">
              <Option v-for="item in items" :value="item.name" :key="item.type">{{
                item.name
              }}</Option>
            </Select>
          </FormItem>
          <FormItem label="渠道ID" class="redDot" v-if="isShowDing">
            <FormItem  prop="channelID">
            <Input class="input" v-model="inputData.channelID" placeholder=""></Input>
            </FormItem>
          </FormItem>
          <FormItem label="渠道ID" class="redDot" v-if="isShowWechat">
            <FormItem prop="channelIDone">
            <Input class="input" v-model="inputData.channelIDone" placeholder=""></Input>
            </FormItem>
          </FormItem>
          <FormItem label="AppKey" v-if="isShowAppKey" prop="appkey">
            <Input class="input" v-if="isShowDing" v-model="inputData.appkey" placeholder=""></Input>
            <Input class="input" v-if="isShowWechat" v-model="inputData.appkey1" placeholder=""></Input>
            <Input class="input" v-if="isShowLark" v-model="inputData.appkey2" placeholder=""></Input>
          </FormItem>
          <FormItem label="AppSecret" v-if="isShowAppKey" >
            <Input class="input" v-if="isShowDing" v-model="inputData.appsecret" placeholder=""></Input>
            <Input class="input" v-if="isShowWechat" v-model="inputData.appsecret1" placeholder=""></Input>
            <Input class="input" v-if="isShowLark" v-model="inputData.appsecret2" placeholder=""></Input>
          </FormItem>
          <FormItem label="AdminSecret" v-if="isShowWechat">
            <Input class="input" v-model="inputData.adminsecret" placeholder="企业微信需要的管理密钥"></Input>
          </FormItem>
          <FormItem style="text-align: right;height: 50px;">
            <Button @click="onClose">取消</Button>
            <Button
              type="primary"
              @click="onSubmit('inputData')"
              style="margin-right: 25px;margin-left: 20px;">确定</Button>
          </FormItem>
        </div>
      </Form>
    </Modal>
  </div>
</template>

<script>
import { Modal, Icon, Input, Button, Select, Option, Form, FormItem } from 'view-design';

import BindingApi from '@/api/binding';
export default {
  // 不要忘记了 name 属性
  name: 'AccountNumberThirdParty',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 是否显示弹窗
    value: {
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      items: [],
      inputData: {
        channel: '', // 钉钉/微信/飞书
        channelID: null, // 钉钉渠道
        channelIDone: null, // 微信渠道
        appkey: '',
        appkey1: '',
        appkey2: '',
        appsecret: '',
        appsecret1: '',
        appsecret2: '',
        adminsecret: null,
        type: ''
      },
      ruleValidate: {
        channel: [{ required: true, message: '请选择渠道', trigger: 'change' }],
        channelID: [
          {
            pattern: /^[0-9><=]+$/,
            required: true,
            message: '请输入数字',
            trigger: 'change'
          }
        ],
        channelIDone: [
          {
            pattern: /^[0-9><=]+$/,
            required: true,
            message: '请输入数字',
            trigger: 'change'
          }
        ]
      }
    };
  },

  // 使用其它组件
  components: {
    Modal,
    Icon,
    Input,
    Button,
    Select,
    Option,
    Form,
    FormItem
  },
  // 计算属性
  computed: {
    isShowAppKey() {
      return (
        this.inputData.type === 'ding' ||
        this.inputData.type === 'wechat' ||
        this.inputData.type === 'lark'
      );
    },
    isShowInput() {
      return this.inputData.type === 'ding' || this.inputData.channel === '';
    },
    isShowDing() {
      return this.inputData.type === 'ding';
    },
    isShowWechat() {
      return this.inputData.type === 'wechat';
    },
    isShowLark() {
      return this.inputData.type === 'lark';
    }
  },
  // 监听
  watch: {
    value(newVal) {
      if (newVal) {
        this.getQuerydata();
      }
    }
  },
  // 方法
  methods: {
    onSelect(value) {
      this.inputData.channel = value.value;
      if (this.inputData.channel === '钉钉') {
        this.inputData.type = 'ding';
      } else if (this.inputData.channel === '微信') {
        this.inputData.type = 'wechat';
      } else if (this.inputData.channel === '飞书') {
        this.inputData.type = 'lark';
      }
    },
    // 查询钉钉微信飞书接口
    getQuerydata() {
      BindingApi.getQuerydata()
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            this.items = data;
            // 钉钉
            this.inputData.channelID = this.items[0].agentId;
            this.inputData.appkey = this.items[0].appKey;
            this.inputData.appsecret = this.items[0].appSecret;
            // 微信
            this.inputData.channelIDone = this.items[1].agentId;
            this.inputData.appkey1 = this.items[1].appKey;
            this.inputData.appsecret1 = this.items[1].appSecret;
            this.inputData.adminsecret = this.items[1].adminSecret;
            // 飞书
            this.inputData.appkey2 = this.items[2].appKey;
            this.inputData.appsecret2 = this.items[2].appSecret;
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: '查询信息失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(() => {
          this.$Message.destroy();
          this.$Message.error({
            content: '查询信息失败！',
            duration: 5,
            closable: true
          });
        });
    },
    // 关闭对话框
    onClose() {
      this.$emit('on-close');
    },

    // 显示状态发生变化时触发
    onChange(value) {
      if (!value) {
        this.onClose();
      }
    },
    onSubmit(inputData) {
      this.$refs[inputData].validate(valid => {
        if (valid) {
          const data = [
            {
              hasAgentId: true,
              adminSecret: null,
              hasAdminSecret: false,
              agentId: this.inputData.channelID,
              appKey: this.inputData.appkey,
              appSecret: this.inputData.appsecret,
              name: '钉钉',
              type: 'ding'
            },
            {
              hasAgentId: true,
              adminSecret: this.inputData.adminsecret,
              hasAdminSecret: true,
              agentId: this.inputData.channelIDone,
              appKey: this.inputData.appkey1,
              appSecret: this.inputData.appsecret1,
              name: '微信',
              type: 'wechat'
            },
            {
              hasAgentId: false,
              adminSecret: null,
              hasAdminSecret: false,
              agentId: null,
              appKey: this.inputData.appkey2,
              appSecret: this.inputData.appsecret2,
              name: '飞书',
              type: 'lark'
            }
          ];
          this.$emit('on-ok', data);
        }
      });
    }
  },

  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
.redDot/deep/.ivu-form-item-error-tip {
  position: absolute;
  top: 100%;
  left: 20px;
}
.input/deep/.ivu-input {
  width: 88%;
  position: relative;
  left: 20px;
}
.redDot/deep/.ivu-form-item-label::before {
  content: '';
  margin-right: 0px;
}
.header {
  text-align: center;
  font-family: PingFangSC-Regular;
  height: 20px;
}
</style>
