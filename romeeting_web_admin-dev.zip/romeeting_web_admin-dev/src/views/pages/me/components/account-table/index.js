import AccountTable from './account-table.vue';

export default AccountTable;
