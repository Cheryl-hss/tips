<template>
  <div v-if="value">
    <div class="me-menu-title">{{ $t('me_account_security') }}</div>
    <div class="me-button">
      <Button v-if="isCreate" class="me-button-create" @click="onClickAccoutCreate">创建子账号</Button>
      <Button v-if="showDomainSetting" class="me-button-seeting" @click="onClick">{{ $t('account_setting_host') }}</Button>
      <Button class="me-button-seeting" @click="onClickAccountNumber">第三方配置</Button>
    </div>
    <Table :columns="columns" :data="accountList">
      <template slot-scope="{ row, index }" slot="binding">
        <div class="imgDiv"
             v-if="accountList[index].phone === '' || accountList[index].phone === null">
          <Poptip transfer confirm title="请先新增手机号">
            <div class="imgDiv-Nodiv">
              <img style="margin-bottom: 2px" src="~@/assets/images/nail-nail-grey.png" />
            </div>
          </Poptip>
          <Poptip transfer confirm title="请先新增手机号">
            <div class="imgDiv-Nodiv">
              <img src="~@/assets/images/enterprise-wechat-grey.png" />
            </div>
          </Poptip>
          <Poptip transfer confirm title="请先新增手机号">
            <div class="imgDiv-Nodiv larkDiv">
              <img class="larkDiv-img" src="~@/assets/images/lark-grey.png" />
              <p class="grey">飞书</p>
            </div>
          </Poptip>
        </div>
        <div class="imgDiv" v-else>
          <!-- 钉钉 -->
          <div class="imgDiv-noclickNodiv" v-if="accountList[index].dingBind !== false">
            <img style="margin-bottom: 2px" src="~@/assets/images/nail-nail-blue.png" />
          </div>
          <div class="imgDiv-div" v-else @click="dingBind(index)">
            <img style="margin-bottom: 2px" src="~@/assets/images/nail-nail-grey.png" />
          </div>
          <!-- 企业微信 -->
          <div class="imgDiv-noclickNodiv" v-if="accountList[index].weChatBind !== false">
            <img src="~@/assets/images/enterprise-wechat-blue.png" />
          </div>
          <div class="imgDiv-div" v-else @click="weChatBind(index)">
            <img src="~@/assets/images/enterprise-wechat-grey.png" />
          </div>
          <!-- 飞书 -->
            <div class="imgDiv-noclickNodiv larkDiv" v-if="accountList[index].larkBind !== false">
              <img class="larkDiv-img" src="~@/assets/images/lark-blue.png" />
              <p class="lark">飞书</p>
            </div>
            <div class="imgDiv-Nodiv larkDiv" @click="larkBind(index)" v-else>
              <img class="larkDiv-img" src="~@/assets/images/lark-grey.png" />
              <p class="grey">飞书</p>
            </div>
        </div>
      </template>
      <template slot-scope="{ row, index }" slot="action">
        <Button type="info" size="small" ghost @click="changePwd(index)">修改密码</Button>
        <div>
          <Button
            v-if="accountList[index].phone === '' || accountList[index].phone === null"
            class="margin-left"
            type="info"
            size="small"
            ghost
            @click="cellphonenumber(index)"
            >新增手机号</Button>
          <Button
            v-else
            class="margin-left"
            type="info"
            size="small"
            ghost
            @click="cellphonenumber(index)"
            >修改手机号</Button>
        </div>
        <Button
          class="margin-left"
          type="error"
          size="small"
          :ghost="row.userId !== currentUserId"
          :disabled="row.userId === currentUserId"
          @click="deleteUser(row, index)"
          >删除</Button>
      </template>
    </Table>

    <DomainSettingModal
      :value="showDomainSettingModal"
      @on-close="closeDomainSettingModal"
      @on-ok="onOk"
    />
    <AccountCreateModal
      :value="showAccountCreateModal"
      @on-close="closeAccoutCreateModal"
      @on-ok="onOkAccountCreate"
    />
    <ModifyPwdModal
      :value="showModifyPwdModal"
      @on-close="closeModifyPwdModal"
      @on-ok="onOkModifyPwdModal"
    />
    <!-- 第三方账号通知和新增修改手机号弹框 -->
    <AccountMobileNumber
      :value="showAccountMobileNumber"
      @on-close="closeAccountMobileNumber"
      @on-ok="onOkAccountMobileNumber"
    />
    <!-- 第三方账号渠道弹框 -->
    <AccountNumberThirdParty
      :value="showAccountNumberThirdParty"
      @on-close="closeAccountNumberThirdParty"
      @on-ok="onOkAccountNumberThirdParty"
    />
  </div>
</template>

<script>
import { Button, Table, Poptip } from 'view-design';
import DomainSettingModal from '@/views/main/domain-setting-modal';
import AccountCreateModal from '@/views/pages/me/components/account-table/accout-create-modal';
import ModifyPwdModal from '@/views/pages/me/components/account-table/account-modifypwd-modal';
import AccountMobileNumber from '@/views/pages/me/components/account-table/account-mobile-number';
import AccountNumberThirdParty from '@/views/pages/me/components/account-table/account-number-third-party';
import LoginApi from '@/api/login';
import CommonApi from '@/api/common';
import BindingApi from '@/api/binding';
export default {
  // 不要忘记了 name 属性
  name: 'AccountTable',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    value: {
      // 是否显示账户表格
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      message: '',
      accountList: [], // 设备列表
      isCreate: false, // 是否是超级管理员，超级管理员显示创建子账号权限
      isDelete: false, // 是否展示删除用户按钮
      isSuperDomain: false, // 是否具有设置域名的权限
      isModifyPwd: false, // 是否展示修改用户密码按钮
      showDomainSetting: false, // 是否显示设置域名按钮（快捷键按钮）
      showDomainSettingModal: false, // 是否显示设置域名弹出框
      showAccountCreateModal: false, // 是否显示创建子账号弹出框
      isSuper: false, // 是否显示创建子账号按钮
      showModifyPwdModal: false, // 是否展示修改密码弹出框
      showAccountMobileNumber: false, // 是否显示修改手机号弹框
      showAccountNumberThirdParty: false, // 是否显示第三方账号
      currentIndex: -1, // 当前选中的index
      columns: [
        // table列
        {
          title: this.$t('account_table_index'),
          type: 'index',
          width: 70,
          className: 'table-head-style'
        },
        {
          title: this.$t('account_table_account'),
          key: 'username',
          minWidth: 100,
          className: 'table-head-style'
        },
        {
          title: this.$t('account_table_binding'),
          slot: 'binding',
          minWidth: 260,
          className: 'table-head-style'
        },
        {
          title: this.$t('account_table_password'),
          key: 'password',
          minWidth: 150,
          className: 'table-head-style',
          render: (h, params) => {
            return h('div', '******');
          }
        },
        {
          title: this.$t('account_table_role'),
          key: 'role',
          minWidth: 100,
          className: 'table-head-style',
          render: (h, params) => {
            return h('div', params.row.role || '-');
          }
        },
        {
          title: this.$t('account_table_cell_phone_number'),
          key: 'phone',
          minWidth: 140,
          className: 'table-head-style',
          render: (h, params) => {
            return h('div', params.row.phone || '-');
          }
        },
        {
          title: this.$t('account_table_action'),
          slot: 'action',
          minWidth: 280,
          className: 'table-head-style'
        }
      ]
    };
  },

  // 使用其它组件
  components: {
    Button,
    Table,
    Poptip,
    DomainSettingModal,
    AccountCreateModal,
    ModifyPwdModal,
    AccountMobileNumber,
    AccountNumberThirdParty
  },
  // 计算属性
  computed: {
    // 获取当前用户的UserID
    currentUserId() {
      return JSON.parse(localStorage.getItem('userInfo')).userId;
    }
  },
  // 监听
  watch: {
    value(newVal) {
      if (newVal) {
        this.getAccountList();
        if (this.isSuperDomain) {
          document.addEventListener('keyup', this.reaKey);
        }
      } else {
        this.showDomainSetting = false;
        if (this.isSuperDomain) {
          document.removeEventListener('keyup', this.reaKey);
        }
      }
    }
  },
  // 方法
  methods: {
    // 获取账户列表
    getAccountList() {
      LoginApi.getAccountList()
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            // 把返回数据给table的数据赋值
            this.accountList = data;
          } else {
            this.$Message.error({
              content: msg || '获取账户列表失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          this.$Message.error({
            content: err.msg || '获取账户列表失败！',
            duration: 5,
            closable: true
          });
        });
    },
    // 显示设置域名弹出框
    onClick() {
      //
      this.showDomainSettingModal = true;
      this.showAccountCreateModal = false;
      this.showModifyPwdModal = false;
    },

    // 显示创建子账号的弹框
    onClickAccoutCreate() {
      this.showAccountCreateModal = true;
      this.showDomainSettingModal = false;
      this.showModifyPwdModal = false;
    },

    // 显示修改密码弹出框
    onClickShowModifyPwdModal() {
      this.showAccountCreateModal = false;
      this.showDomainSettingModal = false;
      this.showModifyPwdModal = true;
    },
    // 显示第三方账号弹出框
    onClickAccountNumber() {
      this.showAccountNumberThirdParty = true;
    },

    isHiddenCreateBtn() {
      //
      var auth = JSON.parse(localStorage.getItem('userInfo')).auth;
      if (auth.indexOf('security-create') > -1) {
        this.isCreate = true;
      }
      if (auth.indexOf('security-domain') > -1) {
        this.isSuperDomain = true;
      }
      if (auth.indexOf('security-delete（') > -1) {
        this.isDelete = true;
      }
      if (auth.indexOf('security-pwd') > -1) {
        this.isModifyPwd = true;
      }
    },

    changePwd(index) {
      //
      this.showModifyPwdModal = true;
      this.currentIndex = index;
    },
    // 手机号弹框
    cellphonenumber(index) {
      this.currentIndex = index;
      this.showAccountMobileNumber = true;
      localStorage.setItem(
        'this.accountList[this.currentIndex]',
        JSON.stringify(this.accountList[this.currentIndex])
      );
    },
    // 钉钉绑定
    dingBind(index) {
      const vm = this;
      vm.currentIndex = index;
      const dingArr = {
        mobile: vm.accountList[vm.currentIndex].phone,
        thirdpartflag: 'ding'
      };
      BindingApi.binDing(dingArr)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            vm.$Message.success({
              content: '钉钉绑定成功！',
              duration: 5,
              closable: true
            });
            vm.getAccountList();
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '钉钉绑定失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg || '钉钉绑定失败！',
            duration: 5,
            closable: true
          });
        });
    },
    // 企业微信绑定
    weChatBind(index) {
      const vm = this;
      vm.currentIndex = index;
      const wechatArr = {
        mobile: vm.accountList[vm.currentIndex].phone,
        thirdpartflag: 'wechat'
      };
      BindingApi.binDing(wechatArr)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            vm.$Message.success({
              content: '企业微信绑定成功！',
              duration: 5,
              closable: true
            });
            vm.getAccountList();
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '企业微信绑定失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg || '企业微信绑定失败！',
            duration: 5,
            closable: true
          });
        });
    },
    // 飞书绑定
    larkBind(index) {
      const vm = this;
      vm.currentIndex = index;
      const wechatArr = {
        mobile: vm.accountList[vm.currentIndex].phone,
        thirdpartflag: 'lark'
      };
      BindingApi.binDing(wechatArr)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            vm.$Message.success({
              content: '飞书绑定成功！',
              duration: 5,
              closable: true
            });
            vm.getAccountList();
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '飞书绑定失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg || '飞书绑定失败！',
            duration: 5,
            closable: true
          });
        });
    },

    onOkAccountMobileNumber(value) {
      const vm = this;
      const user = {
        uid: vm.accountList[vm.currentIndex].userId,
        phone: value
      };
      vm.showAccountMobileNumber = false;
      if (vm.accountList[vm.currentIndex].phone === null) {
        vm.message = '新增';
      } else {
        vm.message = '修改';
      }
      BindingApi.newMobilePhoneNumber(user)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            vm.$Message.success({
              content: vm.message + '手机号成功！',
              duration: 5,
              closable: true
            });
            vm.getAccountList();
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: vm.message + '手机号失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg || this.message + '手机号失败！',
            duration: 5,
            closable: true
          });
        });
    },
    onOkModifyPwdModal(value) {
      // 修改密码
      const userId = this.accountList[this.currentIndex].userId;
      const vm = this;
      const params = value;
      vm.showModifyPwdModal = false;
      LoginApi.modifyPwd(params, userId)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            vm.$Message.success({
              content: '修改密码成功！',
              duration: 5,
              closable: true
            });
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '修改密码失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg || '修改密码失败！',
            duration: 5,
            closable: true
          });
        });
    },
    // 提交输入内容
    onOkAccountNumberThirdParty(data) {
      BindingApi.addAndmodify(data)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            this.showAccountNumberThirdParty = false;
            this.$Message.success({
              content: '新增信息成功！',
              duration: 5,
              closable: true
            });
          } else {
            this.$Message.error({
              content: msg || '新增信息失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(error => {
          this.$Message.destroy();
          this.$Message.error({
            content: error.msg || '新增信息失败！',
            duration: 5,
            closable: true
          });
        });
    },
    // 删除用户接口
    deleteUser(row, index) {
      //
      const vm = this;
      this.$Modal.confirm({
        title: '确定删除账号 "' + row.username + '" 吗？',
        onOk: () => {
          const deleteUserID = this.accountList[index].userId;
          const userInfo = JSON.parse(localStorage.getItem('userInfo'));
          if (deleteUserID === userInfo.userId) {
            this.$Message.error({
              content: '不能删除自己！',
              duration: 5,
              closable: true
            });
          } else {
            vm.onDeleteConfirm(index);
          }
        },
        onCancel: () => {
          // 点击了取消
        }
      });
    },

    onDeleteConfirm(index) {
      // 删除账号
      const userId = this.accountList[index].userId;
      LoginApi.deleteAccount(userId)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            this.$Message.success({
              content: '删除账号成功！',
              duration: 5,
              closable: true
            });
            this.accountList.splice(index, 1);
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: '删除账号失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          this.$Message.destroy();
          this.$Message.error({
            content: err.msg || '删除账号失败！',
            duration: 5,
            closable: true
          });
        });
      // this.$Message.info('Clicked ok');
    },
    // 关闭设置主机模态框
    closeDomainSettingModal() {
      this.showDomainSettingModal = false;
      this.showAccountCreateModal = false;
      this.showModifyPwdModal = false;
    },

    // 关闭创建子账号弹框
    closeAccoutCreateModal() {
      this.showAccountCreateModal = false;
      this.showDomainSettingModal = false;
      this.showModifyPwdModal = false;
    },

    // 关闭修改密码弹框
    closeModifyPwdModal() {
      this.showAccountCreateModal = false;
      this.showDomainSettingModal = false;
      this.showModifyPwdModal = false;
    },
    // 关闭修改手机号弹框
    closeAccountMobileNumber() {
      this.showAccountMobileNumber = false;
    },
    // 关闭第三方账号弹框
    closeAccountNumberThirdParty() {
      this.showAccountNumberThirdParty = false;
    },

    // 提交设置主机域名
    onOk(value) {
      const vm = this;
      const params = { value };
      CommonApi.setConfigHost(params)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            // 把设置成功的域名存储到localStorage里
            const userInfo = JSON.parse(localStorage.getItem('userInfo'));
            userInfo.host = value;
            localStorage.setItem('userInfo', JSON.stringify(userInfo));
            vm.$Message.destroy();
            vm.$Message.success({
              content: '设置成功！',
              duration: 5,
              closable: true
            });
            vm.showDomainSettingModal = false;
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '设置失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(error => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: error.msg || '设置失败！',
            duration: 5,
            closable: true
          });
        });
    },

    // 提交创建子账号的请求
    onOkAccountCreate(params) {
      LoginApi.createAccount(params)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            this.showAccountCreateModal = false;
            this.$Message.success('创建子账号成功!');
            this.getAccountList();
          } else {
            this.$Message.error({
              content: msg || '创建子账号失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(error => {
          this.$Message.destroy();
          this.$Message.error({
            content: error.msg || '创建子账号失败aaa！',
            duration: 5,
            closable: true
          });
        });
    },

    reaKey(e) {
      if (e.ctrlKey === true && e.keyCode === 123) {
        e.preventDefault();
        this.showDomainSetting = !this.showDomainSetting;
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      this.isHiddenCreateBtn();
      // this.getAccountList();
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>

<style lang='less'>
.ivu-poptip-confirm .ivu-poptip-body {
  padding: 12px;
}
.ivu-poptip-footer {
  display: none;
}
.ivu-table-cell-slot {
  display: flex;
}
.me {
  &-menu-title {
    font-size: 18px;
    color: #333333;
    height: 18px;
    line-height: 18px;
    margin-bottom: 10px;
    font-weight: bold;
  }
  &-button {
    height: 32px;
    margin-bottom: 20px;
    &-create {
      float: right;
    }
    &-seeting {
      float: right;
      margin-right: 10px;
    }
  }
}
.imgDiv {
  width: 100%;
  height: 100%;
  display: flex;
  margin-left: -20px;
  &-div {
    width: 50%;
    height: 100%;
    min-width: 83px;
    margin-right: 10px;
    > img {
      width: 100%;
      height: 100%;
      margin-top: 10px;
      cursor: pointer;
    }
  }
  &-noclickNodiv {
    width: 50%;
    height: 100%;
    min-width: 83px;
    cursor: default;
    margin-right: 10px;
    > img {
      width: 100%;
      height: 100%;
      margin-top: 10px;
      cursor: default;
    }
  }
  &-Nodiv {
    width: 50%;
    height: 100%;
    min-width: 83px;
    cursor: pointer;
    margin-right: 10px;
    > img {
      width: 100%;
      height: 100%;
      margin-top: 10px;
      cursor: pointer;
    }
  }
}
.lark {
  color: #5bbaeb;
  padding: 13px 10px 0px 4px;
  font-weight: 600;
}
.grey {
  color: #e3e2e2;
  padding: 13px 10px 0px 4px;
  font-weight: 600;
}
.larkDiv {
  display: flex;
  font-size: 12px;
  margin-left: 20px;
  > img {
    width: 18px;
    height: 18px;
    margin-top: 12px;
    margin-left: 10px;
  }
}
</style>
