<template>
  <div v-if="value">
    <div class="me-menu-title">{{ $t('me_attendee') }}</div>
    <div class="form-body">
      <Table :columns="columns"
             :data="attendeeList">

        <template slot-scope="{ row, index }"
                  slot="name">
          <Form v-if="editIndex === index"
                ref="nameForm"
                :model="editForm"
                @submit.native.prevent>
            <FormItem prop="name"
                      :label-width="0"
                      :show-message="false"
                      :rules="{ required: true, message: '必填', trigger: 'change'}">
              <Input v-model="editForm.name"
                     v-if="editIndex === index"
                     placeholder="姓名"
                     maxlength="24"
                     @on-keyup="showMessageOfOverLimit($event, editForm.name, 24, '姓名' )" />
            </FormItem>
          </Form>
          <span v-else>{{ row.name }}</span>
        </template>

        <template slot-scope="{ row, index }"
                  slot="company">
          <Input v-model="editForm.company"
                 v-if="editIndex === index"
                 placeholder="公司"
                 maxlength="16"
                 @on-keyup="showMessageOfOverLimit($event, editForm.company, 16, '公司' )" />
          <span v-else>{{ row.company || '-' }}</span>
        </template>

        <template slot-scope="{ row, index }"
                  slot="logo">
          <div v-if="editIndex === index">
            <Upload class="margin-top-10"
                    action=""
                    accept=".jpg, .png"
                    :format="['.jpg', '.png']"
                    :before-upload="beforeUpload"
                    ref="uploader">
              <div v-if="editForm.logo"
                   :title="$t('meeting_select_logo')"
                   class="table-icon pointer margin-top-2">
                <img :src="editForm.logoUrl" />
              </div>
              <Button v-else
                      type="info"
                      size="small"
                      ghost>{{$t('meeting_select_logo')}}</Button>
            </Upload>
          </div>
          <div v-else
               class="table-icon">
            <img v-if="row.logoUrl"
                 :src="row.logoUrl" />
            <span v-else>-</span>
          </div>
        </template>

        <template slot-scope="{ row, index }"
                  slot="position">
          <Input v-model="editForm.position"
                 v-if="editIndex === index"
                 placeholder="职位"
                 maxlength="18"
                 @on-keyup="showMessageOfOverLimit($event, editForm.position, 18, '职位' )" />
          <span v-else>{{ row.position }}</span>
        </template>

        <template class="form-body-action"
                  slot-scope="{ row, index }"
                  slot="action">
          <Button v-if="editIndex === index && row.id"
                  class="submit-btn"
                  type="primary"
                  size="small"
                  float-left
                  @click="submitDataRow(index)">
            {{ $t('meeting_table_save') }}
          </Button>
          <Button v-if="editIndex === index && row.id"
                  class="submit-btn"
                  size="small"
                  float-left
                  @click="cancel(row)">
            {{ $t('meeting_table_cancel') }}
          </Button>
          <div v-if='editIndex !== index && row.id'
               class="form-body-action-edit"
               @click="editTableDataRow(row, index)">
            <img src="@/assets/images/icon-edit@2x.png" />
          </div>
          <Button v-if="editIndex === index && !row.id"
                  class="submit-btn"
                  type="primary"
                  size="small"
                  float-left
                  @click="submitDataRow(index)">
            {{ $t('meeting_table_submit') }}
          </Button>
          <div v-if='editIndex !== index || !row.id'
               class="form-body-action-close"
               @click="remove(row, index)">
            <img src="@/assets/images/icon-close@2x.png" />
          </div>
        </template>

      </Table>

      <Button class="margin-top-12"
              long
              type="primary"
              ghost
              @click="openAddAttendee">
        <div class="form-body-action-add margin-right-8"
             float-left>
          <img src="@/assets/images/icon-add-blue@2x.png">
        </div>
        {{ $t('meeting_table_add') }}
      </Button>
      <CropModal :value="showCropModal"
                 :src="src"
                 :file-name="fileName"
                 @on-close="onClose"
                 @on-ok="onOk"></CropModal>
    </div>

  </div>
</template>

<script>
import { Table, Form, FormItem, Input, Upload, Button } from 'view-design';
import CropModal from '../crop-modal';

import PersonApi from '@/api/person';
import { uploadToOSS, addOssResourse, getOssResourse } from '@/api/upload';
import { deepCopy } from '@/utils/tools';

export default {
  // 不要忘记了 name 属性
  name: 'AttendeeTable',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    value: {
      // 是否显示参会人列表
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      attendeeList: [], // 设备列表
      attendeeListCopy: [], // 设备列表
      editIndex: -1, // 当前编辑的行数
      editForm: {
        // 当前编辑的参会人行数据
        name: '',
        company: '',
        logo: '',
        logoUrl: '',
        position: ''
      },
      showCropModal: false,
      src: '', // 需要截得图片路径
      fileName: '', // 图片名称
      columns: [
        // table列
        {
          title: this.$t('attendee_table_index'),
          type: 'index',
          width: 70,
          className: 'table-head-style'
        },
        {
          title: this.$t('attendee_table_name'),
          slot: 'name',
          minWidth: 150,
          className: 'table-head-style'
        },
        {
          title: this.$t('attendee_table_company'),
          slot: 'company',
          minWidth: 160,
          className: 'table-head-style'
        },
        {
          title: this.$t('attendee_table_logo'),
          slot: 'logo',
          minWidth: 100,
          className: 'table-head-style'
        },
        {
          title: this.$t('attendee_table_position'),
          slot: 'position',
          minWidth: 100,
          className: 'table-head-style'
        },
        {
          title: this.$t('attendee_table_action'),
          slot: 'action',
          width: 150,
          align: 'center',
          className: 'table-head-style'
        }
      ]
    };
  },

  // 使用其它组件
  components: {
    Table,
    Form,
    FormItem,
    Input,
    Upload,
    Button,
    CropModal
  },
  // 计算属性
  computed: {},
  // 监听
  watch: {
    value(newVal) {
      if (newVal) {
        this.getAttendeeList();
      }
    }
  },
  // 方法
  methods: {
    // 超出输入框最大长度弹出提示
    showMessageOfOverLimit($event, text, limit, name) {
      // 在Chrome下keyCode=229 而不是13
      if (
        ($event.keyCode >= 48 && $event.keyCode <= 57) ||
        ($event.keyCode >= 65 && $event.keyCode <= 90) ||
        $event.keyCode === 13 ||
        $event.keyCode === 32 ||
        $event.keyCode === 229
      ) {
        if (text.length >= limit) {
          this.$Message.destroy();
          text = text.substring(0, limit);
          this.$forceUpdate();
          this.$Message.info({
            content: name + '不超过' + limit + '个字符',
            duration: 5,
            closable: true
          });
        }
      }
    },

    // 获取参会人列表
    getAttendeeList() {
      const vm = this;
      PersonApi.getAttendeeList()
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            // 把返回数据给table的数据赋值
            vm.attendeeListCopy = deepCopy(data);
            vm.attendeeList = deepCopy(vm.attendeeListCopy);
            vm.attendeeListCopy.map((item, index) => {
              if (item.logo) {
                vm.getLogoUrl(item.logo, index, function callback() {
                  vm.attendeeList = deepCopy(vm.attendeeListCopy);
                });
              }
            });
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: msg || '获取设备列表失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: err.msg || '获取设备列表失败！',
            duration: 5,
            closable: true
          });
        });
    },

    // 获取公司logoUrl
    getLogoUrl(id, index, callback) {
      const vm = this;
      const userId = this.$store.state.user.userId;
      getOssResourse(userId, { id })
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            vm.attendeeListCopy[index].logoUrl = data;
            callback();
          } else {
            callback();
          }
        })
        .catch(err => {
          window.console.log(err);
        });
    },

    // 打开新一行添加参会人
    openAddAttendee() {
      if (
        (this.attendeeList &&
          this.attendeeList.length &&
          !this.attendeeList[this.attendeeList.length - 1].name) ||
        this.editIndex !== -1
      ) {
        this.$Message.warning({
          content: '请完成当前添加项！',
          duration: 5,
          closable: true
        });
        return;
      }
      this.editForm = {
        name: '',
        company: '',
        logo: '',
        logoUrl: '',
        position: ''
      };
      this.attendeeList.push(this.editForm);
      this.editIndex = this.attendeeList.length - 1;
    },

    // 编辑参会人列
    editTableDataRow(row, index) {
      if (this.editIndex !== -1) {
        this.$Message.destroy();
        this.$Message.warning({
          content: '请完成当前添加项！',
          duration: 5,
          closable: true
        });
        return;
      }
      this.editForm = deepCopy(row);
      this.editIndex = index;
    },

    // 取消编辑参会人行数据
    cancel(row) {
      this.editIndex = -1;
    },

    // 提交参会人行数据
    submitDataRow(index) {
      const vm = this;
      // 表单校验
      const $nameForm = this.$refs['nameForm'];
      $nameForm && $nameForm.validate();

      if (!vm.editForm.name) {
        vm.$Message.destroy();
        vm.$Message.warning({
          content: '姓名必填！',
          duration: 5,
          closable: true
        });
        return;
      }

      vm.attendeeListCopy = deepCopy(vm.attendeeList);
      vm.attendeeListCopy[index] = deepCopy(vm.editForm);
      const alterData = deepCopy(vm.attendeeListCopy[index]);
      delete alterData.logoUrl;
      if (vm.attendeeListCopy[index].id) {
        PersonApi.alterAttendee([alterData])
          .fetch()
          .then(({ success, msg }) => {
            if (success) {
              vm.attendeeList = deepCopy(vm.attendeeListCopy);
              vm.$Message.destroy();
              vm.$Message.success({
                content: '修改参会人成功！',
                duration: 5,
                closable: true
              });
              vm.editIndex = -1;
            } else {
              vm.$Message.destroy();
              vm.$Message.error({
                content: msg || '修改参会人失败！',
                duration: 5,
                closable: true
              });
            }
          })
          .catch(err => {
            window.console.log(err);
          });
      } else {
        alterData.disable = false;
        PersonApi.addAttendee([alterData])
          .fetch()
          .then(({ success, msg, data }) => {
            if (success) {
              vm.attendeeListCopy = deepCopy(vm.attendeeList);
              vm.attendeeList = deepCopy(vm.attendeeListCopy);
              vm.attendeeListCopy[index].id = data[0].id;
              vm.attendeeList = deepCopy(vm.attendeeListCopy);
              vm.$Message.destroy();
              vm.$Message.success({
                content: '添加参会人成功！',
                duration: 5,
                closable: true
              });
              vm.editIndex = -1;
            } else {
              vm.$Message.destroy();
              vm.$Message.error({
                content: msg || '添加参会人失败！',
                duration: 5,
                closable: true
              });
            }
          })
          .catch(err => {
            window.console.log(err);
          });
      }
    },

    // 删除参会人列
    remove(row, index) {
      if (!row.id) {
        this.attendeeList.splice(index, 1);
        this.editIndex = -1;
        return;
      }
      PersonApi.deleteAttendee(row.id)
        .fetch()
        .then(({ success, msg }) => {
          if (success) {
            this.$Message.destroy();
            this.$Message.success({
              content: '删除参会人成功！',
              duration: 5,
              closable: true
            });
            this.attendeeList.splice(index, 1);
            // 如果当前有在编辑行
            // 1、当前编辑行为新增行时
            if (this.editIndex === index) {
              this.editIndex = -1;
              return;
            }
            // 2、当前编辑行在删除行后面时，editIndex需要减1
            if (this.editIndex > index) {
              this.editIndex--;
            }
            // 3、当编辑行在删除行前面是不需要改变 editIndex
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: msg || '删除参会人失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          window.console.log(err);
        });
    },

    // 上传logo
    beforeUpload(file) {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = event => {
        this.src = event.srcElement.result;
        this.fileName = file.name;
        this.showCropModal = true;
      };
      return false;
    },

    // 获取上传资源url
    getOssResourse(file, userId, params) {
      getOssResourse(userId, params)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            this.editForm.logoUrl = data;
            this.editForm.logo = params.id;
            this.loading = false;
            this.showCropModal = false;
          } else {
            this.loading = false;
            this.showCropModal = false;
            this.$Message.destroy();
            this.$Message.error({
              content: msg || file.name + '获取失败',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          window.console.log(err);
          this.loading = false;
          this.showCropModal = false;
        });
    },

    // 关闭剪裁图片modal框
    onClose() {
      this.showCropModal = false;
    },

    onOk(file) {
      // 剪裁图片确认按钮点击事件
      this.loading = true;
      this.uploadCropperImg(file);
    },

    // 上传截图
    uploadCropperImg(file) {
      uploadToOSS(file).then(res => {
        // 1、创建oss资源 ，拿到资源id，push到 resourceIds
        // 2、拿返回的objectKey去请求资源，得到资源路径，显示出来

        // 获取用户id
        const userId = this.$store.state.user.userId;
        // 获取创建资源参数
        const fileData = {
          fileKey: res.key,
          name: file.name,
          size: file.size,
          desc: file.desc,
          md5: res.md5,
          fileType: 'Image'
        };
        // 发送创建资源请求
        addOssResourse(userId, fileData)
          .fetch()
          .then(({ success, msg, data }) => {
            if (success) {
              this.getOssResourse(fileData, userId, { id: data.resourceId });
            } else {
              this.loading = false;
              this.showCropModal = false;
              this.$Message.destroy();
              this.$Message.error({
                content: msg || file.name + '上传失败，请重试！',
                duration: 5,
                closable: true
              });
            }
          })
          .catch(err => {
            this.loading = false;
            this.showCropModal = false;
            this.$Message.destroy();
            this.$Message.error({
              content: err.msg || file.name + '上传失败，请重试！',
              duration: 5,
              closable: true
            });
          });
      });
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
    // this.getAttendeeList();
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.me-menu-title {
  font-size: 18px;
  color: #333333;
  height: 18px;
  line-height: 18px;
  margin-bottom: 30px;
  font-weight: bold;
}

.table-icon {
  width: 77px;
  height: 21px;

  > img {
    width: 100%;
    height: 100%;
  }
}

.pointer {
  cursor: pointer;
}

.form-body {
  .ivu-form-item {
    margin-bottom: 0 !important;
  }
  &-action {
    &-edit {
      float: left;
      width: 22px;
      height: 22px;
      margin-left: 24px;

      > img {
        width: 82%;
        height: 82%;
      }

      &:hover {
        cursor: pointer;
      }
    }

    &-close {
      float: left;
      width: 22px;
      height: 22px;
      margin-left: 26px;

      > img {
        width: 82%;
        height: 82%;
      }

      &:hover {
        cursor: pointer;
      }
    }

    &-add {
      float: left;
      width: 18px;
      height: 18px;

      > img {
        width: 100%;
        height: 100%;
      }
    }
  }
}

.submit-btn {
  font-size: 12px;
  width: 42px;
  height: 22px;
  margin-left: 17px;
  margin-right: -9px;
}
</style>
