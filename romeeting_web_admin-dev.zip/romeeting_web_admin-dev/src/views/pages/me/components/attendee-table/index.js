import AttendeeTable from './attendee-table.vue';

export default AttendeeTable;
