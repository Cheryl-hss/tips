import CropModal from './crop-modal.vue';

export default CropModal;
