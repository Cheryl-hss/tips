<template>
  <div v-if="value">
    <Modal :value="value"
           :mask-closable="false"
           :width="500"
           @on-visible-change="onChange">
      <p slot="header"
         class="header">
        <span>剪裁</span>
      </p>
      <div slot="close"
           @click="onClose"
           class="margin-right">
        <Icon type="ios-close"
              :size="35"
              color="#999999" />
      </div>
      <Cropper v-if="src"
               ref='cropperComponent'
               :src="src" />
      <div slot="footer">
        <Button class="button-width"
                @click="onClose">取消</Button>
        <!-- 确定剪裁的图片 -->
        <Button class="button-width"
                type="primary"
                :loading="loading"
                @click="onOk">确定</Button>
      </div>
    </Modal>
  </div>
</template>

<script>
import { Modal, Icon, Button } from 'view-design';
import Cropper from '@/components/cropper';

export default {
  // 不要忘记了 name 属性
  name: 'CropModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    fileName: {
      // 文件名称
      type: String,
      default() {
        return '';
      }
    },

    loading: {
      // modal框关闭前确认按钮loading
      type: Boolean,
      default() {
        return false;
      }
    },

    src: {
      // 需要截的图片
      type: '',
      default() {
        return '';
      }
    },

    value: {
      // modal框是否显示
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      insideSrc: '' // 处理
    };
  },

  // 使用其它组件
  components: { Modal, Icon, Button, Cropper },
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    // 关闭对话框
    onClose() {
      this.$emit('on-close');
    },

    // 点击确认按钮事件
    onOk() {
      this.$refs.cropperComponent.cropper.getCroppedCanvas().toBlob(blob => {
        const file = this.blobToFile(blob, this.fileName);
        this.$emit('on-ok', file);
      });
    },

    // 显示状态发生变化时触发
    onChange(value) {
      if (!value) {
        this.onClose();
      }
    },

    blobToFile(blob, fileName) {
      blob.lastModifiedDate = new Date();
      blob.name = fileName;
      return blob;
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.header {
  text-align: center;
  font-family: PingFangSC-Regular;
  height: 18px;
}
</style>
