<template>
  <div v-if="value">
    <div class="device-table-nav">
      <div class="me-menu-title">
        {{ $t('me_device_binding') }}
      </div>
      <div class="update"
           v-if="isUpdateAllow">
        <p class="update-text">{{upgradeInfoMessage}}</p>
        <Button class="update-button"
                type="primary"
                :disabled='!isUpgrade'
                @click="onClickUpgradeInfo">
          <img class="update-button-pic"
               src="@/assets/images/icon-upgradeall@2x.png">
          批量升级
        </Button>
      </div>
    </div>

    <Table :columns="columns"
           :data="deviceList"
           class="device-table">
      <template slot-scope="{ row, index }"
                slot="devName">
        <Form v-if="editIndex === index"
              :ref="'devForm_'+index"
              :model="deviceList[index]"
              @submit.native.prevent>
          <FormItem prop="devName"
                    :label-width="0"
                    :show-message="false"
                    :rules="{ required: true, type: 'string', trigger: 'change'}">
            <Input v-model="deviceList[index].devName"
                   placeholder="必填" />
          </FormItem>
        </Form>
        <span class="padding-left-8"
              v-else>{{ row.devName || '铭牌' + row.number }}</span>
      </template>
      <template slot-scope="{ row, index }"
                slot="action">
        <div v-if="isAuth">
          <Button v-if="editIndex === index"
                  type="info"
                  size="small"
                  @click="save(index)">保存</Button>
          <Button v-else
                  type="info"
                  size="small"
                  ghost
                  @click="edit(row, index)">编辑</Button>
          <Button class="margin-left"
                  type="info"
                  size="small"
                  ghost
                  @click="openGetLogModal(row, index)">获取日志</Button>
        </div>
      </template>
    </Table>

    <GetLogModal :value="showGetLogModal"
                 :data="row"
                 @on-ok="onOk"
                 @on-close="onClose"></GetLogModal>
  </div>
</template>

<script>
import { Table, Input, Button, Form, FormItem } from 'view-design';
import GetLogModal from './get-log-modal';

import { checkUpgradeInfo, upgradeAll } from '@/api/upload';
import PersonApi from '@/api/person';

export default {
  // 不要忘记了 name 属性
  name: 'DeviceTable',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    value: {
      // 是否显示设备表格
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      deviceList: [], // 设备列表
      editIndex: -1, // 当前编辑的行数
      devName: '', // 当前编辑的设备名称
      logIndex: -1,
      upgradeInfoMessage: '', // 拼接字符串 最新软件版本/最新系统版本 +版本号
      isShowBadge: false,
      isUpgrade: false,
      isAuth: false, // 是否有操作设备日志的权限
      isUpdateAllow: false, // 是否有展示设备升级按钮的权限
      showGetLogModal: false, // 是否显示获取设备日志modal
      row: {}, // 设备日志行数据
      upgradeInfo: {
        versionCode: -1,
        apkUrl: '',
        devType: '',
        devices: [],
        packageName: '',
        type: '',
        versionName: '',
        md5: '',
        updateInfo: ''
      },
      columns: [
        // table列
        {
          title: this.$t('device_table_index'),
          type: 'index',
          className: 'table-head-style',
          minWidth: 70
        },
        {
          title: this.$t('device_table_mac'),
          key: 'devMac',
          className: 'table-head-style',
          minWidth: 165
        },
        {
          title: this.$t('device_table_name'),
          slot: 'devName',
          className: 'table-head-style',
          minWidth: 120
        },
        {
          title: this.$t('device_table_software_version'),
          key: 'versionName',
          className: 'table-head-style',
          minWidth: 90
        },
        {
          title: this.$t('device_table_system_version'),
          key: 'sysName',
          className: 'table-head-style',
          minWidth: 90
        },
        {
          title: this.$t('device_table_action'),
          slot: 'action',
          className: 'table-head-style',
          minWidth: 170,
          align: 'center'
        }
      ],
      showLogpopUp: false, // 设备日志组件是否显示
      nameMac: {
        devName: null,
        devMac: null,
        devId: null
      }
    };
  },

  // 使用其它组件
  components: { Table, Input, Button, Form, FormItem, GetLogModal },
  // 计算属性
  computed: {},
  // 监听
  watch: {
    value(newVal) {
      if (newVal) {
        this.getDeviceList();
        this.checkUpgradeInfo();
      }
    }
  },
  // 方法
  methods: {
    // 关闭获取设备日志弹出框
    closeLogpopUp() {
      this.showLogpopUp = false;
    },
    // 获取账户列表
    getDeviceList() {
      PersonApi.getDeviceList()
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            // 把返回数据给table的数据赋值
            this.deviceList = data;
            var auth = JSON.parse(localStorage.getItem('userInfo')).auth;
            if (auth.indexOf('maintenance-edit') > -1) {
              this.isAuth = true;
            }
            if (auth.indexOf('maintenance-upgrade') > -1) {
              this.isUpdateAllow = true;
            }
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: msg || '获取设备列表失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          this.$Message.destroy();
          this.$Message.error({
            content: err.msg || '获取设备列表失败！',
            duration: 5,
            closable: true
          });
        });
    },

    // 点击编辑设备备注名
    edit(row, index) {
      // 给设备备注名赋值，有devName则显示devName，没有则显示默认备注名
      this.deviceList[index].devName = row.devName || '铭牌' + row.number;
      this.editIndex = index;
    },

    // 打开获取设备日志model
    openGetLogModal(row, index) {
      this.row = row;
      this.showGetLogModal = true;
    },

    onOk() {
      this.showGetLogModal = false;
    },

    // 关闭获取日志弹窗
    onClose() {
      this.showGetLogModal = false;
    },

    // 保存编辑
    save(index) {
      // 表单校验
      let passed = true;
      const $devForm = this.$refs['devForm_' + index];
      $devForm &&
        $devForm.validate(valid => {
          passed = passed && valid;
        });
      if (!passed) {
        return;
      }

      const alterData = {
        devId: this.deviceList[index].devId,
        devName: this.deviceList[index].devName
      };
      PersonApi.alterDeviceName(alterData)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            this.$Message.destroy();
            this.$Message.success({
              content: msg || '修改成功！',
              duration: 5,
              closable: true
            });
            this.editIndex = -1;
          } else {
            this.$Message.destroy();
            this.$Message.success({
              content: msg || '修改失败，请稍后重试！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          window.console.log(err);
        });
    },

    showUpgradeInfoBadge() {
      this.isShowBadge = true;
    },

    hideUpgradeInfoBadge() {
      this.isShowBadge = false;
    },

    checkUpgradeInfo(region) {
      //
      this.hideUpgradeInfoBadge();
      var region1 = 'default';
      var params = { region1 };
      checkUpgradeInfo(params)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            if (data.length) {
              this.showUpgradeInfoBadge();
              const upgradeInfo = data[0];
              if (upgradeInfo.type === 'App') {
                // 应用升级包
                this.upgradeInfoMessage = '最新软件版本：' + upgradeInfo.versionName;
                this.isUpgrade = true;
              } else {
                this.upgradeInfoMessage = '最新系统版本：' + upgradeInfo.versionName;
                this.isUpgrade = true;
              }
            } else {
              this.upgradeInfoMessage = '已经是最新版本啦';
              this.hideUpgradeInfoBadge();
              this.isUpgrade = false;
            }
          }
        })
        .catch(err => {
          this.$Message.error({
            content: err.msg || '获取设备升级信息失败！',
            duration: 5,
            closable: true
          });
        });
    },

    onClickUpgradeInfo() {
      const data = [];
      upgradeAll(data)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            this.hideUpgradeInfoBadge();
            this.$Message.destroy();
            this.$Message.success({
              content: msg || '操作成功！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          this.$Message.error({
            content: err.msg || '设备升级失败！',
            duration: 5,
            closable: true
          });
        });
      // }
    }
  },

  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
    this.getDeviceList();
    this.checkUpgradeInfo();
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
.device-table-nav {
  height: 50px;
}
.me-menu-title {
  float: left;
  font-size: 18px;
  color: #333333;
  height: 30px;
  line-height: 30px;
  margin-bottom: 20px;
  font-weight: bold;
  width: 200px;
}
.device-table {
  .ivu-form-item {
    margin-bottom: 0 !important;
  }
}
.update {
  float: right;
  height: 30px;
  width: 380px;
  &-button {
    float: right;
    background-color: rgb(255, 255, 255);
    color: #333333;
    width: 100px;
    padding: 0px;
    line-height: 30px;
    text-align: center;
    &-pic {
      float: left;
      margin: 5px 5px 5px 0;
      width: 20px;
      height: 20px;
    }
  }
  &-text {
    float: left;
    margin-left: 10px;
    margin-right: 10px;
    line-height: 30px;
    text-align: right;
    font-size: 10px;
    width: 250px;
    color: rgb(134, 130, 130);
  }
}
</style>
