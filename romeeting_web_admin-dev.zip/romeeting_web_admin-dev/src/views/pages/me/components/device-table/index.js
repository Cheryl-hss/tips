import DeviceTable from './device-table.vue';

export default DeviceTable;
