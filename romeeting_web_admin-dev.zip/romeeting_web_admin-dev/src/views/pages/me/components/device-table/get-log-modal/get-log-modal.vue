<template>
  <div v-if="value"
       :class="classes">
    <Modal :class="[prefixCls+'-modal']"
           :value="value"
           :mask-closable="false"
           footer-hide
           :width="500"
           @on-visible-change="onChange">
      <p slot="header"
         class="header">
        <span>获取日志</span>
      </p>
      <div slot="close"
           @click="onClose"
           class="margin-right">
        <Icon type="ios-close"
              :size="35"
              color="#999999" />
      </div>

      <div :class="[prefixCls+'-header']">
        <span :class="[prefixCls+'-name']">{{ data.devName || '铭牌' + data.number }}</span>
        <span class="margin-left-10">{{'(' + data.devMac + ')'}}</span>
      </div>
      <div :class="[prefixCls+'-body']">
        <div :class="[prefixCls+'-body-step']">
          <Row>
            <Col :class="[prefixCls+'-body-step-left']">
            <div class="margin-top-8"> 铭牌检测 </div>
            <div :class="step1Status === 'error' ? 'left-margin' : 'margin-top-28'"> 日志上传 </div>
            </Col>
            <Col>
            <Steps :current="current"
                   direction="vertical">
              <Step :status="step1Status">
                <div slot='icon'
                     :class="[prefixCls+'-icon']">
                  <img v-if="step1Status === 'process'"
                       class="loading"
                       :src="step1Icon" />
                  <img v-else
                       :src="step1Icon" />
                </div>
                <div slot="title"
                     :class="[step1Status === 'finish' ? prefixCls+'-blue' : '']">
                  {{ step1Status === 'process' ? '进行中' : step1Status === 'finish' ? '已完成' : '失败' }}
                </div>
                <div v-if="step1Status === 'error'"
                     slot="content">
                  请将铭牌连接网络后重试
                </div>

              </Step>
              <Step :status="step2Status">
                <div slot='icon'
                     :class="[prefixCls+'-icon']">
                  <img v-if="step2Status === 'process'"
                       class="loading"
                       :src="step2Icon" />
                  <img v-else
                       :src="step2Icon" />
                </div>
                <div slot="title"
                     :class="[step2Status === 'finish' ? prefixCls+'-blue' : '']">
                  {{ step2Status === 'wait' ? '等待' : step2Status === 'process' ? '进行中' : step2Status === 'finish' ? '已完成' : '失败' }}
                </div>
                <div v-if="step2Status === 'error'"
                     slot="content">
                  请重新获取日志
                </div>

              </Step>

            </Steps>
            </Col>
          </Row>
        </div>
      </div>

      <!-- <div v-if="step2Status === 'finish'"
           :class="[prefixCls+'-log']">
        <div :class="[prefixCls+'-log-left']"></div>
        <div :class="[prefixCls+'-log-center']">{{ '日志' + data.devMac }}</div>
        <div :class="[prefixCls+'-log-right']"
             @click="downloadLogsUrl">
          下载
        </div>
      </div>
      <div v-if="step2Status === 'finish'"
           :class="[prefixCls+'-tips']">
        请下载该日志文件并发送到售后人员，支持问题分析
      </div> -->

    </Modal>
  </div>
</template>

<script>
import { Modal, Icon, Row, Col, Steps, Step } from 'view-design';

import IconSuccess from '@/assets/images/icon-log-success.png';
import IconError from '@/assets/images/icon-log-error.png';
import IconWait from '@/assets/images/icon-log-wait.png';
import IconProcess from '@/assets/images/icon-log-loading.png';

import PersonApi from '@/api/person';
import { getLogsKey, getOssResourse } from '@/api/upload';
import { deepCopy } from '@/utils/tools';

export default {
  // 不要忘记了 name 属性
  name: 'GetLogModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    data: {
      // 设备行数据
      type: Object,
      default() {
        return {};
      }
    },
    value: {
      // modal框是否显示
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      prefixCls: 'get-log-modal',
      current: 1, // 当前步骤
      step1Status: 'process', // 步骤1状态
      step2Status: 'wait', // 步骤2状态
      key: '' // 下载资源key
    };
  },

  // 使用其它组件
  components: { Modal, Icon, Row, Col, Steps, Step },
  // 计算属性
  computed: {
    classes() {
      return [this.prefixCls, {}];
    },

    step1Icon() {
      var iconSrc = IconSuccess;
      switch (this.step1Status) {
        case 'process':
          iconSrc = IconProcess;
          break;
        case 'finish':
          iconSrc = IconSuccess;
          break;
        case 'error':
          iconSrc = IconError;
          break;
      }
      return iconSrc;
    },

    step2Icon() {
      var iconSrc = IconSuccess;
      switch (this.step2Status) {
        case 'wait':
          iconSrc = IconWait;
          break;
        case 'process':
          iconSrc = IconProcess;
          break;
        case 'finish':
          iconSrc = IconSuccess;
          break;
        case 'error':
          iconSrc = IconError;
          break;
      }
      return iconSrc;
    }
  },
  // 监听
  watch: {
    value(newVal) {
      if (newVal) {
        this.step1Status = 'process';
        this.step2Status = 'wait';
        this.getDeviceStatus();
      } else {
        // window.console.log('移除监听器');
        this.$root.eventHub.$off('MQTT_MSG', this.getMqttMsg);
      }
    },

    step2Status(newVal) {
      if (newVal === 'finish') {
        this.downloadLogsUrl();
      }
    }
  },
  // 方法
  methods: {
    // 关闭对话框
    onClose() {
      this.$emit('on-close');
    },

    // 点击确认按钮事件
    onOk() {
      this.$emit('on-ok');
    },

    // 显示状态发生变化时触发
    onChange(value) {
      if (!value) {
        this.onClose();
      }
    },

    // 获取设备在线状态
    getDeviceStatus() {
      const devId = this.data.devId;
      if (!devId) {
        return;
      }
      PersonApi.getDeviceStatus(devId)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            if (data === 1) {
              this.step1Status = 'finish';
              this.getDeviceLog();
            } else {
              this.step1Status = 'error';
            }
          } else {
            this.step1Status = 'error';
            this.$Message.error({
              content: msg || '获取设备在线状态请求失败',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(err => {
          this.step1Status = 'error';
          this.$Message.error({
            content: err.msg || '获取设备在线状态请求失败',
            duration: 5,
            closable: true
          });
        });
    },

    // 获取设备日志
    getDeviceLog() {
      // 1、获取下载日志资源的key
      const vm = this;
      if (!vm.data.devId) {
        return;
      }
      getLogsKey(vm.data.devId)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            // 下载错误日志的key数组
            var keyArr = deepCopy(data);
            if (keyArr.length) {
              for (var i = 0; i < keyArr.length; i++) {
                vm.key = keyArr[i];
              }
            }
            vm.step2Status = 'process';
            vm.onNewMesssage();
          } else {
            vm.step2Status = 'error';
          }
        })
        .catch(() => {
          vm.step2Status = 'error';
        });
    },

    // 下载日志请求
    downloadLogsUrl() {
      if (!this.key) {
        return;
      }
      const userId = this.$store.state.user.userId;
      const params = { key: this.key };
      getOssResourse(userId, params)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            if (data) {
              var downloadUrl = data;
              this.downloadFile(downloadUrl);
            } else {
              this.$Message.error({
                content: msg || '获取设备日志失败！',
                duration: 5,
                closable: true
              });
            }
          }
        })
        .catch(err => {
          this.$Message.error({
            content: err.msg || '获取设备日志失败！',
            duration: 5,
            closable: true
          });
        });
    },

    // 下载方法
    downloadFile(url) {
      var iframe = document.createElement('iframe');
      iframe.style.display = 'none'; // 防止影响页面
      iframe.style.height = 0; // 防止影响页面
      iframe.src = url;
      document.body.appendChild(iframe); // 这一行必须，iframe挂在到dom树上才会发请求
      window.setTimeout(() => {
        iframe.remove();
      }, 5000);
    },

    // 接收MQTT消息: 文件推送消息
    onNewMesssage() {
      const vm = this;
      vm.$root.eventHub.$on('MQTT_MSG', vm.getMqttMsg);
    },

    getMqttMsg(event) {
      const vm = this;
      // window.console.log('收到MQTT_MSG', event);
      // 只处理设备下载进度和状态相关的消息
      if (event.topic.indexOf('/NOTIFY') !== -1) {
        const message = event.msg;
        const msg = JSON.parse(message);
        // window.console.log(msg.notify);
        const data = msg.notify.data;
        if (
          !msg.notify.type ||
          msg.notify.type !== 'ReportLog' ||
          data.devId !== vm.data.devId ||
          data.status !== 'Success'
        ) {
          vm.step2Status = 'error';
          return;
        }
        // 接受到设备日志已上传完的mqtt消息，更改上传日志状态为'已完成'
        vm.step2Status = 'finish';
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
@prefix: get-log-modal;
@color-bold: #333333;
@color-bleak: #b9bdc5;

.loading {
  animation: rotation 1s linear infinite;
}

@keyframes rotation {
  from {
    transform: rotate(0deg);
  }
  25% {
    transform: rotate(90deg);
  }
  50% {
    transform: rotate(180deg);
  }
  75% {
    transform: rotate(270deg);
  }
  to {
    transform: rotate(360deg);
  }
}

.left-margin {
  margin-top: 43px;
}

.@{prefix} {
  color: #b9bdc5;
  height: 100%;

  &-modal {
    .ivu-modal-body {
      padding: 16px 32px;
    }
  }

  &-header {
    font-size: 16px;
    border-bottom: 1px solid #eaedf0;
    padding-bottom: 10px;
  }

  &-name {
    color: @color-bold;
  }

  &-body {
    width: 100%;
    height: 140px;
    padding-top: 32px;
    &-step {
      margin-left: 136px;
      &-left {
        color: #333333;
        margin-right: 10px;
        font-weight: 400;
      }
    }
  }

  &-icon {
    width: 24px;
    height: 24px;
    margin-left: -2px;

    > img {
      width: 24px;
      height: 24px;
    }
  }

  &-blue {
    color: #0050ff;
  }

  &-log {
    display: inline-flex;
    width: 100%;
    height: 32px;
    padding: 9px 12px;
    font-size: 12px;
    background: #e8eef8;

    &-left {
      height: 14px;
      width: 14px;
      margin-right: 6px;
      background-image: url('~@/assets/images/icon-log@2x.png');
      background-repeat: 'no-repeat';
      background-position: 'center';
      background-size: 100%;
      z-index: 1;
    }

    &-center {
      width: ~'calc(100% - 44px)';
      font-family: PingFangSC-Regular;
      font-size: 12px;
      color: #666666;
      line-height: 14px;
    }

    &-right {
      width: 24px;
      font-family: PingFangSC-Regular;
      font-size: 12px;
      color: #0050ff;
      line-height: 14px;

      &:hover {
        cursor: pointer;
      }
    }
  }

  &-tips {
    height: 14px;
    margin: 10px 0;
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #adb2bb;
    line-height: 14px;
  }
}
</style>
