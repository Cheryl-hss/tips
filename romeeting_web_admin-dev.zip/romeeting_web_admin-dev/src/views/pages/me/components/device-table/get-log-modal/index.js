import GetLogModal from './get-log-modal.vue';

export default GetLogModal;
