import NetworkSpeedmMeasurement from './network-speed-measurement.vue';

export default NetworkSpeedmMeasurement;
