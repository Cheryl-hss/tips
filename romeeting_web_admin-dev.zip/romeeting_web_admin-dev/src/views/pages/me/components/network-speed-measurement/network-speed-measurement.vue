<template>
  <div v-if="value">
    <div class="me-networkspeedmmeasurement">
      <h2 style="min-width: 100px">网络测速</h2>
      <div class="me-networkspeedmmeasurement-div">
        <div class="me-networkspeedmmeasurement-div-left">
          <div v-show="isTest">
            <div id="gaugeChart" style="width: 400px; height: 450px; margin-top: 15px"></div>
            <Button class="me-networkspeedmmeasurement-div-left-button" @click="onCancel"
              >取消测速</Button
            >
          </div>
          <div
            class="me-networkspeedmmeasurement-div-left-dot"
            @click="clickStart"
            v-show="!isTest"
          >
            <p class="me-networkspeedmmeasurement-div-left-dot-startTest">开始测速</p>
          </div>
        </div>
        <div class="me-networkspeedmmeasurement-div-right">
          <div class="me-networkspeedmmeasurement-div-right-top">
            <span style="min-width: 100px">下载 MB/s</span>
            <div id="downloadCheart" style="width: 400px; height: 250px; margin-top: -50px"></div>
          </div>
          <div class="me-networkspeedmmeasurement-div-right-center">
            <span style="min-width: 100px">上传 MB/s</span>
            <div id="uploadCheart" style="width: 400px; height: 250px; margin-top: -50px"></div>
          </div>
          <div class="me-networkspeedmmeasurement-div-right-bottom">
            <span style="min-width: 100px">网络状态： </span>
            <p style="margin-left: 50px; min-width: 100px">{{ message }}</p>
          </div>
        </div>
        <div></div>
      </div>
    </div>
  </div>
</template>

<script>
import NetworkApi from '@/api/network';
// import axios from '@/utils/api.request';
export default {
  // 不要忘记了 name 属性
  name: 'NetworkSpeedmMeasurement',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    value: {
      // 是否显示帮助模块
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      isTest: false,
      startButton: true,
      endButton: false,
      endShowButton: false,
      showButton: true, // 测试按钮
      showDiv: false, //
      request: null,
      gaugeChart: null,
      downloadChart: null,
      downloadSpeeds: [0],
      uploadSpeeds: [0],
      testType: 'download',
      timer: null,
      arr: [],
      message: ''
    };
  },

  // 使用其它组件
  components: {},
  // 计算属性
  computed: {},
  // 监听
  watch: {
    downloadSpeeds(value) {
      if (this.testType !== 'download') {
        this.testType = 'download';
      }
      this.refreshGaugeEchart();
      this.refreshDownloadSpeed();
    },
    uploadSpeeds(value) {
      if (this.testType !== 'upload') {
        this.testType = 'upload';
      }
      this.refreshGaugeEchart();
      this.refreshUploadSpeed();
    },
    value(val) {
      this.gaugeChart && this.gaugeChart.dispose();
      this.netWorkDownload && this.netWorkDownload.dispose();
      this.netWorkUpload && this.netWorkUpload.dispose();
      if (val) {
        this.$nextTick(() => {
          this.gaugeChart = this.$echarts.init(document.getElementById('gaugeChart'));
          this.netWorkDownload = this.$echarts.init(document.getElementById('downloadCheart'));
          this.netWorkUpload = this.$echarts.init(document.getElementById('uploadCheart'));
          this.refreshGaugeEchart();
          this.refreshDownloadSpeed();
          this.refreshUploadSpeed();
        });
      } else {
        this.onCancel();
      }
    }
  },
  // 方法
  methods: {
    // 判断网络状态
    network() {
      var downloadSpeeds = this.downloadSpeeds;
      var avg = 0;
      var sum = 0;
      for (var i = 0; i < downloadSpeeds.length; i++) {
        sum += downloadSpeeds[i];
      }
      avg = sum / downloadSpeeds.length;
      var uploadSpeeds = this.uploadSpeeds;
      var avg1 = 0;
      var sum1 = 0;
      for (var j = 0; j < uploadSpeeds.length; j++) {
        sum1 += uploadSpeeds[j];
      }
      avg1 = sum1 / uploadSpeeds.length;
      const arr = avg + avg1;
      const speeds = arr / 2;
      const qaz = speeds / (1024 * 1024);
      if (qaz <= 1) {
        this.message = '差';
      } else if (qaz > 1 && qaz < 3) {
        this.message = '良好';
      } else if (qaz >= 3) {
        this.message = '非常好';
      }
    },
    // 点击开始按钮
    clickStart() {
      this.message = '';
      this.downloadSpeeds = [0];
      this.uploadSpeeds = [0];
      this.request = NetworkApi.networkTest(this.downloadSpeeds, this.uploadSpeeds, 15);
      this.isTest = true;
      this.timer = window.setTimeout(() => {
        this.request.abort();
        this.isTest = false;
        this.network();
      }, 30100);
    },
    onCancel() {
      this.timer && window.clearTimeout(this.timer);
      if (this.request !== null) {
        this.request.abort();
      }
      this.isTest = false;
      this.downloadSpeeds = [0];
      this.uploadSpeeds = [0];
    },
    // 仪表盘
    refreshGaugeEchart() {
      // if (!this.gaugeChart) {
      //   this.gaugeChart = this.$echarts.init(document.getElementById('gaugeChart'));
      // }
      const download =
        (this.testType === 'download'
          ? this.downloadSpeeds[this.downloadSpeeds.length - 1]
          : this.uploadSpeeds[this.uploadSpeeds.length - 1]) /
        (1024 * 1024);
      // 125MB
      const maxValue = 125;
      let option = {
        title: {},
        tooltip: {
          formatter: '{a} <br/>{b} : {c}%'
        },
        series: [
          {
            // 类型
            type: 'gauge',
            // 半径
            min: 0,
            max: maxValue,
            radius: 180,
            color: 'rgb(36, 202, 228)',
            // 起始角度。圆心 正右手侧为0度，正上方为90度，正左手侧为180度。
            startAngle: 210,
            // 结束角度。
            endAngle: -30,
            center: ['50%', '60%'],
            // 仪表盘轴线相关配置。
            axisLine: {
              show: true,
              // 属性lineStyle控制线条样式
              lineStyle: {
                width: 20,
                // color: [[1, '#63869e']]
                color: [[1, '#EDEFF2']]
              }
            },
            // 分隔线样式。
            splitLine: {
              show: false
            },
            // 刻度样式。
            axisTick: {
              show: false
            },
            // 刻度标签。
            axisLabel: {
              show: true,
              color: 'rgb(36, 202, 228)'
            },
            // 仪表盘指针。
            pointer: {
              show: true,
              // 指针长度
              length: '90%'
              // width: 15
            },
            // 仪表盘标题。
            title: {
              // 其余属性默认使用全局文本样式，详见TEXTSTYLE
              fontWeight: 'bolder',
              fontSize: 20,
              color: 'rgb(36, 202, 228)'
              // 文字倾斜样式
            },
            // 仪表盘详情，用于显示数据。
            detail: {
              show: true,
              offsetCenter: [0, '60%'],
              formatter: '{value}MB/s',
              fontSize: 30,
              color: 'rgb(36, 202, 228)'
            },
            data: [
              {
                value: download.toFixed(2)
              }
            ]
          }
        ]
      };
      // 基于准备好的dom，初始化echarts实例
      // 使用刚指定的配置项和数据显示图表。
      var color = [[download / maxValue, 'rgb(36, 202, 228)'], [1, '#EDEFF2']];
      option.series[0].axisLine.lineStyle.color = color;
      this.gaugeChart.setOption(option, true);
    },

    // 下载
    refreshDownloadSpeed() {
      const speeds = this.downloadSpeeds.map(speed => speed / (1024 * 1024));
      let optionDownload = {
        xAxis: {
          // interval: 24 * 60 * 60 * 100,
          type: 'category',
          axisLine: {
            show: true
          },
          axisTick: {
            show: false
          }
        },
        yAxis: {
          // minInterval: 1,
          type: 'value',
          show: true,
          axisLabel: {
            margin: 10,
            fontSize: 15
          },
          scale: true, // 自适应
          axisLine: {
            show: false,
            lineStyle: { color: '#ccc' }
          },
          axisTick: {
            // show: true
            inside: true
          },
          splitLine: {
            show: true,
            lineStyle: {
              type: 'dashed'
            }
          },
          boundaryGap: [0, 0.1]
        },
        grid: {
          left: 65
        },

        series: [
          {
            symbol: 'none',
            data: speeds,
            type: 'line',
            smooth: true,
            color: 'rgb(36, 202, 228)'
          }
        ]
      };
      this.netWorkDownload.setOption(optionDownload, true);
    },
    // 上传
    refreshUploadSpeed() {
      const speeds = this.uploadSpeeds.map(speed => speed / (1024 * 1024));
      let optionUpload = {
        xAxis: {
          type: 'category',
          axisLine: {
            show: true
          },
          axisTick: {
            show: false
          }
        },
        yAxis: {
          type: 'value',
          show: true,
          axisLabel: {
            margin: 10,
            fontSize: 15
          },
          scale: true,
          axisLine: {
            show: false,
            lineStyle: { color: '#ccc' }
          },
          axisTick: {
            // show: false
            inside: true
          },
          splitLine: {
            show: true,
            lineStyle: {
              type: 'dashed'
            }
          },
          boundaryGap: [0, 0.1]
        },
        grid: {
          left: 65
        },
        series: [
          {
            symbol: 'none',
            data: speeds,
            type: 'line',
            smooth: true,
            color: 'rgb(36, 202, 228)'
          }
        ]
      };
      this.netWorkUpload.setOption(optionUpload, true);
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      //
    });
  },
  destroyed() {
    //
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less' scoped>
// 动画效果样式
@keyframes an-ripple {
  75% {
    transform: scale(0.8);
    -webkit-transform: scale(0.8);
    opacity: 1;
  }

  100% {
    transform: scale(1);
    -webkit-transform: scale(1);
    opacity: 1;
  }
}
.me-networkspeedmmeasurement {
  height: 100%;
  width: 100%;
  overflow-y: hidden;
  overflow-x: hidden;
  &-div {
    display: flex;
    color: black;

    &-left {
      position: relative;
      float: left;
      width: 400px;
      // 测试按钮样式
      &-dot {
        // float: left;
        cursor: pointer;
        position: relative;
        margin: 100px auto;
        margin-bottom: 10px;
        width: 390px;
        height: 390px;
        background: linear-gradient(to right, #00d2fa, rgb(36, 202, 228), rgb(16, 189, 241));
        opacity: 0.6;

        border-radius: 50%;
        animation-timing-function: ease; /*动画频率，和transition-timing-function是一样的*/
        animation: an-ripple /*动画样式名称*/ 2s /*动画时间*/ linear /*线性运动*/ infinite
          /*无限播放*/ alternate /*往返动画*/;
        &-startTest {
          position: absolute;
          left: 38%;
          top: 47%;
          color: #fff;
          font-size: 24px;
        }
      }
      &-buttonStyle {
        text-align: center;
      }
      // 开始测速按钮
      &-button {
        width: 200px;
        height: 40px;
        margin-left: 100px;
        background: rgb(36, 202, 228);
        border-radius: 15px;
        border: none;
        box-shadow: none;
        border: 1px solid rgb(36, 202, 228);
        color: #fff;
        &:hover {
          background: #fff;
          opacity: 0.8;
          color: rgb(36, 202, 228);
          cursor: pointer;
        }
      }
    }
    // 下载速率样式
    &-right {
      width: 550px;
      height: 100%;
      margin-top: 80px;
      margin-left: 86px;
      color: black;
      &-top {
        display: flex;
      }
      &-center {
        display: flex;
      }
      &-bottom {
        display: flex;
        font-size: 18px;
        > p {
          margin-right: 82px;
        }
      }
    }
  }
}
</style>
