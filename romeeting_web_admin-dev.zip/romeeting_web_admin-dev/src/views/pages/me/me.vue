<template>
  <div class="me-content">
    <TitleBar :name="titleBarName" />
    <div class="me-content-body">
      <Layout style="height: 100%">
        <Sider :width='230'
               style="height: 100%; background: #f6f7f8; padding-top: 30px;">
          <Menu active-name="1"
                theme="light"
                width="230px"
                style="background: #f6f7f8;"
                @on-select="onSelect">
            <MenuItem name="1"
                      class="me-content-body-menu">{{$t('me_device_binding')}}</MenuItem>
            <MenuItem name="2"
                      class="me-content-body-menu">{{$t('me_attendee')}}</MenuItem>
            <MenuItem name="3"
                      class="me-content-body-menu">{{$t('me_account_security')}}</MenuItem>
            <MenuItem name="4"
                      class="me-content-body-menu">网络测速</MenuItem>
            <MenuItem name="5"
                      class="me-content-body-menu">{{$t('me_help')}}</MenuItem>
          </Menu>
        </Sider>
        <Content :style="{padding: '30px 48px', minHeight: '280px', background: '#fff'}">
          <DeviceTable :value="showDevices" />
          <AttendeeTable :value="showAttendee" />
          <AccountTable :value="showAccount" />
          <Help :value="showHelp" />
          <NetworkSpeedmMeasurement :value="showNetworkSpeedmMeasurement"/>
        </Content>
      </Layout>
    </div>

  </div>
</template>

<script>
import { Layout, Sider, Menu, MenuItem, Content } from 'view-design';
import TitleBar from '../components/title-bar';
import DeviceTable from './components/device-table';
import AttendeeTable from './components/attendee-table';
import AccountTable from './components/account-table';
import Help from './components/help';
import NetworkSpeedmMeasurement from './components/network-speed-measurement';
export default {
  // 不要忘记了 name 属性
  name: 'Me',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
  },
  // 变量
  data() {
    return {
      titleBarName: this.$t('me_title'),
      showDevices: true,
      showAttendee: false,
      showAccount: false,
      showHelp: false, // 是否显示帮助页面
      showNetworkSpeedmMeasurement: false
    };
  },

  // 使用其它组件
  components: {
    TitleBar,
    Layout,
    Sider,
    Menu,
    MenuItem,
    Content,
    DeviceTable,
    AttendeeTable,
    AccountTable,
    Help,
    NetworkSpeedmMeasurement
  },
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    // 点击菜单切换内容
    onSelect(name) {
      switch (name) {
        case '1':
          this.showDevices = true;
          this.showAttendee = false;
          this.showAccount = false;
          this.showHelp = false;
          this.showNetworkSpeedmMeasurement = false;
          break;

        case '2':
          this.showAttendee = true;
          this.showDevices = false;
          this.showAccount = false;
          this.showHelp = false;
          this.showNetworkSpeedmMeasurement = false;
          break;

        case '3':
          this.showAccount = true;
          this.showAttendee = false;
          this.showDevices = false;
          this.showHelp = false;
          this.showNetworkSpeedmMeasurement = false;
          break;

        case '4':
          this.showNetworkSpeedmMeasurement = true;
          this.showAccount = false;
          this.showAttendee = false;
          this.showDevices = false;
          this.showHelp = false;
          break;

        case '5':
          this.showHelp = true;
          this.showAccount = false;
          this.showAttendee = false;
          this.showDevices = false;
          this.showNetworkSpeedmMeasurement = false;
          break;
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.me-content {
  width: 100%;
  height: 100%;

  &-body {
    height: ~'calc(100% - 64px)';
    padding: 0;
    background: #35383a;

    &-menu {
      font-size: 16px;
      height: 36px;
      line-height: 36px;
    }
  }
}
</style>
