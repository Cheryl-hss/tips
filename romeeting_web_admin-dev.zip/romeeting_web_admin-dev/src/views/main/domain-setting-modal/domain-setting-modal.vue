<template>
  <div v-if="value">
    <Modal class="domain-setting"
           :value="value"
           :mask-closable="false"
           :width="500"
           footer-hide
           @on-visible-change="onChange">
      <p slot="header"
         class="header">
        <span>{{ $t('meeting_domain_setting') }}</span>
      </p>
      <div slot="close"
           @click="onClose"
           class="margin-right">
        <Icon type="ios-close"
              :size="35"
              color="#999999" />
      </div>
      <div class="domain-setting-body">
        <Input v-model="domain"
               placeholder="romeeting.royole.com">
        <Select v-model="selectDomain"
                slot="prepend"
                style="width: 80px">
          <Option value="http://">http://</Option>
          <Option value="https://">https://</Option>
        </Select>
        </Input>
        <div class="domain-setting-body-text">{{ $t('meeting_domain_input') }}</div>
      </div>
      <div class="domain-setting-footer">
        <div class="domain-setting-footer-button">
          <Button class="button-width margin-right"
                  style="width: 92px"
                  @click="onClose">取消</Button>
          <Button v-if="domain"
                  class="button-width"
                  style="width: 92px"
                  type="primary"
                  @click="onOk">确定</Button>
          <Button v-else
                  class="button-width"
                  style="width: 92px"
                  disabled>确定</Button>
        </div>
      </div>
    </Modal>
  </div>
</template>

<script>
import { Modal, Icon, Input, Select, Option, Button } from 'view-design';

export default {
  // 不要忘记了 name 属性
  name: 'DomainSettingModal',
  // 使用组件 mixins 共享通用功能
  mixins: [],
  // 组成新的组件，优先级高于mixins
  extends: {},
  // 组件属性、变量
  props: {
    // 按字母顺序
    value: {
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  // 变量
  data() {
    return {
      domain: '', // 域名
      selectDomain: 'https://' // 域名协议
    };
  },

  // 使用其它组件
  components: { Modal, Icon, Input, Select, Option, Button },
  // 计算属性
  computed: {},
  // 监听
  watch: {},
  // 方法
  methods: {
    // 关闭对话框
    onClose() {
      this.$emit('on-close');
    },

    onOk() {
      this.$emit('on-ok', this.selectDomain + this.domain);
    },

    // 显示状态发生变化时触发
    onChange(value) {
      if (!value) {
        this.onClose();
      }
    }
  },
  // 生命周期函数
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  }
};
</script>
<style lang='less'>
.header {
  text-align: center;
  font-family: PingFangSC-Regular;
  height: 18px;
}

.domain-setting {
  .ivu-modal-header {
    padding: 21px 22px;
  }

  .ivu-modal-body {
    padding: 24px 30px;
  }

  &-body {
    &-text {
      height: 14px;
      font-family: PingFangSC-Regular;
      font-size: 14px;
      color: #999999;
      line-height: 14px;
      font-weight: 400;
      margin-top: 16px;
    }
  }

  &-footer {
    .clearFix();
    width: 100%;
    margin-top: 84px;

    &-button {
      float: right;
    }
  }
}
</style>
