import DomainSettingModal from './domain-setting-modal';

export default DomainSettingModal;
