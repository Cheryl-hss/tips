<template>
  <Layout style="height: 100%"
          class="main">
    <Header class="header-con">
      <router-link to="/">
        <div float-left>
          <div class="title"
               @click="onClickTitle">
          </div>
        </div>
      </router-link>

      <div float-left
           class="header-menu">
        <Menu mode="horizontal"
              theme="primary"
              :active-name="$route.name">
          <MenuItem :style="{ padding: '0 34px' }"
                    name="meeting"
                    v-if="showMeetingTab"
                    to="meeting">{{$t('meeting')}}</MenuItem>
          <MenuItem name="call"
                    v-if="showCallTab"
                    to="call"> {{$t('call')}}</MenuItem>
          <MenuItem name="me"
                    to="me"> {{$t('me')}}</MenuItem>
        </Menu>
      </div>
      <div float-right
           :style="{color: '#FFFFFF'}">
        <div class="flex">

          <div class="message">

            <Dropdown trigger="click"
                      placement="bottom-start"
                      @on-click="onNotificationItem"
                      @on-visible-change="onVisibleChange">
              <div class="pointer">
                <div float-left
                     class="margin-right"></div>
                <Badge float-left
                       class="notifications"
                       :count="countUnread">
                  <div class="notifications-icon">
                    <img src="~@/assets/images/icon-notifications@2x.png" />
                  </div>
                </Badge>
              </div>
              <DropdownMenu slot="list"
                            class="mess-posi">
                <DropdownItem class="msg"
                              disabled>
                  <div class="msg-icon">
                    <img src="~@/assets/images/icon-notifications-small@2x.png" />
                  </div>
                  <div class="msg-text">消息</div>
                </DropdownItem>
                <div class="msg-body">
                  <div v-if="countUnread === 0"
                       class="no-message">
                    <div class="no-message-icon">
                      <img src="~@/assets/images/no-msg@2x.png" />
                    </div>
                    <div class="no-message-text">暂无消息</div>
                  </div>
                  <div v-else
                       v-for='(meeting) in unreadMeetingChats.meetings'
                       :key="'meeting_'+meeting.id">
                    <DropdownItem :name="'msg_' + meeting.id + '_' + device.id"
                                  v-for='(device) in meeting.devices'
                                  v-if="device.chats && device.chats.length >0"
                                  :key="'device_'+device.id">
                      <div class="msg-list">
                        <div class="msg-list-item">
                          <div class="msg-list-header ellipsis">{{meeting.name}}</div>
                          <div class="msg-list-body">
                            <div class="msg-list-name ellipsis">{{device.person.name}}</div>
                            <Badge :count="device.chats.length" />
                          </div>
                          <div class="msg-list-content">
                            <div class="msg-list-content-text ellipsis">
                              {{ latestMsgContent(device.chats) }}
                            </div>
                            <div class="msg-list-time">
                              {{ latestMsgTime(device.chats) }}
                            </div>
                          </div>
                        </div>
                      </div>
                    </DropdownItem>
                  </div>

                </div>

              </DropdownMenu>
            </Dropdown>

          </div>
          <Dropdown placement="bottom-start"
                    @on-click="onClickAvatar">
            <div class="pointer">
              <div float-left
                   class="margin-right">{{ username }}</div>
              <Avatar class="avatar"
                      :src="userAvator" />
            </div>
            <DropdownMenu slot="list"
                          class="avatar-dropdown">
              <DropdownItem name="me">
                个人中心
              </DropdownItem>
              <DropdownItem name="logout"
                            divided>
                退出登录
              </DropdownItem>
            </DropdownMenu>
          </Dropdown>
        </div>

      </div>
    </Header>

    <Content class="main-content-con">
      <Layout class="main-layout-con">
        <Content class="content-wrapper">
          <keep-alive :include="cacheList">
            <router-view :show-meeting-list="showMeetingList" />
          </keep-alive>
        </Content>
      </Layout>
    </Content>
    <DomainSettingModal :value="showDomainSettingModal"
                        @on-close="closeDomainSettingModal"
                        @on-ok="onOk" />
  </Layout>
</template>
<script>
import {
  Menu,
  MenuItem,
  Header,
  Layout,
  Content,
  Row,
  Col,
  Avatar,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  Badge
} from 'view-design';
import DomainSettingModal from './domain-setting-modal';

import { mapMutations, mapActions } from 'vuex';
import { getNewTagList, getNextRoute, routeEqual } from '@/utils/util';
import './main.less';
import config from '@/config';
import AvatarIcon from '@/assets/images/avatar-default@2x.png';
import CommonApi from '@/api/common';
import MQTTClient from '@/utils/mqtt';
import CallApi from '@/api/call';
import { dateFormat } from '@/utils/tools';
import LogoIcon from '@/assets/icons/logo.png';
// import { find } from 'highcharts';
// import Vue from 'vue';
export default {
  name: 'Main',
  components: {
    Menu,
    MenuItem,
    Header,
    Layout,
    Content,
    Row,
    Col,
    Avatar,
    Dropdown,
    DropdownMenu,
    DropdownItem,
    DomainSettingModal,
    Badge
  },
  data() {
    return {
      collapsed: false,
      isFullscreen: false,
      showMeetingList: false,
      showDomainSettingModal: false, // 是否显示域名配置弹出框
      showMeetingTab: false, // 展示会议中心
      showCallTab: false // 展示呼叫中心
    };
  },
  computed: {
    countUnread() {
      return this.unreadMeetingChats && this.unreadMeetingChats.totalUnreadNum
        ? this.unreadMeetingChats.totalUnreadNum
        : 0;
    },

    mqtt() {
      return this.$store.state.mqtt;
    },

    userInfo() {
      return this.$store.state.user;
    },

    unreadMeetingChats() {
      return this.$store.state.unreadMeetingChats || {};
    },

    nowDialogue() {
      return this.$store.state.nowDialogue;
    },

    meetingDatail() {
      return this.$store.state.meetingDatail;
    },

    meetingList() {
      return this.$store.state.meetingList;
    },

    breadCrumbList() {
      return this.$store.state.app.breadCrumbList;
    },

    tagNavList() {
      return this.$store.state.app.tagNavList;
    },

    tagRouter() {
      return this.$store.state.app.tagRouter;
    },

    userAvator() {
      return (
        this.$store.state.user.iconUrl || AvatarIcon
        // 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif?imageView2/1/w/80/h/80'
      );
    },

    username() {
      return this.$store.state.user.username;
    },

    cacheList() {
      return this.tagNavList.length
        ? this.tagNavList.filter(item => !(item.meta && item.meta.notCache)).map(item => item.name)
        : [];
    },

    menuList() {
      return this.$store.getters.menuList;
    },

    local() {
      return this.$store.state.app.local;
    },

    appID() {
      return this.$store.state.app.appID;
    }
  },
  methods: {
    ...mapMutations(['setBreadCrumb', 'setTagNavList', 'setLocale', 'setAppID']),
    ...mapActions(['handleLogin', 'handleLogOut']),

    turnToPage(route) {
      let { name, params, query } = {};
      if (typeof route === 'string') {
        name = route;
      } else {
        name = route.name;
        params = route.params;
        query = route.query;
      }
      if (name.indexOf('isTurnByHref_') > -1) {
        window.open(name.split('_')[1]);
        return;
      }
      this.$router.push({
        name,
        params,
        query
      });
    },

    handleCloseTag(res, type, route) {
      let openName = '';
      if (type === 'all') {
        this.turnToPage(config.homeName);
        openName = config.homeName;
      } else if (routeEqual(this.$route, route)) {
        if (type === 'others') {
          openName = route.name;
        } else {
          const nextRoute = getNextRoute(this.tagNavList, route);
          this.$router.push(nextRoute);
          openName = nextRoute.name;
        }
      }
      this.setTagNavList(res);
      this.$refs.sideMenu.updateOpenName(openName);
    },

    handleCollapsedChange(state) {
      this.collapsed = state;
    },

    handleClick(item) {
      this.turnToPage(item);
    },

    turnToHome() {
      this.$router.push('/');
    },

    onSiderBreakpoint(value) {
      this.collapsed = value;
    },

    onClickTitle() {
      this.showMeetingList = !this.showMeetingList;
    },

    onClickAvatar(name) {
      const user = JSON.parse(localStorage.getItem('userInfo'));
      const token = user.token;
      const userId = user.userId;

      switch (name) {
        case 'me':
          this.$router.push('/me');
          break;
        case 'logout':
          this.handleLogOut({ token }).then(() => {
            this.mqtt && this.mqtt.unsubscribe(userId);
            this.$router.push({
              name: 'login'
            });
          });
          break;
      }
    },

    // 关闭设置主机模态框
    closeDomainSettingModal() {
      this.showDomainSettingModal = false;
    },
    // 提交设置主机域名
    onOk(value) {
      const vm = this;
      const params = { value };
      CommonApi.setConfigHost(params)
        .fetch()
        .then(({ success, msg, data }) => {
          if (success) {
            // 把设置成功的域名存储到localStorage里
            const userInfo = JSON.parse(localStorage.getItem('userInfo'));
            userInfo.host = value;
            localStorage.setItem('userInfo', JSON.stringify(userInfo));
            vm.$Message.destroy();
            vm.$Message.success({
              content: '设置成功！',
              duration: 5,
              closable: true
            });
            vm.showDomainSettingModal = false;
          } else {
            vm.$Message.destroy();
            vm.$Message.error({
              content: '设置失败！',
              duration: 5,
              closable: true
            });
          }
        })
        .catch(error => {
          vm.$Message.destroy();
          vm.$Message.error({
            content: error || '设置失败！',
            duration: 5,
            closable: true
          });
        });
    },
    alertNotice(meetingId, title, msg) {
      this.$Notice.warning({
        title: title,
        desc: msg,
        duration: 2
      });
      const notify = () => {
        const notification = new Notification(title, {
          dir: 'auto',
          lang: 'hi',
          requireInteraction: true,
          icon: LogoIcon,
          body: msg
        });
        notification.onclick = event => {
          this.$router.replace({
            name: 'meeting',
            query: {
              meetingId: meetingId,
              timestamp: new Date().getTime()
            }
          });
          window.focus();
        };
      };
      if (Notification.permission === 'granted') {
        notify();
      } else {
        // 请求权限
        Notification.requestPermission(perm => {
          if (perm === 'granted') {
            notify();
          }
        });
      }
    },
    onNewMessage() {
      const _this = this;
      this.$root.eventHub.$on('MQTT_MSG', event => {
        // 处理 EndMeeting 相关的消息
        if (event.topic.indexOf('/NOTIFY') !== -1) {
          const message = event.msg;
          const msg = JSON.parse(message);

          switch (msg.notify.type) {
            case 'EndMeeting':
              // 清除未读消息
              if (_this.unreadMeetingChats && _this.unreadMeetingChats.meetings) {
                const meeting = _this.unreadMeetingChats.meetings.find(meeting => {
                  return meeting.id === msg.notify.meetingId;
                });
                meeting &&
                  meeting.devices.forEach(device => {
                    if (device.chats) {
                      _this.unreadMeetingChats.totalUnreadNum -= device.chats.length;
                    }
                  });
              }
              break;
            case 'Alert':
              this.alertNotice(
                msg.notify.meetingId,
                msg.notify.data.title,
                msg.notify.data.content
              );
              break;
            default:
              break;
          }
          return;
        }
        // 只处理chat相关的消息
        if (event.topic.indexOf('/chat') === -1) {
          return;
        }
        const message = event.msg;
        const msg = JSON.parse(message);
        if (
          window.localStorage.getItem(msg.msgId + ':' + msg.data.mId) &&
          msg.data.type !== 'Resp'
        ) {
          // window.console.log('重复消息===>', msg);
          return;
        }
        window.localStorage.setItem(msg.msgId + ':' + msg.data.mId, true);
        if (msg.data.type === 'Resp') {
          // 收到应答消息，是当前打开的会议的消息, 直接更新消息状态
          if (_this.meetingDatail && msg.data.mId === _this.meetingDatail.id) {
            for (const dIndex in _this.meetingDatail.devices) {
              const device = _this.meetingDatail.devices[dIndex];
              if (msg.data.chatId === device.person.id + '') {
                const chats = device.chats;
                for (const index in chats) {
                  const oldMsg = JSON.parse(chats[index].msg);
                  if (oldMsg.msgId === msg.msgId) {
                    if (chats[index].status === 'Unread') {
                      msg.data.content === 'Read' && (chats[index].status = msg.data.content);
                    } else if (chats[index].status === 'Sent') {
                      (msg.data.content === 'Unread' || msg.data.content === 'Read') &&
                        (chats[index].status = msg.data.content);
                    } else if (chats[index].status === 'Sending') {
                      chats[index].status = msg.data.content;
                    }
                    break;
                  }
                }
                break;
              }
            }
          }
        } else {
          const chat = {
            subId: _this.userInfo.userId,
            status: 'Unread',
            msg: message
          };
          // _this.showNotice(msg.data.mId, msg.data.content);
          /**
           * 更新全局未读消息
           */
          let isRefresh = true;
          if (_this.unreadMeetingChats && _this.unreadMeetingChats.meetings) {
            _this.unreadMeetingChats.meetings.forEach(meeting => {
              if (meeting.id === msg.data.mId) {
                meeting.devices.forEach(device => {
                  if (device.person.id + '' === msg.data.chatId) {
                    // 不需要刷新列表,  加入 newMessage
                    isRefresh = false;
                    _this.unreadMeetingChats.totalUnreadNum
                      ? _this.unreadMeetingChats.totalUnreadNum++
                      : (_this.unreadMeetingChats.totalUnreadNum = 1);
                    device.chats ? device.chats.push(chat) : (device.chats = [chat]);
                  }
                });
              }
            });
          }
          if (isRefresh) {
            // 如果有新的未读数据刷新，则先更新未读消息
            _this.refreshUnreadChats().then(() => {
              _this.refreshMeetingChats(msg.data.chatId, msg.data.mId, chat, msg.data.content);
            });
          } else {
            _this.refreshMeetingChats(msg.data.chatId, msg.data.mId, chat, msg.data.content);
          }
          _this.mqtt.respUnread(msg);
          _this.$forceUpdate();
        }
      });
    },

    onConnectionLost(response) {
      // window.console.log('onConnectionLost:' + response);
      const _this = this;
      window.setTimeout(() => {
        const userInfo = JSON.parse(localStorage.getItem('userInfo'));
        // eslint-disable-next-line no-undef
        _this.mqttConnect(userInfo.userId);
      }, 100);
    },

    // called when a message arrives
    onMessageArrived(message) {
      // window.console.log(
      //   'Got message from topic <' + message.topic + '>',
      //   'Message:',
      //   message.payloadString
      // );
      // 将收到的消息分发
      this.$root.eventHub.$emit('MQTT_MSG', {
        topic: message.topic,
        msg: message.payloadString
      });

      this.$store.commit('setValue', { key: 'newStatus', value: true });
    },

    mqttConnect(userId) {
      CommonApi.getMQTTConfig()
        .fetch()
        .then(res => {
          if (res.success) {
            const mqttConfig = res.data;
            this.$mqtt = new MQTTClient({
              port: mqttConfig.port,
              userId: userId,
              timestamp: res.timestamp
            });
            this.$mqtt.connect({
              password: mqttConfig.password,
              useSSL: mqttConfig.ssl,
              onSuccess: () => {
                // Once a connection has been made, make a subscription and send a message.
                // window.console.log('bruce onConnect');
                this.$mqtt.subscribe(userId); // 订阅自己，可以接受别人发过来的消息
                this.$store.commit('setValue', { key: 'mqtt', value: this.$mqtt });
              },
              onFailure: message => {
                // window.console.log('client failure: ', message);
              }
            });
            this.$mqtt.onConnectionLost = this.onConnectionLost;
            this.$mqtt.onMessageArrived = this.onMessageArrived;
          } else {
            this.$Message.destroy();
            this.$Message.error({
              content: res.msg,
              duration: 5,
              closable: true
            });
          }
        });
    },

    refreshUnreadChats() {
      return new Promise((resolve, reject) => {
        CallApi.getUnreadChats()
          .fetch()
          .then(res => {
            if (res.success) {
              // window.console.log(res);
              this.$store.commit('setValue', {
                key: 'unreadMeetingChats',
                value: res.data
              });
            } else {
              this.$Message.destroy();
              this.$Message.error({
                content: res.msg,
                duration: 5,
                closable: true
              });
            }
            resolve();
          })
          .catch(err => {
            // window.console.log(err);
            this.$Message.destroy();
            this.$Message.error({
              content: '获取未读信息列表失败！',
              duration: 5,
              closable: true
            });
            reject(err);
          });
      });
    },

    refreshMeetingChats(chatId, mId, chat, content) {
      if (this.unreadMeetingChats) {
        // show notice
        const person = this.unreadMeetingChats.meetings
          .find(meeting => {
            return meeting.id === mId;
          })
          .devices.find(device => {
            return device.person.id + '' === chatId;
          }).person;
        this.showNotice(mId, person, content);
      }
      this.meetingList &&
        this.meetingList.forEach(meeting => {
          if (mId === meeting.id) {
            if (!meeting.stat) {
              meeting['stat'] = {
                unreadNum: 0
              };
            }
            meeting.stat.unreadNum++;
          }
        });
      /**
       * 更新到会议消息列表, 检查是否是当前chat-window的消息，
       * 若是, 加入当前Dialogue
       */
      if (this.nowDialogue && chatId === this.nowDialogue.person.id + '') {
        if (!this.nowDialogue.chats) {
          this.nowDialogue.chats = [];
        }
        this.nowDialogue.chats.push(chat);
      } else {
        // 更新会议消息
        if (this.meetingDatail && mId === this.meetingDatail.id) {
          // 是当前打开的会议的消息
          this.$root.eventHub.$emit('REFRESH_MEETING_CHAT_NOTIFY', { chatId, chat });
        }
      }
    },

    showNotice(meetingId, person, msg) {
      this.$Notice.info({
        title: person.name,
        desc: msg,
        duration: 2
      });
      const notify = () => {
        const notification = new Notification(person.name, {
          dir: 'auto',
          lang: 'hi',
          requireInteraction: true,
          icon: LogoIcon,
          body: msg
        });
        notification.onclick = event => {
          this.$router.replace({
            name: 'call',
            query: {
              meetingId: meetingId,
              timestamp: new Date().getTime()
            }
          });
          window.focus();
        };
      };
      if (Notification.permission === 'granted') {
        notify();
      } else {
        // 请求权限
        Notification.requestPermission(perm => {
          if (perm === 'granted') {
            notify();
          }
        });
      }
    },

    latestMsgTime(chats) {
      const latestMsg = this.latestMsg(chats);
      return (latestMsg && dateFormat(latestMsg.timestamp, 'HH:mm')) || '';
    },

    latestMsgContent(chats) {
      const latestMsg = this.latestMsg(chats);
      return latestMsg && latestMsg.data.content;
    },

    latestMsg(chats) {
      return chats && chats.length > 0 && JSON.parse(chats[chats.length - 1].msg);
    },

    // 点击小铃铛菜单项消息触发
    onNotificationItem(name) {
      const strs = name.split('_');
      const meetingId = strs[1];
      const dId = strs[2];
      // window.console.log('onNotificationItem===', name);
      this.$router.replace({
        name: 'call',
        query: {
          meetingId: meetingId,
          dId: dId,
          timestamp: new Date().getTime()
        }
      });
    },

    // 点击小铃铛触发：重新刷新未读消息
    // 按Esc也会触发
    onVisibleChange(visible) {
      if (visible) {
        // 刷新未读消息列表
        this.refreshUnreadChats();
      }
    }
  },

  watch: {
    $route(newRoute) {
      this.setBreadCrumb(newRoute.matched);
      this.setTagNavList(getNewTagList(this.tagNavList, newRoute));
    },

    collapsed(val) {
      this.$store.state.app.collapsed = val;
    }
  },

  beforeMount() {
    // 监听新chat消息
    this.onNewMessage();
    let userInfo = JSON.parse(localStorage.getItem('userInfo'));
    this.mqttConnect(userInfo.userId);
  },

  mounted() {
    // called when the client loses its connection

    /**
     * @description 初始化设置面包屑导航和标签导航
     */
    this.setTagNavList();
    this.setBreadCrumb(this.$route.matched);
    // 设置初始语言
    this.setLocale(this.$i18n.locale);
    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
      const host = JSON.parse(localStorage.getItem('userInfo')).host;
      var auth = JSON.parse(localStorage.getItem('userInfo')).auth;
      if (auth.indexOf('meeting') > -1) {
        this.showMeetingTab = true;
      }
      if (auth.indexOf('call') > -1) {
        this.showCallTab = true;
      }
      // const host = 'userInfo';
      if (!host) {
        this.showDomainSettingModal = true;
      }
    });
  },
  created() {
    // 初始未读消息列表
    this.refreshUnreadChats();
  }
};
</script>

<style lang='less'>
.ivu-dropdown {
  .ivu-select-dropdown {
    z-index: 1191;
  }
}
.message {
  position: relative;
  height: 64px;
}

.mess-posi {
  position: absolute;
  top: 64px;
  transform: translate(-90%, -10px);
  box-shadow: 0px 4px 10px 0px rgba(204, 204, 204, 0.5);
  background: #fff;
  border-radius: 6px;
  width: 240px;
  height: 300px;

  li {
    width: 240px;
    height: auto;
    white-space: inherit;
  }

  .ivu-dropdown-item {
    padding: 0 18px;
  }
}

.msg {
  display: flex;
  padding: 14px 18px !important;
  border-bottom: 1px solid #e8e8e8;
  &-icon {
    width: 18px;
    height: 18px;

    > img {
      width: 100%;
      height: 100%;
    }
  }

  &-text {
    font-family: PingFangSC-Regular;
    font-weight: 400;
    font-style: normal;
    font-size: 14px;
    height: 18px;
    line-height: 18px;
    color: #333333;
    margin-left: 4px;
  }
}

.msg-body {
  width: 240px;
  height: 254px;
  overflow-y: auto;
  border-bottom: 1px solid #e8e8e8;
  border-radius: 6px;
  ::-webkit-scrollbar {
    display: none;
  }
}

.msg-list {
  text-rendering: optimizeLegibility;
  font-feature-settings: 'kern' 1;
  -webkit-font-feature-settings: 'kern';
  -moz-font-feature-settings: 'kern';
  -moz-font-feature-settings: 'kern=1';
  font-kerning: normal;

  &-header {
    height: 12px;
    max-width: 170px;
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #999999;
    line-height: 12px;
    font-weight: 400;
  }

  &-item {
    box-sizing: border-box;
    border-width: 0 0 1px 0;
    border-style: solid;
    border-color: rgba(242, 242, 242, 1);
    padding: 12px 0;
  }

  &-body {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex: auto;
    margin: 12px 0 8px 0;
  }

  &-name {
    height: 12px;
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #999999;
    line-height: 12px;
    font-weight: 400;
  }

  &-time {
    height: 12px;
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #999999;
    line-height: 12px;
    font-weight: 400;
    width: 32px;
  }

  &-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 12px;
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #333333;
    line-height: 12px;
    font-weight: 400;

    &-text {
      max-width: 170px;
      height: 14px;
    }
  }

  .notification-bg {
    width: 10px;
    height: 10px;
  }
}

.no-message {
  position: absolute;
  left: 50%;
  top: 42%;
  transform: translate(-50%);
  width: 56px;
  height: 62px;

  &-icon {
    width: 56px;
    height: 56px;
    padding: 7px;

    > img {
      width: 42px;
      height: 42px;
    }
  }

  &-text {
    width: 56px;
    height: 14px;
    font-family: PingFangSC-Regular;
    font-size: 14px;
    color: #bbbbbb;
    text-align: center;
    line-height: 14px;
    font-weight: 400;
  }
}

.avatar-dropdown {
  position: absolute;
  top: -5px;
  padding: 5px 0;
  box-sizing: border-box;
  box-shadow: 0 1px 6px rgba(0, 0, 0, 0.2);
  background: #fff;
  border-radius: 4px;
}
</style>
