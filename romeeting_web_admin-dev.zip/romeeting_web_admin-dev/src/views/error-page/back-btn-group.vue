<template>
  <div>
    <i-button size="large"
              type="text"
              @click="backHome">返回首页</i-button>
    <!-- <i-button size="large" type="text">返回上一页({{ second }}s)</i-button> -->
  </div>
</template>

<script>
import { Button } from 'view-design';
import './error.less';

export default {
  name: 'backBtnGroup',
  data() {
    return {
      second: 5,
      timer: null
    };
  },
  components: { 'i-button': Button },
  methods: {
    backHome() {
      this.$router.replace('/');
    },
    backPrev() {
      this.$router.go(-1);
    }
  },
  mounted() {
    // this.timer = window.setInterval(() => {
    //   if (this.second === 0) {
    //     this.backPrev();
    //   } else {
    //     this.second--;
    //   }
    // }, 1000);
  },
  beforeDestroy() {
    clearInterval(this.timer);
  }
};
</script>
