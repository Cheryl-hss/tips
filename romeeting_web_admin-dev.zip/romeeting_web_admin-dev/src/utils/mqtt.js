/**
 * 用于处理mqtt连接的类
 */

import Paho from 'paho-mqtt';

// 客户端ID前缀
const CLIENT_ID_PREFIX = 'royole_cast@@@';

// 用户名前缀
const USERNAME_PREFIX = 'Signature|royole|';

// chat Topic前缀
const CHAT_TOPIC_PREFIX = 'royole_cast/chat/';

// notify Topic
const NOTIFY_TOPIC = 'royole_cast/MEETING/{uid}/NOTIFY';

// device status Topic
const DEVICE_STATUS_TOPIC = 'royole_cast/SYS/{uid}/DEVICESTATUS';

// 设备数据变化 Topic
const DATA_CHANGE_TOPIC = 'royole_cast/SYS/{uid}/DATACHANGE';

// 默认连接配置
const DEFAULT_CONNECT_OPTIONS = {
  // userName: `Signature|royole|${this._client.clientId}`,
  // password: this.account.password,
  // useSSL: false, // 如果使用 HTTPS 加密则配置为 true
  timeout: 30,
  mqttVersion: 4,
  cleanSession: false,
  onSuccess() {
    // Once a connection has been made, make a subscription and send a message.
    // window.console.log('client onConnect');
  },
  onFailure(message) {
    window.console.error('client onFailure: ', message);
  }
};

const getUUID = () =>
  'xxxx-xxxx-xxxx-xxxx-xxxx'.replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });

/**
 * 用于生成 mqtt 连接的 clientId
 * @param {String} uid 用户ID，可以是动态的
 * @returns {String} clientId
 */
const getRealClientID = uid => CLIENT_ID_PREFIX + (uid || '') + '(' + new Date().getTime() + ')';

const getNotifyTopic = uid => NOTIFY_TOPIC.replace('{uid}', uid);

const getDeviceStatusTopic = uid => DEVICE_STATUS_TOPIC.replace('{uid}', uid);

const getDataChangeTopic = uid => DATA_CHANGE_TOPIC.replace('{uid}', uid);

/**
 * 获取完整的订阅/发送 topic
 * @param {String} topic 订阅/发送目标名
 * @returns {String} 完整的 topic
 */
const getChatTopic = topic => {
  if (!topic || typeof topic !== 'string') {
    throw new Error('topic is required and must be a string');
  }

  // window.console.log('topic', CHAT_TOPIC_PREFIX + topic);
  return CHAT_TOPIC_PREFIX + topic;
};

/**
 * 获取完整的用于连接的用户名
 * @param {String} userId 用户ID
 * @returns {String} 完整的连接用户名
 */
const getRealUsername = userId => {
  if (!userId || typeof userId !== 'string') {
    throw new Error('clientId is required and must be a string');
  }
  return USERNAME_PREFIX + userId;
};

export default class MQTTClient {
  constructor({ host, port, userId, timestamp }) {
    this.host = host || location.hostname === 'localhost' ? '10.0.100.84' : location.hostname;
    this.port = port;
    this.path = '';
    this.userId = userId || 'web_default_uid' + getUUID();
    this.clientId = getRealClientID(this.userId);
    this.timeDelta = (timestamp || new Date().getTime()) - new Date().getTime();
    // window.console.log(this.host, this.port, this.path);
    this._client = new Paho.Client(this.host, this.port, this.path, this.clientId);

    Object.defineProperties(this, {
      onConnected: {
        get: () => {
          return this._client.onConnected;
        },
        set: newOnConnected => {
          this._client.onConnected = newOnConnected;
        }
      },
      onConnectionLost: {
        get: () => {
          return this._client.onConnectionLost;
        },
        set: newOnConnectionLost => {
          this._client.onConnectionLost = newOnConnectionLost;
        }
      },
      onMessageDelivered: {
        get: () => {
          return this._client.onMessageDelivered;
        },
        set: newOnMessageDelivered => {
          this._client.onMessageDelivered = newOnMessageDelivered;
        }
      },
      onMessageArrived: {
        get: () => {
          return this._client.onMessageArrived;
        },
        set: newOnMessageArrived => {
          this._client.onMessageArrived = newOnMessageArrived;
        }
      }
    });
    return this;
  }

  /**
   * 连接
   * @param {Object} options
   */
  connect(options) {
    if (!options && !options.password) {
      throw new Error('connect requires a password in options');
    }

    return (
      this._client &&
      this._client.connect(
        Object.assign({}, DEFAULT_CONNECT_OPTIONS, options, {
          userName: getRealUsername(this.userId)
        })
      )
    );
  }

  /**
   * 断开连接
   * @returns {void}
   */
  disconnect() {
    return this._client && this._client.disconnect();
  }

  /**
   *  发送消息
   * @param {String} target 目标对象ID
   * @param {String} message 消息
   * @returns {void}
   */
  send(message, target) {
    if (this._client) {
      if (!target) {
        throw Error('send method requires a target in options');
      }

      if (!message) {
        window.console.error('There is nothing to send');
        return;
      }

      const msg = new Paho.Message(message);
      msg.destinationName = getChatTopic(target);
      return this._client.send(msg);
    }
  }

  /**
   * 订阅方法
   * @param {String} userId
   * @param {any} subscribeOptions 订阅配置
   */
  subscribe(userId, subscribeOptions) {
    const topics = [
      getChatTopic(userId),
      getNotifyTopic(userId),
      getDeviceStatusTopic(userId),
      getDataChangeTopic(userId)
    ];
    return this._client && this._client.subscribe(topics, subscribeOptions);
  }

  /**
   * 取消订阅方法
   * @param {String} userId 订阅对象ID
   * @param {any} subscribeOptions 订阅配置
   */
  unsubscribe(userId, subscribeOptions) {
    const topics = [getChatTopic(userId), getNotifyTopic(userId)];
    return this._client && this._client.unsubscribe(topics, subscribeOptions);
  }

  /**
   * 判断MQTT是否连接上了
   * @returns {Boolean}
   */
  isConnected() {
    return !!(this._client && this._client.isConnected());
  }

  resp(msg, status) {
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));
    const response = JSON.stringify({
      msgId: msg.msgId, // 消息ID, 如果是Resp类消息，则msgId和接收到的msgId一样
      timestamp: new Date().getTime() + this.timeDelta,
      msgCode: 0,
      data: {
        type: 'Resp',
        mId: msg.data.mId, // 会议ID
        chatId: userInfo.userId,
        content: status
      }
    });
    this.send(response, msg.data.chatId);
  }

  respUnread(msg) {
    if (new Date().getTime() + this.timeDelta - msg.timestamp > 10000) {
      // 时间超过10s不响应
      return;
    }
    this.resp(msg, 'Unread');
  }

  respRead(msg) {
    this.resp(msg, 'Read');
  }

  chat(subId, meetingId, content) {
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));
    const message = JSON.stringify({
      msgId: getUUID(),
      timestamp: new Date().getTime() + this.timeDelta, // 消息发送时间戳
      msgCode: 0,
      data: {
        type: 'Text', // Resp表示应答类消息
        mId: meetingId, // 会议ID
        chatId: userInfo.userId,
        content: content // 内容
      }
    });
    this.send(message, subId);
    return message;
  }

  isFailure(chat) {
    // 时间超过10s未响应
    const msg = JSON.parse(chat.msg);
    return (
      chat.status === 'Sending' && new Date().getTime() + this.timeDelta - msg.timestamp > 10000
    );
  }
}
