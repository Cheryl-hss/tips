/**
 * 自定义定时器替代 setTimeout 和 setInterval，
 * {
 *   fn: function, // 执行函数
 *   auto: boolean, // 是否自动执行
 *   interval: int, // 每次执行的时间间隔 ms
 *   limit: int, // 要执行的次数，如果 limit 为负数，则该定时器将一直执行，没有次数限制，直到定时器被销毁
 * }
 * let timer = new Timer({
 * interval: 1000,
 *  limit: 5,
 *  auto: false,
 *  fn: () => {
 *    Logger.log('run timer', timer);
 *    timer.stop();
 *  }
 * });
 * timer.start();
 */

let queue = []; // 用于存放所有的定时器

let Timer = function(options) {
  options = {
    ...{
      fn: null, // 执行函数
      auto: true, // 是否自动执行
      interval: 0, // 每次执行的时间间隔
      limit: 1 // 要执行的次数
    },
    ...options
  };

  this.fn = (typeof options.fn === 'function' && options.fn) || null;
  this.auto = (typeof options.auto === 'boolean' && options.auto) || true;
  this.interval = (typeof options.interval === 'number' && options.interval) || 0;
  this.limit = (typeof options.limit === 'number' && options.limit) || 1; // 如果 limit 为负数，则该定时器将一直执行，没有次数限制，直到定时器被销毁
  this.status = 'pending'; // 定时器状态 'pending' 等待中，'done' 结束或被销毁， 'pause' 暂停
  this.counted = 0; // 已经执行的次数
  this.id = null; // 定时器 ID

  let self = this;

  function intervalTask(fn, n) {
    let _vm = this;

    _vm.id = (function(vm) {
      return window.setInterval(() => {
        if (vm.status === 'pause') {
          // 暂停中
          return;
        }

        fn(); // 执行

        vm.counted++;

        // 如果 limit 为负数，则该定时器将一直执行，没有次数限制，直到定时器被销毁
        if (vm.limit >= 0 && vm.counted >= vm.limit) {
          // 已完成
          vm.status = 'done';
          clearInterval(vm.id);
        }
      }, n);
    })(_vm);
    queue.push(_vm.id); // 保存定时器
    return _vm.id;
  }

  // 是否自动执行
  this.auto && intervalTask.call(self, this.fn, this.interval);

  // 开始
  this.start = function() {
    if (this.id) {
      if (this.status === 'pause') {
        this.status = 'pending';
      }
    } else {
      // 定时器不存在则创建
      intervalTask.call(self, this.fn, this.interval);
    }
  };

  // 暂停
  this.stop = function() {
    if (this.id) {
      if (this.status === 'pending') {
        this.status = 'pause';
      }
    }
  };

  // 销毁
  this.destroy = function() {
    if (this.id) {
      this.status = 'done';
      clearInterval(this.id);
    }
  };
};

Timer.clear = function(id) {
  if (!id) {
    queue.forEach(item => {
      clearInterval(item);
      queue = [];
    });
  } else {
    for (let i = 0; i < queue.length; i++) {
      if (queue[i] === id) {
        clearInterval(id);
        queue.splice(i, 1);
        return;
      }
    }
  }
};
export default Timer;
