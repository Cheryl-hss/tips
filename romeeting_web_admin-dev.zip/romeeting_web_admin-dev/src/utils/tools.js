/**
 * Get the first item that pass the test
 * by second argument function
 *
 * @param {Array} list
 * @param {Function} f
 * @return {*}
 */
function find(list, f) {
  return list.filter(f)[0];
}

/**
 * Deep copy the given object considering circular structure.
 * This function caches all nested objects and its copies.
 * If it detects circular structure, use cached copy to avoid infinite loop.
 *
 * @param {*} obj
 * @param {Array<Object>} cache
 * @return {*}
 */
export const deepCopy = (obj, cache) => {
  if (cache === void 0) {
    cache = [];
  }

  // just return if obj is immutable value
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }

  // if obj is hit, it is in circular structure
  const hit = find(cache, function(c) {
    return c.original === obj;
  });
  if (hit) {
    return hit.copy;
  }

  const copy = Array.isArray(obj) ? [] : {};
  // put the copy into cache at first
  // because we want to refer it in recursive deepCopy
  cache.push({
    original: obj,
    copy: copy
  });

  Object.keys(obj).forEach(function(key) {
    copy[key] = deepCopy(obj[key], cache);
  });

  return copy;
};

export const forEach = (arr, fn) => {
  if (!arr.length || !fn) {
    return;
  }
  let i = -1;
  let len = arr.length;
  while (++i < len) {
    let item = arr[i];
    fn(item, i, arr);
  }
};

/**
 * @param {Array} arr1
 * @param {Array} arr2
 * @description 得到两个数组的交集, 两个数组的元素为数值或字符串
 */
export const getIntersection = (arr1, arr2) => {
  let len = Math.min(arr1.length, arr2.length);
  let i = -1;
  let res = [];
  while (++i < len) {
    const item = arr2[i];
    if (arr1.indexOf(item) > -1) {
      res.push(item);
    }
  }
  return res;
};

/**
 * @param {Array} arr1
 * @param {Array} arr2
 * @description 得到两个数组的并集, 两个数组的元素为数值或字符串
 */
export const getUnion = (arr1, arr2) => {
  return Array.from(new Set([...arr1, ...arr2]));
};

/**
 * @param {Array} target 目标数组
 * @param {Array} arr 需要查询的数组
 * @description 判断要查询的数组是否至少有一个元素包含在目标数组中
 */
export const hasOneOf = (targetarr, arr) => {
  return targetarr.some(_ => arr.indexOf(_) > -1);
};

/**
 * @param {String|Number} value 要验证的字符串或数值
 * @param {*} validList 用来验证的列表
 */
export function oneOf(value, validList) {
  for (let i = 0; i < validList.length; i++) {
    if (value === validList[i]) {
      return true;
    }
  }
  return false;
}

/**
 * @param {Number} timeStamp 判断时间戳格式是否是毫秒
 * @returns {Boolean}
 */
const isMillisecond = timeStamp => {
  const timeStr = String(timeStamp);
  return timeStr.length > 10;
};

/**
 * @param {Number} timeStamp 传入的时间戳
 * @param {Number} currentTime 当前时间时间戳
 * @returns {Boolean} 传入的时间戳是否早于当前时间戳
 */
const isEarly = (timeStamp, currentTime) => {
  return timeStamp < currentTime;
};

/**
 * @param {Number} num 数值
 * @returns {String} 处理后的字符串
 * @description 如果传入的数值小于10，即位数只有1位，则在前面补充0
 */
const getHandledValue = num => {
  return num < 10 ? '0' + num : num;
};

/**
 * @param {Number} timeStamp 传入的时间戳
 * @param {String} startType 要返回的时间字符串的格式类型，传入'year'则返回年开头的完整时间
 */
export const getDate = (timeStamp, startType) => {
  const d = new Date(timeStamp * 1000);
  const year = d.getFullYear();
  const month = getHandledValue(d.getMonth() + 1);
  const date = getHandledValue(d.getDate());
  const hours = getHandledValue(d.getHours());
  const minutes = getHandledValue(d.getMinutes());
  const second = getHandledValue(d.getSeconds());
  let resStr = '';
  if (startType === 'year') {
    resStr = year + '-' + month + '-' + date + ' ' + hours + ':' + minutes + ':' + second;
  } else {
    resStr = month + '-' + date + ' ' + hours + ':' + minutes;
  }
  return resStr;
};

/**
 * @param {String|Number} timeStamp 时间戳
 * @returns {String} 相对时间字符串
 */
export const getRelativeTime = timeStamp => {
  // 判断当前传入的时间戳是秒格式还是毫秒
  const IS_MILLISECOND = isMillisecond(timeStamp);
  // 如果是毫秒格式则转为秒格式
  if (IS_MILLISECOND) {
    Math.floor((timeStamp /= 1000));
  }
  // 传入的时间戳可以是数值或字符串类型，这里统一转为数值类型
  timeStamp = Number(timeStamp);
  // 获取当前时间时间戳
  const currentTime = Math.floor(Date.parse(new Date()) / 1000);
  // 判断传入时间戳是否早于当前时间戳
  const IS_EARLY = isEarly(timeStamp, currentTime);
  // 获取两个时间戳差值
  let diff = currentTime - timeStamp;
  // 如果IS_EARLY为false则差值取反
  if (!IS_EARLY) {
    diff = -diff;
  }
  let resStr = '';
  const dirStr = IS_EARLY ? '前' : '后';

  if (diff <= 59) {
    // 少于等于59秒
    resStr = diff + '秒' + dirStr;
  } else if (diff > 59 && diff <= 3599) {
    // 多于59秒，少于等于59分钟59秒
    resStr = Math.floor(diff / 60) + '分钟' + dirStr;
  } else if (diff > 3599 && diff <= 86399) {
    // 多于59分钟59秒，少于等于23小时59分钟59秒
    resStr = Math.floor(diff / 3600) + '小时' + dirStr;
  } else if (diff > 86399 && diff <= 2623859) {
    // 多于23小时59分钟59秒，少于等于29天59分钟59秒
    resStr = Math.floor(diff / 86400) + '天' + dirStr;
  } else if (diff > 2623859 && diff <= 31567859 && IS_EARLY) {
    // 多于29天59分钟59秒，少于364天23小时59分钟59秒，且传入的时间戳早于当前
    resStr = getDate(timeStamp);
  } else {
    resStr = getDate(timeStamp, 'year');
  }
  return resStr;
};

/**
 * 将 Date 转化为指定格式的String
 * 月(M)、日(d)、12小时(h)、24小时(H)、分(m)、秒(s)、周(E)、季度(q) 可以用 1-2 个占位符
 * 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
 * eg:
 *   (new Date(), "yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
 *   (new Date(), "yyyy-MM-dd E HH:mm:ss") ==> 2009-03-10 二 20:09:04
 *   (new Date(), "yyyy-MM-dd EE hh:mm:ss") ==> 2009-03-10 周二 08:09:04
 *   (new Date(), "yyyy-MM-dd EEE hh:mm:ss") ==> 2009-03-10 星期二 08:09:04
 *   (new Date(), "yyyy-M-d h:m:s.S") ==> 2006-7-2 8:9:4.18
 * @param {Date|Number} date 时间或时间戳
 * @param {String} pattern 时间格式
 * @returns {String} 相对时间字符串
 */
export const dateFormat = (date, pattern) => {
  if (!date) {
    return '';
  }
  if (typeof date !== 'number' && !(date instanceof Date)) {
    throw new Error('The first argument must be a Date or Number');
  }
  if (typeof pattern !== 'string') {
    pattern = 'yyyy-MM-dd HH:mm:ss';
  }

  typeof date === 'number' && (date = new Date(date));

  const o = {
    'M+': date.getMonth() + 1, // 月份
    'd+': date.getDate(), // 日
    'h+': date.getHours() % 12 === 0 ? 12 : date.getHours() % 12, // 小时
    'H+': date.getHours(), // 小时
    'm+': date.getMinutes(), // 分
    's+': date.getSeconds(), // 秒
    'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
    S: date.getMilliseconds() // 毫秒
  };
  const week = {
    '0': '/u65e5',
    '1': '/u4e00',
    '2': '/u4e8c',
    '3': '/u4e09',
    '4': '/u56db',
    '5': '/u4e94',
    '6': '/u516d'
  };
  if (/(y+)/.test(pattern)) {
    pattern = pattern.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
  }
  if (/(E+)/.test(pattern)) {
    pattern = pattern.replace(
      RegExp.$1,
      (RegExp.$1.length > 1 ? (RegExp.$1.length > 2 ? '/u661f/u671f' : '/u5468') : '') +
        week[date.getDay() + '']
    );
  }
  for (const k in o) {
    if (new RegExp('(' + k + ')').test(pattern)) {
      pattern = pattern.replace(
        RegExp.$1,
        RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length)
      );
    }
  }
  return pattern;
};

/**
 * @returns {String} 当前浏览器名称
 */
export const getExplorer = () => {
  const ua = window.navigator.userAgent;
  const isExplorer = exp => {
    return ua.indexOf(exp) > -1;
  };
  if (isExplorer('MSIE')) {
    return 'IE';
  } else if (isExplorer('Firefox')) {
    return 'Firefox';
  } else if (isExplorer('Chrome')) {
    return 'Chrome';
  } else if (isExplorer('Opera')) {
    return 'Opera';
  } else if (isExplorer('Safari')) {
    return 'Safari';
  }
};

/**
 * @description 绑定事件 on(element, event, handler)
 */
export const on = (function() {
  if (document.addEventListener) {
    return function(element, event, handler) {
      if (element && event && handler) {
        element.addEventListener(event, handler, false);
      }
    };
  }
  return function(element, event, handler) {
    if (element && event && handler) {
      element.attachEvent('on' + event, handler);
    }
  };
})();

/**
 * @description 解绑事件 off(element, event, handler)
 */
export const off = (function() {
  if (document.removeEventListener) {
    return function(element, event, handler) {
      if (element && event) {
        element.removeEventListener(event, handler, false);
      }
    };
  }
  return function(element, event, handler) {
    if (element && event) {
      element.detachEvent('on' + event, handler);
    }
  };
})();

/**
 * 判断一个对象是否存在key，如果传入第二个参数key，则是判断这个obj对象是否存在key这个属性
 * 如果没有传入key这个参数，则判断obj对象是否有键值对
 */
export const hasKey = (obj, key) => {
  if (key) {
    return key in obj;
  }

  let keysArr = Object.keys(obj);
  return keysArr.length;
};

/**
 * @param {*} obj1 对象
 * @param {*} obj2 对象
 * @description 判断两个对象是否相等，这两个对象的值只能是数字或字符串
 */
export const objEqual = (obj1, obj2) => {
  const keysArr1 = Object.keys(obj1);
  const keysArr2 = Object.keys(obj2);
  if (keysArr1.length !== keysArr2.length) {
    return false;
  } else if (keysArr1.length === 0 && keysArr2.length === 0) {
    return true;
  }
  /* eslint-disable-next-line */
  return !keysArr1.some(key => obj1[key] != obj2[key]);
};

/**
 * @param {*} array 数组
 * @param {*} key 对象属性的键
 * @param {*} value 对象属性的值
 * @description 根据key和其值判断此对象是否在该数组中，要求key的值类型为非对象类型, 并返回位置
 * @return 该对象在数组中的位置，不在则为 -1
 */
export const indexOfByKeyAndValue = (array, key, value) => {
  if (!Array.isArray(array) || typeof key !== 'string') {
    return -1;
  }

  for (let i = 0; i < array.length; i++) {
    if (value === array[i][key]) {
      return i;
    }
  }
  return -1;
};

/**
 * @description 从 url 中获取查询参数
 * @param {String} url url 地址，例如，http://xxx.com/test?name=haha&sex=male
 * @returns {Object}
 */
export const getQueryFromURL = url => {
  if (typeof url !== 'string') {
    return {};
  }

  try {
    url = decodeURIComponent(url); // 解码 url
  } catch (err) {
    url = url + '';
  }

  let queryStr = url.indexOf('?') > -1 ? url.substring(url.indexOf('?')) : '';
  const regExp = /([^\\?&=]+)=([\w\W]*?)(&|$)/g;
  const result = {};
  let match = [];
  while ((match = regExp.exec(queryStr)) != null) {
    try {
      result[match[1]] = decodeURIComponent(match[2]);
    } catch (error) {
      result[match[1]] = match[2];
    }
  }
  return result;
};

/**
 * @description 判断是否是正确的 url 地址
 * @param {*} url
 * @returns
 */
export const isURL = url => {
  if (typeof url !== 'string') {
    return false;
  }
  let re = new RegExp(
    '^' +
      // protocol identifier
      '(?:(?:https?|ftp)://)?' +
      // user:pass authentication
      '(?:\\S+(?::\\S*)?@)?' +
      '(?:' +
      // IP address dotted notation octets
      // excludes loopback network 0.0.0.0
      // excludes reserved space >= 224.0.0.0
      // excludes network & broacast addresses
      // (first & last IP address of each class)
      '(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])' +
      '(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}' +
      '(?:\\.(?:[1-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))' +
      '|' +
      // host name
      '(?:(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)' +
      // domain name
      '(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*' +
      // TLD identifier
      '(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))' +
      ')' +
      // port number
      '(?::\\d{2,5})?' +
      // resource path
      '(?:/\\S*)?' +
      '$',
    'i'
  );
  if (re.test(url)) {
    return true;
  }
  return false;
};

/**
 * @description 字节大小单位转换
 * @param {Number} bytes 字节数，如果单位是比特，bytes = bit/8 转换为字节后输入
 * @returns {String} 返回值字符串保留两位小数，例如：2.15 MB
 */
export const byteConvert = bytes => {
  if (isNaN(bytes)) {
    return '';
  }
  const symbols = ['bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  let exp = Math.floor(Math.log(bytes) / Math.log(2));
  if (exp < 1) {
    exp = 0;
  }
  const i = Math.floor(exp / 10);
  bytes = bytes / Math.pow(2, 10 * i);

  if (bytes.toString().length > bytes.toFixed(2).toString().length) {
    bytes = bytes.toFixed(2);
  }
  return bytes + ' ' + symbols[i];
};

/**
 * 保存到本地 localStorage
 * @param {String} key 键
 * @param {any} value 值
 * @returns {Boolean} 是否成功
 * @description 保存到本地 localStorage
 */
export const setLocalStorage = (key, value) => {
  // key 值必须为有效字符串，尽管其值的类型不限于 String，但是为了统一，还是规范下。
  if (typeof key !== 'string') {
    return false;
  }
  window.localStorage.setItem(key, typeof value === 'object' ? JSON.stringify(value) : value);
  return true;
};

/**
 * 从 localStorage 中取出保存的值
 * @param {String} key 键
 * @returns {any} value 值
 * @description 从 localStorage 中取出保存的值
 */
export const getLocalStorage = key => {
  // key 值必须为有效字符串，尽管其值的类型不限于 String，但是为了统一，还是规范下。
  if (typeof key !== 'string') {
    return;
  }
  const str = window.localStorage.getItem(key);
  try {
    return JSON.parse(str);
  } catch (error) {
    return str === 'undefined' ? undefined : str;
  }
};

/**
 * 保存到本地 sessionStorage
 * @param {String} key 键
 * @param {any} value 值
 * @returns {Boolean} 是否成功
 * @description 保存到本地 sessionStorage
 */
export const setSessionStorage = (key, value) => {
  // key 值必须为有效字符串，尽管其值的类型不限于 String，但是为了统一，还是规范下。
  if (typeof key !== 'string') {
    return false;
  }
  sessionStorage.setItem(key, typeof value === 'object' ? JSON.stringify(value) : value);
  return true;
};

/**
 * 从 sessionStorage 中取出保存的值
 * @param {String} key 键
 * @returns {any} value 值
 * @description 从 sessionStorage 中取出保存的值
 */
export const getSessionStorage = key => {
  // key 值必须为有效字符串，尽管其值的类型不限于 String，但是为了统一，还是规范下。
  if (typeof key !== 'string') {
    return;
  }
  const str = sessionStorage.getItem(key);
  try {
    return JSON.parse(str);
  } catch (error) {
    return str === 'undefined' ? undefined : str;
  }
};

/**
 * @description 返回当前input框maxLength
 * @param {String} value 输入值
 * @param {Number} CnLength 中文长度
 * @param {Number} Enlength 英文长度
 */
export const getMaxLength = (value, CnLength, Enlength) => {
  // 含有中文正则表达式
  const reg = /[\u4e00-\u9fa5]{1}/g;
  const Cn = value.match(reg);
  if (!Cn) {
    return Enlength;
  }
  return CnLength;
};

/**
 * 自定义函数名：PrefixZero
 * @param num： 被操作数
 * @param n： 固定的总位数
 */
export const PrefixZero = (num, n) => {
  return (Array(n).join(0) + num).slice(-n);
};

/**
 * @description 去掉前面后面的空格
 * @param {String} str 输入的字符串
 * @returns 输出的字符串
 */
export const getRealSendText = str => {
  if (typeof str !== 'string') {
    return '';
  }
  str = str.replace(/^[\s\n]+/gm, ''); // 去掉前面的空格和换行
  str = str.replace(/[\s\n]+$/gm, ''); // 去掉后面的空格和换行
  return str;
};
/**
 * @description 随机生成一个uuid
 * @returns {String} Uuid
 */
export const getUuid = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    let r = (Math.random() * 16) | 0;
    let v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
};
