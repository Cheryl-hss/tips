// import store from '@/store';

/**
 * @func
 * @desc 根据参数返回路由routes数组
 * @param {object[]} basicRoutes- 基本路由，用于加载用
 * @param {object[]} allRoutes- 全部应用路由
 * @param {object[]} singleRoutes- 单个应用路由
 * @return {object} 返回的结构为 {routes: object[], id: string}
 */

export default dynamicRoutes => {
  // if (!basicRoutes || !Array.isArray(basicRoutes)) {
  //   basicRoutes = [];
  // }
  // if (!allRoutes || !Array.isArray(allRoutes)) {
  //   allRoutes = [];
  // }
  // if (!singleRoutes || !Array.isArray(singleRoutes)) {
  //   singleRoutes = [];
  // }

  // let routes;
  // // let id;
  // // let matches = window.location.href.match(
  // //   /\/apps\/(?!(app_list|group_trend|authorised_apps)$)([A-Za-z0-9_]*)(\/)?/i
  // // ); // 根据 url 的格式来区分，/apps/c160103c875c89df03381e35，其中的 c160103c875c89df03381e35 为 id

  // // if (matches && matches.length) {
  // //   id = matches[2] || '';
  // // } else {
  // //   id = '';
  // // }

  // let id = store.state.app.appID;
  // let name = store.state.app.appName;

  // // id为24位的hash字符串，如：c160103c875c89df03381e35，使用单个应用路由，否则使用全部应用路由
  // if (typeof id === 'string' && /^[A-Za-z0-9_]{24}$/.test(id)) {
  //   // 修改路由中 name， 用于导航栏显示
  //   let rootRoute = singleRoutes[0] || {};
  //   let children = rootRoute.children[0] || {};
  //   children.name = name;

  //   routes = basicRoutes.concat(...singleRoutes);
  // } else {
  //   routes = basicRoutes.concat(...allRoutes);
  // }
  return dynamicRoutes;
};
