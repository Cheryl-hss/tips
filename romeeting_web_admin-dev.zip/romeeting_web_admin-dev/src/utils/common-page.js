import Logger from '@/utils/logger';

/**
 * 页面组件的父类，处理一些公共的逻辑
 */
export default {
  data() {
    return {
      title: '',
      access: []
    };
  },
  computed: {},
  // 生命周期函数
  beforeRouteEnter(to, from, next) {
    // 进入页面前
    next();
  },
  beforeCreate() {
    // 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
  },
  created() {
    // 在实例创建完成后被立即调用。在这一步，实例已完成以下的配置：数据观测 (data observer)，属性和方法的运算，watch/event 事件回调。然而，挂载阶段还没开始，el 属性目前不可见。
    this.title =
      (this.$route.meta && this.$route.meta.title) ||
      (this.$route.name && this.$t(this.$route.name)) ||
      '';
    this.access = (this.$route.meta && this.$route.meta.access) || [];

    Logger.log(
      `[${Logger.OPTIONS && Logger.OPTIONS.ENTER}]`,
      `${this.title || '--'}`,
      `[Path]`,
      this.$route.path || '--',
      `[Params]`,
      JSON.stringify(this.$route.params || {}),
      `[Query]`,
      JSON.stringify(this.$route.query || {})
    );
  },
  beforeMount() {
    // 在挂载开始之前被调用：相关的 render 函数首次被调用。
  },
  mounted() {
    // el 被新创建的 vm.el 替换，并挂载到实例上去之后调用该钩子。如果 root 实例挂载了一个文档内元素，当 mounted 被调用时 vm.el 也在文档内。

    this.$nextTick(() => {
      // Code that will run only after the
      // entire view has been rendered
    });
  },
  beforeDestroy() {
    // 实例销毁之前调用。在这一步，实例仍然完全可用。
  },
  beforeRouteLeave(to, from, next) {
    // 离开页面前
    next();
  }
};
