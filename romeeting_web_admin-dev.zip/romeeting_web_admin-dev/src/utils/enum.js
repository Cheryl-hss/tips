/**
 * 枚举值
 */

/**
 * @description ajax请求响应体里的errorCode
 * @param FAILED 失败
 * @param SUCCESS 成功
 * @param UNAUTH 未登录
 * @param LOCKED_FOR_USED 因被关联而无法被删除
 * @param MUTI_DEL_FAILED 批量删除失败
 */
export const ResponseErrorCode = {
  FAILED: -1, // 失败
  SUCCESS: 0, // 成功
  UNAUTH: 401, // 未登录
  LOCKED_FOR_USED: 2202, // 因被关联而无法被删除
  MUTI_DEL_FAILED: 1007 // 批量删除失败
};
