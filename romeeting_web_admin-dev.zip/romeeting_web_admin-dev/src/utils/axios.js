import axios from 'axios';
import { Message } from 'view-design';
import Logger from '@/utils/logger';

axios.defaults.withCredentials = true; // 用于保存 cookie，和服务器同时配置

// import { Spin } from 'view-design'
class HttpRequest {
  constructor(baseURL) {
    this.baseURL = baseURL;
    this.queue = {};
  }
  getInsideConfig() {
    let headers = {};
    const config = {
      baseURL: this.baseURL,
      headers: {
        hash: location.hash.split('?')[0],
        ...headers
      }
    };
    // 非登录接口请求头带上token，appId
    if (location.href.indexOf('/login') < 0) {
      config.headers.token = JSON.parse(localStorage.getItem('userInfo')).token;
      config.headers.appId = 'zwz3vdA7IJ';
    }
    return config;
  }
  distroy(url) {
    delete this.queue[url];
    if (!Object.keys(this.queue).length) {
      // Spin.hide()
    }
  }
  interceptors(instance, url) {
    // 请求拦截
    instance.interceptors.request.use(
      config => {
        // 这里面可以做请求数据的统一处理，进行判断跳转
        Logger.log(
          `[${Logger.OPTIONS.BEFORE_REQUEST}]`,
          `${url}`,
          `[Config]`,
          JSON.stringify({
            baseURL: config.baseURL,
            method: config.method,
            params: config.params
          })
        );

        // 添加全局的loading...
        if (!Object.keys(this.queue).length) {
          // Spin.show() // 不建议开启，因为界面不友好
        }

        this.queue[url] = true;
        return config;
      },
      error => {
        return Promise.reject(error);
      }
    );
    // 响应拦截
    instance.interceptors.response.use(
      res => {
        this.distroy(url);
        const { data } = res;

        // 这里面可以做响应数据的统一处理，进行判断跳转
        Logger.log(
          `[${Logger.OPTIONS.AFTER_RESPONSE}]`,
          `${url}`,
          `[Respose]`,
          JSON.stringify({ status: res.status, statusText: res.statusText }),
          `[Data]`,
          data
        );

        return {
          data: data.data,
          msg: data.errorMessage,
          code: data.errorCode,
          success: data.errorCode === 0,
          status: data.status,
          timestamp: data.timestamp
        };
      },
      error => {
        this.distroy(url);
        let errorData = (error && error.response) || {};
        errorData = {
          data: errorData.data,
          code: errorData.status || -1,
          msg: errorData.statusText || '请求出错，请检查网络设置，稍后刷新浏览器重试',
          success: false
        };

        if (errorData.code === 401) {
          // 无权限，跳转到统一登录页面
          Message.info({
            content: '当前页面需要登录后方能操作，即将跳转到登录页面...',
            duration: 10
          });
          window.location.href = errorData.data;
        }

        return Promise.reject(errorData);
      }
    );
  }
  request(options) {
    const instance = axios.create();
    options = Object.assign(this.getInsideConfig(), options);
    this.interceptors(instance, options.url);
    return instance(options);
  }
}
export default HttpRequest;
