/**
 * 不在代码中直接使用 console, 而是使用 logger
 */
let c = {};
c.log = c.info = c.warn = c.debug = c.error = c.time = c.dir = c.profile = c.clear = c.exception = c.trace = c.assert = function() {};

let Logger = process.env.NODE_ENV === 'development' ? window.console || c : c;
Logger.OPTIONS = {
  ENTER: '进入页面',
  LEAVE: '离开页面',
  BEFORE_REQUEST: '发送请求',
  AFTER_RESPONSE: '接收响应'
};
export default Logger;
