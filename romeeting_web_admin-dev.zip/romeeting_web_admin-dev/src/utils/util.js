import { Poptip, Icon } from 'view-design';

import config from '@/config';
import CountryCodes from './country-codes';
import LanguageCodes from './language-codes';
import {
  deepCopy,
  forEach,
  objEqual,
  indexOfByKeyAndValue,
  getLocalStorage,
  setLocalStorage
} from '@/utils/tools';

export const hasChild = item => {
  return item.children && item.children.length !== 0;
};

/**
 * @param {Array} list 通过路由列表得到菜单列表
 * @returns {Array}
 */
export const getMenuByRouter = list => {
  let res = [];
  forEach(list, item => {
    if (!item.meta || (item.meta && !item.meta.hideInMenu)) {
      // 只隐藏自己，不隐藏子目录
      if (item.meta && item.meta.hideSelfInMenu && hasChild(item)) {
        res.push(...getMenuByRouter(item.children));
      } else {
        let obj = {
          icon: (item.meta && item.meta.icon) || '',
          name: item.name,
          meta: item.meta
        };
        if (hasChild(item) || (item.meta && item.meta.showAlways)) {
          obj.children = getMenuByRouter(item.children);
        }
        if (item.meta && item.meta.href) {
          obj.href = item.meta.href;
        }
        res.push(obj);
      }
    }
  });
  return res;
};

/**
 * @param {Array} routeMetched 当前路由metched
 * @returns {Array}
 */
export const getBreadCrumbList = routeMetched => {
  let res = routeMetched
    .filter(item => {
      // item.meta.hide 为true的路由不会出现在header 的 breadcrumb
      return item.meta === undefined || !item.meta.hide;
    })
    .filter(item => {
      // item.meta.hideInMenu 为true的路由不会出现在header 的 breadcrumb
      return !item.meta.hideInMenu;
    })
    .map(item => {
      let obj = {
        icon: (item.meta && item.meta.icon) || '',
        name: item.name,
        meta: item.meta
      };
      return obj;
    });
  return res;
};

export const showTitle = (item, vm) =>
  vm.$config.useI18n ? vm.$t(item.name) : (item.meta && item.meta.title) || item.name;

/**
 * @description 本地存储和获取标签导航列表
 */
export const setTagNavListInLocalstorage = list => {
  setLocalStorageWithPrefix('tagNavList', list);
};
/**
 * @returns {Array} 其中的每个元素只包含路由原信息中的name, path, meta三项
 */
export const getTagNavListFromLocalstorage = () => {
  return getLocalStorageWithPrefix('tagNavList') || [];
};

/**
 * @param {Array} routers 路由列表数组
 * @description 用于找到路由列表中name为home的对象
 */
export const getHomeRoute = routers => {
  let i = -1;
  let len = routers.length;
  let homeRoute = {};
  while (++i < len) {
    let item = routers[i];
    if (item.name === config.homeName) {
      homeRoute = item;
    } else {
      if (item.children && item.children.length) {
        let res = getHomeRoute(item.children);
        if (res.name) {
          return res;
        }
      }
    }
  }
  return homeRoute;
};

/**
 * @param {*} list 现有标签导航列表
 * @param {*} newRoute 新添加的路由原信息对象
 * @description 如果该newRoute已经存在则不再添加
 */
export const getNewTagList = (list, newRoute) => {
  const { name, path, meta } = newRoute;
  let newList = [...list];
  if (newList.findIndex(item => item.name === name) >= 0) {
    return newList;
  }
  newList.push({ name, path, meta });
  return newList;
};

/**
 * @description 将 router 对象转换成 paths xx/xxx/xxx
 * @param {Object} { name: 'xxx', show: true, children: [{ name: 'xxx', show: true, children: []}]}
 * @return {Array} ['device/list','device/page','group/page',...,'user/page']
 */
export const routerToPaths = router => {
  if (!router || typeof router.name !== 'string') {
    return [];
  }
  let paths = [];
  let path = router.name;
  if (Array.isArray(router.children) && router.children.length > 0) {
    forEach(router.children, item => {
      paths.push(...routerToPaths(item));
    });
  }
  if (!paths.length) {
    paths = [path];
  } else {
    paths = paths.map(item => {
      return path + '/' + item;
    });
  }
  return paths;
};

/**
 * @description 将权限列表中的元素 转换成 router 对象
 * @param {Object} item {name: '设备管理/设备组', uri: 'device_manage/device_group', buttonList: ['device_group:delete',...]}
 * @return {Object} { name: 'xxx', children: [{ name: 'xxx', children: []}]}
 */
export const accessToRouter = item => {
  if (!item || typeof item.uri !== 'string' || !item.uri) {
    return;
  }
  // 例如
  let router;

  const name = item.uri.split('/')[0];
  let subPath = item.uri.substring(name.length);
  if (subPath.indexOf('/') === 0) {
    subPath = subPath.substring(1);
  }

  if (!name && !subPath) {
    return;
  }

  if (!name && subPath) {
    return accessToRouter({ ...item, uri: subPath });
  }

  router = {
    name: name,
    show: true
  };
  const subRouter = accessToRouter({ ...item, uri: subPath });
  subRouter && (router.children = [subRouter]);
  !subRouter && (router.access = item.buttonList); // 在叶子末端加上acees

  return router;
};

/**
 * @description 将重复的路由和或路由分支合并到一起，并去掉空路由
 * @param {Array} routers
 * @returns
 */
export const combineRouters = routers => {
  if (!Array.isArray(routers)) {
    return [];
  }

  const res = [];
  forEach(routers, item => {
    if (item && item.name) {
      const index = indexOfByKeyAndValue(res, 'name', item.name); // 判断 item 在数组 res 中的位置

      if (index > -1) {
        // item已存在数组中
        const basic = res[index];
        if (Array.isArray(basic.children) && Array.isArray(item.children)) {
          basic.children.push(...item.children);
          basic.children = combineRouters(basic.children); // 合并子路由
        } else if (!Array.isArray(basic.children) && Array.isArray(item.children)) {
          basic.children = item.children;
        }
      } else {
        // 不在数组中
        res.push(item);
      }
    }
  });

  return res;
};

/**
 * @description 通过动态路由表比较服务器返回的权限列表转化而成的路由路由表得到动态路由
 * @param {Array} routerMap [{name:'device_manage', path: '/device_manage', children:[{name:'device_group', path: 'device_group', meta: {}},...]},...]
 * @param {Array} accessRouterMap [{name:'device_manage', children:[{name:'device_group', access:['add', 'delete']},...]},...]
 * @return {Array}  [{name:'device_manage', path: '/device_manage', children:[{name:'device_group', path: 'device_group', meta: {access:['add', 'delete']}},...]},...]
 */
export const filterAsyncRouters = (routerMap, accessRouterMap) => {
  if (!Array.isArray(routerMap)) {
    return [];
  }
  if (!Array.isArray(accessRouterMap)) {
    return routerMap;
  }

  const routers = [];

  forEach(routerMap, item => {
    const index = indexOfByKeyAndValue(accessRouterMap, 'name', item.name);

    // 在菜单列表中找到该组件
    const accessRouter = accessRouterMap[index];
    if (accessRouter && accessRouter.show) {
      item = deepCopy(item); // 深拷贝防止对原始routerMap进行改动
      if (item.children && item.children.length) {
        // 有子路由
        item.children = filterAsyncRouters(
          item.children,
          Array.isArray(accessRouter.children) ? accessRouter.children : []
        );

        // 若没有配置 showAlways 则默认设置 showAlways 为 true
        if (!item.meta || !item.meta.hasOwnProperty('showAlways')) {
          item.meta = {
            ...item.meta,
            showAlways: true
          };
        }
        // 重定向到它的第一个子路由里
        if (item.children.length) {
          item.redirect = { name: item.children[0].name };
        }
      }

      if (accessRouter.access && accessRouter.access.length) {
        item.meta = {
          ...item.meta,
          access: accessRouter.access
        };
      }

      routers.push(item);
    }
  });
  return routers;
};

/**
 * @description 根据动态路由表和服务器返回的权限列表返回动态路由
 * @param {Array} routerMap [{name:'device', children:[{name:'list'},{name:'page'}]}]
 * @param {Array} accessList [{name: '设备管理/设备组', uri: 'device_manage/device_group', access: ['device_group:delete',]},...]
 */
export const getAsyncRouters = (routerMap, accessList) => {
  if (!Array.isArray(accessList)) {
    return routerMap;
  }
  return setRedirectPath(
    filterAsyncRouters(routerMap, combineRouters(accessList.map(item => accessToRouter(item))))
  );
};

/**
 * @description 根据动态路由表重置 redirect 重定向的页面
 * @param {Array} routerMap [{name:'device', children:[{name:'list'},{name:'page'}]}]
 * @return {Array} [{path: '/redirect',name: 'redirect',...,redirect: { name: 'device' }},{name:'device', children:[{name:'list'},{name:'page'}]}]
 */
export const setRedirectPath = routerMap => {
  if (!Array.isArray(routerMap) || !routerMap.length) {
    return [
      {
        path: '/redirect',
        name: 'redirect',
        meta: {
          hide: true,
          hideInMenu: true
        },
        redirect: { name: 'error_404' }
      }
    ];
  }

  // 过滤重定向路由和空路由
  routerMap = routerMap.filter(item => {
    return item && item.name && item.name !== 'redirect';
  });

  // 将第一个路由作为重定向
  routerMap.unshift({
    path: '/redirect',
    name: 'redirect',
    meta: {
      hide: true,
      hideInMenu: true
    },
    redirect: { name: (routerMap[0] && routerMap[0].name) || 'error_404' }
  });
  return routerMap;
};

/**
 * @param {String} url
 * @description 从URL中解析参数
 */
export const getParams = url => {
  const keyValueArr = url.split('?')[1].split('&');
  let paramObj = {};
  keyValueArr.forEach(item => {
    const keyValue = item.split('=');
    paramObj[keyValue[0]] = keyValue[1];
  });
  return paramObj;
};

/**
 * @param {Array} list 标签列表
 * @param {String} name 当前关闭的标签的name
 */
export const getNextRoute = (list, route) => {
  let res = {};
  if (list.length === 2) {
    res = getHomeRoute(list);
  } else {
    const index = list.findIndex(item => routeEqual(item, route));
    if (index === list.length - 1) {
      res = list[list.length - 2];
    } else {
      res = list[index + 1];
    }
  }
  return res;
};

/**
 * @param {Number} times 回调函数需要执行的次数
 * @param {Function} callback 回调函数
 */
export const doCustomTimes = (times, callback) => {
  let i = -1;
  while (++i < times) {
    callback(i);
  }
};

/**
 * @param {Object} file 从上传组件得到的文件对象
 * @returns {Promise} resolve参数是解析后的二维数组
 * @description 从Csv文件中解析出表格，解析成二维数组
 */
export const getArrayFromFile = file => {
  let nameSplit = file.name.split('.');
  let format = nameSplit[nameSplit.length - 1];
  return new Promise((resolve, reject) => {
    let reader = new FileReader();
    reader.readAsText(file); // 以文本格式读取
    let arr = [];
    reader.onload = function(evt) {
      let data = evt.target.result; // 读到的数据
      let pasteData = data.trim();
      arr = pasteData
        .split(/[\n\u0085\u2028\u2029]|\r\n?/g)
        .map(row => {
          return row.split('\t');
        })
        .map(item => {
          return item[0].split(',');
        });
      if (format === 'csv') {
        resolve(arr);
      } else {
        reject(new Error('[Format Error]:你上传的不是Csv文件'));
      }
    };
  });
};

/**
 * @param {Array} array 表格数据二维数组
 * @returns {Object} { columns, tableData }
 * @description 从二维数组中获取表头和表格数据，将第一行作为表头，用于在iView的表格中展示数据
 */
export const getTableDataFromArray = array => {
  let columns = [];
  let tableData = [];
  if (array.length > 1) {
    let titles = array.shift();
    columns = titles.map(item => {
      return {
        title: item,
        key: item
      };
    });
    tableData = array.map(item => {
      let res = {};
      item.forEach((col, i) => {
        res[titles[i]] = col;
      });
      return res;
    });
  }
  return {
    columns,
    tableData
  };
};

export const findNodeUpper = (ele, tag) => {
  if (ele.parentNode) {
    if (ele.parentNode.tagName === tag.toUpperCase()) {
      return ele.parentNode;
    }
    return findNodeUpper(ele.parentNode, tag);
  }
};

export const findNodeUpperByClasses = (ele, classes) => {
  let parentNode = ele.parentNode;
  if (parentNode) {
    let classList = parentNode.classList;
    if (classList && classes.every(className => classList.contains(className))) {
      return parentNode;
    }
    return findNodeUpperByClasses(parentNode, classes);
  }
};

export const findNodeDownward = (ele, tag) => {
  const tagName = tag.toUpperCase();
  if (ele.childNodes.length) {
    let i = -1;
    let len = ele.childNodes.length;
    while (++i < len) {
      let child = ele.childNodes[i];
      if (child.tagName === tagName) {
        return child;
      }
      return findNodeDownward(child, tag);
    }
  }
};

/**
 * @description 根据name/params/query判断两个路由对象是否相等
 * @param {*} route1 路由对象
 * @param {*} route2 路由对象
 */
export const routeEqual = (route1, route2) => {
  const params1 = route1.params || {};
  const params2 = route2.params || {};
  const query1 = route1.query || {};
  const query2 = route2.query || {};
  return route1.name === route2.name && objEqual(params1, params2) && objEqual(query1, query2);
};

/**
 * 判断打开的标签列表里是否已存在这个新添加的路由对象
 */
export const routeHasExist = (tagNavList, routeItem) => {
  let len = tagNavList.length;
  let res = false;
  doCustomTimes(len, index => {
    if (routeEqual(tagNavList[index], routeItem)) {
      res = true;
    }
  });
  return res;
};

/**
 * @param {Array} array 表格数据
 * @param {Number} size 页大小
 * @param {Number} pageNum 当前页码
 * @returns {Array} 当前页面数据
 * @description 从所有的表格数据获取当前页面的数据
 */
export const getCurrentTableData = (list, size, pageNum) => {
  if (!list || !Array.isArray(list)) {
    return [];
  }
  if (typeof size !== 'number' || size >= list.length) {
    return list;
  }
  if (typeof pageNum !== 'number' || pageNum < 1) {
    // 默认返回第一页
    return list.slice(0, size);
  }
  pageNum = Math.floor(pageNum);
  size = Math.floor(size);
  return list.slice(size * (pageNum - 1), size * pageNum);
};

/**
 * 根据区域code获取区域数据
 * @param {String} code 区域code
 * @returns {Object} 区域数据
 * @description 根据区域code获取区域数据
 */

export const getCountryByCode = code => {
  let arr = CountryCodes;
  for (let i = 0; i < arr.length; i++) {
    if (code === arr[i].code) {
      return arr[i];
    }
  }
  return null;
};

/**
 * 根据语言code获取语言数据
 * @param {String} code 语言code
 * @returns {Object} 语言数据
 * @description 根据语言code获取语言数据
 */
export const getLanguageByCode = code => {
  let arr = LanguageCodes;
  for (let i = 0; i < arr.length; i++) {
    if (code === arr[i].code) {
      return arr[i];
    }
  }
  return null;
};

/**
 * @description 根据权限获取应该渲染的操作按钮数组
 * @param {*} h h 函数
 * @param {*} buttons 按钮数组 {access:'device:add', ele: h('Button')}
 * @param {*} access 页面权限数据 ['device:add','device:view']
 * @returns
 */
export const getOptsButtons = (h, buttons, access) => {
  const btns = [];
  const otherBtns = [];
  buttons.forEach(item => {
    (!item.access || access.includes(item.access)) && btns.push(item.ele);
  });
  if (btns.length > 2) {
    const res = [];
    btns.forEach((item, index) => {
      if (index > 0) {
        otherBtns.push(item);
        index < btns.length - 1 && otherBtns.push(h('br'));
      }
    });
    const poptip = h(Poptip, { props: { trigger: 'hover', transfer: true, placement: 'bottom' } }, [
      h('div', { class: 'link-btn' }, ['更多', h(Icon, { props: { type: 'ios-arrow-down' } })]),
      h('div', { attrs: { 'text-center': true }, slot: 'content' }, otherBtns)
    ]);

    res.push(btns[0]);
    res.push(poptip);
    return res;
  } else if (btns.length > 0) {
    return btns;
  }

  return [];
};

/**
 * @description 根据当前语言显示在浏览器标签的 title
 * @param {String} title i18n 对象
 */
export const setAppTitle = title => {
  window.document.title = title;
};

/**
 * 保存到本地 localStorage，会带上应用独特的标识
 * @param {String} key 键
 * @param {any} value 值
 * @returns {Boolean} 是否成功
 * @description 保存到本地 localStorage
 */
export const setLocalStorageWithPrefix = (key, value) => {
  return setLocalStorage(process.env.VUE_APP_PREFIX + '_' + key, value);
};

/**
 * 从 localStorage 中取出保存的值，会带上应用独特的标识
 * @param {String} key 键
 * @returns {any} value 值
 * @description 从 localStorage 中取出保存的值
 */
export const getLocalStorageWithPrefix = key => {
  return getLocalStorage(process.env.VUE_APP_PREFIX + '_' + key);
};
