const path = require('path');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
const CompressionWebpackPlugin = require('compression-webpack-plugin');

const resolve = dir => {
  return path.join(__dirname, dir);
};

// 项目部署基础
// 默认情况下，我们假设你的应用将被部署在域的根目录下,
// 例如：https://www.my-app.com/
// 默认：'/'
// 如果您的应用程序部署在子路径中，则需要在这指定子路径
// 例如：https://www.foobar.com/my-app/
// 需要将它改为'/my-app/'

// 设置应用名称，在config里面配置
// process.env.VUE_APP_TITLE = '柔派助手后台管理系统';

module.exports = {
  // tweak internal webpack configuration.
  // see https://cli.vuejs.org/zh/guide/mode-and-env.html
  baseUrl: process.env.VUE_APP_BASE_URL,
  filenameHashing: false,
  // 多入口配置
  // pages: {
  //   app: {
  //     // page 的入口
  //     entry: 'src/main.js',
  //     // 模板来源
  //     template: 'public/index.html',
  //     // 在 dist/index.html 的输出
  //     filename: 'index.html',
  //     // 当使用 title 选项时，
  //     // template 中的 title 标签需要是 <title><%= htmlWebpackPlugin.options.title %></title>
  //     title: 'Royole Data Platform',
  //     // 在这个页面中包含的块，默认情况下会包含
  //     // 提取出来的通用 chunk 和 vendor chunk。
  //     chunks: ['chunk-vendors', 'chunk-common', 'app']
  //   }
  // },
  // babel 转义 node_module 中的模块
  // transpileDependencies: ['view-design', 'vue-i18n'],
  // webpack插件配置
  chainWebpack: config => {
    config.resolve.alias
      .set('@', resolve('src')) // key,value自行定义，比如.set('@@', resolve('src/components'))
      .set('_c', resolve('src/components'))
      .set('_conf', resolve('config'));

    // 自动化导入文件 (用于颜色、变量、mixin……)
    const types = ['vue-modules', 'vue', 'normal-modules', 'normal'];
    types.forEach(type => addStyleResource(config.module.rule('less').oneOf(type)));

    config.resolve.symlinks(true);
    // 移除prefetch插件，避免加载多余的资源
    config.plugins.delete('prefetch');
    // 移除 preload 插件，避免加载多余的资源
    config.plugins.delete('preload');

    return config;
  },
  configureWebpack: config => {
    // 打包优化相关
    let optimization = {
      runtimeChunk: {
        name: 'manifest'
      },
      minimizer: [
        new UglifyJsPlugin({
          exclude: /\.min\.js$/, // 过滤掉以".min.js"结尾的文件，我们认为这个后缀本身就是已经压缩好的代码，没必要进行二次压缩
          cache: true,
          parallel: true, // 开启并行压缩，充分利用cpu
          sourceMap: false,
          extractComments: false, // 移除注释
          uglifyOptions: {
            compress: {
              unused: true,
              warnings: false,
              drop_debugger: true
            },
            output: {
              comments: false
            }
          }
        }),
        new CompressionWebpackPlugin({
          filename: '[path].gz[query]',
          algorithm: 'gzip',
          test: new RegExp('\\.(' + ['js', 'css'].join('|') + ')$'),
          threshold: 10240,
          minRatio: 0.8
        })
      ],
      splitChunks: {
        // 参考文档 https://webpack.js.org/plugins/split-chunks-plugin/
        chunks: 'async',
        minSize: 30000, // Minimum size, in bytes, for a chunk to be generated.
        minChunks: 1, // Minimum number of chunks that must share a module before splitting.
        maxAsyncRequests: 5, // Maximum number of parallel requests when on-demand loading.
        maxInitialRequests: 3, // Maximum number of parallel requests at an entry point.
        name: true,
        cacheGroups: {
          vendor: {
            test: /[\\/]node_modules[\\/]/, // Controls which modules are selected by this cache group.
            name: 'vendor',
            minChunks: 2, // 最少有两个文件共用的代码
            priority: -10,
            chunks: 'all',
            reuseExistingChunk: true
          },
          vue: {
            test: /[\\/]node_modules[\\/](vue|vuex|vue-router|vue-i18n|axios)[\\/]/,
            name: 'vue',
            chunks: 'all'
          },
          charts: {
            test: /[\\/]node_modules[\\/](echarts|highcharts)[\\/]/,
            name: 'charts',
            chunks: 'all'
          },
          iview: {
            test: /[\\/]node_modules[\\/](iview)[\\/]/,
            name: 'view-design',
            chunks: 'all'
          }
        }
      }
    };

    // 插件配置
    let plugins = [];

    // 只有打发布包的时候才使用
    if (process.env.NODE_ENV === 'production') {
      config.optimization = { ...config.optimization, ...optimization };
      config.plugins = [...config.plugins, ...plugins];
    }
  },

  // css 配置
  css: {
    loaderOptions: {
      // 给 less-loader 传递选项
      less: {
        // @/ 是 src/ 的别名
        data: `@import "@/assets/styles/mixins.less";`
      }
    },
    sourceMap: process.env.NODE_ENV !== 'production', // 开启 CSS source maps?
    extract: process.env.NODE_ENV === 'production' // 是否使用css分离插件 ExtractTextPlugin,需要热更新此处设置成false
  },

  // 打包时不生成.map文件
  productionSourceMap: false,

  // webpack-dev-server 相关配置
  devServer: {
    hot: true, // 开启热点
    https: true,
    inline: true, // 开启页面自动刷新
    compress: true, // 一切服务都启用gzip压缩
    progress: true, // 显示打包的进度
    useLocalIp: true, // 允许浏览器使用本地 IP 打开
    disableHostCheck: true, // 允许使用host配置访问
    // host: 'localhost',
    port: 8888,
    overlay: {
      // 让 lint 错误在开发时直接显示在浏览器中
      warnings: true,
      errors: true
    },
    // watchOptions: {
    //   poll: true
    // }
    // http://10.0.34.93:12001   本地服务器
    // http://10.0.100.83:12001  线上服务器
    proxy: {
      // ajax 请求转发
      // ['^' + process.env.VUE_APP_BASE_API]: {
      //   target: 'http://10.0.100.84',
      //   changeOrigin: true,
      //   pathRewrite: {
      //     ['^' + process.env.VUE_APP_BASE_API]: ''
      //   }
      // }
      '^/iot': {
        changeOrigin: true,
        // target: 'http://10.0.100.82:6688'
        target: 'https://10.0.100.84'
      },
      '^/mqtt': {
        target: 'http://10.0.100.84:9001',
        ws: true, // 支持websokcet
        changeOrigin: true,
        pathRewrite: {
          '^/mqtt': ''
        }
      }
      // sso 图片资源请求转发
      // '/resources/(.+\\/)*.+\\.(jpg|jpeg|png|gif)$': {
      //   target: 'http://10.0.100.83:8181', // 匹配 /resources/ 下及其子孙路径下的图片资源。 访问 http://localhost:8080/resources/xx/xx.png 会转发到  http://10.0.100.83:8181/resources/xx/xx.png
      //   changeOrigin: true
      // }
    }

    // public: '10.0.34.94:8080' // 本机ip
  },

  // enabled by default if the machine has more than 1 cores
  parallel: require('os').cpus().length > 1,

  // PWA 插件相关配置
  pwa: {},

  // 第三方插件配置
  pluginOptions: {
    // ...
  }
};
function addStyleResource(rule) {
  rule
    .use('style-resource')
    .loader('style-resources-loader')
    .options({
      // 在此处配置需要作为全局引用的less
      patterns: [path.resolve(__dirname, 'src/assets/styles/mixins.less')]
    });
}
