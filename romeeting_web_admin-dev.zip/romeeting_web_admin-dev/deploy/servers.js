/*
* 定义多个服务器账号 及 根据 SERVER_ID 导出当前环境服务器账号
*/

module.exports = [
  {
    id: 'development', // development, production, test
    name: '开发环境',
    domain: 'admin-dev.royole.com', // 域名
    host: '10.0.100.82', // ip
    port: 22, // 端口
    username: 'jianlin', // 登录服务器的账号
    password: 'Royole#1901', // 登录服务器的账号
    path: '/home/jianlin/sso_admin_web/', // 服务器上传位置
    nginxPath: '/usr/share/nginx/html/sso_admin_web/' // 发布至静态服务器的项目路径
  }
];
