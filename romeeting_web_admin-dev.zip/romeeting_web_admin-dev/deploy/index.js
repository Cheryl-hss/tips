/* eslint-disable no-console */
//  deploy/index.js里面
const scpClient = require('scp2');
const chalk = require('chalk');
const server = require('./products');
const Client = require('ssh2').Client;

const sshConfig = {
  host: server.host,
  port: server.port,
  username: server.username,
  password: server.password,
  path: server.path
  // privateKey: require('fs').readFileSync('/home/admin/.ssh/id_dsa')
};

const conn = new Client();
conn
  .on('ready', function() {
    console.log('\n\n');
    console.log(chalk.yellow(`正在部署到服务器${server.host}...\n\n`));
    // 1. 删除原来服务上的文件
    console.log(`>> 1. 删除服务器上的项目文件夹 ${chalk.blue(server.path)}\n\n`);

    conn.exec('rm -rf ' + server.path, function(err, stream) {
      if (err) {
        console.log(chalk.red(`  删除 ${server.path} 出错了，ERROR:`, err));
        throw err;
      }
      console.log(chalk.green(`  删除成功\n\n`));

      stream
        .on('close', function(code, signal) {
          // 在执行shell命令后，把开始上传部署项目代码放到这里面
          console.log(`>> 2. 上传 dist/ 到服务器文件夹 ${chalk.blue(server.path)}\n\n`);
          scpClient.scp('./dist/', sshConfig, function(err) {
            // conn.end(); // 关闭连接
            if (err) {
              console.log(chalk.red(`  上传失败，ERROR:`, err));
              throw err;
            } else {
              console.log(chalk.green(`  上传成功\n\n`));

              // 2. 使用sudo权限将用户目录下的文件覆盖到nginx的html下
              console.log(
                `>> 3. 使用 sudo 权限复制 ${chalk.blue(server.path)} 到 ${chalk.blue(
                  server.nginxPath
                )}`,
                '\n\n'
              );
              conn.exec(
                `sudo cp -rf ${server.path}* ${server.nginxPath} && exit`,
                { pty: true },
                function(err, stream) {
                  if (err) {
                    console.log(chalk.red(`  复制出错，ERROR:`, err));
                    throw err;
                  }
                  let b = '';
                  let pwsent = false;

                  stream
                    .on('data', function(data) {
                      if (!pwsent) {
                        b += data.toString();
                        console.log(data.toString(), '******\n');
                        if (b.substr(-2) === ': ') {
                          pwsent = true;
                          stream.write(`${server.password}\n`); // 使用密码获取sudo权限
                          b = '';
                        }
                        console.log(chalk.green(`\n恭喜你，本次部署圆满成功😃😃`));
                      } else {
                        console.log(data.toString());
                      }
                    })
                    .on('close', function(code, signal) {
                      conn.end(); // 关闭连接
                    })
                    .stderr.on('data', function(data) {
                      console.log('STDERR: ' + data);
                    });
                }
              );
            }
          });
        })
        .on('data', function(data) {
          console.log('STDOUT: ' + data);
        })
        .stderr.on('data', function(data) {
          console.log('STDERR: ' + data);
        });
    });
  })
  .connect(sshConfig);

// const conn2 = new Client();
// conn2
//   .on('ready', function(params) {
//     // 2. 使用sudo权限将用户目录下的文件覆盖到nginx的html下
//     console.log(
//       chalk.blue(`2. 使用 sudo 权限复制 ${server.path} 到 ${server.nginxPath}`),
//       '\n\n\n'
//     );
//     conn2.exec(`sudo cp -rf ${server.path}* ${server.nginxPath}`, { pty: true }, function(
//       err,
//       stream
//     ) {
//       spinner.stop();

//       if (err) {
//         console.log(chalk.red(`复制出错，ERROR:`, err));
//         throw err;
//       }
//       let b = '';
//       let pwsent = false;
//       stream
//         .on('close', function(code, signal) {
//           conn2.end();
//         })
//         .on('data', function(data) {
//           if (!pwsent) {
//             b += data.toString();
//             if (b.substr(-2) === ': ') {
//               pwsent = true;
//               stream.write(`${server.password}\n`);
//               b = '';
//             }
//           } else {
//             console.log(data.toString());
//           }
//         })
//         .stderr.on('data', function(data) {
//           console.log('STDERR: ' + data);
//         });
//       console.log(chalk.green(`恭喜你，本次部署圆满成功😃😃`));
//     });
//   })
//   .connect(sshConfig);
