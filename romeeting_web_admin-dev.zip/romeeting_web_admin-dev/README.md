
# 铭牌私有云
[![](https://img.shields.io/travis/iview/iview-admin.svg?style=flat-square)](https://travis-ci.org/iview/iview-admin)
[![vue](https://img.shields.io/badge/vue-2.6.10-brightgreen.svg?style=flat-square)](https://github.com/vuejs/vue)
[![iview ui](https://img.shields.io/badge/iview-4.4.0-brightgreen.svg?style=flat-square)](https://github.com/iview/iview)

[iView admin 使用文档](https://lison16.github.io/iview-admin-doc/#/)

[iViewComponents 使用文档](http://10.0.100.82:8004/#/)

## Clone source file

> 从 gitlab 地址上把项目克隆下来

```bush
git clone http://172.16.100.140/SAP/WEB/romeeting_web_admin.git
```

## Install

> 进入项目根目录后，安装依赖

```bush
cd romeeting_web_admin

yarn install
```
## Lint

> 代码提交前，必须执行这个命令，保证没有错误了，才能提交

```bush
yarn run lint
```

## Run

### Development

> 启动本地服务

```bush
yarn run dev
```

### Production(Build)

> 生成发布包（静态文件）

```bush
yarn run build
```

## Deploy

> 开发环境自动化部署，相应的服务器配置在`./deploy/products.js`文件里。测试环境和生产环境的部署使用[Jenkins](http://al2szjks.royole.com:8030/)操作

```bush
yarn run deploy
```


## 文件结构
```shell
.
├── build  项目构建配置，vue-cli3 创建的项目没有此项
├── public  根index.html
├── deploy  自动化部署配置
├── .vue.config.js vue-cli3 创建的项目的webpack配置文件
├── .env.development Vue开发环境变量配置文件
├── .env.test Vue测试环境变量配置文件
├── .env.production Vue生产环境变量配置文件
│
├─src
│  ├─api AJAX请求
│  ├─assets 项目静态资源
│  │  ├─icons 自定义图标资源
│  │  ├─images 图片资源
│  │  └─styles 公用样式
│  ├─components 业务组件
│  ├─config 项目运行配置
│  ├─directive 自定义指令
│  ├─utils封装工具函数
│  ├─locale 多语言文件
│  ├─mock mock模拟数据
│  ├─router 路由配置
│  ├─store Vuex配置
│  └─views 页面文件
└─tests 测试相关


```

## VUE_APP_ 环境变量配置

对应的环境配置位于根目录下的 `.env.development`, `.env.production`, `.env.test` 下。默认为 development 模式，如要使用不同模式，可以在scripts中添加 `--mode <nev_name>`，如 `--mode production` 来使用对应的配置文件。

#### 设置变量

设置变量的格式为 `VUE_APP_{variable_name}`，如 `VUE_APP_TITLE = 用户管理系统`

#### 读取变量

获取变量值的方式为 `process.env.VUE_APP_{variable_name}`

## Links

- [TalkingData](https://github.com/TalkingData)
- [iView](https://github.com/iview/iview)
- [Vue](https://github.com/vuejs/vue)
- [Webpack](https://github.com/webpack/webpack)
- [Less](http://lesscss.cn/features/#mixins-as-functions-feature)
